<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*" %>

<%! ResourceBundle labels,messages;
    LanguageUtilities lang;%>
<%
if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");

  Properties props = new Properties();
  FileInputStream fis = new FileInputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
  props.load(fis);
%>
 <html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES&linked=true" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("createPlace")%> : </b></font></td></tr>
</table>

<table width=90%>
   <form method="post">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("placeName")%> : </b><input type="text" size="30" maxlength="30" name="name"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("placeDescription")%> : </b><input type="text" size="50" maxlength="50" name="description"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("placeType")%> : </b>
      <select name="type">
      <%
        String key;
        String value;
        for(Enumeration e=props.keys();e.hasMoreElements();){
          key=(String)e.nextElement();
          value=(String)props.get(key);

          %>
          <option value="<%=value%>"> <%=value.substring(0,value.lastIndexOf("_"))%>
          <%
        }
      %>
      </select>
      <a href="newPlace.jsp"><FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%></FONT></a>

    </td>
   </tr>
   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
      <br> <hr>
    </td>
   </tr>
  </form>
  <tr>
   <td><H3>-<%=messages.getString("previewPlace")%>:</h3></td>
  </tr>
  <tr>
    <td>
     <%
        for(Enumeration e=props.keys();e.hasMoreElements();){
          key=(String)e.nextElement();
          value=(String)props.get(key);
          %>
           <a href="resources/things/places/<%=props.get(key)%>/main.wrl" target="_blank"><b>[<%=value.substring(0,value.lastIndexOf("_"))%>]</b></a>&nbsp;&nbsp;
          <%
        }
      %>
   </td>
  </tr>
 </table>
 </center>
      <br><br>


  <jsp:include page="footer.jsp" flush="true"/>
 </HTML>
<%
}else{
 try{
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  String worldId=(String)session.getAttribute("worldId");
  int num=pm.getPlaces(worldId).size();
  if(num!=0){
    Place p;
    for(Iterator i=pm.getPlaces(worldId).iterator();i.hasNext();){
      p=(Place)i.next();
      if(p.getProperty("lastCreated").equalsIgnoreCase("true")){
        num=Integer.parseInt(p.getId().substring(p.getId().lastIndexOf("P")+1));
        num++;
        p.setProperty("lastCreated","false");
      }
    }
  }

  String placeId=worldId+"_P"+num;
  Place place=pm.createPlace(placeId,request.getParameter("name"),
                            request.getParameter("type"),worldId);
  place.setDescription(request.getParameter("description"));
  place.setProperty("date",(new Date()).toGMTString());
  place.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  place.setProperty("lastCreated","true");
  Tool tool=null;
  for (Iterator i=tm.getTools().iterator();i.hasNext();){
    tool=(Tool)i.next();
    place.setProperty(tool.getId(),"inactive");
  }
  response.sendRedirect("createWrl.jsp?placeId="+placeId+"&placeType="+request.getParameter("type"));
 }catch(Exception e){
  Syslog.error(this,"Unable to create Place :"+ e);
 }
}
%>
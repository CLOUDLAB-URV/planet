c:\jdk1.3\bin\rmiregistry 1152



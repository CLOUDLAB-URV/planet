package ants.comm.examples;

import java.applet.*;
import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;


public class JmsProducerApplet extends Applet
{
	
	public void init()
	{
		try
		{
			Hashtable env = new Hashtable ();
			env.put(Context.INITIAL_CONTEXT_FACTORY,"com.swiftmq.jndi.InitialContextFactoryImpl");
			env.put(Context.PROVIDER_URL,"smqp://pgarcia.etse.urv.localhost:4001/timeout=30000");
			env.put(Context.CONNECTION_FACTORY,"TopicConnectionFactory");
			env.put(Context.TOPIC,"testtopic");
			env.put(Context.PROVIDER_CLASS,"ants.comm.jms.Session");
			
			ants.comm.Session chatZone = SessionFactory.createSession(env);
			Hashtable evt = new Hashtable();
			evt.put("arg1","value1");	
			chatZone.send(evt);
			chatZone.close();
		
		}catch (SessionException s1)
		{
			System.out.println(s1.getException().getMessage());
		}

		
	}
	
	
	
}
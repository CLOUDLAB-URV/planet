
package ants.core;

import java.util.*;

public class User extends ThingUtil
{

/*	public static Properties getProps(String baseURL,String userName)
		throws java.io.IOException
	{
		return getProperties(baseURL,"users/"+userName);

	}
*/
}
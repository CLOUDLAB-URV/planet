<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");
%>
  <html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("createVideoStream")%> : </b></font></td></tr>
</table>
<table width=90%>
   <tr>
    <td colspan="3">
    <b><%=messages.getString("createVideoStream")%></b>
    </td>
   </tr>
   <form method="post">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("videoStreamName")%> : </b><input type="text" size="50" maxlength="50" name="name"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("videoStreamDescription")%> : </b><input type="text" size="50" maxlength="200" name="desc"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("videoStreamSource")%> : </b><input type="text" size="50" maxlength="400" name="url"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
    </td>
   </tr>
   </form>
  </table>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>
 </HTML>
<%
}else{
 try{
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  Thing thing=thm.createThing(""+System.currentTimeMillis(),request.getParameter("name"),
                            (String)session.getAttribute("placeId"),"videoStream.v01");
  thing.setDescription(request.getParameter("desc"));
  thing.setProperty("url",request.getParameter("url"));
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  response.sendRedirect("listThings.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}
%>


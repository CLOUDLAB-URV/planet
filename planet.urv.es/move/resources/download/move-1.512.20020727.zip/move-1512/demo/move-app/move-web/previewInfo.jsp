<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
String thingId = request.getParameter("thingId");
String worldKey=(String)session.getAttribute("worldId");
String placeKey=(String)session.getAttribute("placeId");
Thing thing=null;

LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

try{
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  thing=thm.getThing(thingId);

} catch (Exception e) {
    Syslog.log (this, e);
}


%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("previewInfo")%> : </b></font></td></tr>
</table>
<table width=90%>
 <tr>
  <td colspan="3">
  <table bgcolor="teal" align="center" width="80%">
   <td align="center">
      <img  height="200" src="<%=request.getContextPath()%>/worlds/<%=worldKey%>/<%=placeKey%>/<%=thing.getProperty("fileName")%>">
   </td>
   </table>
  </td>
 </tr>
</form>
</table>

</center>
<jsp:include page="footer.jsp" flush="true"/>
</BODY>
</HTML>


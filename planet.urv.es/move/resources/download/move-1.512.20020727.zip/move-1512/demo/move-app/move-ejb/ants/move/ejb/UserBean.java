package ants.move.ejb;

import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;
import com.protomatter.syslog.*;
import java.util.*;


/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Entity Bean for a User
 *  It is a BMP (Bean Managed Persistence) EJB (Enterprise JavaBean)
 */
public class UserBean implements EntityBean {
  // Primary key
  private String          login="";
  private String          password="";
  private String          role="";
  protected EntityContext context;
  /**
   * This method gets a connection to the database
   */
  private Connection getConnection() throws SQLException {
    try {
      InitialContext jndiContext = new InitialContext();

      DataSource source = (DataSource) jndiContext.lookup (
                          "jdbc/DefaultPooledDS");
      return source.getConnection();
    } catch (Exception ex) {
      Syslog.fatal (this, "Exception getting database connection!");
      Syslog.fatal (this, ex);
      return null;
    }
  }

  /**
   * This method inserts a new register into the database
   */
  public String ejbCreate (String login) {
    this.login = login;
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("INSERT INTO user (login) VALUES ('"
                             + login + "')");
      return login;
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbPostCreate (String login) { }

  /**
   * This method removes a previously existent register from the database
   */
  public void ejbRemove () {
    String primaryKey = (String) context.getPrimaryKey();
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("DELETE FROM user WHERE login = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM userproperty WHERE subid = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM userindexproperty WHERE subid = '" +
                             primaryKey+"'");

    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the beginning of a transaction
   */
  public void ejbLoad() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                              "SELECT * FROM user WHERE login = '" +
                              primaryKey+"'");

      if (results.next()) {
        // Get the login information from the user table
        login = new String (results.getString ("LOGIN"));
        // Get the password information from the user table
        password = new String (results.getString ("PASSWORD"));
        // Get the role information from the user table
        role = new String (results.getString ("ROLE"));

      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the end of the transaction, just before
   * the container sends all the changes to the database
   */
  public void ejbStore() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      PreparedStatement sqlPrep = conn.prepareStatement (
                                  "UPDATE user SET " +
                                  "password = ?, role = ?" +
                                  "WHERE login = ?");
      sqlPrep.setString (1, password);
      sqlPrep.setString (2, role);
      sqlPrep.setString (3, login);
      sqlPrep.executeUpdate();
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method finds by primary key
   */
  public String ejbFindByPrimaryKey (String primaryKey)
                 throws ObjectNotFoundException {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT * FROM user WHERE login = '" +
                            primaryKey+"'");
      if (results.next()) {
        return primaryKey;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method returns all primary keys
   */
  public Collection ejbFindByAll() throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT login FROM user");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("login"));
       while (results.next()){
              keys.add(results.getString("login"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }


  }

  public void ejbActivate() {}
  public void ejbPassivate() {}



  public void setEntityContext (EntityContext cntx) {
    context = cntx;
  }

  public void unsetEntityContext() {
    context = null;
  }

  public String getLogin() {
    return login;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword (String password) {
    this.password = password;
  }

  public String getRole() {
    return role;
  }

  public void setRole (String role) {
    this.role = role;
  }


  public String getProperty (String property) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM userproperty " +
                            "WHERE subId ='"+login+"' and name='"+property+"'");
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setProperty (String property, String value)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE userproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+login+"' and name='"+property+"'");
      if(results==0){
         //Property no exists --> add property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO userproperty VALUES " +
                            "('"+login+"','"+property+"','"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public String getIndexedProperty (String property, int index) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM userindexproperty " +
                            "WHERE subId ='"+login+"' and name='"+property+"' and index="+index);
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Indexed property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setIndexedProperty (String property, String value, int index)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE userindexproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+login+"' and name='"+property+"' and index="+index);
      if(results==0){
         //indexed Property not exists --> add indexed property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO userindexproperty VALUES " +
                            "('"+login+"','"+property+"',"+index+",'"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

}
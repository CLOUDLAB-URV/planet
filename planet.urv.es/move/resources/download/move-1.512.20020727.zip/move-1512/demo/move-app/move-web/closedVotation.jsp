<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
Thing thing =((ThingManager)session.getAttribute("thingManager")).getThing(request.getParameter("thingId"));
if(request.getParameter("vote").equalsIgnoreCase("yes")){
  String syes = thing.getProperty ("yes");
  int yes;
  if (syes.equalsIgnoreCase ("----")) {
     yes = 0;
  }
  else {
   yes = Integer.parseInt (syes);
  }
  yes++;
  thing.setProperty("yes",""+yes);
}else if (request.getParameter("vote").equalsIgnoreCase("no")){
  String sno = thing.getProperty ("no");
  int no;
  if (sno.equalsIgnoreCase ("----")) {
     no = 0;
  }
  else {
   no = Integer.parseInt (sno);
  }
  no++;
  thing.setProperty("no",""+no);
}else if(request.getParameter("vote").equalsIgnoreCase("unknown")){
  String sunknown = thing.getProperty ("unknown");
  int unknown;
  if (sunknown.equalsIgnoreCase ("----")) {
     unknown = 0;
  }
  else {
   unknown = Integer.parseInt (sunknown);
  }
  unknown++;
  thing.setProperty("unknown",""+unknown);
}
response.sendRedirect("previewVotation.jsp?thingId="+request.getParameter("thingId"));
%>

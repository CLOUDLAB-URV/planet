// Package ants.move.core.dynamicObjects
// VRMLEventListener.java
// eventPerformed() method interface
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views;

/** eventPerformed() method interface. <BR>
    This interface provides control of VRML Events in VRML objects.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface VRMLEventListener{
  /** Executed when a VRML Event is received.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  void eventPerformed();
}

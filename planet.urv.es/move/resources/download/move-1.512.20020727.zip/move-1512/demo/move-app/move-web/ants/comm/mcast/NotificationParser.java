package ants.comm.jms;

import ants.comm.*;
import ants.util.*;
import javax.jms.*;

public class NotificationParser implements MessageListener
{
	RemoteEventListener subs;
	
	public NotificationParser (RemoteEventListener subs)
	{
		this.subs = subs;	
	}
	 public void onMessage(Message msg)
  {
		try
		{
				subs.eventArrived(JmsParser.getEvt(msg));
		}catch (JMSException ex){Debug.error(ex);}
  }	
}
// Package ants.move.core.models.video
// VideoModel.java
// Implementation of Video Model
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.video;

// Notification Service imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Video Model.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2002
*/
public class VideoModel extends Thing implements PropertyChangeListener {
  // Playing video?
  private boolean playing = false;
  // Video loaded?
  private boolean videoLoaded = false;
  private Vector listeners = new Vector();

  /** Sole & void constructor.
  */
  public VideoModel() {
  }
/**
 * Initialize model
 */
  public void init() {
    addPropertyChangeListener(this);
    System.err.println("[MOVE] - Video model initialized.");
  }
/**
 * Adds new listener
 * @param vList Class that implements VideoListener interface
 */
  public void addVideoListener (VideoListener vList) {
    listeners.addElement(vList);
  }
/**
 * removes listeners
 * @param vList Class that implements VideoListener interface
 */
  public void removeVideoListener (VideoListener vList) {
    listeners.removeElement(vList);
  }

  /**
   * Remotely load video file in Video tool.
   * @param thingKey Key of the Thing
   */
  public void loadVideo (String thingKey) {
    try {
      setProperty ("videoThing", thingKey);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
/**
 * Set video play or stop
 * @param p True indicate play and false indicate stop
 */
  public void controlVideo (boolean p) {
    try {
      if (p) {
        setProperty ("playing", "true");
      }
      else {
        if (getProperty("playing").equals("true")){
          setProperty ("playing", "false");
        }
      }
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * get videothing key
 * @return key of the thing that is now loaded in video Tool
 */
  public String getVideoThing() {
    try {
      return getProperty("videoThing");
    } catch (Exception x) {
      System.err.println("Exception capturing property \"videoThing\" from ThingTool");
      return null;
    }
  }

  /**
   * Return if video tool is playing a video
   * @return true or false
   */
  public String isPlaying() {
    try {
      return getProperty("playing");
    } catch (Exception x) {
      System.err.println("Exception capturing property \"playing\" from ThingTool");
      return null;
    }
  }


  public void propertyChange (PropertyChangeEvent evt) {
    Vector listeners = (Vector) this.listeners.clone ();
    String propName = evt.getPropName();
    // Play video
/*    if (propName.equals("videoThing")) {
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoListener) listeners.elementAt (i)).loadVideo();
      }
    }
    else*/
    if (propName.equals("playing")) {
      // Video must start to be played
      if (evt.getPropValue().equals("true")) {
        for (int i = 0; i < listeners.size (); ++ i) {
          try {
            ((VideoListener) listeners.elementAt (i)).playVideo(getProperty("videoThing"));
          } catch (Exception x) {
            x.printStackTrace();
          }
        }
      }
      // Video must be stopped
      else {
        for (int i = 0; i < listeners.size (); ++ i) {
          ((VideoListener) listeners.elementAt (i)).stopVideo();
        }
      }
    }
  }

/*  public String getVideoFileName() {
    return getProperty("videoThing");
  }
*/
/*  public void eventArrived (Hashtable evt) {
    // Play Video
    if (((String)evt.get("METHOD")).equals("PLAYVIDEO")) {
      videoURL = (String) evt.get("URL");
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoListener) listeners.elementAt (i)).playVideo((String) evt.get("URL"));
      }
    }
    // Load Video
    else if (((String)evt.get("METHOD")).equals("LOADVIDEO")) {
      videoURL = (String) evt.get("URL");
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoListener) listeners.elementAt (i)).loadVideo();
      }
    }
    // Stop Video
    else if (((String)evt.get("METHOD")).equals("STOPVIDEO")) {
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoListener) listeners.elementAt (i)).stopVideo();
      }

    }
  }
*/
/**
 * Tool Type
 * @return VIDEO
 */
  public String getType() {
    return "VIDEO";
  }
/**
 * Destroy method
 */
  public void destroy () {
//    removePropertyChangeListener(this);
    super.destroy();
  }

}

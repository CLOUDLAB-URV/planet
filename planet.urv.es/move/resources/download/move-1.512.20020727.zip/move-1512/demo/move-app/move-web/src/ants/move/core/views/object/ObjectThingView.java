package ants.move.core.views.object;

/**
* Package ants.move.core.views.object
* ObjectView.java
* Implementation of Object Thing View
* (C) 2002 Oriol Montal� Collaborators: CarlesPairot, Francesc Pi�as
*/

// ANTS imports
import ants.move.core.teacher.object.*;
import ants.move.core.views.*;
import ants.move.core.models.*;
import ants.move.core.models.object.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;


public class ObjectThingView implements VRMLEventListener {
  private ObjectThing oT;
  private DynamicObject root;
  private Browser browser;
  private Node[] vrmlNode;
  private Node[] catchNode;
  private EventOutSFBool TS;
  private VRMLZone zone;
  private String thingId;
  private ObjectControl oc;
  private EventInSFVec3f itemTranslation;
  private EventInSFRotation itemRotation;



  public ObjectThingView(Hashtable ht) {
   try{
    browser=(Browser)ht.get("browser");
    root=(DynamicObject)ht.get("root");
    oT=(ObjectThing)ht.get("objectThing");
    root.setChNodes();
    thingId = oT.getThingId();

    show();
   }catch(Exception e){}
  }

  public void show (){
   try{
    if(vrmlNode!=null){
      root.setreChValue(vrmlNode);
    }
    String sObject=" DEF "+thingId+" Transform\n" +
                "{\n" +
		"translation "+oT.getProperty("translation")+"\n" +
                "rotation "+oT.getProperty("rotation")+"\n" +
		"scale "+oT.getProperty("scale")+"\n" +
  		"children [\n" +
                "       DEF TS1 TouchSensor{}\n" +
  		"       Inline{ url \"./"+oT.getProperty("fileName")+"/main.wrl"+"\"}\n" +

  		"]\n" +
	    	"}\n" +
                "DEF TS2 Script{\n" +
                "  eventIn SFBool active\n" +
                "  eventOut SFBool eOut\n" +
                "  url \"javascript: \n" +
                " function active(value)\n" +
                " { if (eOut == TRUE) eOut=FALSE;\n" +
                "     else eOut=TRUE;}\"" +
                "}\n" +
                "ROUTE TS1.isActive TO TS2.active\n" +
                "\n";


    vrmlNode = browser.createVrmlFromString(sObject);
    root.setaddChValue(vrmlNode);

    TS = (EventOutSFBool)vrmlNode[1].getEventOut("eOut");
    zone= new VRMLZone();
    zone.addVRMLEventListener(this,thingId);
    TS.advise(zone, thingId);
    itemTranslation = (EventInSFVec3f) vrmlNode[0].getEventIn ("translation");
    itemRotation = (EventInSFRotation) vrmlNode[0].getEventIn ("rotation");


   }catch(Exception e){System.err.println("ObjectView show error: ");e.printStackTrace();}
  }

  public void eventPerformed() {
    if (TS.getValue()) {
     if(oT.getPlace().hasPermission("object.v01")){
      Hashtable params = new Hashtable();
      params.put("browser",browser);
      params.put("objectThing",oT);
      params.put("objectThingView",this);
      oc = new ObjectControl();
      oc.init(params);
     }
    }
  }
  public void hook(float[] value){
   try{
    itemTranslation.setValue(value);
   }catch(Exception e){e.printStackTrace();}
  }


  public void catchMe(){
   try{
    root.setreChValue(vrmlNode);
    String sObject="DEF "+thingId+" Transform\n" +
                "{\n" +
		"translation "+oT.getProperty("translation")+"\n" +
                "rotation "+oT.getProperty("rotation")+"\n" +
		"scale "+oT.getProperty("scale")+"\n" +
  		"children [\n" +
                   " Transform\n" +
                           "{\n" +
      		           "translation 0.35 -0.20 -0.6\n" +
	                   "scale 0.4 0.4 0.4" +
                           "children [\n" +
  		            "       Inline{ url \"../../../resources/things/object.v01.wrl\"}\n" +
                            "]\n" +
      	    	      "}\n" +
  		"]\n" +
	    	"}\n" +
                "\n";
    catchNode = browser.createVrmlFromString(sObject);
    root.setaddChValue(catchNode);

    Node PS= browser.getNode("PS");
    browser.addRoute(PS,"position_changed",catchNode[0],"set_translation");
    browser.addRoute(PS,"orientation_changed",catchNode[0],"set_rotation");
    browser.addRoute(PS,"position_changed",vrmlNode[0],"set_translation");
    browser.addRoute(PS,"orientation_changed",vrmlNode[0],"set_rotation");

//    System.err.println("Node catched");
   }catch(Exception e){e.printStackTrace();}
  }

  public void destroy() {
    zone.removeVRMLEventListener(thingId);
    if (oc!=null) oc.dispose();
    root.setreChValue(vrmlNode);
  }

  public void deploy() {
   try{

    Node PS= browser.getNode("PS");
    browser.deleteRoute(PS,"position_changed",vrmlNode[0],"set_translation");
    browser.deleteRoute(PS,"orientation_changed",vrmlNode[0],"set_rotation");
    browser.deleteRoute(PS,"position_changed",catchNode[0],"set_translation");
    browser.deleteRoute(PS,"orientation_changed",catchNode[0],"set_rotation");

    root.setreChValue(catchNode);

     // Capture VRML position & orientation of avatar
    float[] t = new float[3];
    float[] r = new float[4];
    EventOutSFVec3f positionChanged=(EventOutSFVec3f)PS.getEventOut("position_changed");
    EventOutSFRotation orientationChanged=(EventOutSFRotation)PS.getEventOut("orientation_changed");
    t = positionChanged.getValue();
    r = orientationChanged.getValue();
    oT.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
    oT.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
    root.setaddChValue(vrmlNode);
    itemTranslation = (EventInSFVec3f) vrmlNode[0].getEventIn ("translation");
    itemRotation = (EventInSFRotation) vrmlNode[0].getEventIn ("rotation");

   }catch(Exception ex){ex.printStackTrace();}

  }

}
<%@ page session="true" import="ants.move.lang.*, java.text.*, ants.move.ejb.*, com.protomatter.syslog.*, ants.move.core.*, ants.move.builder.*, java.util.*, java.net.*, java.rmi.*" %>

<%! ResourceBundle labels; 
    LanguageUtilities lang;%>
<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");

  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "MOVE! Builder remote object not bound. Let's bind it now...");
     try {
       Hashtable env = new Hashtable();
       env.put ("PATH", (pageContext.getServletContext()).getRealPath(""));
       Syslog.debug (this, "Initializing MOVE! Builder remote object...");
       MOVEBuilderRemoteEngine engine = new MOVEBuilderRemoteEngine (env);
       Syslog.debug (this, "MOVE! Builder remote object initialized.");
       Naming.rebind ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder", engine);
       Syslog.debug (this, "MOVE! Builder remote object bound on rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }



  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  String userRole=((User)session.getAttribute("user")).getRole();
  String userLogin=((User)session.getAttribute("user")).getLogin();
  String placeType=null;
  try {
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
      placeType=(pm.getPlace(placeId)).getType();
      
  } catch (Exception e) {
      Syslog.log (this, e);
  }
%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b>Move builder: </b></font></td></tr>
   <tr>
    <td colspan="3" align="center">
     <EMBED SRC="resources/util/new3d.wrl" HEIGHT="350" WIDTH="450">
     <APPLET CODE="ants.move.builder.MOVEBuilderApplet.class" mayscript WIDTH="100" HEIGHT="350"
          ALIGN="ABSCENTER"
          ARCHIVE="jars/move-builder.jar,jars/move-core.jar">
            <PARAM name=worldKey value="<%=worldId%>">
	    <PARAM name=placeKey value="<%=placeId%>">
            <PARAM name=userRole value="<%=userRole%>">
            <PARAM name=userLogin value="<%=userLogin%>">
            <PARAM name=placeType value="<%=placeType%>">
    </APPLET>
    <br>
  </td>
 </tr>
 </table>
</center>
  <jsp:include page="footer.jsp" flush="true"/>
</HTML>





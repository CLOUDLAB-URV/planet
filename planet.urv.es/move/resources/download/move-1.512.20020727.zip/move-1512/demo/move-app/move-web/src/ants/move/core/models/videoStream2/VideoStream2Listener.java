// Package ants.move.core.models.videoStream2
// VideoStream2Listener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.videoStream2;

/** VideoStream2Listener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2002
*/
public interface VideoStream2Listener {
/**
 * Bind a URL
 * @param url URL of videoStream2
 */
  public void setVideoStream (String url);
  /**
   * Destroy method
   */
  public void destroy();
}
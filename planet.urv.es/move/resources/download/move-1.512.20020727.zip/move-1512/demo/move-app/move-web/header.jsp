<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! LanguageUtilities lang; 
    ResourceBundle labels; %>

<center>
<table width=90%>
<tr>
  <td><img src="images/moveSmall.jpg"></td>
  <td align="left"><h2>   
<%  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    
    String link=request.getParameter("linked");
    StringTokenizer str=new StringTokenizer(request.getParameter("string"),"/");
    while(str.hasMoreTokens()){
	String s=str.nextToken();
	if (s.equals("WORLDS")){
             if (str.hasMoreTokens()){ %>
                 <a href="listWorlds.jsp" target="_parent"><font color="green">/WORLDS</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("true")){ %>
                 <a href="listWorlds.jsp" target="_parent"><font color="green">/WORLDS</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("false")){ %>
                 <font color="green">/WORLDS</font>
<%           }
       }else if (s.equals("PLACES")){
             if (str.hasMoreTokens()){ %>
                 <a href="listPlaces.jsp" target="_parent"><font color="green">/PLACES</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("true")){ %>
                 <a href="listPlaces.jsp" target="_parent"><font color="green">/PLACES</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("false")){ %>
                 <font color="green">/PLACES</font>
<%           }
       }else if (s.equals("USERS")){
             if (str.hasMoreTokens()){ %>
                 <a href="listUsers.jsp" target="_parent"><font color="green">/<%=labels.getString("users")%></font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("true")){ %>
                 <a href="listUsers.jsp" target="_parent"><font color="green">/<%=labels.getString("users")%></font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("false")){ %>
                 <font color="green">/<%=labels.getString("users")%></font>

<%           } 
       }else if (s.equals("THINGS")){
             if (str.hasMoreTokens()){ %>
                 <a href="listThings.jsp" target="_parent"><font color="green">/THINGS</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("true")){ %>
                 <a href="listThings.jsp" target="_parent"><font color="green">/THINGS</font></a>
<%           }else if(!str.hasMoreTokens() && link.equals("false")){ %>
                 <font color="green">/THINGS</font>
<%           } 

       }
    }
%>
  </h2></td>

  <td align="left" width="25%">
    <font color ="#00800F"><b><%=labels.getString("user2")%> :</b></font><a href="editUser.jsp?<%=((User)session.getAttribute("user")).getLogin()%>"> <%=((User)session.getAttribute("user")).getLogin()%></a><br>
    <font color="#00800F"><b><%=labels.getString("roleOL")%> :</b></font><a href="editUser.jsp?<%=((User)session.getAttribute("user")).getLogin()%>"> <%=lang.translateText(((User)session.getAttribute("user")).getRole(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))%></a>
  </td>
</tr>
</table>
</center>
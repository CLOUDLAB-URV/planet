// Package ants.move.core.views
// ViewInterface.java
// init() method interface
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views;

import java.util.Hashtable;

/** setConstructorParams() method interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface ViewInterface {
  public void init (Hashtable ht);
}
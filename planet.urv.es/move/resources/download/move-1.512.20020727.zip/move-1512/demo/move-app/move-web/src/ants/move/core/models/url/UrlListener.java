// Package ants.move.core.models.url
// UrlListener.java
// (C) 2002 Oriol Montal� & Francesc Pi�as  collaborator: Carles Pairot
package ants.move.core.models.url;

/** UrlListener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator: Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2000
*/
public interface UrlListener {
/**
 * Refresh thing state
 * @param urlThingId
 */
  public void refreshThing (String urlThingId);
  /**
   * Load thing
   * @param uT
   */
  public void loadThing(UrlThing uT);
  /**
   * Add a new thing
   * @param uT
   */
  public void newThing(UrlThing uT);
  /**
   * Remove thing
   * @param urlThingId
   */
  public void removeThing(String urlThingId);
  /**
   * Cacth thing
   * @param urlThingId
   */
  public void catchThing(String urlThingId);
  /**
   * Deploy thing
   * @param urlThingId
   */
  public void deployThing(String urlThingId);
}

// Package ants.move.core.teacher.chat
// ChatWindow.java
// Implementation of Chat User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.chat;

// Notification Service imports
import ants.comm.*;
import ants.core.*;

//import move.core.core;

// java.awt Package imports
import java.awt.*;
import java.awt.event.*;

// java.util Package import
import java.util.*;

import ants.move.core.models.chat.ChatModel;
import ants.move.core.models.chat.ChatListener;

/** Implementation of Chat User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.20 Build 2000
*/
public class ChatWindow implements ChatListener, PlaceListener {
  private TextArea chatArea;
  // TextField
  private TextField chatField;
  // Chat internal class
  private ChatModel internalModel;
  private java.awt.List chatUsers;
  private Place conn;

  /** Sole constructor.
      @param iclass Chat internal class
      @exception exceptions No exceptions thrown
  */
  public ChatWindow (ChatModel cm, TextField cF, TextArea cA, java.awt.List cU, Place p) {
    internalModel = cm;
    internalModel.addChatListener(this);
    chatField = cF;
    chatArea = cA;
    chatUsers = cU;
    conn = p;

    conn.addPlaceListener(this);
    this.init();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    chatField.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        chatField_actionPerformed(e);
      }
    });

    chatUsers.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        chatUsers_actionPerformed(e);
      }
    });

    addUsers();
  }

  public void addUsers() {
    Vector listUsers = conn.getUsers();
    chatUsers.removeAll();

    if (listUsers != null) {
      Enumeration enum = listUsers.elements();

      while (enum.hasMoreElements()) {
        String usr = (String)enum.nextElement();
        chatUsers.add(usr);
      }
    }
  }


  /** Display a system message on the Chat Window.
      @param String Message
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void consoleMessage (String msg) {
    chatArea.append (msg +"\n");
  }

  /** chatField's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void chatField_actionPerformed (ActionEvent e) {
    try {
      if (!(chatField.getText().equals(""))) {
        StringTokenizer tokens = new StringTokenizer(chatField.getText());
        if (tokens.nextToken().equalsIgnoreCase("/priv")) {
          String toUser = new String(tokens.nextToken());   // Next token will be the username
          String message = new String();
          while (tokens.hasMoreTokens()) {
            message = message + tokens.nextToken() + " ";
          }
          internalModel.sendPrivateMsg(toUser, message);
        }
        else {
          internalModel.sendMsg(chatField.getText());
        }
        chatField.setText("");
      }
    } catch (Exception ex) {
      System.err.println("Exception trying to send message " + ex);
    }
  }

  public void chatUsers_actionPerformed (ActionEvent e) {
    try {
      System.err.println ("Opening private chat window for " + conn.getUser() + "and " + chatUsers.getSelectedItem());
      PrivateChatWindow w = new PrivateChatWindow (chatUsers.getSelectedItem(), conn, internalModel);

    } catch (Exception x) {
      System.err.println ("Exception trying to get user from chat users list " + x);
    }
  }

  /** Displays message on Chat Window.
      @param msg String to be displayed
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void writeLine (String msg) {
    chatArea.append(msg);
  }

  public void userJoined (String u) {
//    chatUsers.add(u);
    chatUsers.removeAll();
    addUsers();
  }

  public void userLeft (String u) {
    chatUsers.removeAll();
    addUsers();
  }

  public void onMessage (Hashtable ht) {
    if ((String) ht.get ("MSG") != null) {
      chatArea.append((String)ht.get("MSG"));
    }
  }

  public void usersChanged (String u) {
    chatUsers.removeAll();
    addUsers();
  }
  public void addThing (String thingKey){}
  public void removeThing (String thingKey){}
}

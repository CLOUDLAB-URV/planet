package ants.comm.examples;

import java.applet.*;
import ants.comm.*;
import ants.comm.jsdt.*;
import java.util.Hashtable;


public class JSDTProducerApplet extends Applet
{
	
	public void init()
	{
			try
		{
				Hashtable env = new Hashtable();
				env.put(Context.PROVIDER_PORT,"4461");
				env.put(Context.CONNECTION_TYPE,"socket");
				env.put(Context.SESSION_NAME,"VRMLSession");
 				env.put(Context.CHANNEL_NAME,"worldChannel");	
 				env.put(Context.PROVIDER_CLASS,"ants.comm.jsdt.Session");	

 				
 				ants.comm.Session chatZone = SessionFactory.createSession(env);
				
				Hashtable evt = new Hashtable();
				evt.put("arg1",getParameter("principal"));	
				chatZone.send(evt);
				chatZone.close();
		
		}catch (SessionException s1)
		{
			System.out.println(s1.getException().getMessage());
		}



	}
	
	
	
}
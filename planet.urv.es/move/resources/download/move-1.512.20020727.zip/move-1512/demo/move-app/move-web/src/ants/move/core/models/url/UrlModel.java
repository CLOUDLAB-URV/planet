package ants.move.core.models.url;

import ants.core.*;
import java.util.*;
import ants.util.*;
import ants.comm.*;

/**
 * Implementation of URL model
 * @author:      Oriol Montal� & Carles Pairot & Francesc Pi�as
 * @version 1.0
 */
public class UrlModel extends Thing implements ants.comm.RemoteEventListener{
  protected Vector listeners = new Vector();
  private Hashtable subs = new Hashtable();
  private Hashtable urlThings = new Hashtable();
  private String thingCatched= "";
  private String user=null;
/**
 * Initialize model
 */
  public void init() {
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","URL.V01");
      user=this.getPlace().getUser();
      super.getPlace().addPlaceListener(this,subs);
      Vector thingKeys = super.getPlace().getThings("url.v01");
      loadUrlThings(thingKeys);
    } catch (Exception x) {
      x.printStackTrace();
    }
    System.err.println("[MOVE] - URL model initialized.");
  }

  private void loadUrlThings(Vector thingKeys){
    ants.core.Thing key;
    for(Enumeration e=thingKeys.elements();e.hasMoreElements();){
      key=(ants.core.Thing)e.nextElement();
      loadThing(key.getThingId());
    }
  }

/**
 * Add new listener
 * @param urlL Class that implements UrlListener
 */
  public void addUrlListener (UrlListener urlL) {
    listeners.addElement(urlL);
  }

  /**
   * Return all Url things in place key=thingKey value=UrlThing class
   * @return Hashtable that contains all url things in place
   */
  public Hashtable getUrlThings(){
    return (urlThings);
  }

  /**
   * Notify to listeners that thing was catched
   * @param thingKey Key of the thing
   */
  public void catchThing(String thingKey){
    try{
      thingCatched=thingKey;
      //catch Thing
      for (int i = 0; i < listeners.size (); i++) {
        ((UrlListener) listeners.elementAt (i)).catchThing(thingKey);
      }
      //removeThing from Place
      UrlThing uTH=(UrlThing)urlThings.get(thingKey);
      uTH.setProperty("catched",user);
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","URL.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }

  /**
   * Notify to listeners to refresh thing
   * @param thingKey Key of the thing
   */
  public void refreshThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((UrlListener) listeners.elementAt (i)).refreshThing(thingKey);
      }
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Loads a new thing
 * @param thingKey Key of the thing
 */
  public void loadThing(String thingKey){
   try{
   if(!urlThings.containsKey(thingKey)){
     ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
     UrlThing uTH = new UrlThing();
     uTH.init(ctx, super.getThingGateway());
     uTH.setModel(this);
     if((uTH.getProperty("catched").equalsIgnoreCase("false"))||
     (uTH.getProperty("catched").equalsIgnoreCase(user))){
       urlThings.put(thingKey,uTH);
       for (int i = 0; i < listeners.size (); i++) {
         ((UrlListener) listeners.elementAt (i)).loadThing(uTH);
       }
     }else{
      uTH.destroy();
     }

   }else{
      System.err.println("Trying to load an existing URL THING");
   }
   }catch(Exception ex){}
  }

/**
 * Notify to listeners that a thing was deployed
 * @param thingKey Key of the thing
 */
  public void deployThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((UrlListener) listeners.elementAt (i)).deployThing(thingKey);
      }
      thingCatched="";
      UrlThing uTH=(UrlThing)urlThings.get(thingKey);
      uTH.setProperty("catched","false");
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","URL.V01");
      subs.put("METHOD","LOADTHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Send a remove event
 * @param thingKey Key of the thing
 */
  public void sendRemoveThing(String thingKey){
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","URL.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}

  }


  public void eventArrived (Hashtable evt) {
    String method = (String)evt.get("METHOD");
    //adding a new thing
   try{
    if(method.equalsIgnoreCase("NEWTHING")){
      ANTSContext ctx = new ANTSContext(super.getPlace(), (String)evt.get("THINGKEY"));
      UrlThing uTH = new UrlThing();
      uTH.init(ctx, super.getThingGateway());
      uTH.setModel(this);
      uTH.setProperty("catched","false");
      urlThings.put((String)evt.get("THINGKEY"),uTH);
      for (int i = 0; i < listeners.size (); i++) {
        ((UrlListener) listeners.elementAt (i)).newThing(uTH);
      }

    }else if(method.equalsIgnoreCase("REMOVETHING")){
      UrlThing uT= (UrlThing)urlThings.get((String)evt.get("THINGKEY"));
      if(!thingCatched.equalsIgnoreCase(uT.getThingId())){
        urlThings.remove((String)evt.get("THINGKEY"));
        for (int i = 0; i < listeners.size (); i++) {
          ((UrlListener) listeners.elementAt (i)).removeThing(uT.getThingId());
        }
        uT.destroy();
      }
    }else if(method.equalsIgnoreCase("LOADTHING")){
       loadThing((String)evt.get("THINGKEY"));
    }
   }catch(Exception ex){}
  }

  /**
   * Tool type
   * @return URL
   */
  public String getType() {
    return "URL";
  }
/**
 * Destroy method
 */
  public void destroy() {
   try{
//    super.getPlace().removePlaceListener(subs);
    super.destroy();
   }catch(Exception ex){System.err.println("[MOVE] -- Unable to destroy URL model");ex.printStackTrace();}
  }


}
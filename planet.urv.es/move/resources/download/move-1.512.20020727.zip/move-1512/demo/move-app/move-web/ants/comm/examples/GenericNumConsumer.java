
package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class GenericNumConsumer {
	
	
	public GenericNumConsumer(String envFile)
	{
	 try
		{
		
		
			ants.comm.Session chatZone = SessionFactory.createSession(envFile);
	
			Listener1 l1 = new Listener1();
		
			String subs = "num > 7 AND num < 14";
			chatZone.addRemoteEventListener(l1,subs);

		
	
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	public class Listener1 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("event arrived !!!  " + evt);
		}
	}
	

	public static void main(String args[])
	{
			GenericNumConsumer tc = new GenericNumConsumer(args[0]);
			System.out.println("Ready !  (Press CTRL+C to exit)");

			try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
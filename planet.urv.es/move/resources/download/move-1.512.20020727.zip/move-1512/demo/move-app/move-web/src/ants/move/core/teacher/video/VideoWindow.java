// Package ants.move.core.teacher.video
// VideoWindow.java
// Implementation of Video User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.video;

// dynamicObjects.Video import
import ants.move.core.models.video.*;
import ants.move.core.models.*;
import ants.core.*;
import ants.move.core.teacher.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/** Implementation of Video User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.30 Build 2000
*/
public class VideoWindow extends Windows implements TeacherInterface,
                                                    VideoListener {
  // Labels
  private Label FileLabel;
  private Label videoLabel;

  private Button playButton;
  private Button stopButton;

  private Choice videoChoice;

  // Video internal model
  private VideoModel internalModel;
  // Video name
  private String videoName;
  private boolean URLentered = false;
  private boolean playing = false;
  private Place conn;
  private Vector videoThings = new Vector();
  private String codeBase;
  private String dispName;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public VideoWindow () {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Video: " + (String) ht.get("src"));
    videoName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (VideoModel) conn.getModel(videoName);

    // Obtain all things of type Slides in that place
    videoThings = conn.getThings("video.v01");

    this.init();

  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;
    window.setSize(200, 175);
    window.setLocation(400, 400);
    window.setResizable(false);
    window.setLayout(gbLayout);
    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(videoLabel = new Label("Video Clip:"), gc);
    window.add(videoLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 2;
    gc.gridheight = 1;
    gbLayout.setConstraints(videoChoice = new Choice(), gc);
    p = new Panel();
    p.setLayout(null);
    p.setSize(145, 50);
    playButton = new Button(">");
    playButton.setBounds(80, 0, 40, 24);
    p.add(playButton);
    stopButton = new Button("S");
    stopButton.setBounds(40, 0, 40, 24);
    p.add(stopButton);
    FileLabel = new Label("Clip: <none> or <remote>");
    FileLabel.setBounds(0, 25, 144, 24);
    p.add(FileLabel);
    gc.gridy = 2;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);

    videoChoice.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        videoChoice_itemStateChanged(e);
      }
    });

    playButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        playButton_actionPerformed(e);
      }
    });

    stopButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stopButton_actionPerformed(e);
      }
    });
    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowVideo_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });

  // Add things to choice
  try {
    Enumeration e = videoThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      videoChoice.addItem(th.getName());
    }

  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Video to choice"); e.printStackTrace();}

    window.add(videoChoice);

    // Check whether video is loaded or not
    String videoThing =  internalModel.getVideoThing();
    if (!(videoThing.equals("----"))) {
      FileLabel.setText("Clip: " + getVideoThingName(videoThing));
      URLentered = true;
    }

    internalModel.addVideoListener(this);
    System.err.println("[MOVE] - Video control window initialized.");
  }



  /** videoChoice's itemStateChanged() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void videoChoice_itemStateChanged (ItemEvent e) {
    try {
      ants.core.Thing t = (ants.core.Thing) videoThings.elementAt(videoChoice.getSelectedIndex());
      internalModel.loadVideo(t.getThingId());
      FileLabel.setText("Clip: " + videoChoice.getSelectedItem());
      URLentered = true;
    } catch (Exception ex) {
      URLentered = false;
    }
  }

  private String getVideoThingName (String thingKey) {
    Enumeration e = videoThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getThingId().equals(thingKey)) {
        return t.getName();
      }
    }
    System.err.println("Thing with ID = " + thingKey + " not found in this place!");
    return null;
  }

  public void playButton_actionPerformed (ActionEvent e) {
    if (URLentered && !playing) {
      internalModel.controlVideo(true);
      playing = true;
    }
  }

  public void stopButton_actionPerformed (ActionEvent e) {
    internalModel.controlVideo(false);
    playing = false;
  }

  public void loadVideo () {
    FileLabel.setText("Clip: " + getVideoThingName(internalModel.getVideoThing()));
  }

  public void playVideo (String url) { playing = true; }
  public void stopVideo () { playing = false; }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Video";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }
  public void windowVideo_actionPerformed (WindowEvent evt){
        window.dispose();
  }

}

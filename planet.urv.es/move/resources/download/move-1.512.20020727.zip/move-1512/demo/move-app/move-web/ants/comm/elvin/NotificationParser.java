package ants.comm.elvin;

import org.elvin.je4.*;
import org.elvin.util.*;
import ants.comm.*;
import ants.util.*;

// Lanzar processing Thread


public class NotificationParser implements NotificationListener
{
	RemoteEventListener subs;
	
	public NotificationParser (RemoteEventListener subs)
	{
		this.subs = subs;	
	}
	
	public void notificationAction(Notification event)
	{
		 ElvinDispatcher dP = new ElvinDispatcher(subs,event);
		 dP.start();
	//	 subs.eventArrived(ElvinParser.getEvt(event));
	}
}
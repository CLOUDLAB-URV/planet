package ants.move.server;


/**
 * Title:        User Proxy
 * Description:  Send Avatar movements to users
 * Copyright:    Copyright (c) 2002
 * Company:      MOVE! TF
 * @author       Oriol Montal�, Francesc Pi�as & Carles Pairot
 * @version 1.0
 */
import ants.core.*;
import ants.comm.*;
import java.util.*;



public class UserProxy {
  private String user;
  private String world;
  private String place;
  private Session session;
  private float p[] = new float[4];
  private Hashtable moveEvt;
  private Hashtable exitAreaEvt;
  private float a; //influence area
  private float px;
  private float pz;
  private Hashtable users; //users into influence area
  private String usr;

  public UserProxy(String world,String place, String user, Session session, float a) {
    this.world=world;
    this.place=place;
    this.user=user;
    this.session=session;
    this.a=a;
    users = new Hashtable();
    moveEvt=new Hashtable();
    moveEvt.put("SENDER", "MOVEPROXY");
    moveEvt.put("OWNER", user);
    moveEvt.put("WORLD", world);
    moveEvt.put("PLACE", place);
    moveEvt.put("METHOD", "move");
//    moveEvt.put("PX", "");
//    moveEvt.put("PY", "");
//    moveEvt.put("PZ", "");
//    moveEvt.put("OY", "");
//    moveEvp.put("OA", "");
    exitAreaEvt = new Hashtable();
    exitAreaEvt.put("SENDER", "MOVEPROXY");
    exitAreaEvt.put("OWNER", user);
    exitAreaEvt.put("WORLD", world);
    exitAreaEvt.put("PLACE", place);
    exitAreaEvt.put("METHOD", "exitArea");

  }

  public void setPosition(Hashtable evt){
   p[0] = Float.parseFloat((String)evt.get("PX"));
//   p[2] = Integer.parseInt((String)evt.get("PY"));
   p[3] = Float.parseFloat((String)evt.get("PZ"));
//   p[4] = Integer.parseInt((String)evt.get("OA"));
//   System.out.println("MOVE Position set in "+user+" class : "+p[0]+" "+p[3]);
  }

  public void moveAvatar(Hashtable evt){
    try{
//      System.out.println("MOVE Event in "+user+" class : from "+(String)evt.get("USER"));
      usr=(String)evt.get("USER");
      if(!usr.equalsIgnoreCase(user)){
        px=Float.parseFloat((String)evt.get("PX"));
        pz=Float.parseFloat((String)evt.get("PZ"));
        if( (px>(p[0]-a)) && (px<(p[0]+a)) && (pz>(p[3]-a)) && (pz<(p[3]+a))  ){
//          System.out.println("MOVE Event in "+user+ " Influence IN");
          moveEvt.put("PX", (String)evt.get("PX"));
          moveEvt.put("PY", (String)evt.get("PY"));
          moveEvt.put("PZ", (String)evt.get("PZ"));
          moveEvt.put("OY", (String)evt.get("OY"));
          moveEvt.put("OA", (String)evt.get("OA"));
          moveEvt.put("USER",usr);
//          System.out.println("MOVE Event in "+user+" class : from "+(String)evt.get("USER")+" SEND "+ moveEvt.size());
          session.send(moveEvt);
          if(!users.containsKey(usr)){ //user into influence Area
            users.put(usr,""+0);
          }
        }else{
//           System.out.println("MOVE Event in "+user+" class : from "+(String)evt.get("USER")+" No into influence Area");
          if(users.containsKey(usr)){//user into influence Area
            users.remove(usr);
            exitAreaEvt.put("USER",usr);
            session.send(exitAreaEvt);
//            System.out.println("MOVE Event in "+user+" class : from "+(String)evt.get("USER")+" Exiting influence Area");
          }
        }
      }
    }catch(Exception e){}

  }



}
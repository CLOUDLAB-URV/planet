package ants.move.builder;
import java.net.*;
import java.util.Hashtable;

/** Class that stores all information of a thing or a model in the 3D environment
  *  @author Oriol Montal� (omontala@tinet.org)
  *  @author Carles Pairot (cpairot@tinet.org)
  */
  public class Item implements java.io.Serializable {
    private String name;
    private String type;
    private String toolId;
    private float[] translation = new float[3];
    private float[] scale = new float[3];
    private float[] rotation = new float[4];
    private Hashtable props;

    /** Constructor
      *  @param params None
      *  @exception exceptions No exceptions thrown
      */
    public Item() {
      name = "Static object";
      translation[0] = (float) 0.0;
      translation[1] = (float) 0.0;
      translation[2] = (float) 0.0;
      scale[0] = (float) 1.0;
      scale[1] = (float) 1.0;
      scale[2] = (float) 1.0;
      rotation[0] = (float) 0.0;
      rotation[1] = (float) 0.0;
      rotation[2] = (float) 1.0;
      rotation[3] = (float) 0.0;
      type = "thing";
      props = new Hashtable();
    }


    public Item (String n, float[] t, float[] s, float[] r) {
      name = n;
      translation[0] = t[0];
      translation[1] = t[1];
      translation[2] = t[2];
      scale[0] = s[0];
      scale[1] = s[1];
      scale[2] = s[2];
      rotation[0] = r[0];
      rotation[1] = r[1];
      rotation[2] = r[2];
      rotation[3] = r[3];
      props = new Hashtable();
      type = "thing";
    }

    public void setType (String t) {
      type = t;
    }

    public String getToolId() {
      return toolId;
    }

    public void setToolId (String tId) {
      toolId = tId;
    }

    public String getType() {
      return type;
    }

    public void setRotation (float[] r) {
      rotation[0] = r[0];
      rotation[1] = r[1];
      rotation[2] = r[2];
      rotation[3] = r[3];
    }

    public float[] getRotation() {
      return (rotation);
    }

    public void setScale (float[] s) {
      scale[0] = s[0];
      scale[1] = s[1];
      scale[2] = s[2];
    }

    public float[] getScale () {
      return scale;
    }

    public void setName (String n) {
      name = n;
    }

    public String getName() {
      return name;
    }

    public float[] getTranslation() {
      return translation;
    }

    public void setTranslation (float[] t) {
      translation[0] = t[0];
      translation[1] = t[1];
      translation[2] = t[2];
    }

    public void addProperty (String key, String value) {
      props.put(key,value);
    }

    public String getProperty(String key) {
      return((String) props.get (key));
    }

    public Hashtable getProperties() {
      return props;
    }
}
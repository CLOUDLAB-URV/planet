c:\jdk1.3\bin\java -cp jars/ants-comm.jar;jars/je-4.jar;. ants.move.server.MoveProxy

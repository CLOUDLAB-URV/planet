package ants.move.core.models.banner;

// dynamicObjects.banner import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.banner.*;

import java.util.*;

public class BannerEngine extends java.lang.Thread
{

  BannerModel internalModel ;
  int delay;

  public BannerEngine(){}

  public void init(Hashtable ht)
  {

     internalModel=(BannerModel)ht.get("model");	
     try {
       delay=Integer.parseInt(internalModel.getProperty("delay"));
     } catch (Exception e) {
        e.printStackTrace();
     }

  }


  public void run()
  {

    while(true){
     try{
       sleep(delay);
       internalModel.nextImage();
     }catch(Exception e){}
     
    }

  }

}
<%@ page session="true" import = "ants.move.lang.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, ants.move.core.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");
%>
  <html>
<body>
<center>
<table width=90%>

   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("addUrl")%> : </b></font></td></tr>
   <form method="post">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("url")%> : </b> <br>
      http://<input type="text" size="40" maxlength="500" name="url"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("urlDescription")%> : </b><br>
      <input type="text" size="50" maxlength="50" name="desc"><br><br>
    </td>
   </tr>
 <tr>
  <td colspan="3">
    <input type="checkbox" name="copy">
    <b><%=labels.getString("copy")%></b>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <input type="checkbox" name="catch">
    <b><%=labels.getString("catch")%></b>
  </td>
 </tr>

   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
    </td>
   </tr>
   </form>
  </table>
  </center>
  </HTML>
<%
}else{
 try{
  String thingCopy="";
  String thingCatch="";
  try{
    if(request.getParameter("copy").equalsIgnoreCase("on")){
       thingCopy = new String("true");
    }else{
       thingCopy = new String("false");
    }
  }catch(Exception exc){}
  try{
    if(request.getParameter("catch").equalsIgnoreCase("on")){
       thingCatch = new String("true");
    }else{
       thingCatch = new String("false");
    }
  }catch(Exception exx){}
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  String url=new String("http://"+request.getParameter("url"));
  String thingKey = ""+System.currentTimeMillis();
  Thing thing=thm.createThing(thingKey,url,
                            (String)session.getAttribute("placeId"),"url.v01");
  thing.setDescription(request.getParameter("desc"));
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  thing.setProperty("translation","0 1 0");
  thing.setProperty("rotation","0 0 1 0");
  thing.setProperty("scale","1 1 1 ");
  thing.setProperty("copy",thingCopy);
  thing.setProperty("catch",thingCatch);


  //Add Thing to running Move Applet
  Hashtable env = new Hashtable();
  Constants.init(request.getRealPath(""));
  env.put(Constants.NSPORT, Constants.getNSPort());
  env.put(Constants.ANTSCLASS, Constants.getAntsClass());
  env.put(Constants.SERVER, Constants.getServer());
  ants.comm.Session commSession = ants.comm.SessionFactory.createSession (env);

  Hashtable evt2 = new Hashtable();
  evt2.put(Constants.WORLD, (String)session.getAttribute("worldId"));
  evt2.put(Constants.PLACE, (String)session.getAttribute("placeId"));
  evt2.put("CLASS","URL.V01");
  evt2.put("METHOD","NEWTHING");
  evt2.put("THINGKEY",thingKey);
  commSession.send(evt2);
  commSession.close();
%>
  <script> window.close(); </script>

<%}catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}


%>



	package ants.core;

	import java.util.*;
	import java.io.*;
	import java.net.*;
        import ants.move.ejb.*;
        import javax.naming.Context;
        import javax.naming.InitialContext;
        import javax.rmi.PortableRemoteObject;


	public class ThingUtil
	{
		public static Properties getProps (String wName, String pName, String tName)
		{
/*                    try {
                       WorldManager manager;
                       World currentWorld;
                       ants.moo.Place currentPlace;
                       ants.moo.Thing currentThing;

    		        Properties env = new Properties();

                        Context initial = new InitialContext();
                        Object obj = initial.lookup("worldmanager");
                        WorldManagerHome home = (WorldManagerHome) PortableRemoteObject.narrow(obj, WorldManagerHome.class);
                        manager = home.create();
                        currentWorld = manager.getWorld(wName);
                        currentPlace = currentWorld.getPlace(pName);
                        currentThing = currentPlace.getThing(tName);

                        Collection c = currentThing.getProperties();
                        Iterator i = c.iterator();
                        Properties p = new Properties();

                        while (i.hasNext()) {
                          ants.moo.Property pr = (ants.moo.Property) i.next();
                          p.setProperty(pr.getName(), pr.getValue());
                        }

                        return p;
                  } catch (Exception ex) {
                    System.err.println ("Exception: ");
                    ex.printStackTrace();
    */                return null;
  //                }
		}

/*		public static Properties getProperties(String base,String objId) throws IOException
		{
			Properties env = new Properties();
			StringTokenizer sT = new StringTokenizer(objId,"/");
			URL objUrl= null;

			int cnt = sT.countTokens();

			if (cnt==2)
			{
					String objClss =sT.nextToken();
					String obj =sT.nextToken();
					objUrl = new URL (base+objClss+"/"+obj+".properties");

			}


			env.load(objUrl.openStream());

			return env;
		}

    public static Properties getProperties(Properties p)
		{

			Properties result = new Properties();
			int numprops=  Integer.parseInt(p.getProperty("props"));
			for (int i=0;i<numprops;i++)
			{
				String name = p.getProperty("p"+i+"name");
				String value = p.getProperty ("p"+i+"value");
				result.setProperty(name,value);

			}
			return result;


		}

    public static Hashtable getIndexedProperties(Properties p)
    {
		  Hashtable h = new Hashtable();

    	int numiprops=  Integer.parseInt(p.getProperty("iprops"));

			for (int i=0;i<numiprops;i++)
			{
         int ipropsize=  Integer.parseInt(p.getProperty("ip"+i+"size"));
        String values [] = new String[ipropsize];
				for (int j=0;j<ipropsize;j++)
				{
					  values[j] = p.getProperty("ip"+i+"value"+j);
				}
 				String name = p.getProperty("ip"+i+"name");

				IndexedProperty ip = new IndexedProperty(name,values);
				h.put(name,ip);

			}


    	return h;

		}
*/

    public static Hashtable getIndexedProperties (String objId)
    {
      /*             try {
                       WorldManager manager;
                       World currentWorld;
                       ants.moo.Place currentPlace;
                       ants.moo.Thing currentThing;

    		        Properties env = new Properties();
			StringTokenizer sT = new StringTokenizer(objId,"/");

                        String wName = sT.nextToken();
                        String pName = sT.nextToken();
                        String tName = sT.nextToken();

                        Context initial = new InitialContext();
                        Object obj = initial.lookup("worldmanager");
                        WorldManagerHome home = (WorldManagerHome) PortableRemoteObject.narrow(obj, WorldManagerHome.class);
                        manager = home.create();
                        currentWorld = manager.getWorld(wName);
                        currentPlace = currentWorld.getPlace(pName);
                        currentThing = currentPlace.getThing(tName);

                        Collection c = currentThing.getIndexedProperties();
                        Iterator i = c.iterator();
                        Hashtable ht = new Hashtable();

                        while (i.hasNext()) {
                          IndexedPropertyModel pr = (IndexedPropertyModel) i.next();
                          ArrayList a = pr.getValues();
                          Iterator i1 = a.iterator();

                          String[] str = new String[a.size()];
                          int k = 0;
                          while (i1.hasNext()) {
                            str[k] = (String) i1.next();
                            k++;
                          }
                          IndexedProperty ip = new IndexedProperty(pr.getName(), str);
                          ht.put(pr.getName(), ip);
                        }

                        return ht;
                  } catch (Exception ex) {
                    System.err.println ("Exception: ");
                    ex.printStackTrace();
          */          return null;
        //          }

	}
}
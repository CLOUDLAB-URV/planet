package ants.core;

import ants.comm.*;
import java.util.*;
import java.io.*;
import java.net.*;
import ants.util.*;
import java.rmi.*;
import ants.core.rmi.*;


/**
*		Essential class representing the shared session. It contains information about
*   connected users, active models, and links to other places.
*   It also provides methods for sending events inside the current context (Place).
*   It also permits customized event subcriptions inside the place.
*
*
*/

public class Place
{
	private ants.comm.Session conn;
	private Properties props = null;
	private String userName;
	private String userRole;
	private String placeKey;
	private String worldKey;
	private String baseURL;
	private String busName;
	private String placeServer;
        private String thingServer;
        private String userServer;
	private Hashtable models = new Hashtable();
        private Vector thTools = new Vector();
	private Vector listeners = new Vector();
	private Vector links = new Vector();

        private PlaceGateway placeGateway;
        private UserGateway userGateway;
        private ThingGateway thingGateway;

        private boolean joined = false;

        // Must be a unique description or RemoveRemoteEventListener in ants.comm.elvin.Session fails!!!!!!
        private Hashtable subscription = new Hashtable();

        public Place (Hashtable env) {
          this.placeServer = (String) env.get(Context.PLACESERVER);
	  this.thingServer = (String) env.get(Context.THINGSERVER);
	  this.userServer = (String) env.get(Context.USERSERVER);
        }


	public Place (ants.comm.Session conn, Hashtable env)
	{
		this.conn = conn;
		this.userName = (String)env.get(Context.USER);
		this.userRole = (String)env.get(Context.ROLE);
		this.placeKey = (String)env.get(Context.PLACE);
		this.worldKey = (String)env.get(Context.WORLD);
		this.baseURL = (String)env.get(Context.BASE);
		this.busName = (String)env.get(Context.BUS);
		this.placeServer = (String) env.get(Context.PLACESERVER);
		this.thingServer = (String) env.get(Context.THINGSERVER);
		this.userServer = (String) env.get(Context.USERSERVER);
		try {
			PlaceParser cp = new PlaceParser(this);
			subscription.put(Context.WORLD, worldKey);
			subscription.put(Context.PLACE, placeKey);
			subscription.put(Context.CLASS, "PLACE");

			conn.addRemoteEventListener (cp, subscription);

                        connectToGateway();

//			this.join();

		}catch (SessionException ex){ants.util.Debug.error(ex.getException());};
	}

        public void connectToGateway() {
          try {
            placeGateway = (PlaceGateway) Naming.lookup (placeServer);
            thingGateway = (ThingGateway) Naming.lookup (thingServer);
            userGateway = (UserGateway) Naming.lookup (userServer);
          } catch (Exception ex) {
            System.err.println("Exception occured in connectToGateway: " + ex);
          }
        }

	public void join() throws SessionException
	{
           try {
		Hashtable evt = new Hashtable();
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
		evt.put(Context.METHOD,"JOIN");
		evt.put(Context.USER,userName);
		conn.send(evt);

		}catch(Exception e2){
                  throw new SessionException(e2);
		}

                addUser (userName);
//                this.getUsers();
	}

	/**
	*	 Method that disconnect the user from the current session (Place).
	*  It also call the destroy method in every model contained in the Place.
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/


	public void leave() throws SessionException
	{
		Hashtable evt = new Hashtable();
		evt.put(Context.WORLD,  worldKey);
		evt.put(Context.PLACE,  placeKey);
		evt.put(Context.CLASS,  "PLACE");
		evt.put(Context.METHOD, "LEAVE");
		evt.put(Context.USER,   userName);
		conn.send(evt);

                removeUser (userName);
		destroy();
	}

	public void destroy()
	{
        	try{
	    	  conn.removeRemoteEventListener(subscription);
  		  Enumeration e = thTools.elements();
                  while (e.hasMoreElements())
                  {
                    Model model = (Model)e.nextElement();
                    model.destroy();
                  }

		}catch (SessionException ex){ants.util.Debug.error(ex.getException());};
	}

	public void close() throws SessionException
	{
		leave();
		conn.close();
	}

	/**
	*	 Method that disconnect the specified user from the current session (Place).
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/

	public void ban(String user) throws SessionException
	{

		send(user+" has been banned");

		Hashtable evt2 = new Hashtable();
		evt2.put(Context.WORLD,worldKey);
		evt2.put(Context.PLACE,placeKey);
		evt2.put(Context.CLASS,"PLACE");
		evt2.put(Context.METHOD,"BAN");
		evt2.put("TARGET",user);
		evt2.put(Context.USER,userName);
		conn.send(evt2);

	}

	/**
	*	 Method that sends a String message to all users in the current session (Place).
	* @param msg String message to be sent to all users
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/

	public void send(String  msg) throws SessionException
	{
		Hashtable evt = new Hashtable();
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
		evt.put(Context.METHOD,"MSG");
		evt.put(Context.USER,userName);
		evt.put("MSG",msg);
		evt.put("TO","ALL");

		conn.send(evt);
	}


	/**
	*	 Method that sends a Hashtable event to all users in the current session (Place).
	* If it contains a key = "object" it will also send the Serializable Java object contained in the matching event value.
	* @param evt Hashtable event containing key-value pairs.
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/
	public void send(Hashtable evt) throws SessionException
	{
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
//		evt.put("CLASS","CHANNEL");
		evt.put(Context.USER,userName);
		evt.put("TO","ALL");

		Serializable obj =(Serializable)evt.get("object");
		if (obj!=null)
			{

				evt.remove("object");
				conn.sendObj(evt,obj);
			} else
			  conn.send(evt);
	}


	/**
	* Method that sends a String message to a specified user in the current session (Place).
	* @param user Target user name
	* @param msg String message to be sent to the specified user
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/
	public void send2(String user,String msg) throws SessionException
	{
		Hashtable evt = new Hashtable();
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
		evt.put(Context.METHOD,"MSG");
		evt.put("TO",user);
		evt.put(Context.USER,userName);
		evt.put("MSG",msg);
		conn.send(evt);
	}


	public Session getSession()
	{
		return conn;

	}

	public String getBus()
	{
		return busName;

	}

	public void send2(String user,Hashtable evt) throws SessionException
	{

		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
//		evt.put(Context.METHOD,"MSG");
		evt.put("TO",user);
		evt.put(Context.USER,userName);
	//	evt.put("MSG",msg);


		Serializable obj =(Serializable)evt.get("object");
		if (obj!=null)
			{

				evt.remove("object");
				conn.sendObj(evt,obj);

			} else
			  conn.send(evt);


	}

	/**
	*	 Method that sends a String message to all other connected users in the current session (Place).
	* @param msg String message to be sent
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/

	public void send2Others(String msg) throws SessionException
	{
		Hashtable evt = new Hashtable();
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
		evt.put(Context.METHOD,"MSG");

		evt.put("TO","REST");
		evt.put(Context.USER,userName);
		evt.put("MSG",msg);
		conn.send(evt);
	}


	/**
	*	 Method that sends a Hashtable event to all other connected users in the current session (Place).
	* If it contains a key = "object" it will also send the Serializable Java object contained in the matching event value.
	* @param evt Hashtable event containing key-value pairs
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/
	public void send2Others(Hashtable evt) throws SessionException
	{
		evt.put(Context.WORLD,worldKey);
		evt.put(Context.PLACE,placeKey);
		evt.put(Context.CLASS,"PLACE");
		evt.put("TO","REST");
		evt.put(Context.USER,userName);

		Serializable obj =(Serializable)evt.get("object");
		if (obj!=null)
			{

				evt.remove("object");
				conn.sendObj(evt,obj);

			} else
			  conn.send(evt);


	}

	/**
	*	 Method for subscribing to PlaceListener events in the  current place.
	* @param cL Listener class for events produced in the shared session
	*/
	public void addPlaceListener(PlaceListener cl)
	{
		listeners.addElement(cl);

	}

	/**
	*	 Method for unsubscribing to PlaceListener events in the  current place.
	* @param cL Listener class for events produced in the shared session
	*/
	public void removePlaceListener(PlaceListener cl)
	{
		listeners.removeElement(cl);
	}

	public String getUser()
	{
		return userName;
	}

	public String getRole()
	{
		return userRole;
	}
        public boolean isBot(String usr){
          try{
            return(userGateway.isBot(worldKey, placeKey, usr));
          }catch(Exception e){ System.err.println("Exception isBot("+usr+")");}
         return false;
        }

        public void setBot(){
          try{
            userGateway.setBot(worldKey, placeKey, userName);
          }catch(Exception e){ System.err.println("Exception sBot("+userName+")");}

        }


        public void addToBag (String thingId){
          try{
            userGateway.addToBag(userName,thingId);
          }catch(Exception e){ System.err.println("Exception addToBag("+thingId+")");}

        }

        public boolean hasPermission (String tool){
          boolean value=false;
          try{
            value=userGateway.hasPermission(tool,userRole,worldKey);
          }catch(Exception e){ System.err.println("Exception locating permissions...");}
          return value;
        }


	/**
	*
	* Method returning place name.
	* @return String place name
	*/


	public String getPlaceId()
	{
            return placeKey;
	}

	public String getBaseURL()
	{
		return baseURL;
	}

	/**
	*	 Method for subscribing to RemoteEventListener events in the  current place matching the specified subcription.
	* @param rL Listener class for RemoteEventListener events produced in the shared session
	* @param subs Hashtable subscription to events produced in the session.
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/

	public void addPlaceListener(RemoteEventListener rL, Hashtable subs) throws SessionException

	{
		conn.addRemoteEventListener(rL, subs);
	}

	/**
	*	 Method for unsubscribing to RemoteEventListener events in the  current place matching the specified subcription.
	* @param subs Hashtable subscription to events produced in the session.
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/
	public void removePlaceListener(Hashtable subs) throws SessionException

	{
		conn.removeRemoteEventListener(subs);
	}


	/**
	*	 Method for dynamically class-loading JavaBeans components stored in the current session (Place)
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection.
	*/
	public Hashtable loadModels() throws SessionException
	{
          try {
            models = placeGateway.loadModels (placeKey);
            Enumeration k = models.keys();

            while (k.hasMoreElements()) {
              Vector modelInfo = (Vector) k.nextElement();
              String key = (String) modelInfo.elementAt(1);
              try {
                Model obj = (Model) models.get (modelInfo);
                ANTSContext ctx = new ANTSContext (this, key);
                obj.init (ctx, thingGateway);
                // Add model to Models Vector
               thTools.addElement(obj);
              } catch (ClassCastException cce) {
//              System.err.println("Object " + key + " has no model.");
            }
          }

          } catch (Exception e) {
            System.err.println("Exception loading models...");
            e.printStackTrace();
          }

        return models;

	}


/*	private void loadProperties() throws IOException
	{
			props = ThingUtil.getProps(worldName+"/"+placeName);
	}
*/
/*	public Properties getProps() throws IOException
	{

		if (props==null)
				loadProperties();

		return props;
	}
*/

	/**
	* Method returning all JavaBeans components in the ANTS container for the current Place.
	* @return java.util.Hashtable Dictionary containing component names and references.
	*/

	public Hashtable getModels()
	{
		return models;
	}

	/**
	*
	* Method returning a specified JavaBean component in the ANTS container.
	* @param id JavaBean id.
	* @return java.lang.Object Reference to the JavaBean component
	*/
	public Object getModel (String id) {
          Enumeration enum = models.keys();

          while (enum.hasMoreElements()) {
            Vector modelInfo = (Vector) enum.nextElement();
            if (((String) modelInfo.elementAt(1)).equals (id)) {
              return models.get (modelInfo);
            }
          }
          // Model not found
          return null;
	}

	public Vector getListeners()
	{

		return listeners;
	}

        // Returns a Vector containing all thing IDs in that place

        public Vector getThings (String thingType) {
          Vector v;
          Vector things = new Vector();

          try {
            v = placeGateway.getThings (placeKey, thingType);

            Enumeration k = v.elements();

            while (k.hasMoreElements()) {
              String thingKey = (String) k.nextElement();
  	      ANTSContext ctx = new ANTSContext(this, thingKey);
              Thing th = new Thing();
              th.init (ctx, thingGateway);
              things.addElement(th);
            }

            return things;
          } catch (Exception e) {
            System.err.println("Exception occured in getThings(): returning NULL!!");
            e.printStackTrace();
            return null;
          }
        }


        // Returns all connected users in that place (in MOO's place)

/*	public Vector getUsers()
	{
          Vector v;
          try {
            v = pgate.getUsers (worldName, placeName);
            return v;
          } catch (Exception e) {
            System.err.println("Exception occured in getUsers(): returning NULL!!");
            e.printStackTrace();
            return null;
          }
	}
*/
        // Returns all connected users in that place (only those connected to MOVE's place)

        public Vector getUsers() {
          try {
            return userGateway.getUsers (worldKey,placeKey);
          } catch (Exception x) {
            x.printStackTrace();
            return null;
          }
        }

        public void addUser (String usr) {
          try {
            userGateway.addUser (worldKey,placeKey, usr);
          } catch (Exception x) {
              x.printStackTrace();
          }
        }

        public void removeUser (String usr) {
          try {
            userGateway.removeUser (worldKey,placeKey, usr);
          } catch (Exception x) {
            x.printStackTrace();
          }
        }

        public boolean contains (String usr) {
          Vector a = getUsers();
          if (a != null) {
            Enumeration e = a.elements();

            while (e.hasMoreElements()) {
              if (((String)e.nextElement()).equalsIgnoreCase(usr)) {
                return true;
              }
            }
          }
            return false;
        }

	/**
	*
	* Method returning the place description.
	* @return java.lang.String Place description
	*/

	public String getDescription()
		{
			return "Welcome to "+placeKey+" \n"+props.getProperty("description");
		}

		/**
	*
	* Method returning the world name.
	* @return java.lang.String World name
	*/

	public String getWorld()
		{
			return worldKey;
		}

		/**
	*
	* Method returning a list of links to other places
	* @return java.util.Enumeration A list of links.
	*/


	public Enumeration getLinks()
	{
		return links.elements();
	}

		/**
	*
	* Method that load to memory all links in the current place.
	*/


	public void loadLinks()
	{
		if (props!=null)
		{
			int numLinks = Integer.parseInt(props.getProperty("links"));

			for (int i = 0;i<numLinks;i++)
			{
				String link = props.getProperty("link"+i);

				Link lnk = new Link(link);

				links.addElement(lnk);

			}
		}
	}

}
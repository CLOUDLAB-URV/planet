package ants.core.rmi;

import ants.core.*;
import ants.comm.*;
import ants.move.ejb.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;

import com.protomatter.syslog.*;
import fr.dyade.jdring.*;

public class UserGatewayImpl extends UnicastRemoteObject implements UserGateway, RemoteEventListener {
    private Session session;
    private String src;
    private String clss;
    private Hashtable subscription = new Hashtable();
    private long lastPing;
    // Minutes until next ping
    private int timeToNextPing = 1;
    // Every entry of the hashmap is the user's vector (VALUE) of that place (KEY)
    private Hashtable placeUsersHT = new Hashtable();
    private Hashtable aliveUsers;
    private javax.naming.Context initial = null;
    private WorldManager worldManager = null;
    private UserManager userManager = null;

    public UserGatewayImpl (Session ses, Hashtable env) throws java.rmi.RemoteException {
      src = "UserManager";
      clss = "PLACE";
      session = ses;

      try {
        timeToNextPing = (new Integer((String) env.get (ants.core.Context.PINGTIME))).intValue();
      } catch (Exception x) {
        Syslog.debug (this, "Error parsing ping time. Defaulting to 1 minute.");
        timeToNextPing = 1;
      }

      // Add ping avatar event listener
      subscription.put("CLASS", clss);   // Avatar
      subscription.put("SRC", src);
      subscription.put("TO", "MOVEUsersServer");

      try {
        session.addRemoteEventListener (this, subscription);
      }
      catch (Exception ex) {
        Syslog.log (this, ex);
      }

      // Set up ping alarm event
      AlarmManager mgr = new AlarmManager();

      try {
        mgr.addAlarm(timeToNextPing, true, new AlarmListener() {
        public void handleAlarm(AlarmEntry entry) {
          checkHungUsers();
          sendPingEvent();
        }
      });
      } catch (Exception x) { x.printStackTrace(); }

      try {
        Syslog.debug (this, "Getting InitialContext reference...");
        initial = new InitialContext(env);
        Object obj = initial.lookup ("java:comp/env/WorldManagerBean");
        WorldManagerHome home = (WorldManagerHome) PortableRemoteObject.narrow(obj, WorldManagerHome.class);
        worldManager = home.create();
        Object obj2 = initial.lookup ("java:comp/env/UserManagerBean");
        UserManagerHome home2 = (UserManagerHome) PortableRemoteObject.narrow(obj2, UserManagerHome.class);
        userManager = home2.create();
        Syslog.debug (this, "InitialContext for ants.core.rmi.UserGateway remote object gotten OK.");
      } catch (Exception x) {
        Syslog.error(this, x);
      }

    }


    public boolean hasPermission (String tool, String role, String worldId) throws java.rmi.RemoteException {
      try{
        World world=worldManager.getWorld(worldId);
        int size=Integer.parseInt(world.getProperty(role+"size"));
        String value;
        for(int i=0;i<size;i++){
          value=world.getIndexedProperty(role,i);
          if(value.equalsIgnoreCase(tool)){
            return true;
          }
        }
      }catch(Exception e){
        Syslog.error (this, "Unable to locate tool permisons");
      }
      return false;
    }


    public boolean isBot(String wKey, String pKey, String usr) throws java.rmi.RemoteException {
	Vector pUE;
      UserInfo ui;

	pUE = (Vector) placeUsersHT.get(wKey + "/" + pKey);
      if ((ui = contains(pUE, usr)) != null) {
          Syslog.debug(this, "User " + usr + "is a Bot");
          return(ui.isBot());
      }
      else Syslog.error(this, "Unable to locate user " + usr);

      return false;

    }

    public void setBot(String wKey, String pKey, String usr) throws java.rmi.RemoteException {
      Vector pUE;
      UserInfo ui;

      pUE = (Vector) placeUsersHT.get(wKey + "/" + pKey);
      if ((ui = contains(pUE, usr)) != null) {
          Syslog.debug(this, "User " + usr + "is a Bot");
          ui.setBot();
      }
      else Syslog.error(this, "Unable to locate user " + usr);
    }

    public void addToBag (String login, String thingId) throws java.rmi.RemoteException {
      try{
        ants.move.ejb.User user=userManager.getUser(login);
        int size=Integer.parseInt(user.getProperty("BagSize"));
        String value;
        boolean equals=false;
        for(int i=0;i<size;i++){
          value=user.getIndexedProperty("Bag",i);
          if(value.equalsIgnoreCase(thingId)){
            equals=true; //Thing is already in bag
          }
        }
        if(!equals){
          user.setIndexedProperty("Bag",thingId,size);
          user.setProperty("BagSize",""+(size+1));
        }

      }catch(Exception e){
        Syslog.error (this, "Unable to locate bag");
        try{
          ants.move.ejb.User user=userManager.getUser(login);
          user.setProperty("BagSize",""+1);
          user.setIndexedProperty("Bag",thingId,0);
        }catch(Exception ex){}
      }
    }

    public Vector getUsers (String wKey, String pKey) {
      Vector pUE;

      if(placeUsersHT.containsKey(wKey + "/" + pKey)){
        pUE = (Vector) placeUsersHT.get(wKey + "/" + pKey);
      }else{
        pUE = new Vector();
        placeUsersHT.put(wKey + "/" + pKey, pUE);
      }

      Enumeration e = pUE.elements();
      Vector toReturn = new Vector();
      Syslog.debug(this, "GET USERS IN "+ pKey);
      while (e.hasMoreElements()) {
        String u =((UserInfo) e.nextElement()).getUserName();
        toReturn.addElement (u);
        Syslog.debug(this, "User:"+u);
      }

      return toReturn;
    }

    public String getUserIP (String wKey, String pKey, String usr) throws java.rmi.RemoteException {
      Vector pUE;

        pUE = (Vector) placeUsersHT.get(wKey + "/" + pKey);
        UserInfo ui;
        String ip=null;

        if ((ui = contains(pUE, usr)) != null) {
          ip = ui.getUserIP();
          Syslog.debug(this, "User " + usr + "IP: " + ui.getUserIP());
        }
        else Syslog.debug(this, "Unable to obtain IP from user " + usr);

        return ip;
    }

    public void addUser (String wKey, String pKey, String usr) throws java.rmi.RemoteException {
      Vector a;
      try {

        if(placeUsersHT.containsKey(wKey + "/" + pKey)){
           a = (Vector) placeUsersHT.get(wKey + "/" + pKey);
        }else{
          a = new Vector();
          placeUsersHT.put(wKey + "/" + pKey, a);
        }

        UserInfo u = new UserInfo (usr);
        u.setUserIP(getClientHost());


        if (contains (a, usr) == null) {
          a.addElement(u);
          Syslog.debug(this, "User " + usr + " added to place " + pKey);
        }
        else Syslog.debug (this, "User " + usr + " is already in place " + pKey);

      } catch (Exception x) {
        Syslog.error(this, x);
      }
    }


    public void removeUser (String wKey, String pKey, String usr) throws java.rmi.RemoteException {
      Vector a;
      try {
        a = (Vector) placeUsersHT.get(wKey + "/" + pKey);
        UserInfo ui;

        if ((ui = contains(a, usr)) != null) {
          a.removeElement(ui);
          Syslog.debug(this, "User " + usr + " removed from place: " + pKey);
        }
        else Syslog.debug(this, "Unable to remove user " + usr + " from place " + pKey + ". Reason: Not in vector.");

      } catch (Exception x) {
        Syslog.error(this, x);
      }
    }

    public UserInfo contains (Vector a, String usr) {
      Enumeration e = a.elements();

      while (e.hasMoreElements()) {
        UserInfo ui = (UserInfo) e.nextElement();
        if (ui.getUserName().equalsIgnoreCase(usr)) {
          return ui;
        }
      }
      return null;
    }

    public void sendPingEvent() {
      Hashtable evtp = new Hashtable();

      evtp.put("CLASS", "PingResponder");
      evtp.put("SRC", src);
      evtp.put("METHOD", "PING");
      evtp.put("PING_TIMESTAMP", "" + System.currentTimeMillis());

      try {
        // Store ping time
        lastPing = System.currentTimeMillis();

        session.send(evtp);
//        Syslog.debug(this, "Ping event sent.");
      } catch (Exception x) {
        Syslog.log(this, x);
      }
    }



    public void checkHungUsers() {
      Syslog.debug(this, "Check hung users");
      Enumeration e = placeUsersHT.elements();
      Enumeration k = placeUsersHT.keys();
      Vector v;
      String s;
      while (e.hasMoreElements()) {
          v = (Vector) e.nextElement();
          s = (String) k.nextElement();
          checkPlaceUsersVector(v,s);
      }
    }

    private void checkPlaceUsersVector (Vector usr, String key) {
      boolean changed=false;
      Vector usersOK= new Vector();
      Vector usersKO= new Vector();
      try {
        Enumeration usrInPlace = usr.elements();

        while (usrInPlace.hasMoreElements()) {
          UserInfo ui = (UserInfo) usrInPlace.nextElement();
          if (ui.isAlive()){
            ui.setAlive(false);
            usersOK.addElement(ui);
          }else{
            changed=true;
            usersKO.addElement(ui);
          }
        }
        if(changed){
          placeUsersHT.remove(key);
          placeUsersHT.put(key,usersOK);
          notifyPlaceUsers (key, usersOK);
        }
        Syslog.debug(this, "In" + key+" Changed= "+changed);
      } catch (Exception e) {
        Syslog.log(this, e);
      }
    }

    public void notifyPlaceUsers (String key, Vector org) {
      // Parse world id from key
      StringTokenizer tokens = new StringTokenizer (key, "/");
      String wrl = tokens.nextToken();

      // Parse place id from key
      String plc = tokens.nextToken();

      Hashtable evt = new Hashtable();
      evt.put("CLASS", "PLACE");
      evt.put(ants.core.Context.WORLD, wrl);
      evt.put(ants.core.Context.PLACE, plc);
      evt.put("METHOD", "USERS");

      Enumeration enum = getUsers(wrl, plc).elements();
      String userz = new String();

      while (enum.hasMoreElements()) {
        userz = enum.nextElement() + " ";
      }

      evt.put("USERS", userz);

      evt.put("TO", "ALL");

      try {
        Syslog.debug (this, "Users from " + key + " have been sent a new users list.");
        session.send (evt);
      } catch (Exception x) {
        Syslog.log(this, x);
      }

    }

    public void eventArrived (Hashtable evt) {
      String user = (String) evt.get("USER");
      String place = (String) evt.get("PLACE");
      String world = (String) evt.get("WORLD");

      Vector usersIn = (Vector)placeUsersHT.get(world+"/"+place);
      UserInfo uf;
      if((uf=contains(usersIn,user)) != null){
        uf.setAlive(true);
      }
    }
}
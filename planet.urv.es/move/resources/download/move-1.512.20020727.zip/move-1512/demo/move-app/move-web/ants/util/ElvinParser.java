
package ants.util;

import java.util.*;
import org.elvin.je4.*;
import org.elvin.util.*;
import java.util.Hashtable;
import java.io.*;


public class ElvinParser 
{

public static Hashtable getEvt(Notification nt)
{
	Hashtable evt =  new Hashtable();
	
	
	Enumeration keys = nt.keys();
	
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		if (!key.equals("object"))
		  {
		  	evt.put(key,nt.get(key));
		  }else
		{
			  
			try{
				byte lista[];
				lista = nt.getOpaque("object");
				ByteArrayInputStream bis = new ByteArrayInputStream(lista);
	  		ObjectInputStream is = new ObjectInputStream(bis);
	  		Object x = (Object)is.readObject();
    		evt.put("object",x);
			}catch(IOException ex){Debug.error(ex);
			}catch(ClassCastException ex2){	Debug.error(ex2);	
			}catch(ClassNotFoundException ex3){	Debug.error(ex3);	}

		}
			
	}
	
	return evt;
}
	
public static Notification getNotif(Hashtable evt)
{
	Notification nt = new Notification();
	Enumeration keys = evt.keys();
	
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		nt.put(key,(String)evt.get(key));
	}
	return nt;
}
	
	
	
	
public static String getSubs (Hashtable evt)
{
	StringBuffer subs = new StringBuffer("");

	Enumeration keys = evt.keys();
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		String value = (String)evt.get(key);
		subs.append(" "+key+" == '"+value +"' && ");
		evt.put(key,value);
		
	}
	String res = subs.toString();
	String result = res.substring(0,res.length()-4);
	return result;
	
}	


	

	
}
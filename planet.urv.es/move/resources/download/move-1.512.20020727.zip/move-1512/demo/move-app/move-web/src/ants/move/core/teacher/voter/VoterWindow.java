// Package ants.move.core.teacher.voter
// VoterWindow.java
// Implementation of Voter User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.voter;

// dynamicObjects.Slides import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.voter.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;

import java.util.*;

/** Implementation of Voter User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.00 Build 2001
*/
public class VoterWindow extends Windows implements TeacherInterface {
  // Buttons
  private Button voterButton;
  // Labels
  private Label voterLabel;
  // Choice
  private Choice voterChoice;
  // Voter name
  private String voterName;
  private VoterModel internalModel;
  private Place conn;
  private String dispName;

  // All things of type Voter in that place
  Vector voterThings = new Vector();


  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public VoterWindow() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Voter: " + (String) ht.get("src"));
    voterName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (VoterModel) conn.getModel(voterName);
    if (internalModel == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: VOTER (from VoterWindow)");
    }

    // Obtain all things of type Voter in that place
    voterThings = conn.getThings("votation.v01");

    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(360, 175);
    window.setLocation(190, 0);
    window.setResizable(false);
    window.setLayout(gbLayout);

    gc.gridy = 1;
    gc.gridx = 6;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(voterButton = new Button("Load"), gc);
    window.add(voterButton);

    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(voterLabel = new Label("Choose a votation:"), gc);
    window.add(voterLabel);

    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 5;
    gc.gridheight = 1;
    gbLayout.setConstraints(voterChoice = new Choice(), gc);

  // Add things to choice
  try {
    Enumeration e = voterThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      try {
        voterChoice.addItem(th.getDescription());
      } catch (NullPointerException ex) {
        System.err.println("Thing not added to Voter choice. Maybe it was deleted ?");
      }
    }

  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Voter to choice"); e.printStackTrace();}

  window.add(voterChoice);

   System.err.println("[MOVE] - Voter control window initialized.");

    voterButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        voterButton_actionPerformed(e);
      }
    });
    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowVoter_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  // Locks the Voter Thing onto the Voter Model
  public void lockThing (int index) {
    ants.core.Thing t = (ants.core.Thing) voterThings.elementAt(index);
    internalModel.setVoterThing(t.getThingId());
  }


  /** voterField's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void voterButton_actionPerformed (ActionEvent e) {
    lockThing (voterChoice.getSelectedIndex());
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Voter";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowVoter_actionPerformed (WindowEvent evt){
        window.dispose();
  }

}

<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*, com.evermind.io.*,ants.move.core.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>
<%
  String toolKey = "doc.v01";
  String worldKey=(String)session.getAttribute("worldId");
  String placeKey=(String)session.getAttribute("placeId");
  String userLogin = ((User)session.getAttribute("user")).getLogin();
  String userRole = ((User)session.getAttribute("user")).getRole();

 if (request.getMethod().equalsIgnoreCase("GET")) {

    lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");

 %>
<html>

<body >
<center>
<table width=90%>

 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("uploadDocument")%> : </b></font></td></tr>

 <form enctype="multipart/form-data" method="POST">
 <tr>
  <td colspan="3">
    <br>
  </td>
 </tr>

 <tr>
  <td colspan="3">
  <b><%=labels.getString("documentName")%> :</b> <br>
     <input type="text" name="Name" size="20">
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("documentDescription")%> :</b><br>
    <input type="text" name="Desc"  size="50">
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <input type="checkbox" name="copy">
    <b><%=labels.getString("copy")%></b>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <input type="checkbox" name="catch">
    <b><%=labels.getString("catch")%></b>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("chooseDocument")%> :</b><br>
     <input type="file" name="file">
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <br>
    <center><input type=submit name=action value="<%=labels.getString("upload")%>"> <input TYPE="reset" VALUE="<%=labels.getString("reset")%>" border="0" cellpadding="0" cellspacing="0">
    </center>
  </td>
 </tr>
</form>
</table>
</center>

</BODY>
</HTML>
  <%
}else{
  try{
   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String thingCopy="";
   String thingCatch="";
   String fileName="";

    Enumeration enumeration = new FilePostParser(request.getInputStream(),
                                                 request.getContentLength());
    while( enumeration.hasMoreElements() ) {
         Object element = enumeration.nextElement();
         if( element instanceof Map.Entry ) {
              Map.Entry entry = (Map.Entry)element;

              if ((entry.getKey()).equals("Name")){
	     	     thingName = (String)entry.getValue();

	      }
	      if ((entry.getKey()).equals("Desc")){
	             thingDesc = (String)entry.getValue();
	      }
	      if ((entry.getKey()).equals("copy")){
	             if(((String)entry.getValue()).equalsIgnoreCase("on")){
                       thingCopy = new String("true");
                     }else{
                       thingCopy = new String("false");
                     }

	      }
	      if ((entry.getKey()).equals("catch")){
	             if(((String)entry.getValue()).equalsIgnoreCase("on")){
                       thingCatch = new String("true");
                     }else{
                       thingCatch = new String("false");
                     }
	      }


         }
         else if( element instanceof PostFileInputStream ) {
              PostFileInputStream in = (PostFileInputStream)element;
              String s=in.getFileName();
              int index=s.lastIndexOf("\\");
              if(index == -1){
                 //Unix platform
                 index=s.lastIndexOf("/");
              }



              fileName=thingKey+"_"+s.substring(index+1);

              FileOutputStream fout = new FileOutputStream
        		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);

              int bite;
              while((bite=in.read()) != -1)
                   fout.write(bite);

              in.close();
              fout.close();
         }

    }
    ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
    ants.move.ejb.Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
    thing.setDescription(thingDesc);
    thing.setProperty("date",(new Date()).toGMTString());
    thing.setProperty("owner",userLogin);
    thing.setProperty("fileName",fileName);
    thing.setProperty("translation","0 1 0");
    thing.setProperty("rotation","0 0 1 0");
    thing.setProperty("scale","1 1 1 ");
    thing.setProperty("copy",thingCopy);
    thing.setProperty("catch",thingCatch);

   //Add Thing to running Move Applet
    Hashtable env = new Hashtable();
    Constants.init(request.getRealPath(""));
    env.put(Constants.NSPORT, Constants.getNSPort());
    env.put(Constants.ANTSCLASS, Constants.getAntsClass());
    env.put(Constants.SERVER, Constants.getServer());
    ants.comm.Session commSession = ants.comm.SessionFactory.createSession (env);

    Hashtable evt2 = new Hashtable();
    evt2.put(Constants.WORLD, worldKey);
    evt2.put(Constants.PLACE, placeKey);
    evt2.put("CLASS","DOC.V01");
    evt2.put("METHOD","NEWTHING");
    evt2.put("THINGKEY",thingKey);
    commSession.send(evt2);
    commSession.close();

    Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
%>
  <script> window.close(); </script>

<%}catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }

}
%>
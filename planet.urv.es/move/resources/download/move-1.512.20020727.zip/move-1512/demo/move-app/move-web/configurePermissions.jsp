<%@ page session="true" import = "ants.move.lang.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  World world=wm.getWorld((String)session.getAttribute("worldId"));
  String role=request.getParameter("role");
  Vector per= new Vector();
  int size=Integer.parseInt(world.getProperty(role+"size"));
  String toolId;
  for(int i=0;i<size;i++){
    toolId=world.getIndexedProperty(role,i);
    per.addElement(toolId);
  }

%>
<html>

<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES&linked=true" flush="true"/>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("configPermissions")%>: </b></font></td></tr>
   <tr>
 <% if (role.equals("teacher")){ %>    
      <td align="middle"><FONT FACE="impact" SIZE=6 COLOR="blue"><i><%=labels.getString("teacher")%></i></font></a>
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="configurePermissions.jsp?role=student"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("student")%></font></a>
      <br><br></td>
 <% }else{ %>
      <td align="middle"><a href="configurePermissions.jsp?role=teacher"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("teacher")%></font></a>
      &nbsp;&nbsp;&nbsp;&nbsp;<FONT FACE="impact" SIZE=6 COLOR="blue"><i><%=labels.getString("student")%></i></font></a>
      <br><br></td>

 <% } %>
   </tr>
</table>

   <table width="80%" border="0" bgcolor="teal">

   <th><font color="white"><%=labels.getString("nameThingTH")%></font></th>
   <th><font color="white"><%=labels.getString("descriptionTH")%></font></th>
   <th><font color="white"><%=labels.getString("thingType")%></font></th>
   <th><font color="white"><%=labels.getString("status")%></font></th>
   <th><font color="white"><%=labels.getString("action")%></font></th>

   <%
   Tool tool=null;
   for(Iterator i=tm.getTools().iterator();i.hasNext();){
    tool=(Tool)i.next();
    %>
    <tr bgcolor="#E6E4DD">
      <form method="post" action="configurePermissions.jsp">
      <td><%=lang.translateText(tool.getName(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))%></td>
      <td><%=lang.translateText(tool.getDescription(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))%></td>
      <td><%=tool.getType()%></td>
      <%
      if(per.contains(tool.getId())){
       %><td><%=messages.getString("active")%></td>
         <input type="hidden" name="toolId" value="<%=tool.getId()%>">
         <input type="hidden" name="role" value="<%=role%>">
         <td align="center"><input type="submit" value="<%=labels.getString("deactivate")%>"></td></form>
       <%
      }else{
       %><td><%=messages.getString("inactive")%></td>
         <input type="hidden" name="toolId" value="<%=tool.getId()%>">
         <input type="hidden" name="role" value="<%=role%>">
         <td align="center"><input type="submit" value="<%=labels.getString("activate")%>"></td></form>
       <%
      }
      %>
    </tr>
    <%
   }

   %>
   </table>
   <br><br>

  </center>
  <jsp:include page="footer.jsp" flush="true" />
 </HTML>
<%
}else{

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  World world=wm.getWorld((String)session.getAttribute("worldId"));
  String toolId=(String)request.getParameter("toolId");
  String role=request.getParameter("role");
  Vector per= new Vector();
  int size=Integer.parseInt(world.getProperty(role+"size"));
  String tool;
  for(int i=0;i<size;i++){
    tool=world.getIndexedProperty(role,i);
    per.addElement(tool);
  }
  if(per.contains(toolId)){
    per.removeElement(toolId);
  }else{
    per.addElement(toolId);
  }
  world.setProperty(role+"size",""+per.size());
  int count=0;
  for(int i=0;i<per.size();i++){
    world.setIndexedProperty(role,(String)per.elementAt(i),i);
  }
  response.sendRedirect("configurePermissions.jsp?role="+role);
}
%>


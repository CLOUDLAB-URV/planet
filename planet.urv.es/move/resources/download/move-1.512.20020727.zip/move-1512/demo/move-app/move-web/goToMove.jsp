<%@ page session="true" import="ants.move.lang.*, ants.move.ejb.*, com.protomatter.syslog.*, ants.comm.*, ants.move.core.*,ants.core.rmi.*, java.util.*, java.net.*, java.rmi.*" %>

<%! ResourceBundle labels;
    LanguageUtilities lang;   %>
<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");

  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "UserGateway remote object not bound. Let's bind it now...");
     try {
      Properties env = new Properties();
      env.put("ants.comm.port", "2917");
      env.put("java.naming.provider.url", InetAddress.getLocalHost().getHostName());
      env.put("ants.comm.class", "ants.comm.elvin.Session");
      // Create session
      ants.comm.Session ses = SessionFactory.createSession (env);
      Hashtable evt = new Hashtable();
      UserGatewayImpl engine = new UserGatewayImpl(ses, evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway", engine);
      Syslog.debug(this, "RMI User Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/UserGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }
  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/PlaceGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "PlaceGateway remote object not bound. Let's bind it now...");
     try {
      Hashtable evt = new Hashtable();
      PlaceGatewayImpl engine = new ants.core.rmi.PlaceGatewayImpl(evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/PlaceGateway", engine);
      Syslog.debug(this, "RMI Place Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/PlaceGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }
  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/ThingGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "ThingGateway remote object not bound. Let's bind it now...");
     try {
      Hashtable evt = new Hashtable();
      ThingGatewayImpl engine = new ThingGatewayImpl(evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/ThingGateway", engine);
      Syslog.debug(this, "RMI Thing Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/ThingGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }


  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  String userRole=((User)session.getAttribute("user")).getRole();
  String userLogin=((User)session.getAttribute("user")).getLogin();
  String userAvatar=((User)session.getAttribute("user")).getProperty("avatar");


  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  Thing thing=null;
  Tool tool;
  Place place=null;
  place=pm.getPlace(placeId);
  String placeType=place.getType();
  String jars= new String();
  jars= jars +"jars/ants-comm.jar,jars/je-4.jar,jars/move-core.jar";
  for (Iterator i=tm.getTools().iterator();i.hasNext();){
     tool=(Tool)i.next();
     if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
        if (!tool.getId().equalsIgnoreCase("netMeeting.v01"))
           jars=jars+",jars/move-"+tool.getId()+".jar";
     }
    }


%>
  <HTML><body>
  <script>
     function winOpen(param) {
         window.open('',param,'width=500,height=350,resizable=0,scrollbars=0')


     }
     function winOpen2(param) {
         window.open('',param,'width=640,height=480,resizable=0,scrollbars=1')


     }
     function openUsers() {
         msgWindow=window.open('usersInPlace.jsp','users','scrollbars=yes,width=500,height=250,resizable=0')
         if (msgWindow.opener == null) msgWindow.opener = self;
     }
   </script>

  <center>

  <table width=90%>
   <tr><td colspan="2" bgcolor="#00800F"><font color="white"><b>Multiuser Oriented Virtual Environments</b></font></td>
   <td align="right" bgcolor="#00800F"><a href="leavePlace.jsp"><FONT FACE="impact" COLOR="white"><%=labels.getString("exit")%></font></a></td></tr>
   <tr>
  <td valign="top">


    <table align="center">
      <th colspan="2"><a href="listThings.jsp?placeId=<%=placeId%>"><img src="images/moveSmall.jpg" border="0"></th>
      <tr>
       <td><FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%>:</FONT>&nbsp;</td>
       <td>

       <%if(place.getProperty("doc.v01").equalsIgnoreCase("active")){%>
         <a href="createDocument.jsp?user=<%=userLogin%>" title="<%=labels.getString("uploadFile")%>" target="createDoc" onClick="winOpen('createDoc');"  ><img src="images/docSmall.gif" border="0"></a>
       <%}
         if(place.getProperty("url.v01").equalsIgnoreCase("active")){%>
         <a href="createUrl.jsp?user=<%=userLogin%>" title="<%=labels.getString("createUrl")%>" target="createURL" onClick="winOpen('createURL');"  ><img src="images/urlSmall.gif" border="0"></a>
       <%}
         if(place.getProperty("object.v01").equalsIgnoreCase("active")){%>
         <a href="createObject.jsp?user=<%=userLogin%>" title="<%=labels.getString("uploadObject")%>" target="createObject" onClick="winOpen('createObject');" ><img src="images/objectSmall.gif" border="0"></a>
       <%}

       %>
         <a href="bagList.jsp?user=<%=userLogin%>" title="<%=labels.getString("bag")%>" target="bagList" onClick="winOpen2('bagList');"  ><img src="images/bag.gif" border="0"></a>
       </td>
      </tr>
      <tr>
       <td>
       </td>
      </tr>
   <% if(place.getProperty("netMeeting.v01").equalsIgnoreCase("active")){ %>
     <tr>
       <td colspan="2">
        <object ID="NetMeeting" CLASSID="CLSID:3E9BAF2D-7A79-11d2-9334-0000F875AE17">
        <PARAM NAME = "MODE" VALUE = "RemoteOnly"></object>
        <object ID="NetMeetingPreview" CLASSID="CLSID:3E9BAF2D-7A79-11d2-9334-0000F875AE17">
        <PARAM NAME = "MODE" VALUE = "PreviewOnly"></object>
        <input type=button value ="<%=labels.getString("hangUp")%>" id=HangUpBtn onclick=NetMeeting.LeaveConference()>
        <input type=button value ="<%=labels.getString("usersBtn")%>" id=UsersBtn onclick="openUsers();">
       </td>
      </tr>

   <% }  %>

    </table>
  </td>

    <td colspan="2" align="center">
     <EMBED SRC="worlds/<%=worldId%>/<%=placeId%>/<%=placeId%>.wrl" HEIGHT="300" WIDTH="560">

     <APPLET CODE="ants.move.core.MOVECoreApplet.class" mayscript WIDTH="560" HEIGHT="150"
          ALIGN="ABSCENTER"
          ARCHIVE="<%=jars%>">
            <PARAM name=worldKey value="<%=worldId%>">
	    <PARAM name=placeKey value="<%=placeId%>">
            <PARAM name=userRole value="<%=userRole%>">
            <PARAM name=userLogin value="<%=userLogin%>">
            <PARAM name=placeType value="<%=placeType%>">
            <PARAM name=avatar value="<%=userAvatar%>">
    </APPLET>
    <br>
  </td>
  </td>
 </tr>
 </table>

</center>
  <jsp:include page="footer.jsp" flush="true"/>
</HTML>





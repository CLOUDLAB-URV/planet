// Package ants.move.core.models.slides
// SlidesListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.slides;

/** SlidesListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface SlidesListener {
/**
 * Set picture
 * @param url picture source url
 */
  public void setPicture (String url);
  /**
   * Destroy method
   */
  public void destroy();
}
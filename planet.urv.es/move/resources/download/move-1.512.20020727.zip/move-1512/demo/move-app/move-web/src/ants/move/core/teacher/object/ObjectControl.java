package ants.move.core.teacher.object;

import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.object.*;
import ants.move.core.views.object.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Frame;
import java.awt.Color;
import java.awt.TextArea;

import java.util.*;
import java.net.*;
import java.awt.event.*;

import vrml.external.Browser;

/** Implementation of Object User Interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator : Carles Pairot (cpairot@tinet.org)
    @version 1.00 Build 2002
*/
public class ObjectControl extends Frame{

  private Button catchButton;
  private Button copyButton;
  private Button moveButton;
  private Button removeButton;
  private Label nameLabel;
  private Label descriptionLabel;
  private Label dateLabel;
  private Label ownerLabel;
  private Label name;
  private TextArea description;
  private Label date;
  private Label owner;
  private ObjectThing oT;
  private ObjectThingView oTV;
  private Browser browser;

  public ObjectControl(){
    catchButton= new Button("Catch");
    catchButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        catchButton_actionPerformed(e);
      }
    });
    copyButton= new Button("Copy");
    copyButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        copyButton_actionPerformed(e);
      }
    });
    moveButton= new Button("Move");
    moveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        moveButton_actionPerformed(e);
      }
    });
    removeButton= new Button("Remove");
    removeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeButton_actionPerformed(e);
      }
    });
    nameLabel = new Label("Name:");
    nameLabel.setForeground(Color.blue);
    descriptionLabel = new Label("Description:");
    descriptionLabel.setForeground(Color.blue);
    dateLabel = new Label("Date:");
    dateLabel.setForeground(Color.blue);
    ownerLabel = new Label("Owner:");
    ownerLabel.setForeground(Color.blue);

    this.enableEvents(WindowEvent.WINDOW_EVENT_MASK);
    this.setLayout(new FlowLayout());
    Panel p = new Panel();
    p.add(catchButton);
    p.add(copyButton);
    p.add(moveButton);
    p.add(removeButton);
    p.setVisible(true);
    this.setSize(250,300);
    this.setLocation(700,250);
    this.setResizable(false);
    this.add(p);
    this.setVisible(false);
    this.setTitle("Move! Object");
  }

  public void init(Hashtable ht){
  try{
    oT= (ObjectThing)ht.get("objectThing");
    browser = (Browser)ht.get("browser");
    oTV = (ObjectThingView)ht.get("objectThingView");
    name = new Label(oT.getName());
    description = new TextArea(oT.getDescription(),1,10,TextArea.SCROLLBARS_HORIZONTAL_ONLY);
    description.setEditable(false);
    date = new Label(oT.getProperty("date"));
    owner = new Label(oT.getProperty("owner"));
    Panel p2 = new Panel();
    p2.setBackground(Color.lightGray);
    p2.add(nameLabel);
    p2.add(name);
    Panel p3 = new Panel();
    p3.setBackground(Color.lightGray);
    p3.add(descriptionLabel);
    p3.add(description);
    Panel p4 = new Panel();
    p4.setBackground(Color.lightGray);
    p4.add(dateLabel);
    p4.add(date);
    Panel p5 = new Panel();
    p5.setBackground(Color.lightGray);
    p5.add(ownerLabel);
    p5.add(owner);
    this.add(p2);
    this.add(p3);
    this.add(p4);
    this.add(p5);
    this.setVisible(true);
    initButtons();
   }catch(Exception ex){ex.printStackTrace();}
  }

  private void initButtons(){
    try{
      if(!this.oT.getProperty("catch").equalsIgnoreCase("true")){
        this.catchButton.enable(false);
      }
      if(!this.oT.getProperty("copy").equalsIgnoreCase("true")){
        this.copyButton.enable(false);
      }
      if((oT.getPlace().getUser().equalsIgnoreCase(oT.getProperty("owner")))
      ||(oT.getPlace().getRole().equalsIgnoreCase("root"))){
        this.removeButton.enable();
        this.moveButton.enable();
      }else{
        this.removeButton.enable(false);
        this.moveButton.enable(false);
      }

    }catch(Exception ex){ex.printStackTrace();}
  }

  void catchButton_actionPerformed (ActionEvent e) {
    try{
      if(catchButton.getLabel().equalsIgnoreCase("Deploy")){
        oT.getModel().deployThing(oT.getThingId());

        if(this.oT.getProperty("copy").equalsIgnoreCase("true")){
           this.copyButton.enable(true);
        }
        if((oT.getPlace().getUser().equalsIgnoreCase(oT.getProperty("owner")))
        ||(oT.getPlace().getRole().equalsIgnoreCase("root"))){
           this.removeButton.enable(true);
           this.moveButton.enable(true);
        }
        this.dispose();
      }else{
        oT.getModel().catchThing(oT.getThingId());
        catchButton.setLabel("Deploy");
        this.copyButton.enable(false);
        this.moveButton.enable(false);
        this.removeButton.enable(false);

      }
    }catch(Exception ex){}
  }

  void copyButton_actionPerformed (ActionEvent e) {
    try{
        oT.getPlace().addToBag(oT.getThingId());
        this.dispose();
    }catch(Exception ex){}
  }


  void moveButton_actionPerformed (ActionEvent e) {
    try{
      Hashtable params = new Hashtable();
      params.put("objectThing",oT);
      params.put("objectThingView",oTV);
      ObjectMoveControl oc= new ObjectMoveControl();
      oc.init(params);
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }


  void removeButton_actionPerformed (ActionEvent e) {
    try{
     if(this.oT.getPlace().hasPermission("object.v01")){
      String[] destination = new String[1];
      String[] params = new String[1];
      destination[0]="../../../deleteObject.jsp?thingId="+oT.getThingId()+"&name="+oT.getProperty("fileName");
      params[0]="target=\"_blank\"";
      browser.loadURL(destination,params);
      oT.getModel().sendRemoveThing(oT.getThingId());
     }
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e);
     if(!catchButton.getLabel().equalsIgnoreCase("Deploy")){
      if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        this.dispose();
      }
     }
  }



}
package ants.core.rmi;

import java.util.*;

public interface PlaceGateway extends java.rmi.Remote {
//  public void join (String wName, String pName, String uName, String role) throws java.rmi.RemoteException;
//  public void leave (String wName, String pName, String uName) throws java.rmi.RemoteException;
//  public Vector getUsers (String wName, String pName) throws java.rmi.RemoteException;
  public Hashtable loadModels (String pName) throws java.rmi.RemoteException;
  public Vector getThings (String pName, String type) throws java.rmi.RemoteException;
//  public boolean checkJLESession (Hashtable env) throws java.rmi.RemoteException;
//  public String getJLESessionAttribute (Hashtable env, String attr) throws java.rmi.RemoteException;
//  public void addUser (String wName, String pName, String usr) throws java.rmi.RemoteException;
//  public void removeUser (String wName, String pName, String usr) throws java.rmi.RemoteException;
}
package ants.comm.examples;

import ants.comm.*;
import java.util.*;

public class ListenerX implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("TerraCAROBnce event !!!");
			System.out.println("LOTA  Terrance event !!!");

			Persona x = (Persona)evt.get("object");
			System.out.println(x.name);
			
			
			
		}
	}	
		
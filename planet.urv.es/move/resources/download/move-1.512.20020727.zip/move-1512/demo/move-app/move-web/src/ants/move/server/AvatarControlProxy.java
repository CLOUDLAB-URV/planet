package ants.move.server;

/**
 * Title:        AvatarControlProxy
 * Description:  Capture avatar movement events
 * Copyright:    Copyright (c) 2002
 * Company:      MOVE! TF
 * @author       Oriol Montal�, Francesc Pi�as and Carles Pairot
 * @version 1.0
 */

import ants.comm.*;
import java.util.*;

public class AvatarControlProxy implements RemoteEventListener{
  private Session session;
  private Hashtable subscription = new Hashtable();
  private Hashtable subscription2 = new Hashtable();
  private Hashtable subscription3 = new Hashtable();
  private HashMap space = new HashMap(); // space(world/place)-->users(user)
  private HashMap users;

  public AvatarControlProxy(Session session) {
    this.session=session;
    // movement event listener
    subscription.put("CLASS", "AVATAR");
    subscription.put("SRC", "MOVE");
    //newUser event listener
    subscription2.put("METHOD", "newUser");
    //delUser event listener
    subscription3.put("CLASS", "Avatar");
    subscription3.put("METHOD", "delUser");
    try {
      session.addRemoteEventListener (this, subscription);
      session.addRemoteEventListener (this, subscription2);
      session.addRemoteEventListener (this, subscription3);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }

  }

  public void addUser(String world,String place,String user){
      if( space.containsKey(world+"/"+place)){
        HashMap u = (HashMap)space.get(world+"/"+place);
        u.put(user,new UserProxy(world,place,user,session,(float)15));
      }else{
        space.put(world+"/"+place, new HashMap());
        HashMap u = (HashMap)space.get(world+"/"+place);
        u.put(user,new UserProxy(world,place,user,session,(float)15));
      }
  }

  public void removeUser(String world,String place,String user){
      HashMap u = (HashMap)space.get(world+"/"+place);
      u.remove(user);
      if (u.isEmpty()){
        space.remove(world+"/"+place);
      }
  }


  public void eventArrived (Hashtable evt) {
   try{
    if(((String)evt.get("SRC")).equalsIgnoreCase("MOVE")){
//      System.out.println("[MOVE PROXY]-->MOVE User "+(String) evt.get("USER"));
      String user = (String) evt.get("USER");
      String place = (String) evt.get("PLACE");
      String world = (String) evt.get("WORLD");
      users = (HashMap)space.get(world+"/"+place);
      UserProxy userProxy=(UserProxy)users.get(user);
      userProxy.setPosition(evt);  //Actualize avatar pilot position
      for(Iterator i=users.values().iterator();i.hasNext();){  //send event to avatars
        userProxy=(UserProxy)i.next();
//        System.out.println("[MOVE PROXY]-->MOVE UserIteration "+(String) evt.get("USER"));
        userProxy.moveAvatar(evt);   //
      }

    }else if(((String)evt.get("METHOD")).equalsIgnoreCase("newUser")){

//      System.out.println("[MOVE PROXY]-->new User "+(String) evt.get("USER"));
      this.addUser((String)evt.get("WORLD"),(String)evt.get("PLACE"),(String)evt.get("USER"));

    }else if(((String)evt.get("METHOD")).equalsIgnoreCase("delUser")){

//      System.out.println("[MOVE PROXY]-->remove User "+(String) evt.get("USER"));
      this.removeUser((String)evt.get("WORLD"),(String)evt.get("PLACE"),(String)evt.get("USER"));
    }
   }catch(Exception e){}
  }

}
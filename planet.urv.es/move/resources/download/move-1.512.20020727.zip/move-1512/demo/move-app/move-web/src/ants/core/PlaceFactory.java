package ants.core;

import ants.comm.*;
import java.util.*;
import java.io.*;
import java.net.*;
import ants.util.*;

/**
*		Facility class that connects to a specified session (Place) transparently accessing the specified Notification service
*   It is built on top of the the ants.comm API.
*/


public class PlaceFactory
{
	
	
	public static Place createPlace(Session ses,Hashtable env)
		throws SessionException
	{
		
			Place ch = new Place(ses,env);
			return ch;
			
	}	
	
	public static Place createPlace(Session ses,String envFile)
		throws SessionException
	{
			try
			{
				FileInputStream  fis = new FileInputStream(envFile);
				Properties env = new Properties();
				env.load(fis);

				Place ch = new Place(ses,env);
				return ch;
			}catch(IOException ex){
				
				throw new SessionException(ex);
	
			}
	}	

	/**
	*	 Static factory method that connects to a specified Place. It also joins the shared session.
	*	@param env Hashtable Environment connection properties
	* @see ants.core.Context
	* @return ants.core.Place return a reference to the shared session (Place).
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/
		
	
	public static Place createPlace(Hashtable env)
		throws SessionException
	{
		
		try
		{
	
			String worldName = (String)env.get(Context.WORLD);
			String baseURL = (String)env.get(Context.BASE);


			
			
			URL url = new URL(baseURL+worldName+"/"+worldName+".properties");
			Properties env2 = new Properties();
			env2.load(url.openStream());
			String bus = (String)env2.get(Context.BUS);
			
			env.put(Context.BUS,bus);
			
			
			URL url2 = new URL(baseURL+"bus/"+bus+".properties");
			Properties env3 = new Properties();
			env3.load(url2.openStream());


			
			Session ses = SessionFactory.createSession(env3);


			Place ch = new Place(ses,env);



			return ch;
		}catch (java.io.IOException e5)
			{
				 throw new SessionException(e5);

			}
			
	}	
	

		/**
	*	 Static factory method that connects to a specified Place. It also joins the shared session.
	*	@param envFile File name containing connection properties
	* @see ants.core.Context
	* @return ants.core.Place return a reference to the shared session (Place).
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/

	
		public static Place createPlace(String envFile)
		throws SessionException
		{
		try
		{
			FileInputStream  fis = new FileInputStream(envFile);
			Properties env = new Properties();
			env.load(fis);
			
			return createPlace(env);
		
	
		
		} catch (java.io.FileNotFoundException e4)
		{
				 throw new SessionException(e4);
		}catch (java.io.IOException e5)
		{
				 throw new SessionException(e5);
		}

	}	

	/**
	*	 Static factory method that connects to a specified Place.It avoids stablishing a new connection to the event bus by reusing the connection when the bus name is the same. It also joins the shared session.
	*	@param envFile File name containing connection properties
	*	@param oldPlace Previously used place
	* @see ants.core.Context
	* @return ants.core.Place return a reference to the shared session (Place).
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/

 
		public static Place createPlace(String envFile,Place oldPlace)
		throws SessionException
		{
		try
		{
			FileInputStream  fis = new FileInputStream(envFile);
			Properties env = new Properties();
			env.load(fis);
			
			
					
			return createPlace(env,oldPlace);

		
	
		
		} catch (java.io.FileNotFoundException e4)
		{
				 throw new SessionException(e4);
		}catch (java.io.IOException e5)
		{
				 throw new SessionException(e5);
		}

	}	

		/**
	*	 Static factory method that connects to a specified Place.It avoids stablishing a new connection to the event bus by reusing the connection when the bus name is the same. It also joins the shared session.
	*	@param env Hashtable containing connection properties
	*	@param oldPlace Previously used place
	* @see ants.core.Context
	* @return ants.core.Place return a reference to the shared session (Place).
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/

	
	
		public static Place createPlace(Hashtable env,Place oldPlace)
		throws SessionException
		{
		try
		{
				
			
			String worldName = (String)env.get(Context.WORLD);
			String baseURL = (String)env.get(Context.BASE);

		

		

			
			URL url = new URL(baseURL+worldName+"/"+worldName+".properties");
			Properties env2 = new Properties();
			env2.load(url.openStream());
			String bus = (String)env2.get(Context.BUS);
		
			
			env.put(Context.BUS,bus);
			
			if (bus.equals(oldPlace.getBus()))
				return createPlace(oldPlace.getSession(),env);

			URL url2 = new URL(baseURL+"bus/"+bus+".properties");
			Properties env3 = new Properties();
 	
			env3.load(url2.openStream());



			Session ses = SessionFactory.createSession(env3);


			Place ch = new Place(ses,env);
			
			return ch;

		
	
		
		} catch (java.io.FileNotFoundException e4)
		{
				 throw new SessionException(e4);
		}catch (java.io.IOException e5)
		{
				 throw new SessionException(e5);
		}

	}	
	
	/**
	*	 Static factory method that connects to a specified Place. It also joins the shared session.
	*	@param env fileUrl URL containing environment connection properties
	* @see ants.core.Context
	* @return ants.core.Place return a reference to the shared session (Place).
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/
		
		
		public static Place createPlace(URL fileUrl)
		throws SessionException
		{
 
	 	try
			{
				Properties env = new Properties();
				env.load(fileUrl.openStream());
				
					
				String worldName = (String)env.get(Context.WORLD);
				String baseURL = (String)env.get(Context.BASE);

				URL url = new URL(baseURL+worldName+"/"+worldName+".properties");
				Properties env2 = new Properties();
				env2.load(url.openStream());
				String bus = (String)env2.get(Context.BUS);

				URL url2 = new URL(baseURL+"bus/"+bus+".properties");
				Properties env3 = new Properties();
				env3.load(url2.openStream());
		

				
				Session ses = SessionFactory.createSession(env3);

				Place ch = new Place(ses,env);
				return ch;
						

			
				}catch (java.io.IOException e5)
			{
				 throw new SessionException(e5);
			}


		}

	
	
}
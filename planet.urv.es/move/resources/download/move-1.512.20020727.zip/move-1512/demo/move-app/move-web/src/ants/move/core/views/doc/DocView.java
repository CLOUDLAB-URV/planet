package ants.move.core.views.doc;
/**
* Package ants.move.core.views.doc
* DocView.java
* Implementation of DOC Tool
* (C) 2002 Oriol Montal� & Carles Pairot
*/

// ANTS imports
import ants.move.core.views.*;
import ants.move.core.models.*;
import ants.move.core.models.doc.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of Documentation Repository.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 0.01 Build 2002
*/
public class DocView extends DynamicObject implements ViewInterface,DocListener {
  private Hashtable docThingViews;
  private Place place;
  private DocModel dM;
  private DynamicObject root;
  private Node proximitySensor;
  // EventOut avatar position
  private EventOutSFVec3f positionChanged;
  // EventOut avatar orientation
  private EventOutSFRotation orientationChanged;


   /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public DocView () {
  }

  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));
    root=(DynamicObject)ht.get("root");
    place=(Place)ht.get("place");
    dM = (DocModel) place.getModel(super.getName());
    if (dM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: DOC");
    }
    dM.addDocListener(this);
    docThingViews= new Hashtable();
    Hashtable docThings=dM.getDocThings();
    String docKey;
    for(Enumeration en=docThings.keys();en.hasMoreElements();){
      docKey=(String)en.nextElement();
      ht.put("docThing",docThings.get(docKey));
      DocThingView dTV= new DocThingView (ht);
      docThingViews.put(docKey,dTV);
    }

    proximitySensor = getBrowser().getNode("PS");   // catch the scene's ProximitySensor

    System.err.println ("[MOVE] - Object DOC VRML view initialized.");
  }
  public void newThing(DocThing dT){
   try{
     if(dT.getProperty("owner").equalsIgnoreCase(dM.getPlace().getUser())){
        // Capture VRML position & orientation of avatar
        float[] t = new float[3];
        float[] r = new float[4];
        positionChanged=(EventOutSFVec3f)proximitySensor.getEventOut("position_changed");
        orientationChanged=(EventOutSFRotation)proximitySensor.getEventOut("orientation_changed");
        t = positionChanged.getValue();
        r = orientationChanged.getValue();
        dT.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
        dT.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
     }
     Hashtable params = new Hashtable();
     params.put("docThing",dT);
     params.put("browser",getBrowser());
     params.put("root",root);
     DocThingView dTV= new DocThingView (params);
     docThingViews.put(dT.getThingId(),dTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Doc Thing");ex.printStackTrace();}
  }

  public void loadThing(DocThing dT){
   try{
     Hashtable params = new Hashtable();
     params.put("docThing",dT);
     params.put("browser",getBrowser());
     params.put("root",root);
     DocThingView dTV= new DocThingView (params);
     docThingViews.put(dT.getThingId(),dTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Doc Thing");ex.printStackTrace();}
  }


  public void refreshThing(String docThingId){
    ((DocThingView)docThingViews.get(docThingId)).show();
  }

  public void removeThing(String docThingId){
    DocThingView dtv =(DocThingView)docThingViews.get(docThingId);
    docThingViews.remove(docThingId);
    dtv.destroy();
  }

  public void catchThing(String docThingId){
    ((DocThingView)docThingViews.get(docThingId)).catchMe();
  }

  public void deployThing(String docThingId){
    ((DocThingView)docThingViews.get(docThingId)).deploy();
  }


  }

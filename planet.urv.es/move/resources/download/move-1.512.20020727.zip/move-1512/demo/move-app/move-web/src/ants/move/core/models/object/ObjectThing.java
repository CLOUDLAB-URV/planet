package ants.move.core.models.object;

import ants.core.*;

public class ObjectThing extends Thing implements PropertyChangeListener {
  private ObjectModel oM;
  private String myId;

  public void init() {
    addPropertyChangeListener(this);
    myId=getContext().getThing();
//    System.err.println("[MOVE] - Object " + getContext().getThing() + " initialized.");
  }

  public void setModel (ObjectModel m) {
    oM = m;
  }

  public ObjectModel getModel () {
    return oM;
  }


  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();
    try {
      // Translation change
      if (propName.equals("translation")) {
        oM.refreshThing(myId);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void destroy () {
    super.destroy();
  }
}
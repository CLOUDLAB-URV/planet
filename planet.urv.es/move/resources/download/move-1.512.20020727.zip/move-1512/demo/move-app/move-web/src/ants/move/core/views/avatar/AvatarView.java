// Package ants.move.core.views.avatar
// AvatarView.java
// Avatar implementation
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.avatar;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;
import ants.move.core.views.DynamicObject;
import ants.move.core.models.avatar.*;
import ants.move.core.teacher.chat.ChatWindow;

// java.util Package imports
import java.util.Hashtable;
import java.util.zip.*;

import java.net.URL;
import java.net.MalformedURLException;
import java.io.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Avatar implementation.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.22 Build 2000
*/
public class AvatarView extends DynamicObject implements AvatarListener {

  private float avatarHeight = 1.75f;

  // Node that contains avatar
  private Node[] avatarNodes;
  // Auxiliary node that contains avatar
  private Node[] auxAvtrNodes;
  // Node that contains avatar's name
  private Node[] avatarTxt;
  // DynamicObject used for avatar
  private DynamicObject root;
  // EventIn avatar's position (so it can be changed)
  private EventInSFVec3f avatarPosition = null;
  // EventIn avatar's orientation (so it can be changed)
  private EventInSFRotation avatarRotation = null;
  // To enable avatar movement

  private EventInSFTime startTime = null;
  private EventInSFTime stopTime = null;
  private EventInSFBool enableGreeting = null;
  private EventInSFBool enableHandUp = null;
  private EventInSFBool enableHandDown = null;
  private EventInSFBool enablePoint = null;
//en  private EventInSFBool enableDancing = null;
  private Node defaultViewpoint;

  // Avatar's name
  private String username;
  private Place conn;
  // Used for avatar's movements
  private AvatarMovement movementsThread;
  private String avatarRepresentation;
  private EventInMFNode avtAddChildren, avtRemChildren;
  private AvatarModel aM;
  private ChatWindow chatWin;
  private int avatarNum;
  private Node[] avatarBody;
  Float[] pos = new Float[3];
  Float[] ori = new Float[4];

  // If an avatar's representation has not yet been loaded and it has received
  // a destroy event, it must wait until it has been loaded
  private boolean toBeDestroyed = false;

  // Is the avatar's representation loaded ?
  private boolean avatarLoaded = false;

  public AvatarView() {
  }

  /** Sole constructor.
      @exception exceptions No exceptions thrown
  */


  public AvatarView (Place ch, Hashtable env) {
    super();
    super.setBrowser((Browser) env.get("browser"));
    root = (DynamicObject) env.get("root");
    username = (String) env.get ("USER");
    avatarRepresentation = (String) env.get("avtRep");
    avatarNum= Integer.parseInt((String) env.get("avatarNum"));
    conn = ch;
    pos = (Float[]) env.get ("POS");
    ori = (Float[]) env.get ("ORI");
    root.setChNodes();        // add / removeChildren
//    movementsThread = (AvatarMovement) env.get("mT");
    chatWin = (ChatWindow)env.get("chatWin");
  }

  public void loadAvatar(){
    String str = new String();
    String auxstr = new String();

    byte[] buffer = new byte[1024];
    int i;

    // Add avatar to VRML scene
    try {
      URL avtURL = new URL (avatarRepresentation);
      ZipInputStream bis = new ZipInputStream(new BufferedInputStream(avtURL.openStream()));

      ZipEntry ze;
      if ((ze = bis.getNextEntry()) != null) {
          System.err.println("[ MOVE! ] - Loading compressed avatar file: " + ze);
          while((i = bis.read(buffer, 0, 1024)) != -1) {
            auxstr = new String (buffer);
            if (i != 1024) {
              byte[] buf2 = new byte[i];
              for (int k=0; k<i; k++) {
                buf2[k]=buffer[k];
              }
              auxstr = new String (buf2);
            }
            str = str + auxstr;
          }
          System.err.println("[ MOVE! ] - Avatar file " + ze + " loaded.");
      }
      bis.close();

    } catch (Exception e) {System.err.println("Exception occured in avatar file: " + avatarRepresentation); e.printStackTrace();}

      // Create Avatar's name node
    avatarTxt = getBrowser().createVrmlFromString("Transform { translation -0.2 0.3 0 children [ Shape { appearance Appearance { material Material { diffuseColor 1 1 1 } " +
       " } geometry Text { string \"" + username + "\" fontStyle FontStyle { horizontal TRUE " +
       " size 0.15 } } } ] }");

    // Create Avatar's shape node
    auxAvtrNodes = getBrowser().createVrmlFromString(str);
    str=null;
//     chatWin.consoleMessage("Get Avatar:"+avatarNum);
//     avatarBody[0] = getBrowser().getNode("AVATAR"+avatarNum);
//     chatWin.consoleMessage("Get Avatar: OK "+avatarNum);

    // Catch translation, rotation & movement enabling so as we can change
    // them whenever we need to
    avatarPosition = (EventInSFVec3f) avatarNodes[0].getEventIn("translation");
    avatarRotation = (EventInSFRotation)avatarNodes[0].getEventIn("rotation");

      // Specification of old avatars (H-Anim 1.2 compatible)
        // Node auxAvtrNodes[0] == Protos
        // Node auxAvtrNodes[1] == WorldInfo
        // Node auxAvtrNodes[2] == DEF Stand_Time
        // Node auxAvtrNodes[3] == DEF Walk_Time      <====
        // Node auxAvtrNodes[4] == DEF hello_Time     <====
        // Node auxAvtrNodes[5] == DEF handUp_Time    <====
        // Node auxAvtrNodes[6] == DEF handDown_Time  <====
        // Node auxAvtrNodes[7] == DEF indicate_Time  <====
        // Node auxAvtrNodes[8] == DEF Humanoid
        // Node auxAvtrNodes[9] == DEF Animations

      // Specification of new avatars (AvatarStudio 2.0 created)
        // Node auxAvtrNodes[0] == Avatar
            // EventIn set_gesture1
            // ...
            // EventIn set_gesture12 <== Default walk gesture

    try {

      startTime = (EventInSFTime) auxAvtrNodes[0].getEventIn("set_gesture12");
      startTime.setValue((System.currentTimeMillis() / 1000));

    } catch (Exception xc) {
        System.err.println("[MOVE] - Avatar not compatible with H-Anim v1.1 standard.");
        System.err.println("[MOVE] - Avatar will not be animated.");
    }
    avatarLoaded=true;
  }


  public void init () {
   // Common code for pilot and non-pilot avatars
    Hashtable ht = new Hashtable();
    ht.put("CLASS", "Avatar");
    ht.put("SRC", "MOVEAvatars");
    ht.put("USER", username);
    ht.put("pilot", Boolean.FALSE);
    ht.put("avtRep", avatarRepresentation);
    ht.put("chatWin",chatWin);


    aM = new AvatarModel (conn, ht);

    aM.addAvatarListener(this);
    aM.setActualPosition(pos);
    aM.setActualOrientation(ori);

    try {
        // Create avatar shape
        String avatarString = "Transform\n" +
                  "{\n" +
                  "rotation " + ori[0] + " " + ori[1] + " " + ori[2] + " " + ori[3] + "\n" +
		  "translation " + pos[0] + " " + pos[1]/*.floatValue() + avatarHeight)  - 0.6f */ + " " + pos[2] + "\n" +
		  "children []\n" +
  	    	  "}\n";
        avatarNodes = getBrowser().createVrmlFromString (avatarString);
        // Capture all avatar nodes
        root.setaddChValue(avatarNodes);
        // Capture all EventIns
        avtAddChildren = (EventInMFNode) avatarNodes[0].getEventIn("addChildren");
        avtRemChildren = (EventInMFNode) avatarNodes[0].getEventIn("removeChildren");
    }
     	catch (Exception e) {
        System.err.println("Exception capturing avatar: " + e);
        e.printStackTrace();
    }

      // Check whether a destroy event has been received
    if (toBeDestroyed) {
      // A previous destroy event was received but it was impossible to do it then
      // Let's destroy him NOW!
      destroyAvatar();
    }

 }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Get user's name.
      @param params None
      @return User's name
      @exception exceptions No exceptions thrown
  */
  public String getUserName() {
    return username;
  }


  public void moveAvatar (float[] p, float[] o) {

/*    if (enableGreeting != null) {
      // Stop greeting movement
      greeting = false;
      enableGreeting.setValue(false);
    }
*/
/*    if (enableDancing != null) {
      // Stop dancing movement
      dancing = false;
      enableDancing.setValue(false);
    } */

    if (avatarLoaded){
      // Add movement to movements Vector in movementsThread
      AvatarMovement am= new AvatarMovement(new AvatarInformation (avatarPosition,
                                                avatarRotation, startTime, stopTime, p, o));
//      (movementsThread.getMovements()).addElement(new AvatarInformation (avatarPosition,
//                                                avatarRotation, startTime, stopTime, p, o));
    }else{
      //avatar enter in Pilot's Influence Area
      loadAvatar();
      showAvatar();
    }
    // Awake movementsThread (if sleeping)
/*    synchronized (movementsThread) {
     movementsThread.threadSuspended = !(movementsThread.threadSuspended);

      if ((!movementsThread.threadSuspended)) {
        movementsThread.restart();
      }
    }
*/
  }

  // Destroys avatar representation
  public void destroyAvatar() {
    if (avatarLoaded) {
      aM.removeAvatarListener(this);
      avtRemChildren.setValue(auxAvtrNodes);   // Avatar hidden
//      avtRemChildren.setValue(avatarBody);   // Avatar hidden
      avtRemChildren.setValue(avatarTxt);
      // Deactivate all movement
    /*  synchronized (movementsThread) {
        movementsThread.avatarEnabled = false;
      }*/
    }

    toBeDestroyed = true;
  }

  // Hides avatar
  public void hideAvatar() {
    if (avatarLoaded) {
      avtRemChildren.setValue(auxAvtrNodes);   // Avatar hidden
      avtRemChildren.setValue(avatarTxt);
      avatarLoaded=false;
      auxAvtrNodes=null;
      avatarTxt=null;
    }
        // Deactivate all movement
  /*     synchronized (movementsThread) {
          movementsThread.avatarEnabled = false;
        }*/
  }

  // Show Avatar in VRML Scene
  public void showAvatar() {
    if (avatarLoaded) {
      avtAddChildren.setValue(auxAvtrNodes);   // Avatar shown
      avtAddChildren.setValue(avatarTxt);
    }
      // Activate all movement
  /*    synchronized (movementsThread) {
        movementsThread.avatarEnabled = true;
      }*/

  }


  public void leaveSession() {
    aM.leaveSession();
  }

  private boolean greeting = false;
  private boolean dancing = false;

  public void greetAvatar() {
    if (!greeting) {
      enableGreeting.setValue(true);
      greeting = true;
    }
    else {
      enableGreeting.setValue(false);
      greeting = false;
    }
  }

  public AvatarModel getModel(){
    return aM;
  }

  public void danceAvatar() {
    if (!dancing) {
//System.err.println("DANCING ENABLED!");
//      enableDancing.setValue(true);
      dancing = true;
    }
    else {
//System.err.println("DANCING DISABLED!");
//      enableDancing.setValue(false);
      dancing = false;
    }
  }
}

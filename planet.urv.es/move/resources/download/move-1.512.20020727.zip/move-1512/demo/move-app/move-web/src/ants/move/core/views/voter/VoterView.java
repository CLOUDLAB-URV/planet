// Package ants.move.core.views.voter
// VoterView.java
// (C) 2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.voter;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.voter.*;
import ants.move.core.teacher.voter.*;
import ants.move.core.*;

// java.util Package imports
import java.util.*;
import java.net.*;
import java.io.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of DynamicObject VRML View: Voter.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.00 Build 2001
*/
public class VoterView extends DynamicObject implements VoterListener,
                                                        ViewInterface,
                                                        VRMLEventListener {
  // Appearance nodes
  private Node apps[] = new Node[3];
  // Material nodes
  private Node mats[] = new Node[3];
  // Shape nodes
  private Node shapes[] = new Node[3];
  // Color nodes
  private EventInSFColor colors[] = new EventInSFColor [3];
  // Transform nodes
  private Node transforms[] = new Node[3];
  // Transform EventIns
  private EventInSFVec3f tEIn[] = new EventInSFVec3f[3];
  // Scale EventIns
  private EventInSFVec3f sEIn[] = new EventInSFVec3f[3];
  // Text EventIns
  private EventInSFVec3f txtTransEIn[] = new EventInSFVec3f[3];
  private float txtPositions[][] = new float[3][3];
  private EventInMFString txtString[] = new EventInMFString[3];
  // Bars' current positions
  private float currentPositions[][] = new float[3][3];
  private Place conn;
  private VoterModel vM;
  private EventOutSFBool TS;
  private EventOutSFBool yesTS;
  private EventOutSFBool noTS;
  private EventOutSFBool unknownTS;
  private EventInMFString topicString;
  private EventInSFBool yesTSEnabled;
  private EventInSFBool noTSEnabled;
  private EventInSFBool unknownTSEnabled;
  private VoterThing vT;
  private DynamicObject root;
  private String codeBase;

  // Indicates whether a votation thing is loaded or not
  private boolean loaded = false;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public VoterView() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      @return No return value
      @exception exceptions No exceptions thrown
  */
    public void init (Hashtable ht) {

    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));
    root=     (DynamicObject)ht.get("root");
    this.conn = (Place) ht.get ("place");
    MOVECoreApplet mc=(MOVECoreApplet)ht.get("MOVECoreApplet");
    codeBase=mc.getCodeBase().toString();
    vM = (VoterModel) conn.getModel(super.getName());
    if (vM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: VOTER");
    }
    try {
      vM.addVoterListener(this);
    } catch (Exception e) {
      System.err.println("EXCEPTION!!!");
    }

    for (int i = 0; i<3; i++) {
      currentPositions[i][0] = i*0.9f + 0.4f;
      currentPositions[i][1] = 0;
      currentPositions[i][2] = -0.50f;
    }

    for (int i = 0; i<3; i++) {
      txtPositions[i][0] = i*0.90f + 0.15f;
      txtPositions[i][1] = 0.05f;
      txtPositions[i][2] = -0.10f;
    }

    this.loadVRMLRepresentation();



    System.err.println ("[MOVE] - Voter VRML view initialized.");
  }



 public void loadVRMLRepresentation(){
    String str = new String();
    String auxstr = new String();
    Node[] node;
    Browser browser=getBrowser();

    byte[] buffer = new byte[1024];
    int i;

    // Add avatar to VRML scene
    try {
      URL slURL = new URL (codeBase+"resources/things/votation.v01.wrl");
      BufferedInputStream bis = new BufferedInputStream(slURL.openStream());

      while((i = bis.read(buffer, 0, 1024)) != -1) {
          auxstr = new String (buffer);
          if (i != 1024) {
            byte[] buf2 = new byte[i];
            for (int k=0; k<i; k++) {
              buf2[k]=buffer[k];
            }
            auxstr = new String (buf2);
          }
          str = str + auxstr;
      }

      bis.close();

      node = browser.createVrmlFromString(str);
      EventOutMFNode tmp=((EventOutMFNode)node[1].getEventOut("children"));
      Node aux = (Node)(((EventOutSFNode) (tmp.get1Value(0)).getEventOut("geometry_changed")).getValue());
      topicString = (EventInMFString) aux.getEventIn("set_string");
      String[] txt = new String[1];
      txt[0] =  "Topic: " + vM.getTopic();
      topicString.setValue(txt);



    yesTS = (EventOutSFBool)(((EventOutMFNode)node[4].getEventOut("children")).get1Value(1)).getEventOut("isActive");
    noTS = (EventOutSFBool)(((EventOutMFNode)node[6].getEventOut("children")).get1Value(1)).getEventOut("isActive");
    unknownTS = (EventOutSFBool)(((EventOutMFNode)node[8].getEventOut("children")).get1Value(1)).getEventOut("isActive");
    yesTSEnabled = (EventInSFBool) (((EventOutMFNode)node[4].getEventOut("children")).get1Value(1)).getEventIn("set_enabled");
    noTSEnabled = (EventInSFBool)(((EventOutMFNode)node[6].getEventOut("children")).get1Value(1)).getEventIn("set_enabled");
    unknownTSEnabled = (EventInSFBool)(((EventOutMFNode)node[8].getEventOut("children")).get1Value(1)).getEventIn("set_enabled");

    VRMLZone vrmlZone = new VRMLZone();
    vrmlZone.addVRMLEventListener(this, "voter");

    yesTS.advise (vrmlZone, "voter");
    noTS.advise (vrmlZone, "voter");
    unknownTS.advise (vrmlZone, "voter");



    for (int k = 0; k < 3; k++) {
        transforms[k] = node[4 + k*2];
        tEIn[k] = (EventInSFVec3f) transforms[k].getEventIn("translation");
        sEIn[k] = (EventInSFVec3f) transforms[k].getEventIn("scale");
        shapes[k] = ((EventOutMFNode)transforms[k].getEventOut("children")).get1Value(0);
        apps[k] = (Node)((EventOutSFNode) shapes[k].getEventOut("appearance_changed")).getValue();
        mats[k] = (Node)((EventOutSFNode) apps[k].getEventOut("material_changed")).getValue();
        colors[k] = (EventInSFColor) mats[k].getEventIn("set_diffuseColor");
        txtTransEIn[k] = (EventInSFVec3f) node[5+k*2].getEventIn("translation");
        aux = (Node)(((EventOutSFNode) (((EventOutMFNode)node[5+k*2].getEventOut("children")).get1Value(0)).getEventOut("geometry_changed")).getValue());
        txtString[k] = (EventInMFString) aux.getEventIn("set_string");
    }




      // Create Container shape node

      str=" Transform\n" +
                "{\n" +
		"translation "+vM.getProperty("translation")+"\n" +
                "rotation "+vM.getProperty("rotation")+"\n" +
		"scale "+vM.getProperty("scale")+"\n" +
  		"children [\n" +
                "     Transform {\n"+
                "        translation 0.6 2.2 0\n"+
                "         children ["+
                "             DEF TS1 TouchSensor{}\n" +
                "             Shape { appearance Appearance { material Material { diffuseColor 1 0 0 } \n" +
                "                  } geometry Text { string \"CONTROL\" fontStyle FontStyle { horizontal TRUE " +
                "                  size 0.30 } } } ] }\n"+
  		"]\n" +
	    	"}\n"+
                "DEF TS2 Script{\n" +
                "  eventIn SFBool active\n" +
                "  eventOut SFBool eOut\n" +
                "  url \"javascript: \n" +
                " function active(value)\n" +
                " { if (eOut == TRUE) eOut=FALSE;\n" +
                "     else eOut=TRUE;}\"" +
                "}\n" +
                "ROUTE TS1.isActive TO TS2.active\n" +
                "\n";

      Node[] nodeBase = browser.createVrmlFromString(str);
      TS = (EventOutSFBool)nodeBase[1].getEventOut("eOut");
      VRMLZone zone= new VRMLZone();
      zone.addVRMLEventListener(this,this.getName());
      TS.advise(zone, this.getName());

      root.setaddChValue(nodeBase);
      EventInMFNode ein=(EventInMFNode)nodeBase[0].getEventIn("addChildren");
      ein.setValue(node);




    // Load default voter thing
    if (!(vM.getTopic().equals("----"))) {
      if (checkThing(vM.getTopic())) {
        vM.loadVotation (vM.getTopic());
        setVoterThing(vM.getVoterThing());

        loaded = true;
      }
      else {
        txt[0] =  "Topic: ----";
        topicString.setValue(txt);
      }
    }


    } catch (Exception e) {System.err.println("Exception occured loading votation representation file: " ); e.printStackTrace();}
  }




  public boolean checkThing (String key) {
    Vector voterThings = conn.getThings("votation.v01");

    try {
      Enumeration e = voterThings.elements();

      while (e.hasMoreElements()) {
        ants.core.Thing th = (ants.core.Thing) e.nextElement();
        if (th.getThingId().equals(key)) {
          return true;
        }
      }
      return false;
    } catch (Exception e) { System.err.println("EXCEPTION: Checking for a thing."); e.printStackTrace(); return false;}
  }

  public void yes (int value, boolean updateOthers) {
    float[] col = new float[3];
    col[2]=0;

    float[] esc = new float[3];
    esc[0]=1;
    esc[2]=1;

    float val = (float)value;
    int total = vT.getYes() + vT.getNo() + vT.getUnknown();

    if (val!=0) {
      String tex[] = new String[1];
      float percent = (val / total) * 100;
      tex[0] = "Yes: " + (int) percent + "%";
      txtString[0].setValue(tex);
      currentPositions[0][1] = (float)((percent * 1.12)/100);
      txtPositions[0][1] = (float)(((percent * 2.24)/100) + 0.05);
      col[1] = (float)(percent/2.56);
      col[0] = (float)(1 - percent/2.56);
      colors[0].setValue(col);
      tEIn[0].setValue(currentPositions[0]);
      txtTransEIn[0].setValue(txtPositions[0]);
      esc[1] = (percent * 224f)/100 ;
      sEIn[0].setValue(esc);
    }
    else {
      String[] tex = new String[1];
      tex[0] = "Yes: 0%";
      txtString[0].setValue(tex);
      currentPositions[0][1] = 0;
      txtPositions[0][1] = 0.05f;
      col[1] = 0;
      col[0] = 1;
      colors[0].setValue(col);
      tEIn[0].setValue(currentPositions[0]);
      txtTransEIn[0].setValue(txtPositions[0]);
      esc[1] = (float)0.1;
      sEIn[0].setValue(esc);
    }

    if (updateOthers) {
      this.no(vT.getNo(), false);
      this.unknown(vT.getUnknown(), false);
    }
  }

  public void no (int value, boolean updateOthers) {
    float[] col = new float[3];
    col[2]=0;

    float[] esc = new float[3];
    esc[0]=1;
    esc[2]=1;

    float val = (float) value;
    int total = vT.getYes() + vT.getNo() + vT.getUnknown();

    if (val!=0) {
      float percent = (val / total) * 100;
      String tex[] = new String[1];
      tex[0] = "No: " +  (int) percent + "%";
      txtString[1].setValue(tex);
      currentPositions[1][1] = (float)((percent * 1.12) / 100);
      txtPositions[1][1] = (float)(((percent * 2.24) / 100) + 0.05);
      col[1] = (float)(percent/2.56);
      col[0] = (float)(1 - percent/2.56);
      colors[1].setValue(col);
      tEIn[1].setValue(currentPositions[1]);
      txtTransEIn[1].setValue(txtPositions[1]);
      esc[1] = (percent * 224f) / 100;
      sEIn[1].setValue(esc);
    }
    else {
      String[] tex = new String[1];
      tex[0] = "No: 0%";
      txtString[1].setValue(tex);
      currentPositions[1][1] = 0;
      txtPositions[1][1] = 0.05f;
      col[1] = 0;
      col[0] = 1;
      colors[1].setValue(col);
      tEIn[1].setValue(currentPositions[1]);
      txtTransEIn[1].setValue(txtPositions[1]);
      esc[1] = (float)0.1;
      sEIn[1].setValue(esc);
    }

    if (updateOthers) {
      this.yes(vT.getYes(), false);
      this.unknown(vT.getUnknown(), false);
    }
  }

  public void unknown (int value, boolean updateOthers) {
    float[] col = new float[3];
    col[2]=0;

    float[] esc = new float[3];
    esc[0]=1;
    esc[2]=1;

    float val = (int) value;
    int total = vT.getYes() + vT.getNo() + vT.getUnknown();

    if (val!=0) {
      float percent = (val / total) * 100;
      String[] tex = new String[1];
      tex[0] = "Unknown: " + (int) percent + "%";
      txtString[2].setValue(tex);
      currentPositions[2][1] = (float)((percent * 1.12) / 100);
      txtPositions[2][1] = (float)(((percent * 2.24) / 100) + 0.05);
      col[1] = (float)(percent/2.56);
      col[0] = (float)(1 - percent/2.56);
      colors[2].setValue(col);
      tEIn[2].setValue(currentPositions[2]);
      txtTransEIn[2].setValue(txtPositions[2]);
      esc[1] = (percent * 224f) / 100;
      sEIn[2].setValue(esc);
    }
    else {
      String[] tex = new String[1];
      tex[0] = "Unknown: 0%";
      txtString[2].setValue(tex);
      currentPositions[2][1] = 0;
      txtPositions[2][1] = 0.05f;
      col[1] = 0;
      col[0] = 1;
      colors[2].setValue(col);
      tEIn[2].setValue(currentPositions[2]);
      txtTransEIn[2].setValue(txtPositions[2]);
      esc[1] = (float)0.1;
      sEIn[2].setValue(esc);
    }

    if (updateOthers) {
      this.yes(vT.getYes(), false);
      this.no(vT.getNo(), false);
    }
  }

  public void setVoterThing (VoterThing v) {
    vT = v;
    vT.setModel (vM);
    String[] txt = new String[1];
    txt[0] = "Topic: " + v.getDescription();
    topicString.setValue(txt);

    // Update all voter bars
    yes (vT.getYes(), true);

    if (!(vT.canIVote (conn.getUser()))) {   // Check whether i can vote or not
      yesTSEnabled.setValue(false);
      noTSEnabled.setValue(false);
      unknownTSEnabled.setValue(false);
    }
    else {
      yesTSEnabled.setValue(true);
      noTSEnabled.setValue(true);
      unknownTSEnabled.setValue(true);
    }

    loaded = true;
  }

  public void eventPerformed() {
    try {
      if (loaded) {
        if (yesTS.getValue()) {
          vT.voteYes();
          // Add user to users who have voted list
          vM.addVote(conn.getUser());
        }
        else if (noTS.getValue()) {
          vT.voteNo();
          // Add user to users who have voted list
          vM.addVote(conn.getUser());
        }
        else if (unknownTS.getValue()) {
          vT.voteUnknown();
          // Add user to users who have voted list
          vM.addVote(conn.getUser());
        }

        // Once a vote has been counted, this user will not be able to vote again
        yesTSEnabled.setValue(false);
        noTSEnabled.setValue(false);
        unknownTSEnabled.setValue(false);
      }
     if (TS.getValue()) {
      if(conn.hasPermission("votation.v01")){
       Hashtable params = new Hashtable();
       params.put("src",this.getName());
       params.put("place",conn);
       params.put("dispName","VOTATION");

       VoterWindow vw = new VoterWindow();
       vw.init(params);
       vw.showWin();
      }
    }

    } catch (Exception ex) {
        System.err.println("Exception in Votation TouchSensors: ");
        ex.printStackTrace();
    }
  }

  public VoterModel getModel() {
    return vM;
  }
}
package ants.move.bot;

// Notification Service imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.*;
import ants.move.core.models.voter.*;

public class RunnerBot extends Bot {

	public RunnerBot(String name, String avatar)
        {
           super(name,avatar);
        }




        public void ai()
        {
           
 	
          try {
	    talk("Hola, soc un robot corredor i la meva missio"+
                 "es correr sense parar");
            talk("Aixi que ... SOM-HI!!!!!");

          for (int i=0;i<12;i++){     
            turnLeft();
            wait(200);
            move(0.4f);                  
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);  
                     
                       
          }  


          talk("Buf!, ja no puc m�s");
          talk("Vaig a pendre una beguda isotonica per agafar "+
               "forces i comen�ar a correr de nou");
          talk("SIAU!!!");
          leavePlace();
	  }catch(Exception e){}
        
       }
}
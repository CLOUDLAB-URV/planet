package ants.move.ejb;


import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;
import com.protomatter.syslog.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a World Manager
 */

public class WorldManagerBean implements SessionBean{

  WorldHome worldHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/WorldBean");
      worldHome =(WorldHome) PortableRemoteObject.narrow(objRef,WorldHome.class);
    }catch(Exception eC){
        Syslog.error (this, "Unable to create Manager");
    }
  }
  public Collection getWorlds(){
    Collection worlds= new ArrayList();
    try{
      worlds=worldHome.findByAll();
    }catch(Exception gwE){
        Syslog.debug (this, "getWorlds() : Contains 0 worlds");
    }
    return worlds;
  }
  public World getWorld(String id){
    World world=null;
    try{
      world=worldHome.findByPrimaryKey(id);
    }catch(Exception gwE){
        Syslog.error (this, "getWorld("+id+") : "+gwE);
    }
    return world;
  }
  public World createWorld(String id,String name,String type){
    World world=null;
    try{
      world= worldHome.create(id);
      world.setName(name);
      world.setType(type);

    }catch(Exception gwE){
        Syslog.error (this, "createWorld("+id+","+name+","+type+") : "+gwE);
    }
    return world;
  }


  public void removeWorld(String id){
    World world=null;
    try{
      world=worldHome.findByPrimaryKey(id);
      world.remove();
    }catch(Exception gwE){
        Syslog.error (this, "removeWorld("+id+") : "+gwE);
    }
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
// Package ants.move.core.views.avatar
// AvatarInformation.java
// Information on avatar movements
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views.avatar;

// VRML Scene import
import vrml.external.field.*;

/** Information on avatar movements.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.2 Build 2000
*/
public class AvatarInformation {
  // EventIn avatar position
  private EventInSFVec3f avatarPosition = null;
  // EventIn avatar orientation
  private EventInSFRotation avatarRotation = null;
  // EventIn avatar movement enabled/disabled
  private EventInSFTime startTime = null;
  private EventInSFTime stopTime = null;
  // New avatar position
  private float[] pos;
  // New avatar orientation
  private float[] ori;

  /** Sole constructor.
      @param aPos EventIn VRML avatar position (so it can be changed)
      @param aRot EventIn VRML avatar rotation (so it can be changed)
      @param eJoints EventIn VRML avatar movement enabled/disabled
      @param p New avatar position
      @param o New avatar orientation
      @exception exceptions No exceptions thrown
  */
  public AvatarInformation (EventInSFVec3f aPos, EventInSFRotation aRot, EventInSFTime start,
                            EventInSFTime stop, float[] p, float[] o) {
    avatarPosition = aPos;
    avatarRotation = aRot;
//    enableJoints = eJoints;
    startTime = start;
    stopTime = stop;
    pos = p;
    ori = o;
  }
public AvatarInformation() {}
  /** Get Avatar's Position EventIn.
      @param params None
      @return Avatar's Position EventIn
      @exception exceptions No exceptions thrown
  */
  public EventInSFVec3f getAvatarPosition() {
    return (avatarPosition);
  }

  /** Get Avatar's Orientation EventIn.
      @param params None
      @return Avatar's Orientation EventIn
      @exception exceptions No exceptions thrown
  */
  public EventInSFRotation getAvatarRotation() {
    return (avatarRotation);
  }

  /** Get Avatar's Movement Enabler EventIn.
      @param params None
      @return Avatar's Movement Enabler EventIn
      @exception exceptions No exceptions thrown
  */
/*  public EventInSFBool getEnableJoints() {
    return (enableJoints);
  }
*/

  public EventInSFTime getStartTime() {
    return startTime;
  }

  public EventInSFTime getStopTime() {
    return stopTime;
  }

  /** Get Avatar's new position.
      @param params None
      @return Avatar's new position
      @exception exceptions No exceptions thrown
  */
  public float[] getPosition() {
    return (pos);
  }

  /** Get Avatar's new orientation.
      @param params None
      @return Avatar's new orientation
      @exception exceptions No exceptions thrown
  */
  public float[] getOrientation() {
    return (ori);
  }
}

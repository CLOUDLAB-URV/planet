package ants.core.rmi;

import java.util.*;

public interface UserGateway extends java.rmi.Remote {
  public Vector getUsers (String wName, String pName) throws java.rmi.RemoteException;
  public String getUserIP (String wName, String pName, String usr) throws java.rmi.RemoteException;
  public void addUser (String wName, String pName, String usr) throws java.rmi.RemoteException;
  public void removeUser (String wName, String pName, String usr) throws java.rmi.RemoteException;
  public boolean hasPermission(String tool,String role,String worldId) throws java.rmi.RemoteException;
  public void addToBag (String login, String thingId) throws java.rmi.RemoteException;
  public boolean isBot (String wName, String pName, String usr) throws java.rmi.RemoteException;
  public void setBot (String wName, String pName, String usr) throws java.rmi.RemoteException;
  

}

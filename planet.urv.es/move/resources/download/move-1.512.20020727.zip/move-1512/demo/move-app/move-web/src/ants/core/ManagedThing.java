package ants.core;

import java.util.*;
import ants.comm.*;
import ants.util.*;
import java.rmi.*;

public class ManagedThing extends Thing
{
	private PolicyManager poli;
	private ANTSContext ctx;

	public void init()
	{

		this.poli = getContext().getManager();
		this.ctx = getContext();


	}

public void setProperty(String propName, String propValue)
throws PropertyVetoException

	{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"WRITE","setProperty");
			if (poli.checkValid(evt2))
				super.setProperty(propName,propValue);
			else throw new PropertyVetoException();



	}

public String getProperty(String propName)
throws PropertyVetoException

	{
		VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"READ","getProperty");
		if (poli.checkValid(evt2))
				return super.getProperty(propName);
			else throw new PropertyVetoException();
	}


public String[] getIndexedProperty(String propName)
throws PropertyVetoException

{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"READ","getIndexedProperty");
			if (poli.checkValid(evt2))
				return super.getIndexedProperty(propName);
			else throw new PropertyVetoException();

}

public void setIndexedProperty(String propName,String [] values)
throws PropertyVetoException
{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"WRITE","setIndexedProperty");
			if (poli.checkValid(evt2))
				setIndexedProperty(propName,values);
			else throw new PropertyVetoException();

}

/*public String getIndexedProperty(String propName,int index)
throws PropertyVetoException
{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"READ","getIndexedProperty");
			if (poli.checkValid(evt2))
				return super.getIndexedProperty(propName,index);
			else throw new PropertyVetoException();

}
*/
public void setIndexedProperty(String propName, int index,String value)
throws PropertyVetoException
{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"WRITE","setIndexedProperty");
			if (poli.checkValid(evt2))
				 setIndexedProperty(propName,index,value);
			else throw new PropertyVetoException();


}

public int getIndexedPropertyLength(String propName)
throws PropertyVetoException
{
		VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"READ","getIndexedPropertyLength");
		if (poli.checkValid(evt2))
				return getIndexedPropertyLength(propName);
			else throw new PropertyVetoException();

}


public void setObjectProperty(String propName,java.io.Serializable obj)
throws PropertyVetoException
	{
			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"WRITE","setObjectProperty");
			if (poli.checkValid(evt2))
				setObjectProperty(propName,obj);
			else throw new PropertyVetoException();

	}


public Object getObjectProperty(String propName)
throws PropertyVetoException
	{

			VetoableActionEvent evt2 = new VetoableActionEvent(ctx.getThing(),ctx.getUser(),ctx.getRole(),"READ","getObjectProperty");
			if (poli.checkValid(evt2))
				 return getObjectProperty(propName);
			else throw new PropertyVetoException();


	}




}
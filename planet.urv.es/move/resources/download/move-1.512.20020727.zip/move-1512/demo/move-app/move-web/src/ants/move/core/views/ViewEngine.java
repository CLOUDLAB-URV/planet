// Package ants.move.core.dynamicObjects
// ModelEngine.java
// Implementation of the Model Engine
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views;

// java.util Package imports
import java.util.*;
import java.net.*;
import java.rmi.*;

import ants.comm.*;
import ants.core.*;
import ants.core.rmi.*;

import ants.move.core.teacher.chat.ChatWindow;
import ants.move.core.views.DynamicObject;
import ants.move.core.Constants;
import vrml.external.Browser;

/** Implementation of Model Engine.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.00 Build 2000
*/
public class ViewEngine {
  private String viewsList = "VRML Views: ";
  private Browser browser;
  private Properties props;
  private Place conn;
  private DynamicObject root;
  private ChatWindow chatWin;
  private Hashtable models;
  private ants.move.core.MOVECoreApplet mbr;

  public ViewEngine (Hashtable env) {
    browser = (Browser) env.get("browser");
    models = (Hashtable) env.get("models");
    conn = (Place) env.get("place");
    root = (DynamicObject) env.get("root");
    chatWin = (ChatWindow) env.get("chatWin");
    mbr = (ants.move.core.MOVECoreApplet) env.get("MOVECoreApplet");
  }

  public void loadViews() {
    // Initialize all dynamicObjects Views
    try {
      Enumeration e = models.keys();

      while (e.hasMoreElements()) {
       //Vector modelInfo: model, thingModelId, toolType, toolName, teacher, VRML, node
        Vector modelInfo = (Vector) e.nextElement();
        String modelId = (String) modelInfo.firstElement();
        String toolId = (String) modelInfo.elementAt (1);
        String modelDisplay = (String) modelInfo.elementAt(3);
        String VRMLViewClassName = (String) modelInfo.elementAt(5);
        String node = (String) modelInfo.elementAt(6);

        if (!VRMLViewClassName.equalsIgnoreCase("----")) {
          Class auxClass = Class.forName(VRMLViewClassName);
          ViewInterface vInt = (ViewInterface) auxClass.newInstance();

          // init() common method is called
          Hashtable ht = new Hashtable();

          ht.put("browser", browser);
          ht.put("VRMLNode", node);
          ht.put("src", toolId);
          ht.put("place", conn);
          ht.put("root", root);
          ht.put("MOVECoreApplet", mbr);

          vInt.init (ht);

          viewsList += modelDisplay + " ";
        }
      }
      chatWin.consoleMessage(viewsList);
      } catch (Exception e) {
        chatWin.consoleMessage("Exception while initializing DynamicObjects: ");
        e.printStackTrace();
      }
    }
}
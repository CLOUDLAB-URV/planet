// Package ants.move.core.models.banner
// BannerListener.java
// 2002 Oriol Montal� & Francesc Pi�as
package ants.move.core.models.banner;

/** BannerListener interface.
    @author Francesc Pi�as (fpd@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2002
*/
public interface BannerListener {
/**
 * Set active banner image
 * @param url image
 */
  public void setImage (String url);
  /**
   * Destroy
   */
  public void destroy();
}
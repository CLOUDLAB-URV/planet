<%@ page session="true" import = "ants.move.lang.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  Place place=pm.getPlace((String)session.getAttribute("placeId"));
  World world=wm.getWorld((String)session.getAttribute("worldId"));
  Vector per = new Vector();
  int size=Integer.parseInt(world.getProperty(((User)session.getAttribute("user")).getRole()+"size"));
  for(int i=0;i<size;i++){
    per.addElement(world.getIndexedProperty(((User)session.getAttribute("user")).getRole(),i));
  }

%>
 <html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("configTools")%>: </b></font></td></tr>

      <%if(per.contains("builder.v01")){
       %>
       <tr>
        <td align="right"><a href="goToBuilder.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue">Builder</font></a><br><br></td>
       </tr>
       <%
      }%>

</table>

   <table width="80%" border="0" bgcolor="teal">

   <th><font color="white"><%=labels.getString("nameThingTH")%></font></th>
   <th><font color="white"><%=labels.getString("descriptionTH")%></font></th>
   <th><font color="white"><%=labels.getString("thingType")%></font></th>
   <th><font color="white"><%=labels.getString("status")%></font></th>
   <th><font color="white"><%=labels.getString("action")%></font></th>

   <%
   Tool tool=null;
   for(Iterator i=tm.getTools().iterator();i.hasNext();){
    tool=(Tool)i.next();
    if(per.contains(tool.getId())){
    if(!tool.getId().equalsIgnoreCase("builder.v01")){
    %>

    <tr bgcolor="#E6E4DD">
      <form method="post" action="configureTools.jsp">
      <td><%=tool.getName()%></td>
      <td><%=lang.translateText(tool.getDescription(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))%></td>
      <td><%=tool.getType()%></td>
      <%
      if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
       %><td><%=messages.getString("active")%></td>
         <input type="hidden" name="toolId" value="<%=tool.getId()%>">
         <td align="center"><input type="submit" value="<%=labels.getString("deactivate")%>"></td></form>
       <%
      }else{
       %><td><%=messages.getString("inactive")%></td>
         <input type="hidden" name="toolId" value="<%=tool.getId()%>">
         <td align="center"><input type="submit" value="<%=labels.getString("activate")%>"></td></form>
       <%
      }
      %>
    </tr>
    <%
    }
    }
   }

   %>
   </table>
   <br><br>

  </center>
  <jsp:include page="footer.jsp" flush="true" />
 </HTML>
<%
}else{

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  Place place=pm.getPlace((String)session.getAttribute("placeId"));
  String toolId=(String)request.getParameter("toolId");
  if(place.getProperty(toolId).equalsIgnoreCase("Active")){
    place.setProperty(toolId,"deactive");
  }else{
    place.setProperty(toolId,"active");
  }
  response.sendRedirect("configureTools.jsp?");
}
%>


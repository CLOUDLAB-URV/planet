
package ants.comm.jsdt;

import ants.comm.*;
import java.util.*;
import ants.util.JSDTParser;
import ants.util.Debug;
import com.sun.media.jsdt.*;



public class Session implements ants.comm.Session, ChannelConsumer
{
	private Hashtable env;	
	private Hashtable subscriptions;
	private Channel channel;
	private String  separator = "^";
	private String sessionName="default";
	private JSDTClient client;	
	private int hostport = 4461;
	private String type = "socket";
	com.sun.media.jsdt.Session session;

	
	// OJO !!! NULLEXCEPTIONS !!!
	
	public void open(Hashtable environment) throws SessionException
	{
		try
    {
     	//Antes estaba a 2000
    	com.sun.media.jsdt.impl.JSDTObject.timeoutPeriod = 50000;
    	String sessionName=(String)environment.get("ants.comm.session");
    	String hostname=(String)environment.get("java.naming.provider.url");
    	hostport= Integer.parseInt((String)environment.get("ants.comm.port"));
			type = (String)environment.get("ants.comm.type");
    	String channelName = (String)environment.get("ants.comm.channel");
     	URLString url=URLString.createSessionURL(hostname,hostport,type,sessionName);
     	
    	String id = String.valueOf(System.currentTimeMillis()); 
     	client = new JSDTClient(id);

     	session = 	com.sun.media.jsdt.SessionFactory.createSession(client,url,true);
			
 		
			channel = session.createChannel(client,channelName,true,true,true);
			channel.addConsumer(client, this);

			subscriptions = new Hashtable();
	
 			
		}
		catch (PermissionDeniedException e)
		{
			throw new SessionException(e);
			// Debug.error(ex);
		
		}	catch (Exception e2)
		{
					throw new SessionException(e2);
			// Debug.error(ex);
		}

				
	 
	}	
		
		
	
	public void close() throws SessionException
	{
		try
		{
	   session.close(true);
	
		}catch(Exception e)
		{	
			throw new SessionException(e);
			
		}
	//OJO CERRAR!!!	
//		conn.close();
	
	}
	
	
	public void send(Hashtable evt) throws SessionException
	{
		try
		{
	
	/*
	
			StringBuffer buf = new StringBuffer();
			Enumeration e = evt.keys();
			while(e.hasMoreElements())
			{
				String key = (String)e.nextElement();
				buf.append(	key+separator+evt.get(key)+separator);
			}
		
			Data data=new Data(buf.toString());
		*/
				Data data=new Data(evt);

			
			data.setPriority(Channel.HIGH_PRIORITY);
			channel.sendToAll(client, data);
		}catch (com.sun.media.jsdt.ConnectionException ex)
		{
			throw new SessionException(ex);
			// Debug.error(ex);
		} catch( com.sun.media.jsdt.InvalidClientException ex2)
		{
						throw new SessionException(ex2);
			// Debug.error(ex);
		} catch (com.sun.media.jsdt.NoSuchChannelException ex3)
		{
				throw new SessionException(ex3);
			// Debug.error(ex);

		} catch (com.sun.media.jsdt.NoSuchClientException ex4)
		{
							throw new SessionException(ex4);
			// Debug.error(ex);

		} catch (com.sun.media.jsdt.NoSuchSessionException ex5)
		{

					throw new SessionException(ex5);
			// Debug.error(ex);
	}		catch (com.sun.media.jsdt.PermissionDeniedException ex6)
		{

				throw new SessionException(ex6);
			// Debug.error(ex);
	}			catch (com.sun.media.jsdt.TimedOutException ex7)
		{

				throw new SessionException(ex7);
			// Debug.error(ex);
	}		


		
	}
	
	
	
		public void sendObj(Hashtable event,java.io.Serializable obj) throws SessionException
	{
	
	
		try
		{
	
				event.put("object",obj);	
				Data data=new Data(event);

			
			data.setPriority(Channel.HIGH_PRIORITY);
			channel.sendToAll(client, data);
		}catch (com.sun.media.jsdt.ConnectionException ex)
		{
			throw new SessionException(ex);
			// Debug.error(ex);
		} catch( com.sun.media.jsdt.InvalidClientException ex2)
		{
						throw new SessionException(ex2);
			// Debug.error(ex);
		} catch (com.sun.media.jsdt.NoSuchChannelException ex3)
		{
				throw new SessionException(ex3);
			// Debug.error(ex);

		} catch (com.sun.media.jsdt.NoSuchClientException ex4)
		{
							throw new SessionException(ex4);
			// Debug.error(ex);

		} catch (com.sun.media.jsdt.NoSuchSessionException ex5)
		{

					throw new SessionException(ex5);
			// Debug.error(ex);
	}		catch (com.sun.media.jsdt.PermissionDeniedException ex6)
		{

				throw new SessionException(ex6);
			// Debug.error(ex);
	}			catch (com.sun.media.jsdt.TimedOutException ex7)
		{

				throw new SessionException(ex7);
			// Debug.error(ex);
	}		

	
	
	}

	
	public void addRemoteEventListener (RemoteEventListener sel, Hashtable event) throws SessionException
	{
		
		if (subscriptions.containsKey(event))
		{
		//	RemoteEventListener rL = (RemoteEventListener)subscription.get(event);
			Vector v = (Vector)subscriptions.get(event);
			v.add(sel);
		//	v.add(
			
		} else 
		{
			Vector v = new Vector();
			v.addElement(sel);
			subscriptions.put(event,v);

		}
		// subscriptions.put(event,sel);

 
	}
	public void addRemoteEventListener (RemoteEventListener sel, String subscription) throws SessionException
	{
		Hashtable subs = JSDTParser.getEvt(subscription);
		
		if (subscriptions.containsKey(subs))
		{
			Vector v = (Vector)subscriptions.get(subs);
			v.add(sel);
		
			
		} else 
		{
			Vector v = new Vector();
			v.addElement(sel);
			subscriptions.put(subs,v);

		}

		
		
		/*
		try
		{
			if (subscriptions.containsKey(subscription))
			{
					Subscription sub = 	(Subscription)subscriptions.get(subscription);
					NotificationParser npar = new NotificationParser(sel);
					sub.addNotificationListener(npar);
				
			}else 
			{

	
				NotificationParser npar = new NotificationParser(sel);
				Subscription sub = new Subscription(subscription,npar);
				cons.addSubscription(sub);
				subscriptions.put(subscription,sub);
			}
		}catch (java.io.IOException ex){
			Debug.error(ex);
		};*/
	}
// con.removeSubscription(sub); Como guardar sub ?
	public void removeRemoteEventListener(Hashtable event) throws SessionException
		{
		
			  subscriptions.remove(event);
				
		}
		
	public void removeRemoteEventListener(String subscription) throws SessionException
		{
		/*	try
			{
	
				
				Subscription sub = 	(Subscription)subscriptions.get(subscription);
				cons.removeSubscription(sub);
			  subscriptions.remove(subscription);

		
			}catch (java.io.IOException ex){
				
					Debug.error(ex);

				};
*/
		}

public void dataReceived(Data data) 
 	{
 
 	//		Hashtable se = parseEvent(data.getDataAsString());
	//	try
 	//	{
		//	Hashtable event =(Hashtable) data.getDataAsObject();
			EventHandler evH = new EventHandler(subscriptions, data);
			evH.start();
 		
 	//	}catch (ClassNotFoundException e1){Debug.error(e1);
 	//	}catch (java.io.StreamCorruptedException e2){Debug.error(e2);
 	//	}


 	}
 	
 	private Hashtable  parseEvent(String event)
 		{
 				Hashtable aux = new Hashtable();
				StringTokenizer st = new StringTokenizer (event,separator);
				while (st.hasMoreTokens())
				{
					aux.put(st.nextToken(),	st.nextToken());
				}
 				return aux;
 		}


}
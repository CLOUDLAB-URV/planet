package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import ants.util.Debug;

public class Tester implements RemoteEventListener
{
	public int n = 0;
	
	public void eventArrived(Hashtable evt)
	{
		n++;
	}
	
	public static void main(String args[])
	{
		try{
			
		Tester nu =new Tester();
		long conn1 = System.currentTimeMillis();
		Session conn = SessionFactory.createSession(args[0]);
		long conn2 = System.currentTimeMillis();
		System.out.println("CONN TIME = "+ (conn2-conn1));
		Hashtable subs = new Hashtable();
		subs.put("type","evt");
		conn.addRemoteEventListener(nu,subs);	
		
		Hashtable evt= new Hashtable();
		evt.put("type","evt");
		evt.put("msg","sdsds");
		long send1 = System.currentTimeMillis();
		for (int i= 0;i<10000;i++)
				conn.send(evt);
		long send2 = System.currentTimeMillis();
		
		System.out.println("SEND TIME = "+ (send2-send1));

		Thread.sleep(50000);		
		System.out.println(nu.n);		
		}catch (Exception e){
			Debug.error(e);
		}
	
	}
	
}
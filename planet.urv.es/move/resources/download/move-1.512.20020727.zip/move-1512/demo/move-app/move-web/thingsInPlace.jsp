<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, java.net.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;

%>

<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ToolManager tm=(ToolManager)session.getAttribute("toolManager");
 PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 Thing thing=null;
 Tool tool=null;
 Place place=null;

 if(request.getParameter("placeId")!=null){
   session.setAttribute("placeId",request.getParameter("placeId"));
 }
 String placeId=(String)session.getAttribute("placeId");

 place=pm.getPlace(placeId);

%>
<html>
<body>
<center>
<h3><%=messages.getString("things")%>:</h3> <br>
  
  <%
    if(((thm.getThings(placeId).size())-(tm.getTools().size()+1))!=0){ 
      System.out.println(thm.getThings(placeId).size());
      System.out.println(tm.getTools().size()+1);
  %>
      <table border="0" bgcolor="teal" width="90%">
         <TR>
              <TH><font color="white">Thing</TH>
              <TH><font color="white"><%=labels.getString("nameTH")%></TH>
              <TH><font color="white"><%=labels.getString("descriptionTH")%></TH>
              <TH><font color="white"><%=labels.getString("creationTH")%></TH>
              <TH><font color="white"><%=labels.getString("createdTH")%></TH>

         </TR>
  <%

      
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"video.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewVideo.jsp?thingId=<%=thing.getId()%>">
              <img src="images/video.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white"><a href="deleteVideo.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }
      //Votation
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"votation.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewVotation.jsp?thingId=<%=thing.getId()%>">
              <img src="images/votation.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white"><a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }
      //Slides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"slides.v05").iterator();i.hasNext();){
        thing=(Thing)i.next();
        
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewSlides.jsp?thingId=<%=thing.getId()%>">
            <img src="images/slides.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white"><a href="deleteSlides.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }
      //3DSlides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"s3d.v06").iterator();i.hasNext();){
        thing=(Thing)i.next();
       
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><img src="images/s3d.gif" align="middle" border="0"></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white"><a href="delete3DSlides.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }

      //URL
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"url.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getName()%>" target="_blank">
              <img src="images/url.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
                  
        </tr><%
      }

      //DOC
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"doc.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        String worldId=(String)session.getAttribute("worldId");
        
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%="worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")%>" target="_blank">
              <img src="images/document.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
          
        </tr><%
      }
      //Audio
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"audio.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="listenAudio.jsp?thingId=<%=thing.getId()%>">
              <img src="images/audiotrack.jpg" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
          <td bgcolor="white"><a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }

      //banner
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"banner.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewBanner.jsp?thingId=<%=thing.getId()%>">
              <img src="images/banner.jpg" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
          <td bgcolor="white"><a href="deleteBanner.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }
      //Videostreaming
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getName()%>" target="_blank">
              <img src="images/videoStream.jpg" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
          
        </tr><%
      }
      //Videostreaming2
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v02").iterator();i.hasNext();){
        thing=(Thing)i.next();
       

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getProperty("url")%>" target="_blank">
              <img src="images/videoStream.jpg" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>    
          <td bgcolor="white"><a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }


    
    %>
    </table>
  <% 
     }
   } catch (Exception e) {
      Syslog.log (this, e);
   }
  %>


</center>
</body>
</html>
package ants.core;

public interface Command
{
	
	public void init(Model theModel);
	public String parseCommand(String command);
	public String getDescription();
	
}

package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class GenericConsumer {
	
	
	public GenericConsumer(String envFile)
	{
	 try
		{
			ants.comm.Session chatZone = SessionFactory.createSession(envFile);

	
			Listener1 l1 = new Listener1();
			Listener2 l2 = new Listener2();
		

			Hashtable evt = new Hashtable ();
			evt.put("arg1","terrance");
			chatZone.addRemoteEventListener(l1,evt);

			Hashtable evt2 = new Hashtable ();
			evt2.put("arg1","filip");
			chatZone.addRemoteEventListener(l2,evt2);
			
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	public class Listener1 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("Terrance event !!!");
		}
	}
	public class Listener2 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("Filip event !!!");

		}
	}

	public static void main(String args[])
	{
			GenericConsumer tc = new GenericConsumer(args[0]);
			System.out.println("Ready !  (Press CTRL+C to exit)");
			try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
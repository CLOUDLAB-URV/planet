package ants.comm.elvin;

import java.util.Hashtable;
import org.elvin.je4.*;
import org.elvin.util.*;
import ants.util.*;
import ants.comm.*;



public class ElvinDispatcher extends Thread
{
	private RemoteEventListener caller;
	private Notification event;
	
	public ElvinDispatcher(RemoteEventListener caller, Notification event)
	{
		this.caller = caller;
		this.event = event;
	}
	

	
	public void run()
	{

		caller.eventArrived(ElvinParser.getEvt(event));		
	}
	
	
}
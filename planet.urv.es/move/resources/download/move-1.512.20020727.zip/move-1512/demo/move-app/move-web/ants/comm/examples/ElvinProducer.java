
package ants.comm.examples;

import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;

public class ElvinProducer{
	
	
	public static void main(String args[])
	{
		try
		{
			Hashtable env = new Hashtable();
			env.put(Context.PROVIDER_URL, "pgarcia.etse.urv.es");
			env.put(Context.PROVIDER_PORT, "2917");
			env.put(Context.PROVIDER_CLASS, "ants.comm.elvin.Session");
			
			ants.comm.Session chatZone = SessionFactory.createSession(env);
			Hashtable evt = new Hashtable();
			evt.put("arg1",args[0]);	
			chatZone.send(evt);
			chatZone.close();
		
		}catch (SessionException s1)
		{
			System.out.println(s1.getException().getMessage());
		}

	}

		
}
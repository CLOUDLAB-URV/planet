// Package ants.move.core.teacher.slides
// SlidesWindow.java
// Implementation of Slides User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.slides;

// dynamicObjects.Slides import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.slides.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.net.*;


/** Implementation of Slides User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.70 Build 2000
*/
public class SlidesWindow extends Windows implements TeacherInterface{
  // Buttons
  private Button slidesButton;
  private Button nextButton;
  private Button prevButton;
  private Button startButton;
  private Button endButton;
  // Labels
  private Label FileLabel;
  private Label slidesLabel;
  // Choice
  private Choice slidesChoice;
  // Slides name
  private String slidesName;
  // Applet's current codeBase
  private String codeBase;
  private SlidesModel internalModel;
  private Place conn;
  private String dispName;

  // All things of type Slides in that place
  Vector slidesThings = new Vector();

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public SlidesWindow() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Slides: " + (String) ht.get("src"));
    slidesName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (SlidesModel) conn.getModel(slidesName);
    if (internalModel == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: SLIDES (from SlidesWindow)");
    }
    codeBase = conn.getBaseURL() + "worlds/" + conn.getWorld() + "/" + conn.getPlaceId() + "/";

    // Obtain all things of type Slides in that place
    slidesThings = conn.getThings("slides.v05");


    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(210, 175);
    window.setLocation(190, 0);
    window.setResizable(false);
    window.setLayout(gbLayout);

    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(slidesLabel = new Label("Slides Sets:"), gc);
    window.add(slidesLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(slidesChoice = new Choice(), gc);

    gc.gridy = 1;
    gc.gridx = 1;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(slidesButton = new Button("Load"), gc);
    window.add(slidesButton);

    p = new Panel();
    p.setLayout(null);
    p.setSize(185, 50);
    startButton = new Button("<<");
    startButton.setBounds(0, 0, 40, 24);
    p.add(startButton);
    prevButton = new Button("<");
    prevButton.setBounds(40, 0, 40, 24);
    p.add(prevButton);
    nextButton = new Button(">");
    nextButton.setBounds(80, 0, 40, 24);
    p.add(nextButton);
    endButton = new Button(">>");
    endButton.setBounds(120, 0, 40, 24);
    p.add(endButton);
    FileLabel = new Label("Current Set: None");
    FileLabel.setBounds(0, 25, 144, 24);
    p.add(FileLabel);
    gc.gridy = 2;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);

  // Add things to choice
  try {
    Enumeration e = slidesThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      slidesChoice.addItem(th.getName());
    }
  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Slides to choice"); e.printStackTrace();}

  window.add(slidesChoice);

    slidesButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        slidesButton_actionPerformed(e);
      }
    });

    startButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        startButton_actionPerformed(e);
      }
    });

    prevButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        prevButton_actionPerformed(e);
      }
    });

    nextButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        nextButton_actionPerformed(e);
      }
    });

    endButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        endButton_actionPerformed(e);
      }
    });

    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });
    // Check if there is any slides set loaded
    String thingKey = internalModel.getSlidesThingId();
    if (thingKey != null) {
      if (!thingKey.equals("----")) {
        Thing t = internalModel.getSlidesThing();
        if (t != null) {
          FileLabel.setText("Current Set: " + t.getName());
        }
        setButtonStatus (true);
      }
    }
    System.err.println("[MOVE] - Slides control window initialized.");
  }

  // Locks the Slides Thing onto the Slides Model
  public void lockThing (int index) {
   if(index!=-1){
    ants.core.Thing t = (ants.core.Thing) slidesThings.elementAt(index);
    internalModel.setSlidesThing(t.getThingId());
    setButtonStatus (true);
   }
  }

  private void setButtonStatus (boolean status) {
    endButton.setEnabled (status);
    nextButton.setEnabled (status);
    prevButton.setEnabled (status);
    startButton.setEnabled (status);
    slidesChoice.setEnabled (status);
    slidesButton.setEnabled (status);
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
//    super.hideWin();
  }

  public String getThingId (String thg) {
    Enumeration e = slidesThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getName().equalsIgnoreCase(thg)) {
        return (t.getThingId());
      }
    }
    return null;
  }

  public void slideChange (String url) { }

  public void setSlidesThing (Thing sT) {
    FileLabel.setText("Current Set: " + sT.getName());
  }

  /** slidesField's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void slidesButton_actionPerformed (ActionEvent e) {
    lockThing(slidesChoice.getSelectedIndex());
    FileLabel.setText("Current Set: " + slidesChoice.getSelectedItem());
  }

  /** startButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void startButton_actionPerformed (ActionEvent e) {
    internalModel.firstPicture();
  }

  /** prevButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void prevButton_actionPerformed (ActionEvent e) {
    internalModel.prevPicture();
  }

  /** nextButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void nextButton_actionPerformed (ActionEvent e) {
    internalModel.nextPicture();
  }

  /** endButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void endButton_actionPerformed (ActionEvent e) {
    internalModel.lastPicture();
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Slides";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }
}

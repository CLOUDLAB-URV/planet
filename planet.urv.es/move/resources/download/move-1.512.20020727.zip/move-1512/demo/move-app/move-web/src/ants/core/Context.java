package ants.core;;

/**
*		This interface represents a naming context, which consists of a set of name-to-object bindings
*   These constants will be used for connecting to different Notification services.
*/


public class Context
{

	/**
	*  Constant that holds the name of the environment property for specifying user information
  *
	*/

	public static final String USER = "USER";

	/**
	*  Constant that holds the name of the environment property for specifying the role name of the user
  *  to use.
	*/
	public static final String ROLE = "ROLE";

/**
	*  Constant that holds the name of the environment property for specifying the world name
  *
	*/

	public static final String WORLD = "WORLD";

/**
	*  Constant that holds the name of the environment property for specifying the place name
  *
	*/
	public static final String PLACE = "PLACE";

/**
	* Constant that holds the name of the environment property for specifying the notification service
  *
  */

	public static final String BUS = "BUS";

/**
	* Constant that holds the name of the environment property for specifying the base URL
  *
  */

	public static final String BASE = "BASE";


	/**
	* Constant that holds the name of the environment property for specifying the ip address of the ANTS Server
  *
  */

	public static final String ANTS_SERVER = "ANTS_SERVER";


	/**
	* Constant that holds the name of the environment property for specifying the method name contained in events.
  *
  */

	public static final String METHOD = "METHOD";

/**
	* Constant that holds the name of the environment property for specifying the tool name contained in events.
  *
  */

	public static final String CLASS = "CLASS";
/**
	* Constant that holds the name of the environment property for specifying the identification key of a concrete thing
  *
  */

	public static final String SRC = "SRC";

        public static final String PLACESERVER = "PLACESERVER";
        public static final String THINGSERVER = "THINGSERVER";
        public static final String USERSERVER = "USERSERVER";
        public static final String WORLDMANAGERID = "ants.core.WorldManagerId";
        public static final String JLESESSIONMANAGERID = "ants.core.JLESessionManagerId";
        public static final String TOOLMANAGERID = "ants.core.ToolManagerId";
        public static final String SECURITYMANAGERID = "ants.core.SecurityManagerId";
        public static final String PERMISSIONCHECKERID = "ants.core.PermissionCheckerId";
        public static final String PINGTIME = "pingTime";
        public static final String SYSLOGMASK = "Syslog.mask";
}
package ants.move.core;

public final class Version {

  public static String version = "1.512";
  public static String dStamp = "20021002";
  public static String tStamp = "1848";
  public static String today = "October 2 2002";
  public static String projectName = "move";
  public static String jVersion = "1.3.0";
  public static String jvmVersion = "1.3.0-C";
  public static String osName = "Windows 2000";
  public static String osArch = "x86";
  public static String coreVersion = "1.2";
  public static String rDate = "27-07-2002";
  public static String coreDate = "27-09-2001";

  public static void printVersion() {
    print ("--------- PRODUCT INFORMATION -----------");
    print ("Version ID: " + version + "." + rDate);
    print ("ANTS/CORE RMI Date: " + coreDate);
    print ("--");
    print ("Project Name: " + projectName);
    print ("Version: " + version);
    print ("Release Date: " + rDate);
    print ("TimeStamp: " + dStamp + "-" + tStamp);
    print ("Build Date: " + today);
    print ("Server Java Version: " + jVersion);
    print ("Server JVM Version: " + jvmVersion);
    print ("Server OS Name: " + osName);
    print ("Server Platform: " + osArch);
    print ("ANTS/CORE RMI Version: " + coreVersion);
    print ("---------------------------------------------------------");
  }

  public static void print (String str) {
    System.err.println ("[MOVE] - " + str);
  }
}


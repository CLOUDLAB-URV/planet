package ants.move.core.models.voter;

import ants.core.*;
import java.util.*;

public class VoterThing extends Thing implements PropertyChangeListener {
  private VoterModel vM;

  public void init() {
    addPropertyChangeListener(this);
    System.err.println("[MOVE] - Votation " + getContext().getThing() + " initialized.");
  }

  public void setModel (VoterModel m) {
    vM = m;
  }

  public String getUsersWhoHaveVotedList () {
    try {
      String str = getProperty ("usersList");
      if (str.equals("----")) {
        return new String();
      }
      else {
        return str;
      }
    }
    catch (Exception x) {
      x.printStackTrace();
      return null;
    }
  }

  public boolean canIVote (String user) {
    String usersWhoHaveVoted = getUsersWhoHaveVotedList();

    if (usersWhoHaveVoted != null) {
      StringTokenizer tokens = new StringTokenizer (usersWhoHaveVoted);

      while (tokens.hasMoreTokens()) {
        String currentUser = tokens.nextToken();

        if (currentUser.equals(user)) {
          System.err.println("User " + super.getPlace().getUser() + " CANNOT vote.");
          return false;   // User has already voted
        }
      }
      System.err.println("User " + super.getPlace().getUser() + " CAN vote.");
      return true;    // User not found, so he had not previously voted
    }
    else return false;
  }

  public int getYes() {
    try {
      return (new Integer(getProperty ("yes")).intValue());
    } catch (NumberFormatException nfe) {
      return 0;
    }
    catch (Exception x) {
      x.printStackTrace();
      return -1;
    }
  }

  public int getNo() {
    try {
      return (new Integer(getProperty ("no")).intValue());
    } catch (NumberFormatException nfe) {
      return 0;
    }
    catch (Exception x) {
      x.printStackTrace();
      return -1;
    }
  }

  public int getUnknown() {
    try {
      return (new Integer(getProperty ("unknown")).intValue());
    } catch (NumberFormatException nfe) {
      return 0;
    }
    catch (Exception x) {
      x.printStackTrace();
      return -1;
    }
  }

  public String getTopic() {
    try {
      return getDescription();
    } catch (Exception x) {
      x.printStackTrace();
      return "----";
    }
  }

  public void voteYes() {
    try {
      incrementProperty ("yes");
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public void voteNo() {
    try {
      incrementProperty ("no");
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public void voteUnknown() {
    try {
      incrementProperty ("unknown");
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    try {
      if (propName.equals("yes")) {
        vM.voteYes ((new Integer(getProperty("yes"))).intValue());
      }
      else if (propName.equals("no")) {
        vM.voteNo ((new Integer(getProperty("no"))).intValue());
      }
      else if (propName.equals("unknown")) {
        vM.voteUnknown ((new Integer(getProperty("unknown"))).intValue());
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void destroy () {
//    removePropertyChangeListener(this);
    super.destroy();
  }

}
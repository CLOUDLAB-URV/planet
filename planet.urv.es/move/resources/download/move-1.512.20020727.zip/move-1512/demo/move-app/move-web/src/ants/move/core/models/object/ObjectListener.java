// Package ants.move.core.models.object
// ObjectListener.java
// (C) 2002 Oriol Montal� & Francesc Pi�as  collaborator: Carles Pairot
package ants.move.core.models.object;

/** ObjectListener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator: Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2000
*/
public interface ObjectListener {
/**
 * Refresh thing state
 * @param objectThingId key
 */
  public void refreshThing (String objectThingId);
  /**
   * Load thing
   * @param oT key
   */
  public void loadThing(ObjectThing oT);
  /**
   * Add new thing
   * @param oT key
   */
  public void newThing(ObjectThing oT);
  /**
   * Remove Thing
   * @param objectThingId key
   */
  public void removeThing(String objectThingId);
  /**
   * Catch thing
   * @param objectThingId key
   */
  public void catchThing(String objectThingId);
  /**
   * Deploy thing
   */
  public void deployThing(String objectThingId);
}

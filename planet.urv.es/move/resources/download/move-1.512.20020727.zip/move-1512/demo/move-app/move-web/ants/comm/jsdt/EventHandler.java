package ants.comm.jsdt;

import java.util.*;
import ants.comm.*;
import com.sun.media.jsdt.*;
import ants.util.Debug;

public class EventHandler extends Thread
{
	private Hashtable event;
	private Hashtable subscriptions;

	
	public EventHandler(Hashtable subscriptions, Data event)
	{
		this.subscriptions = subscriptions;
	
		try
 		{
			Hashtable evt =(Hashtable) event.getDataAsObject();
			this.event = evt;
 		
 		}catch (ClassNotFoundException e1){Debug.error(e1);
 		}catch (java.io.StreamCorruptedException e2){Debug.error(e2);
 		}

	}
	

	
	public void run()
	{
			
		
				
			Enumeration elements = subscriptions.keys();
						
			boolean found = false;

			while(elements.hasMoreElements()&&!found)
			{
				Hashtable theFilter = (Hashtable)elements.nextElement();
		
				Enumeration e = theFilter.keys();
				found = true;
				while(e.hasMoreElements())
						{
							String key = (String)e.nextElement();
							String value = (String)event.get(key);
			


							if (value==null || !value.equals((String)theFilter.get(key)))
									found=false;
						}
					if (found)
					{	
						//	 Dispatcher dP = new Dispatcher(((RemoteEventListener)subscriptions.get(theFilter)),se);
						//	 dP.start();
						Vector v = (Vector)subscriptions.get(theFilter);
						Enumeration listeners = v.elements();
						while (listeners.hasMoreElements())
							((RemoteEventListener)listeners.nextElement()).eventArrived(event);

					}
			//			((RemoteEventListener)subscriptions.get(theFilter)).eventArrived(se);
							
						}
						
 	
	
	}
	
	
}
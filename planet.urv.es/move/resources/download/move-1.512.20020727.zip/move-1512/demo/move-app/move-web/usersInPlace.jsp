<%@ page session="true" import="ants.move.lang.*, ants.move.ejb.*, com.protomatter.syslog.*, ants.comm.*, ants.move.core.*, ants.core.rmi.*, java.util.*, java.net.*, java.rmi.*" %>

<%! ResourceBundle labels,messages;
    LanguageUtilities lang; %>
<%
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");

  UserManager um = (UserManager)session.getAttribute("userManager");
    
  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  UserGateway ug=(UserGateway)Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway");
  
  
  Vector v=ug.getUsers(worldId,placeId);
 
  Enumeration e=v.elements();
  

%>
<html>
<body>
<center>
<h3><%=messages.getString("users")%>:</h3> <br>
<table width="90%" border="0" bgcolor="teal">
     <tr>
        <th><font color="white"><%=labels.getString("userTH")%></font></th>
        <th><font color="white"><%=labels.getString("nameUserTH")%></font></th>
        <th><font color="white"><%=labels.getString("surnameTH")%></font></th>
        <th><font color="white"><%=labels.getString("ipTH")%></font></th>
     </tr>
 <%
  while (e.hasMoreElements()){
    String userName=(String) e.nextElement();

 %>
  <tr ALIGN=CENTER bgcolor="#E6E4DD">
    <td><%=userName%></td>
    <td><%=((User)um.getUser(userName)).getProperty("name")%></td>
    <td><%=((User)um.getUser(userName)).getProperty("surname")%></td>
    <td><%=ug.getUserIP(worldId,placeId,userName)%></td>
    <td><INPUT TYPE="HIDDEN" name="ip" VALUE="<%=ug.getUserIP(worldId,placeId,userName)%>">
        <input type=button value="<%=labels.getString("call")%>" name="CallBtn" onClick=top.opener.window.document.NetMeeting.CallTo("<%=ug.getUserIP(worldId,placeId,userName)%>")>
  </tr>
 <%
  }
%>
</table> 
<br><br>
   <input type=button value="<%=labels.getString("update")%>" name="refreshBtn" onClick=location.reload()>


</center>
</body>
</html>
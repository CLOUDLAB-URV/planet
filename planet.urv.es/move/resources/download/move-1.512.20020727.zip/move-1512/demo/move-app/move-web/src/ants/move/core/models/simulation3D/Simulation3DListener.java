// Package ants.move.core.models.simulation3D
// Simulation3DListener.java
// 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.simulation3D;

/** Simulation3DListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface Simulation3DListener {
/**
 * Create new Simulation3d
 * @param url simulation3d source url
 */
  public void createSimulation (String url);
  /**
   * Remove simulation3d
   */
  public void removeSimulation ();
  /**
   * Move simulation3d
   * @param values
   */
  public void moveSimulation (String values);
  /**
   * Scale simulation3d
   * @param values
   */
  public void scaleSimulation (String values);
}

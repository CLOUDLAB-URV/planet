// Package ants.move.core.teacher
// Windows.java
// Implementation of a generic Applet window
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher;

// java.Applet Package import
import java.applet.Applet;

// java.awt Package imports
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.TextArea;

/** Implementation of a generic Applet window.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public class Windows extends Applet {
  /** Frame window.
  */
  public Frame window;

  /** Window layout.
  */
  public GridBagLayout gbLayout;

  /** Window layout's constraints.
  */
  public GridBagConstraints gc;

  /** Void constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public Windows() {
  }

  /** Main constructor.
      @param s Window title
      @exception exceptions No exceptions thrown
  */
  public Windows (String s) {
    window = new Frame(s);
  }

  /** Create new Window.
      @param s Window title
      @exception exceptions No exceptions thrown
  */
  public void setNewWindow (String s) {
    window = new Frame(s);
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;
    window.setSize(400, 150);
    window.setResizable(false);
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
   	window.setVisible(true);
  }

  /** Get if Window is visible.
      @param params None
      @return True if Window is visible
      @exception exceptions No exceptions thrown
  */
  public boolean isVisible() {
    return (window.isVisible());
  }

  /** Show window.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void showWin() {
    window.setVisible(true);
  }

  /** Hide window.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void hideWin() {
    window.setVisible(false);
  }

  /** Move window to the background.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void back() {
    window.toBack();
  }

  public void destroy() {
    System.err.println("POS ENTRO AL DESTROY DEL WINDOWS!");
  }
}
// Package ants.move.core.models.videoStream
// VideoStreamListener.java
// (C) 2002 Oriol Montal� & Francesc Pi�as  collaborator: Carles Pairot
package ants.move.core.models.videoStream;

/** VideoStreamListener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator: Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2000
*/
public interface VideoStreamListener {
 /**
 * Bind a URL
 * @param url URL of videoStream
 */
  public void setVideoStream (String url);
  /**
   * Destroy method
   */
  public void destroy();
}

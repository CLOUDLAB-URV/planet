package ants.move.ejb;


import javax.ejb.EJBObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for World Manager Session Bean
 */

public interface PlaceManager extends EJBObject {

  public Collection getPlaces(String worldId) throws RemoteException;
  public Place getPlace(String id) throws RemoteException;
  public Place createPlace(String id,String name,String type, String WorldId) throws RemoteException;
  public void removePlace(String id) throws RemoteException;

}


package ants.move.ejb;


import javax.ejb.EJBObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for Tool Manager Session Bean
 */

public interface ToolManager extends EJBObject {

  public Collection getTools() throws RemoteException;
  public Tool getTool(String id) throws RemoteException;
  public Tool createTool(String id,String name,String type) throws RemoteException;
  public void removeTool(String id) throws RemoteException;

}


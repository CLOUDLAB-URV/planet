package ants.core;

import java.util.Properties;


/**
*		Wrapping interface for client-side Java Beans. It provides an essential
*   initialization method with references to the shared session, event subscription
* and remote properties mechanism.
*
*/


public interface Model
{

	/**
	* Initialization method for client-side beans. Invoked by the Place component inorder ti properly
	* initialize the Java-bean in the ANTS container.
	* @param ch A reference to the shared session (Place), aimed for advanced programmers.
	* @param tH A reference to the remote Thing component enabling access to the property mechanism.
	*/



//	public void init(ANTSContext ctx,IThing tH);

	public void init(ANTSContext ctx, ants.core.rmi.ThingGateway tg);
	public void init();
	public void destroy();


	/**
	*	  Facility method for obtaining extra information about a specific bean.
	* @return String keyword describing component type
	*/

	public String getType();

}
package ants.move.core.teacher.doc;

import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.doc.*;
import ants.move.core.views.doc.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Frame;
import java.awt.Color;
import java.awt.TextArea;

import java.util.*;
import java.net.*;
import java.awt.event.*;

import vrml.external.Browser;

/** Implementation of Doc User Interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator : Carles Pairot (cpairot@tinet.org)
    @version 1.00 Build 2002
*/
public class DocControl extends Frame{
  private Button viewButton;
  private Button catchButton;
  private Button copyButton;
  private Button moveButton;
  private Button removeButton;
  private Label nameLabel;
  private Label descriptionLabel;
  private Label dateLabel;
  private Label ownerLabel;
  private Label name;
  private TextArea description;
  private Label date;
  private Label owner;
  private DocThing dT;
  private DocThingView dTV;
  private Browser browser;

  public DocControl(){
    viewButton= new Button("View");
    viewButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        viewButton_actionPerformed(e);
      }
    });
    catchButton= new Button("Catch");
    catchButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        catchButton_actionPerformed(e);
      }
    });
    copyButton= new Button("Copy");
    copyButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        copyButton_actionPerformed(e);
      }
    });
    moveButton= new Button("Move");
    moveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        moveButton_actionPerformed(e);
      }
    });
    removeButton= new Button("Remove");
    removeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeButton_actionPerformed(e);
      }
    });
    nameLabel = new Label("Name:");
    nameLabel.setForeground(Color.blue);
    descriptionLabel = new Label("Description:");
    descriptionLabel.setForeground(Color.blue);
    dateLabel = new Label("Date:");
    dateLabel.setForeground(Color.blue);
    ownerLabel = new Label("Owner:");
    ownerLabel.setForeground(Color.blue);

    this.enableEvents(WindowEvent.WINDOW_EVENT_MASK);
    this.setLayout(new FlowLayout());
    Panel p = new Panel();
    p.add(viewButton);
    p.add(catchButton);
    p.add(copyButton);
    p.add(moveButton);
    p.add(removeButton);
    p.setVisible(true);
    this.setSize(250,300);
    this.setLocation(700,250);
    this.setResizable(false);
    this.add(p);
    this.setVisible(false);
    this.setTitle("Move! File");
  }

  public void init(Hashtable ht){
  try{
    dT= (DocThing)ht.get("docThing");
    browser = (Browser)ht.get("browser");
    dTV = (DocThingView)ht.get("docThingView");
    name = new Label(dT.getName());
    description = new TextArea(dT.getDescription(),1,10,TextArea.SCROLLBARS_HORIZONTAL_ONLY);
    description.setEditable(false);
    date = new Label(dT.getProperty("date"));
    owner = new Label(dT.getProperty("owner"));
    Panel p2 = new Panel();
    p2.setBackground(Color.lightGray);
    p2.add(nameLabel);
    p2.add(name);
    Panel p3 = new Panel();
    p3.setBackground(Color.lightGray);
    p3.add(descriptionLabel);
    p3.add(description);
    Panel p4 = new Panel();
    p4.setBackground(Color.lightGray);
    p4.add(dateLabel);
    p4.add(date);
    Panel p5 = new Panel();
    p5.setBackground(Color.lightGray);
    p5.add(ownerLabel);
    p5.add(owner);
    this.add(p2);
    this.add(p3);
    this.add(p4);
    this.add(p5);
    this.setVisible(true);
    initButtons();
   }catch(Exception ex){ex.printStackTrace();}
  }

  private void initButtons(){
    try{
      if(!this.dT.getProperty("catch").equalsIgnoreCase("true")){
        this.catchButton.enable(false);
      }
      if(!this.dT.getProperty("copy").equalsIgnoreCase("true")){
        this.copyButton.enable(false);
      }
      if((dT.getPlace().getUser().equalsIgnoreCase(dT.getProperty("owner")))
      ||(dT.getPlace().getRole().equalsIgnoreCase("root"))){
        this.removeButton.enable();
        this.moveButton.enable();
      }else{
        this.removeButton.enable(false);
        this.moveButton.enable(false);
      }

    }catch(Exception ex){ex.printStackTrace();}
  }

  void viewButton_actionPerformed (ActionEvent e) {
    try{
     String[] destination = new String[1];
     String[] params = new String[1];
     destination[0]=dT.getProperty("fileName");
     params[0]="target=\"_blank\"";
     browser.loadURL(destination,params);

    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }
  void catchButton_actionPerformed (ActionEvent e) {
    try{
      if(catchButton.getLabel().equalsIgnoreCase("Deploy")){
        dT.getModel().deployThing(dT.getThingId());
        this.viewButton.enable(true);
        if(this.dT.getProperty("copy").equalsIgnoreCase("true")){
           this.copyButton.enable(true);
        }
        if((dT.getPlace().getUser().equalsIgnoreCase(dT.getProperty("owner")))
        ||(dT.getPlace().getRole().equalsIgnoreCase("root"))){
           this.removeButton.enable(true);
           this.moveButton.enable(true);
        }
        this.dispose();
      }else{
        dT.getModel().catchThing(dT.getThingId());
        catchButton.setLabel("Deploy");
        this.viewButton.enable(false);
        this.copyButton.enable(false);
        this.moveButton.enable(false);
        this.removeButton.enable(false);

      }
    }catch(Exception ex){}
  }

  void copyButton_actionPerformed (ActionEvent e) {
    try{
        dT.getPlace().addToBag(dT.getThingId());
        this.dispose();
    }catch(Exception ex){}
  }


  void moveButton_actionPerformed (ActionEvent e) {
    try{
      Hashtable params = new Hashtable();
      params.put("docThing",dT);
      params.put("docThingView",dTV);
      DocMoveControl dc= new DocMoveControl();
      dc.init(params);
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }


  void removeButton_actionPerformed (ActionEvent e) {
    try{
     if(this.dT.getPlace().hasPermission("doc.v01")){
      String[] destination = new String[1];
      String[] params = new String[1];
      destination[0]="../../../deleteDocument.jsp?thingId="+dT.getThingId()+"&name="+dT.getProperty("fileName");
      params[0]="target=\"_blank\"";
      browser.loadURL(destination,params);
      dT.getModel().sendRemoveThing(dT.getThingId());
     }
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e);
     if(!catchButton.getLabel().equalsIgnoreCase("Deploy")){
      if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        this.dispose();
      }
     }
  }



}
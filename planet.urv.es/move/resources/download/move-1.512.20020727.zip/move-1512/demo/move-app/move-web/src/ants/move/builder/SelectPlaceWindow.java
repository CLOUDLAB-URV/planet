package ants.move.builder;

// java.awt Package imports
import java.awt.*;
import ants.move.builder.*;
import java.util.*;
import java.net.*;
import java.awt.event.*;

public class SelectPlaceWindow extends Frame{
  private Button loadButton;
  private Choice placesChoice;
  private Label nameLabel;
  private Vector places=null;
  private Item item;
  private MOVEBuilderRemote comp;

  public SelectPlaceWindow(Item item, MOVEBuilderRemote comp){
    this.item=item;
    this.comp=comp;
    try {
       places= comp.getPlaces(item.getProperty("world"));
    } catch (Exception x) {
      System.err.println ("Error in getWorlds " + x);
    }

    loadButton= new Button(" OK ");
    loadButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loadButton_actionPerformed(e);
      }
    });
    placesChoice= new Choice();
    for(Enumeration en=places.elements();en.hasMoreElements();){
          placesChoice.addItem((String)en.nextElement());
    }

    nameLabel = new Label("Places:");
    nameLabel.setForeground(Color.blue);

    this.enableEvents(WindowEvent.WINDOW_EVENT_MASK);
    this.setLayout(new FlowLayout());
    Panel p = new Panel();
    p.add(nameLabel);
    p.add(placesChoice);
    p.add(loadButton);
    p.setVisible(true);
    this.setSize(250,200);
    this.setLocation(700,250);
    this.setResizable(false);
    this.add(p);
    this.setTitle("Choose Place");
    this.setVisible(true);
  }

  void loadButton_actionPerformed (ActionEvent e) {
    try{
      item.addProperty("place",placesChoice.getSelectedItem());
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.dispose();
    }
  }
}
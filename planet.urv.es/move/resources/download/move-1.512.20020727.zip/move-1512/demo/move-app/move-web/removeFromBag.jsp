<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, java.net.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;

%>

<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {

 String thingId = request.getParameter("thingId");

 User user=(User)session.getAttribute("user");

 int size=Integer.parseInt(user.getProperty("BagSize"));
 String value;
 Vector items=new Vector();
 for(int i=0;i<size;i++){
   value=user.getIndexedProperty("Bag",i);
   items.addElement(value);
 }

 items.removeElement(thingId);

 user.setProperty("BagSize",""+items.size());
 for(int i=0;i<items.size();i++){
    user.setIndexedProperty("Bag",(String)items.elementAt(i),i);
 }

} catch (Exception e) {
    Syslog.log (this, e);
}

response.sendRedirect("bagList.jsp");
%>
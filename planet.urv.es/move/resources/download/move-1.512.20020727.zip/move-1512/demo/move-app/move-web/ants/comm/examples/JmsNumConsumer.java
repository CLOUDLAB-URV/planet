
package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class JmsNumConsumer {
	
	
	public JmsNumConsumer()
	{
	 try
		{
			Hashtable env = new Hashtable ();
			env.put(Context.INITIAL_CONTEXT_FACTORY,"com.swiftmq.jndi.InitialContextFactoryImpl");
			env.put(Context.PROVIDER_URL,"smqp://localhost:4001/timeout=30000");
			env.put(Context.CONNECTION_FACTORY,"TopicConnectionFactory");
			env.put(Context.TOPIC,"testtopic");
			env.put(Context.PROVIDER_CLASS,"ants.comm.jms.Session");

		
			ants.comm.Session chatZone = SessionFactory.createSession(env);
	
			Listener1 l1 = new Listener1();
		
			String subs = "num > 7 AND num < 14";
			chatZone.addRemoteEventListener(l1,subs);

		
	
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	public class Listener1 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("event arrived !!!  " + evt);
		}
	}
	

	public static void main(String args[])
	{
			JmsNumConsumer tc = new JmsNumConsumer();
			System.out.println("Ready !  (Press CTRL+C to exit)");

			try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
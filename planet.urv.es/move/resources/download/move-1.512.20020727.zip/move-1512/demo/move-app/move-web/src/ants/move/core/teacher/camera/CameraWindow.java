// Package ants.move.core.teacher.camera
// CameraWindow.java
// Implementation of Camera User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.camera;

// dynamicObjects Package imports
import ants.core.*;
import ants.move.core.models.camera.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.*;
import vrml.external.field.*;

/** Implementation of Camera User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.30 Build 2000
*/
public class CameraWindow extends Windows implements TeacherInterface,
                                                     CameraListener {
  private CameraModel internalModel;
  // Camera name
  private String cameraName;
  private String codeBase;
  // Is camera viewpoint bound or not?
  private boolean bound = false;
  // ProximitySensor Node
//  private Node posNode;
  // ProximitySensor's positionChanged EventOut
//  private EventOutSFVec3f PSposition_changed;
  // ProximitySensor's orientationChanged EventOut
//  private EventOutSFRotation PSorientation_changed;
  // Buttons
  private Button deployButton;
  private Button unDeployButton;
  private Button goButton;
  // Labels
  private Label posLabel;
  private Label oriLabel;
  private Label pXLabel;
  private Label pYLabel;
  private Label pZLabel;
  private Label oXLabel;
  private Label oYLabel;
  private Label oZLabel;
  private Label oALabel;
  // TextFields
  private TextField pXText;
  private TextField pYText;
  private TextField pZText;
  private TextField oXText;
  private TextField oYText;
  private TextField oZText;
  private TextField oAText;
  // Camera's current orientation
  private float[] oriNow;
  // Camera's current position
  private float[] posNow;
  private Place conn;
  private String dispName;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public CameraWindow() {
    super();
    oriNow = new float[4];
    posNow = new float[3];
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow ("Camera");
    cameraName = (String) ht.get("src");
    conn = (Place) ht.get ("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (CameraModel) conn.getModel(cameraName);

    internalModel.addCameraListener(this);

    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(200, 310);
    window.setLocation(402, 405);
    window.setResizable(false);
    window.setLayout(gbLayout);
    p = new Panel();
    p.setLayout(null);
    p.setSize(190, 240);
    posLabel = new Label("Position");
    posLabel.setBounds(5, 0, 50, 24);
    p.add(posLabel);
    pXLabel = new Label("X");
    pXLabel.setBounds(5, 24, 30, 24);
    p.add(pXLabel);
    pYLabel = new Label("Y");
    pYLabel.setBounds(45, 24, 30, 24);
    p.add(pYLabel);
    pZLabel = new Label("Z");
    pZLabel.setBounds(85, 24, 30, 24);
    p.add(pZLabel);
    pXText = new TextField(5);
    pXText.setBounds(5, 48, 40, 24);
    p.add(pXText);
    pYText = new TextField(5);
    pYText.setBounds(45, 48, 40, 24);
    p.add(pYText);
    pZText = new TextField(5);
    pZText.setBounds(85, 48, 40, 24);
    p.add(pZText);
    oriLabel = new Label("Orientation");
    oriLabel.setBounds(5, 96, 80, 24);
    p.add(oriLabel);
    oXLabel = new Label("X");
    oXLabel.setBounds(5, 120, 30, 24);
    p.add(oXLabel);
    oYLabel = new Label("Y");
    oYLabel.setBounds(45, 120, 30, 24);
    p.add(oYLabel);
    oZLabel = new Label("Z");
    oZLabel.setBounds(85, 120, 30, 24);
    p.add(oZLabel);
    oALabel = new Label("Angle");
    oALabel.setBounds(125, 120, 45, 24);
    p.add(oALabel);
    oXText = new TextField(5);
    oXText.setBounds(5, 144, 40, 24);
    p.add(oXText);
    oYText = new TextField(5);
    oYText.setBounds(45, 144, 40, 24);
    p.add(oYText);
    oZText = new TextField(5);
    oZText.setBounds(85, 144, 40, 24);
    p.add(oZText);
    oAText = new TextField(5);
    oAText.setBounds(125, 144, 40, 24);
    p.add(oAText);
    deployButton = new Button("Deploy");
    deployButton.setBounds(5, 192, 55, 24);
    p.add(deployButton);
    unDeployButton = new Button("Remove");
    unDeployButton.setBounds(65, 192, 55, 24);
    p.add(unDeployButton);
    goButton = new Button("Go");
    goButton.setBounds(125, 192, 55, 24);
    p.add(goButton);
    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);

    deployButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deployButton_actionPerformed(e);
      }
    });

    unDeployButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        unDeployButton_actionPerformed(e);
      }
    });

    goButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        goButton_actionPerformed(e);
      }
    });

//    posNode = (internalModel.getVRMLPS());

/*    VRMLZone vrmlZone = new VRMLZone();
    vrmlZone.addVRMLEventListener(this, "camera");
*/
/*    PSposition_changed = (EventOutSFVec3f)posNode.getEventOut("position_changed");
    PSorientation_changed = (EventOutSFRotation)posNode.getEventOut("orientation_changed");
    PSposition_changed.advise(vrmlZone, "camera");
    PSorientation_changed.advise(vrmlZone, "camera");
*/
    pXText.setText("" + internalModel.getCamPos(0));
    pYText.setText("" + internalModel.getCamPos(1));
    pZText.setText("" + internalModel.getCamPos(2));
    oXText.setText("" + internalModel.getCamOri(0));
    oYText.setText("" + internalModel.getCamOri(1));
    oZText.setText("" + internalModel.getCamOri(2));
    oAText.setText("" + internalModel.getCamOri(3));

    if ((internalModel.getBound()).equals("false")) {
      deployButton.setEnabled(true);
      unDeployButton.setEnabled(false);
      goButton.setEnabled(false);
      textFieldsEnabled(false);
      bound = false;
    }
    else {
      deployButton.setEnabled(false);
      unDeployButton.setEnabled(false);
      goButton.setEnabled(true);
      textFieldsEnabled(false);
      bound = true;
    }
    System.err.println ("[MOVE] - Camera control window initialized.");
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Enables / Disables TextFields.
      @param b True enables TextFields
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void textFieldsEnabled (boolean b) {
    pXText.setEnabled(b);
    pYText.setEnabled(b);
    pZText.setEnabled(b);
    oXText.setEnabled(b);
    oYText.setEnabled(b);
    oZText.setEnabled(b);
    oAText.setEnabled(b);
  }

  /** deployButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void deployButton_actionPerformed (ActionEvent e) {
/*    internalModel.setCamOri(oriNow);
    internalModel.setCamPos(posNow);
*/
    internalModel.lockPosition();

    textFieldsEnabled(false);
    deployButton.setEnabled(false);
    unDeployButton.setEnabled(true);
    goButton.setEnabled(true);
  }

  /** unDeployButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void unDeployButton_actionPerformed (ActionEvent e) {
    textFieldsEnabled(true);
    deployButton.setEnabled(true);
    unDeployButton.setEnabled(false);
    goButton.setEnabled(false);
  }

  /** goButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void goButton_actionPerformed (ActionEvent e) {
    if (bound) {
      internalModel.setBind(false);
      bound = false;
      unDeployButton.setEnabled(true);
    }
    else {
      internalModel.setBind(true);
      bound = true;
      unDeployButton.setEnabled(false);
    }
  }

  public void bind (String pos, String ori) {
    bound = true;

    StringTokenizer tokens = new StringTokenizer (pos);
    pXText.setText(tokens.nextToken());
    pYText.setText(tokens.nextToken());
    pZText.setText(tokens.nextToken());

    tokens = new StringTokenizer (ori);
    oXText.setText(tokens.nextToken());
    oYText.setText(tokens.nextToken());
    oZText.setText(tokens.nextToken());
    oAText.setText(tokens.nextToken());

    textFieldsEnabled(false);
    deployButton.setEnabled(false);
    unDeployButton.setEnabled(false);
    goButton.setEnabled(true);
  }

  public void unBind () {
    bound = false;
    textFieldsEnabled(true);
    deployButton.setEnabled(false);
    unDeployButton.setEnabled(true);
    goButton.setEnabled(true);
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Camera";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }
}

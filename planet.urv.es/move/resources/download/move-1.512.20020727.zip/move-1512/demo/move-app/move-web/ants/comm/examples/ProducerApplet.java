package ants.comm.examples;

import java.applet.*;
import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;
import java.net.*;
import ants.util.Debug;

public class ProducerApplet extends Applet
{
	
	public void init()
	{
		try
		{
			String envFile   =  getParameter("ENVIRONMENT");	
			URL props = new URL("http://127.0.0.1:8080/"+envFile);
			ants.comm.Session conn = SessionFactory.createSession(props);
			Hashtable evt= new Hashtable();
			evt.put("type","evt");
			evt.put("msg","sdsds");
			long send1 = System.currentTimeMillis();
			for (int i= 0;i<10000;i++)
				conn.send(evt);
			long send2 = System.currentTimeMillis();
		
			System.out.println("SEND TIME = "+ (send2-send1));

			conn.close();
		
		}catch (SessionException s1)
		{
			Debug.error(s1.getException());
		}catch (MalformedURLException ex2)
		{
			Debug.error(ex2);
		}
		
	}
	
	
	
}
<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>
<%
 String server = request.getServerName ();
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");

 int port = request.getServerPort ();
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 Thing thing=thm.getThing(request.getParameter("thingId"));

 String url="worlds/"+worldKey+"/"+placeKey+"/"+ thing.getProperty("fileName");
 response.sendRedirect (url);
%>
// Package ants.move.core.teacher
// TeacherViews.java
// Implementation of the Model Engine
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher;

// java.util Package imports
import java.util.*;
import java.net.*;
import java.rmi.*;

import ants.core.*;
import ants.core.rmi.*;
import ants.move.core.teacher.chat.ChatWindow;
import ants.move.core.models.*;
import ants.move.core.*;

/** Implementation of Model Engine.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.00 Build 2000
*/
public class TeacherViews {
  private Vector teacherViews;
  private String tViewsList = "Teacher Views: ";

  public TeacherViews (Place conn, ChatWindow chatWin, Hashtable models) throws Exception {
    teacherViews = new Vector();
    ThingGateway tgate = (ThingGateway) Naming.lookup (Constants.getThingGatewayRMIId());

    Enumeration e = models.keys();

    while (e.hasMoreElements()) {
     //Vector modelInfo : model, thingModelId, toolType, toolName, teacher, VRML, node
      Vector modelInfo = (Vector) e.nextElement();
      String modelId = (String) modelInfo.firstElement();
      String toolId = (String) modelInfo.elementAt (1);
      String modelType = (String) modelInfo.elementAt (2);
      String modelDisplay = (String) modelInfo.elementAt(3);
      String ControlWindowClassName = (String) modelInfo.elementAt(4);

      if (!ControlWindowClassName.equalsIgnoreCase ("----")) {
        if(conn.hasPermission(modelType)){
          Class auxClass = Class.forName (ControlWindowClassName);
          TeacherInterface dObjUI = (TeacherInterface) auxClass.newInstance();
          Hashtable ht = new Hashtable();
          ht.put ("src", toolId);
          ht.put ("place", conn);
          ht.put ("dispName", modelDisplay);
          dObjUI.init (ht);
          tViewsList += modelDisplay + " ";
          // Store Object Interface in Vector for later use
          teacherViews.addElement((Object) dObjUI);
        }
      }
    }
    chatWin.consoleMessage (tViewsList);
  }

  public Vector getTeacherViews() {
    return teacherViews;
  }

  public void printMsg (String msg) {
    System.err.println ("[TeacherViews] - " + msg);
  }
}
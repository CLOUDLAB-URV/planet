<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>
<%
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 response.sendRedirect ("/worlds/"+worldKey+"/"+placeKey+"/"+ request.getParameter("thingId") + ".avi");
%>
// Package ants.move.core.models.avatar
// AvatarControl.java
// Avatar addition and removal control
// 2002 Carles Pairot & Oriol Montal�
package ants.move.core.models.avatar;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

import ants.move.core.views.DynamicObject;
import ants.move.core.views.avatar.*;
import ants.move.core.*;

import vrml.external.Browser;

// java.io Package imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Random;
import java.util.Vector;
import java.util.StringTokenizer;

import ants.move.core.teacher.chat.ChatWindow;

/** Avatar addition and removal control class.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.2 Build 2000
*/
public class AvatarControl implements RemoteEventListener, PlaceListener {
  private Place conn;
  // Reference to VRML browser
  private Browser browser;
  // DynamicObject used for avatar
  private DynamicObject root;
  // User's name
  private String username;
  // Where to write console and error messages
  private ChatWindow chatWin;
  // Current user (pilot)
  private AvatarPilotView currentUser;
  // Controls avatars' movements
  private AvatarMovement movementsThread;
  // Subscription Hashtable
  private Hashtable subscription = new Hashtable();
  // Movement subscription
  private Hashtable subscription2 = new Hashtable();
  // Applet's codeBase
  private String codeBase;
  // Avatar's VRML Representation
  private String avtRep;
  // Avatar's representations Vector
  private Vector usersInPlace;
  // Users Hashtable  [Key=userLogin]-[value=AvatarView]
  private Hashtable users;
  private String src;
  private String clss;
//  private long time;
//  private long arrived;
//  private int events=0;
  //move: position
  private float[] p = new float[3];
  //move: orientation
  private float[] o = new float[4];
  private float a;
  private float imx;
  private float imz;

  public AvatarControl (Place ch, Hashtable env) {
    src = (String) env.get("SRC");
    clss = (String) env.get("CLASS");
    browser = (Browser) env.get("browser");
    root = (DynamicObject) env.get("root");
    chatWin = (ChatWindow) env.get("chatWin");
    codeBase = (String) env.get("codeBase");
    avtRep = (String) env.get("avatar");
    conn = ch;
    username = conn.getUser();
    //move: orientation X is always = 0
    o[0]=0;
    //move: orientation Y is always = 1
    o[1]=1;
    //move: orientation Z is always = 0
    o[2]=0;
    a=Constants.getInfluenceArea();

    // Initialize users Hashtable
    users = new Hashtable();

    // Avatar Event consumer
    subscription.put("CLASS", clss);   // Avatar
    subscription.put("SRC", src);
    subscription.put(ants.core.Context.WORLD, conn.getWorld());
    subscription.put(ants.core.Context.PLACE, conn.getPlaceId());

    // Avatar movement Event consumer
    subscription2.put("SENDER", "MOVEPROXY");
    subscription2.put("OWNER", username);
    subscription2.put(ants.core.Context.WORLD, conn.getWorld());
    subscription2.put(ants.core.Context.PLACE, conn.getPlaceId());


    try {
      conn.addPlaceListener(this);
      conn.addPlaceListener(this, subscription);
      conn.addPlaceListener(this, subscription2);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }

    // Start the movements Thread
//    movementsThread = new AvatarMovement();
//    movementsThread.start();

    // We add ourselves as a pilot avatar using random coordinates
    // based on entry viewpoint 'View0'
    Random rand = new Random();
/*
    // If no photo file specified, load avatar's representation available files
    if (avtRep == null) {
      float numAvatars = 0;

      try {
        URL url = new URL(codeBase + "resources/avatars/avatars.properties");
        Properties props = new Properties();
        props.load(url.openStream());

        numAvatars = new Float((props.getProperty("avatarsNum"))).floatValue();

        for (int i = 1; i <= numAvatars; i++) {
          avtVect.addElement(codeBase + "resources/avatars/" + (props.getProperty("avatar" + i)));
        }
      }
      catch (Exception e) {
        System.err.println("Properties file for avatars does not exist.: "+e);
        System.err.println("Unable to display avatars.");
      }
    }
*/
    Float[] paux = new Float[3];
    paux[0] = new Float(Math.abs((rand.nextInt()%7)) - 3.5f);
    paux[1] = new Float(0);  //0.8f;
    paux[2] = new Float(Math.abs((rand.nextInt()%4)) - 2f);

    Float[] oaux = new Float[4];
    oaux[0] = new Float(0);
    oaux[1] = new Float(1);
    oaux[2] = new Float(0);
    oaux[3] = new Float((float) (rand.nextFloat() * 6.28));

    chatWin.consoleMessage("Adding user: " + username);

    // If none avatar's representation file has been chosen during login, choose
    // one randomly

//    if (avtRep == null) {
//      avtRep = vrmlStringAvatar();
//    }
    avtRep=codeBase+"resources/avatars/"+avtRep;

    // Pilot avatar addition
    Hashtable ht = new Hashtable();
    ht.put("browser", browser);
    ht.put("root", root);
    ht.put("USER", username);
    ht.put("POS", paux);
    ht.put("ORI", oaux);
    ht.put("avtRep", avtRep);
    ht.put("chatWin",chatWin);
    currentUser = new AvatarPilotView(conn, ht);
    currentUser.init();


    // Obtain reference to other users (if any)
    this.getUsers();
    usersInPlace=conn.getUsers();
  }

/*  public Vector getUsersVector() {
    return users;
  }

  public void setUsersVector (Vector v) {
    users = v;
  } */

  /** Remotely gets all users connected at that time.
      This method is used for getting all users connected. <BR>
      Sends an 'ask' remote event.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void getUsers() {
    Hashtable evtp = new Hashtable ();
    evtp.put("CLASS", "Avatar");        // Asking to 'Avatar' subscribers!! not 'AvatarControl' ones!!!
    evtp.put("SRC", src);
    evtp.put(ants.core.Context.WORLD, conn.getWorld());
    evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

    evtp.put("USER", username);
    evtp.put("METHOD", "ask");
    try {
      conn.send(evtp);
    }
    catch (SessionException s) {
      System.err.println("SessionException: Sending 'ask' event: " + s);
    }

  }

  /** Remotely remove ourselves from users Vector and from the VRML scene of other clients.
      Sends a 'delUser' remote event.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void destroyPilotUser() {
    Hashtable evtp = new Hashtable();
    evtp.put("CLASS", "Avatar");
    evtp.put("SRC", src);
    evtp.put(ants.core.Context.WORLD, conn.getWorld());
    evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

    evtp.put("USER", username);
    evtp.put("METHOD", "delUser");
    try {
      conn.send(evtp);
    }
    catch (SessionException s) {
      System.err.println("SessionException: Sending 'delUser' (Avatar) event: " + s);
    }
    Hashtable evtkk = new Hashtable();
    evtkk.put("CLASS", clss);
    evtkk.put("SRC", src);
    evtkk.put(ants.core.Context.WORLD, conn.getWorld());
    evtkk.put(ants.core.Context.PLACE, conn.getPlaceId());

    evtkk.put("USER", username);
    evtkk.put("METHOD", "delUser");
    try {
      conn.send(evtkk);
    }
    catch (SessionException s) {
      System.err.println("SessionException: Sending 'delUser' (AvatarControl) event: " + s);
    }
  }

  /** Adds and removes avatars.
      This method is executed whenever an avatar remote event is received by the Elvin4 client.
      @param evt Context
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventArrived (Hashtable evt) {
    if ( ((String)evt.get("METHOD")).equals("move") ) {
//      if (!(((String)evt.get("USER")).equals(username))) {
      if(users.containsKey((String)evt.get("USER"))){
       synchronized(this){
        p[0] = Float.valueOf((String) evt.get("PX")).floatValue();
        p[2] = Float.valueOf((String) evt.get("PZ")).floatValue();
/*
        float a=Math.abs(currentUser.getModel().getActualPosition(0) - p[0]);
        float b=Math.abs(currentUser.getModel().getActualPosition(2) - p[2]);
        float d= (a*a)+(b*b);
        if( d < Constants.getInfluenceArea()){
*/
        imx=currentUser.getModel().getActualPosition(0);
        imz=currentUser.getModel().getActualPosition(2);
        if( (p[0]>(imx-a)) && (p[0]<(imx+a)) && (p[2]>(imz-a)) && (p[2]<(imz+a))  ){

          p[1] = Float.valueOf((String) evt.get("PY")).floatValue();
//          o[0] = Float.valueOf((String) evt.get("OX")).floatValue();
          o[1] = Float.valueOf((String) evt.get("OY")).floatValue();
//          o[2] = Float.valueOf((String) evt.get("OZ")).floatValue();
          o[3] = Float.valueOf((String) evt.get("OA")).floatValue();
          ((AvatarView)users.get((String)evt.get("USER"))).moveAvatar(p,o);
        }
       }
//       }
      }
//      chatWin.consoleMessage("Event from "+(String)evt.get("USER") );
    }else if (((String)evt.get("METHOD")).equals("exitArea")) {
      if(users.containsKey((String)evt.get("USER"))){
          ((AvatarView)users.get((String)evt.get("USER"))).hideAvatar();
      }

    // Answer received: add old, previously-existing avatar
    }else if (((String)evt.get("METHOD")).equals("answer")) {
      //User is in place
      if(usersInPlace.contains((String)evt.get("USER"))){
        // If avatar has not been added yet
        if (!(contains((String)evt.get("USER")))) {
        // Doesn't have to show its body if it's pilot
         if (!(((String)evt.get("USER")).equals(username))) {
          Float[] pos = new Float[3];
          Float[] ori = new Float[4];
  //        String avtRep;

          // Obtain avatar position
          pos[0] = Float.valueOf((String)evt.get("PX"));
          pos[1] = Float.valueOf((String)evt.get("PY"));
          pos[2] = Float.valueOf((String)evt.get("PZ"));

            // Obtain avatar orientation
          ori[0] = Float.valueOf((String)evt.get("OX"));
          ori[1] = Float.valueOf((String)evt.get("OY"));
          ori[2] = Float.valueOf((String)evt.get("OZ"));
          ori[3] = Float.valueOf((String)evt.get("OA"));

//        avtRep = (String)evt.get("AVTREP");

          // Add avatar
          chatWin.consoleMessage("Adding existing user: " + (String)evt.get("USER"));
          Hashtable ht = new Hashtable();
          ht.put("browser", browser);
          ht.put("root", root);
          ht.put("USER", (String) evt.get("USER"));
          ht.put("POS", pos);
          ht.put("ORI", ori);
//          ht.put("mT", movementsThread);
          ht.put("avtRep", (String) evt.get("AVTREP"));
          ht.put("chatWin",chatWin);
          ht.put("avatarNum",""+(users.size()+1));

          AvatarView av = new AvatarView(conn, ht);
          users.put((String)evt.get("USER"),av);
          av.init();
          imx=currentUser.getModel().getActualPosition(0);
          imz=currentUser.getModel().getActualPosition(2);
          if( (pos[0].floatValue()>(imx-a)) && (pos[0].floatValue()<(imx+a))
           && (pos[2].floatValue()>(imz-a)) && (pos[2].floatValue()<(imz+a))  ){
            av.loadAvatar();
            av.showAvatar();
          }
        }
       }
      }
   // Add a new, non-previously-existing avatar
    }else if (((String)evt.get("METHOD")).equals("newUser")) {
      // If avatar has not been added yet
     synchronized(this){
      if (!(contains((String)evt.get("USER")))) {
        // Doesn't have to show its body if it's pilot
        if (!(((String)evt.get("USER")).equals(username))) {
          Float[] pos = new Float[3];
          Float[] ori = new Float[4];
//          String avtRep;

          // Obtain avatar position, orientation & color
          pos[0] = Float.valueOf((String)evt.get("PX"));
          pos[1] = Float.valueOf((String)evt.get("PY"));
          pos[2] = Float.valueOf((String)evt.get("PZ"));

          ori[0] = Float.valueOf((String)evt.get("OX"));
          ori[1] = Float.valueOf((String)evt.get("OY"));
          ori[2] = Float.valueOf((String)evt.get("OZ"));
          ori[3] = Float.valueOf((String)evt.get("OA"));

//          avtRep = (String)evt.get("AVTREP");

          // Add avatar
//          System.err.println("Adding new user: " + (String)evt.get("USER"));
          Hashtable ht = new Hashtable();
          ht.put("browser", browser);
          ht.put("root", root);
          ht.put("USER", (String) evt.get("USER"));
          ht.put("POS", pos);
          ht.put("ORI", ori);
//          ht.put("mT", movementsThread);
          ht.put("avtRep", (String) evt.get("AVTREP"));
          ht.put("chatWin",chatWin);
          ht.put("avatarNum",""+(users.size()+1));

          AvatarView av = new AvatarView(conn, ht);
          users.put((String)evt.get("USER"),av);
          av.init();
          imx=currentUser.getModel().getActualPosition(0);
          imz=currentUser.getModel().getActualPosition(2);
          if( (pos[0].floatValue()>(imx-a)) && (pos[0].floatValue()<(imx+a))
           && (pos[2].floatValue()>(imz-a)) && (pos[2].floatValue()<(imz+a))  ){
            av.loadAvatar();
            av.showAvatar();
          }
        }
       }
      }
    // Remove user
    }else if (((String)evt.get("METHOD")).equals("delUser")) {
      chatWin.consoleMessage("Removing user: " + (String)evt.get("USER"));
      // Remove user from users Hashtable
      remove((String)evt.get("USER"));

      // If I am removed, session must be left
      if (((String) evt.get("USER")).equals(username)) {
        this.leaveSession();
      }
    }

  }


  /** Checks if user is in the users Hashtable.
      @param user User's name
      @return True if user matches
      @exception exceptions No exceptions thrown
  */
  public boolean contains (String user) {
    return users.containsKey(user);
  }

  /** Removes user from users Hashtable.
      @param user User's name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void remove (String user) {
    if( users.containsKey(user)){
      ((AvatarView)users.get(user)).hideAvatar();
      ((AvatarView)users.get(user)).leaveSession();
      users.remove(user);
    }
  }

  /** Leaves Notification Service's session.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void leaveSession() {
    try {
      // Remove AvatarControl Class subscription
      conn.removePlaceListener(subscription2);
      conn.removePlaceListener(subscription);
      conn.removePlaceListener(this);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }
  }



/*  public Vector getAvatarUsers() {
    return users;
  }
*/
  public AvatarView getUser (String usr) {
    if( users.containsKey(usr)){
      return ((AvatarView)users.get(usr));
    }
    return null;
  }

  public void onMessage(Hashtable evt) {}
  public void userJoined(String userName) {}
  public void userLeft(String userName) {}

  public void usersChanged (String usrs) {
    usersInPlace=conn.getUsers();
    Hashtable nu= new Hashtable();
    String user;

    for(Enumeration en=usersInPlace.elements();en.hasMoreElements();){
      user=(String)en.nextElement();
      nu.put(user,"");
    }


    for(Enumeration e=users.keys();e.hasMoreElements();){
      user=(String)e.nextElement();
      if(!nu.containsKey(user)){
        System.err.println ("[MOVE] - Removing user " + user + " from MOVE!: His ping time has expired.");
        remove(user);
      }
    }
  }
}

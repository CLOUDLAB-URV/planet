
package ants.comm.examples;

import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;

public class NumProducer{
	
	
	public static void main(String args[])
	{
	
	 try
	 	{	
	
	  	ants.comm.Session chatZone = SessionFactory.createSession(args[0]);
	
			for (int i=0;i<100;i++)
			{
				Hashtable evt = new Hashtable();
				evt.put("arg1","value1");	
				evt.put("arg2","value2");
				evt.put("num",new Integer(i));	

				chatZone.send(evt);
			}
		
			chatZone.close();
			
	 	}catch (SessionException ex)
		{
			ex.getException().printStackTrace();
			
		}

	}

		
}
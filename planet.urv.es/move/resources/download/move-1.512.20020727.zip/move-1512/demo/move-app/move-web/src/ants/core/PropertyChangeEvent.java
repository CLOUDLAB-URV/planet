package ants.core;

import java.util.*;


/**
*		Event triggered in response to a property change in the remote Thing component.
*   It aims to mimic bound properties of the JavaBean component model.
*
*/


public class PropertyChangeEvent
{
	private String propName;
	private String propValue;
	private String user;
	private int index;
	private Object obj;
	
	
	public PropertyChangeEvent(String propName,String propValue,String user)
	{
		this.propName = propName;
		this.propValue = propValue;
		this.user = user;
		this.index =0;
		obj = null;
	}

	
	public PropertyChangeEvent(String propName,String propValue,int index,String user)
	{
		this.propName = propName;
		this.propValue = propValue;
		this.user = user;
		this.index =index;
		obj = null;
	}
	
	public PropertyChangeEvent(String propName,Object propValue, String user)
	{
		this.propName = propName;
		this.propValue = "";
		this.index =0;
		this.user = user;
		obj = propValue;

			
	}

		/**
	*	
	* Method returning the property name.
	* @return java.lang.String Property name.
	*/

	public String getPropName()
	{
		return propName;	
	}
	
	/**
	*	
	* Method returning the property value.
	* @return java.lang.String Property value.
	*/

	public String getPropValue()
	{
		return propValue;	
	}
	
		/**
	*	
	* Method returning the property index (for Indexed properties).
	* @return int  Property index.
	*/
	
	public int getIndex()
	{
		return index;	
		
	}
	
		/**
	*	
	* Method returning a property object value.
	* @return java.lang.Object Property object value.
	*/

	
	public Object getObjValue()
	{
		return 	obj;
		
	}
	
		/**
	*	
	* Method returning the user reponsible of a property change.
	* @return java.lang.String User name.
	*/

	
	public String getUser()
	{
		return user;
	}
	
	
}
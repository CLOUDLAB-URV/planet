package ants.core;

import java.util.*;


/**
*		Listener interface for subscribing to events in a Place.
*/


public interface PlaceListener
{

	/**
	*   Method triggered when a message arrives.
	* @param evt Hashtable event containing the received event.
	*/
	public void onMessage(Hashtable evt);

	/**
	*   Method triggered when a user arrives.
	*   @param userName New user`s name
	*/

	public void userJoined(String userName);

	/**
	*   Method triggered when a user leaves the place.
	*   @param userName Name of leaving user.
	*/

	public void userLeft(String userName);

	/**
	*   Method triggered when hung users have been detected
	*   @param users Current users in that place.
	*/
        public void usersChanged (String users);

}
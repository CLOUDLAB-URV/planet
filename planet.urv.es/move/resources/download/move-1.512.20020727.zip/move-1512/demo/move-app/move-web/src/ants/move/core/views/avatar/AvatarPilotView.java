// Package ants.move.core.views.avatar
// AvatarPilotView.java
// Avatar Pilot implementation
// (C) 2000-2002 Oriol Montal� & Carles Pairot

package ants.move.core.views.avatar;
// ANTS imports

import ants.comm.*;
import ants.core.*;
import ants.util.Debug;
import ants.move.core.views.DynamicObject;
import ants.move.core.models.avatar.*;
import ants.move.core.teacher.chat.ChatWindow;

// java.util Package imports
import java.util.Hashtable;
import java.util.zip.*;

import java.net.URL;
import java.net.MalformedURLException;
import java.io.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Avatar implementation.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.22 Build 2000
*/
public class AvatarPilotView extends DynamicObject  {

  private float avatarHeight = 1.75f;

  // DynamicObject used for avatar
  private DynamicObject root;
  // ProximitySensor that will detect pilot avatar's position
  private Node proximitySensor;
  // EventOut avatar position
  private EventOutSFVec3f PSposition_changed;
  // EventOut avatar orientation
  private EventOutSFRotation PSorientation_changed;
  // EventIn avatar's position (so it can be changed)
  private EventInSFVec3f avatarPosition = null;
  // EventIn avatar's orientation (so it can be changed)
  private EventInSFRotation avatarRotation = null;

  private Node defaultViewpoint;

  // Avatar's name
  private String username;
  private String avatarRepresentation;
  private Place conn;
  // Used for avatar's movements
  private EventInMFNode avtAddChildren, avtRemChildren;
  private AvatarModel aM;
  private ChatWindow chatWin;
  private Float[] pos = new Float[3];
  private Float[] ori = new Float[4];

  public AvatarPilotView() {
  }

  /** Sole constructor.
      @exception exceptions No exceptions thrown
  */


  public AvatarPilotView (Place ch, Hashtable env) {
    super();
    super.setBrowser((Browser) env.get("browser"));

    root = (DynamicObject) env.get("root");
    username = (String) env.get ("USER");
    avatarRepresentation = (String) env.get("avtRep");
    conn = ch;
    pos = (Float[]) env.get ("POS");
    ori = (Float[]) env.get ("ORI");
    root.setChNodes();        // add / removeChildren
    chatWin = (ChatWindow)env.get("chatWin");
  }

  public void init () {
   // Common code for pilot and non-pilot avatars
    Hashtable ht = new Hashtable();
    ht.put("CLASS", "Avatar");
    ht.put("SRC", "MOVEAvatars");
    ht.put("USER", username);
    ht.put("pilot", Boolean.TRUE);
    ht.put("avtRep", avatarRepresentation);
    ht.put("chatWin",chatWin);

    aM = new AvatarModel (conn, ht);
    aM.setActualPosition(pos);
    aM.setActualOrientation(ori);

    // Add VRMLEventListener so proximitySensor events can be captured
    super.setVRMLNodeName("avatar");
    super.addListener();

    // As it's a pilot avatar, a proximitySensor is created to catch movements
    proximitySensor = getBrowser().getNode("PS");   // We catch the scene's ProximitySensor

    // Capture VRML position & orientation of avatar
    PSposition_changed=(EventOutSFVec3f)proximitySensor.getEventOut("position_changed");
    PSorientation_changed=(EventOutSFRotation)proximitySensor.getEventOut("orientation_changed");

    // Advise (through event_performed() method) that avatar's position or
    // orientation has changed
    PSposition_changed.advise(getZone(), "avatar");
    PSorientation_changed.advise(getZone(), "avatar");

    // Obtain reference to default viewpoint
    defaultViewpoint = getBrowser().getNode("View0");
    float[] defaultViewpointPosition = new float[3];
    defaultViewpointPosition = ((EventOutSFVec3f) defaultViewpoint.getEventOut("position_changed")).getValue();

    // Create avatar's viewpoint
    Node[] auxNode = (super.getBrowser()).createVrmlFromString("Viewpoint {\n"+
                         	"description \"" + username + "\"\n"+
				"position " +
				(defaultViewpointPosition[0] + pos[0].floatValue()) + " " +
				(defaultViewpointPosition[1] /* + avatarHeight */) + " " +
				(defaultViewpointPosition[2] + pos[2].floatValue()) + "\n" +
      		                "orientation " +
                                ori[0] + " " +
  			        ori[1] + " " +
			        ori[2] + " " +
                                ori[3] + "\n" +
		        "}\n");

    // Add auxNode to VRML scene
    root.setaddChValue(auxNode);

    // Bind viewpoint
    ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(true);

    aM.newUser (pos, ori);

  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Get user's name.
      @param params None
      @return User's name
      @exception exceptions No exceptions thrown
  */
  public String getUserName() {
    return username;
  }

  /** Sends position & orientation of avatar if needed.
      This method is executed whenever an EventOut from proximitySensor is produced. <BR>
      This can happen only if position or orientation of pilot avatar has changed
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventPerformed() {

      Float[] posNow = new Float[3];
      Float[] oriNow = new Float[4];
      float[] aux = new float[4];

      // Get avatar's current position in the VRML scene
      aux = PSposition_changed.getValue();
      posNow[0] = new Float(to1d(aux[0]));
      posNow[1] = new Float(to1d(aux[1])); // - 1.5f);
      posNow[2] = new Float(to1d(aux[2]));

      // Get avatar's current orientation in the VRML scene
      aux = PSorientation_changed.getValue();
      oriNow[0] = new Float(to1d(aux[0]));
      oriNow[1] = new Float(to1d(aux[1]));
      oriNow[2] = new Float(to1d(aux[2]));
      oriNow[3] = new Float(3.14f + to1d(aux[3]));   // We have to add 3.14 to rotate it 180�

      aM.moveAvatar (posNow, oriNow);

  }

  public void leaveSession() {
    aM.leaveSession();
  }

  public AvatarModel getModel(){
    return aM;
  }


}

package ants.move.core.teacher.chat;

import ants.move.core.teacher.*;
import ants.move.core.models.chat.*;
import ants.core.*;

public class PrivateChatWindow extends Windows {
  private String toUser;
  private Place conn;
  private ChatModel cM;

  public PrivateChatWindow (String usr, Place p, ChatModel c) {
  }

}
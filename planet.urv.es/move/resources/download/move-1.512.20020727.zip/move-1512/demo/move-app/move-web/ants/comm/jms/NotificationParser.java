package ants.comm.jms;

import ants.comm.*;
import ants.util.*;
import javax.jms.*;

public class NotificationParser implements MessageListener
{
	RemoteEventListener subs;
	
	public NotificationParser (RemoteEventListener subs)
	{
		this.subs = subs;	
	}
	 public void onMessage(Message msg)
  {
	
				 JmsDispatcher dP = new JmsDispatcher(subs,msg);
		 		 dP.start();

			//	subs.eventArrived(JmsParser.getEvt(msg));
	
  }	
}
package ants.move.builder;

import java.rmi.*;
import java.io.*;
import java.util.Vector;

// This is MOVE! Builder's Remote Interface
public interface MOVEBuilderRemote extends Remote {
  public String store3DPlaceInMOO (Room hab, String user) throws RemoteException, IOException;
  public String create3DPlace (String worldKey, String placeKey, String userRole,
                               String userLogin, String placeType) throws RemoteException;
  public Room load3DPlace (String worldKey, String placeKey, String userRole,
                           String userLogin, String placeType) throws RemoteException;
  public Vector getWorlds() throws RemoteException;
  public Vector getPlaces (String worldName) throws RemoteException;

}
package ants.move.ejb;

import javax.ejb.EJBObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for World Manager Session Bean
 */

public interface WorldManager extends EJBObject {

  public Collection getWorlds() throws RemoteException;
  public World getWorld(String id) throws RemoteException;
  public World createWorld(String id,String name,String type) throws RemoteException;
  public void removeWorld(String id) throws RemoteException;

}


package ants.move.core.models.doc;

import ants.core.*;
import java.util.*;
import ants.util.*;
import ants.comm.*;

/**
 * Implementation of DOC model
 * @author:      Oriol Montal� & Carles Pairot & Francesc Pi�as
 * @version 1.0 build 2002
 */
public class DocModel extends Thing implements ants.comm.RemoteEventListener{
  protected Vector listeners = new Vector();
  private Hashtable subs = new Hashtable();
  private Hashtable docThings = new Hashtable();
  private String thingCatched= "";
  private String user=null;
/**
 * Initialize model
 */
  public void init() {
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","DOC.V01");
      user=this.getPlace().getUser();
      super.getPlace().addPlaceListener(this,subs);
      Vector thingKeys = super.getPlace().getThings("doc.v01");
      loadDocThings(thingKeys);
    } catch (Exception x) {
      x.printStackTrace();
    }
    System.err.println("[MOVE] - DOC model initialized.");
  }

  private void loadDocThings(Vector thingKeys){
    ants.core.Thing key;
    for(Enumeration e=thingKeys.elements();e.hasMoreElements();){
      key=(ants.core.Thing)e.nextElement();
      loadThing(key.getThingId());
    }
  }

/**
 * Add Doc Listener
 * @param docL listener
 */
  public void addDocListener (DocListener docL) {
    listeners.addElement(docL);
  }
/**
 * Remove Doc listener
 * @return Listener
 */
  public Hashtable getDocThings(){
    return (docThings);
  }
/**
 * Catch thing
 * @param thingKey Key
 */
  public void catchThing(String thingKey){
    try{
      thingCatched=thingKey;
      //catch Thing
      for (int i = 0; i < listeners.size (); i++) {
        ((DocListener) listeners.elementAt (i)).catchThing(thingKey);
      }
      //removeThing from Place
      DocThing dTH=(DocThing)docThings.get(thingKey);
      dTH.setProperty("catched",user);
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","DOC.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Refresh thing state
 * @param thingKey key
 */
  public void refreshThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((DocListener) listeners.elementAt (i)).refreshThing(thingKey);
      }
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Load doc thing
 * @param thingKey key
 */
  public void loadThing(String thingKey){
  try{
   if(!docThings.containsKey(thingKey)){
     ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
     DocThing dTH = new DocThing();
     dTH.init(ctx, super.getThingGateway());
     dTH.setModel(this);
     if((dTH.getProperty("catched").equalsIgnoreCase("false"))||
     (dTH.getProperty("catched").equalsIgnoreCase(user))){
       docThings.put(thingKey,dTH);
       for (int i = 0; i < listeners.size (); i++) {
         ((DocListener) listeners.elementAt (i)).loadThing(dTH);
       }
     }else{
      dTH.destroy();
     }
   }else{
    System.err.println("Trying to load an existing DOC THING");
   }
  }catch(Exception ex){System.out.println("Load Thing Exception:"+ex);
                       System.err.println("Load Thing Exception:"+ex);}
  }

/**
 * Destroy thing
 * @param thingKey key
 */
  public void deployThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((DocListener) listeners.elementAt (i)).deployThing(thingKey);
      }
      thingCatched="";
      DocThing dTH=(DocThing)docThings.get(thingKey);
      dTH.setProperty("catched","false");
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","DOC.V01");
      subs.put("METHOD","LOADTHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Send remove thing event
 * @param thingKey key
 */
  public void sendRemoveThing(String thingKey){
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","DOC.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}

  }

  public void eventArrived (Hashtable evt) {
    String method = (String)evt.get("METHOD");
    //adding a new thing
   try{
    if(method.equalsIgnoreCase("NEWTHING")){
      ANTSContext ctx = new ANTSContext(super.getPlace(), (String)evt.get("THINGKEY"));
      DocThing dTH = new DocThing();
      dTH.init(ctx, super.getThingGateway());
      dTH.setModel(this);
      dTH.setProperty("catched","false");
      docThings.put((String)evt.get("THINGKEY"),dTH);
      for (int i = 0; i < listeners.size (); i++) {
        ((DocListener) listeners.elementAt (i)).newThing(dTH);
      }

    }else if(method.equalsIgnoreCase("REMOVETHING")){
      DocThing dT= (DocThing)docThings.get((String)evt.get("THINGKEY"));
      if(!thingCatched.equalsIgnoreCase(dT.getThingId())){
        docThings.remove((String)evt.get("THINGKEY"));
        for (int i = 0; i < listeners.size (); i++) {
          ((DocListener) listeners.elementAt (i)).removeThing(dT.getThingId());
        }
        dT.destroy();
      }
    }else if(method.equalsIgnoreCase("LOADTHING")){
       loadThing((String)evt.get("THINGKEY"));
    }
  }catch(Exception ex){System.out.println("Load Thing Exception:"+ex);
                       System.err.println("Load Thing Exception:"+ex);}
  }
/**
 * Tool type
 * @return DOC
 */
  public String getType() {
    return "DOC";
  }
/**
 * Destroy method
 */
  public void destroy() {
   try{
//    super.getPlace().removePlaceListener(subs);
    super.destroy();
   }catch(Exception ex){System.err.println("[MOVE] -- Unable to destroy DOC model");ex.printStackTrace();}
  }


}
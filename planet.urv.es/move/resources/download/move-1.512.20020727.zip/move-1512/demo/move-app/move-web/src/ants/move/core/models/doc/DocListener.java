// Package ants.move.core.models.doc
// DocListener.java
// (C) 2002 Oriol Montal� & Francesc Pi�as  collaborator: Carles Pairot
package ants.move.core.models.doc;

/** DocListener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator: Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2000
*/
public interface DocListener {
/**
 * Refresh thing state
 * @param docThingId key
 */
  public void refreshThing (String docThingId);
  /**
   * Load thing
   * @param dT key
   */
  public void loadThing(DocThing dT);
  /**
   * Add new thing
   * @param dT key
   */
  public void newThing(DocThing dT);
  /**
   * Remove Thing
   * @param docThingId key
   */
  public void removeThing(String docThingId);
  /**
   * Catch thing
   * @param docThingId key
   */
  public void catchThing(String docThingId);
  /**
   * Deploy thing
   */
  public void deployThing(String docThingId);
}

// Package ants.move.core.models.avatar
// AvatarListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.avatar;

/** AvatarListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface AvatarListener {
  public void moveAvatar (float[] p, float[] o);
  public void greetAvatar();
  public void danceAvatar();
  public void showAvatar ();
  public void hideAvatar();
  public void destroyAvatar();
}

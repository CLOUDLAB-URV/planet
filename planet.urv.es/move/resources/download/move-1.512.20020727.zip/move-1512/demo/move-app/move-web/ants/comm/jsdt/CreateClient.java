package ants.comm.jsdt;

import com.sun.media.jsdt.*;
import com.sun.media.jsdt.event.ClientEvent;

public class CreateClient implements Client
{
  protected String name;

 public CreateClient(){
 }
 public CreateClient(String name)
 {
 	 this.name=name;
 }
 public Object authenticate(AuthenticationInfo info) 
 {
   System.err.println("�Quien ha llamado a authenticate de CreaCliente?"); 
	 return(null);
 }
 /*-----------------------------------------------------------------------------------------------*/    
 //Implementaci�n de la interfaz Client
 public String getName() 
 {
   return(name);
 }
}
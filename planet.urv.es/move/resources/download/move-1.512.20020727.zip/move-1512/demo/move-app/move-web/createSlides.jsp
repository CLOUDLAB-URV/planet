<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*, com.evermind.io.*,java.util.zip.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>
<%
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 String userLogin = ((User)session.getAttribute("user")).getLogin();
 String toolKey = "slides.v05";
 int port = 80;
 if (request.getMethod().equalsIgnoreCase("GET")) {
   String server=request.getServerName();
   port=request.getServerPort();
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");

   %>
   <html>
   <body>
   <jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
   <center>
   <table width=90%>
    <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("uploadSlides")%> : </b></font></td></tr>
   </table>
   <table width=90%>
    <form enctype="multipart/form-data" method="POST">
    <tr>
     <td colspan="3">
       <br><%=messages.getString("uploadSlides")%>
        <br><br>
     </td>
    </tr>
    <tr>
     <td colspan="3">
     <b><%=labels.getString("presentationName")%> :</b> <input type="text" name="Name" size="20"><br><br>
     </td>
    </tr>
    <tr>
    <td colspan="3">
      <b><%=labels.getString("presentationDescription")%> :</b>
      <input type="text" name="Desc"  size="50"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("chooseZipFile")%> :</b><input type="file" name="file"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <center><input type=submit name=action value="<%=labels.getString("upload")%>"> <input TYPE="reset" VALUE="<%=labels.getString("reset")%>" border="0" cellpadding="0" cellspacing="0">
      </center>
    </td>
   </tr>
  </form>
  </table>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>
  </BODY>
  </HTML>
  <%
}else{

   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String fileName="";
   Vector thingFiles=new Vector();

   Enumeration enumeration = new FilePostParser(request.getInputStream(),
                                                request.getContentLength());
   while( enumeration.hasMoreElements() ) {
          Object element = enumeration.nextElement();
          if( element instanceof Map.Entry ) {
               Map.Entry entry = (Map.Entry)element;

               if ((entry.getKey()).equals("Name"))
		   thingName = (String)entry.getValue();
               if ((entry.getKey()).equals("Desc"))
		   thingDesc = (String)entry.getValue();



           }
           else if( element instanceof PostFileInputStream ) {
               PostFileInputStream in = (PostFileInputStream)element;
               File file=new File(in.getFileName());

               fileName=file.getName();
               FileOutputStream fout = new FileOutputStream
       		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
               int bite;
               while((bite=in.read()) != -1)
                   fout.write(bite);

               in.close();
               fout.close();

           }
    }

    ZipFile zip = new ZipFile (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
    byte[] buffer = new byte [1024];
    for (Enumeration images = zip.entries(); images.hasMoreElements(); ) {
           ZipEntry ze = (ZipEntry) images.nextElement();
           File f = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+thingKey);
           f.mkdir ();
           FileOutputStream slide = new FileOutputStream
                                                (pageContext.getServletContext().getRealPath("/worlds/"
                                                 + worldKey+"/"+placeKey+"/")+thingKey + "/"
                                                 + ze.getName());
           InputStream inzip = zip.getInputStream (ze);
           int ix;
           while ((ix = inzip.read (buffer, 0, 1024)) != -1) {
              if (ix != 1024) {
                  byte[] buf2 = new byte [ix];
                  for (int k = 0; k < ix; k++) {
                      buf2[k] = buffer[k];
                  }
                  slide.write (buf2);
                } else {
                    slide.write (buffer);
                }
           }

           thingFiles.addElement("../../../worlds/"+worldKey+"/"+placeKey+"/" + thingKey + "/" + ze.getName());

     }
     zip.close();
     File f = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
     f.delete();
     ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
     Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
     thing.setDescription(thingDesc);
     thing.setProperty("date",(new Date()).toGMTString());
     thing.setProperty("owner",userLogin);
     thing.setProperty ("slidesSize", ""+thingFiles.size());
     Enumeration e = thingFiles.elements();
     int idx = 1;
     while (e.hasMoreElements()) {
       thing.setIndexedProperty ("slides", (String) e.nextElement(), idx);
       idx++;
     }
     Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
     response.sendRedirect("listThings.jsp");
}
%>
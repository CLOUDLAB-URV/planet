<%@ page session="true" import = "net.yagga.util.Unzip, ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, com.evermind.io.FilePostParser,com.evermind.io.PostFileInputStream, ants.move.ejb.*, java.io.*, java.util.zip.*" %>

<%! ResourceBundle labels,messages;
    LanguageUtilities lang;
  String placeType=null;
  String placeName=null;
%>
<%
if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");
   
%>
 <html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES&linked=true" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("newPlace")%> : </b></font></td></tr>
</table>

<table width=90%>
   <tr>
    <td colspan="3">
    <br><%=messages.getString("uploadPlace")%><br><br>
    </td>
   </tr>
   <form enctype="multipart/form-data" method="POST">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("placeType")%> : </b><input type="text" size="10" maxlength="12" name="type"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("chooseFile")%> :</b><input type="file" name="file"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
    </td>
   </tr>
   </form>
  </table>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>
</body>
</HTML>
<%
}else{
   String fileName="";
   
   Properties props = new Properties();
   FileInputStream fis = new FileInputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
   
   props.load(fis);
   
   fis.close();

   Enumeration enumeration = new FilePostParser(request.getInputStream(), 
                                                request.getContentLength()); 
       while( enumeration.hasMoreElements() ) { 
          Object element = enumeration.nextElement(); 
          if( element instanceof Map.Entry ) { 
               Map.Entry entry = (Map.Entry)element; 
       
               if ((entry.getKey()).equals("type"))
		   placeType = (String)entry.getValue();

               
               
           } 
           else if( element instanceof PostFileInputStream ) { 
               PostFileInputStream in = (PostFileInputStream)element;
               File file=new File(in.getFileName());

               fileName=file.getName();
              

               FileOutputStream fout = new FileOutputStream
       		          (pageContext.getServletContext().getRealPath("/resources/things/")+fileName);
               int bite;
               while((bite=in.read()) != -1)
                   fout.write(bite);
          
               in.close();
               fout.close();

              
              
            
           }
       }
    
    placeName=placeType+"_"+System.currentTimeMillis();             
    File f = new File (pageContext.getServletContext().getRealPath
                             ("/resources/things/places/"+placeName));
    f.mkdir ();
    
    

    props.setProperty("place"+(props.size()+1),placeName);

    Unzip u=new Unzip(pageContext.getServletContext().getRealPath("/resources/things/")+fileName,pageContext.getServletContext().getRealPath("/resources/things/places/")+placeName);
    u.uncompress(false); 
    

     File f2 = new File (pageContext.getServletContext().getRealPath("/resources/things/")+fileName);
     f2.delete();

   
   
   FileOutputStream fos = new FileOutputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
   props.store(fos,"Base places");
   fos.close();
   
   response.sendRedirect("createPlace.jsp");
}
%>
package ants.move.ejb;


import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;
import com.protomatter.syslog.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a User Manager
 */

public class UserManagerBean implements SessionBean{

  UserHome userHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/UserBean");
      userHome =(UserHome) PortableRemoteObject.narrow(objRef,UserHome.class);
    }catch(Exception eC){
        Syslog.error (this, "Unable to create Manager");
    }
  }
  public Collection getUsers(){
    Collection users= new ArrayList();
    try{
      users=userHome.findByAll();
    }catch(Exception gwE){
        Syslog.debug (this, "getUsers() : Contains 0 users");
    }
    return users;
  }

  public User getUser (String login){
    User user=null;
    try{
      user=userHome.findByPrimaryKey(login);
    }catch(Exception gwE){
        Syslog.debug (this, "getUser("+login+") : "+gwE);
    }
    return user;
  }
  public User createUser(String login,String password,String role){
    User user=null;
    try{
      user = userHome.create(login);
      user.setPassword(password);
      user.setRole(role);

    }catch(Exception gwE){
        Syslog.error (this, "createUser("+login+","+password+","+role+") : "+gwE);
    }
    return user;
  }
  public void removeUser(String login){
    User user=null;
    try{
      user=userHome.findByPrimaryKey(login);
      user.remove();
    }catch(Exception gwE){
        Syslog.error (this, "removeUser("+login+") : "+gwE);
    }
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
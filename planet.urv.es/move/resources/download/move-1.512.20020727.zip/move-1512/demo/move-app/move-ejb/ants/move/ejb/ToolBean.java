package ants.move.ejb;

import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;
import com.protomatter.syslog.*;
import java.util.*;


/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Entity Bean for a Tool
 *  It is a BMP (Bean Managed Persistence) EJB (Enterprise JavaBean)
 */
public class ToolBean implements EntityBean {
  // Primary key
  private String          toolId;
  private String          myName;
  private String          myDescription;
  private String          myType;
  protected EntityContext context;
  /**
   * This method gets a connection to the database
   */
  private Connection getConnection() throws SQLException {
    try {
      InitialContext jndiContext = new InitialContext();

      DataSource source = (DataSource) jndiContext.lookup (
                          "jdbc/DefaultPooledDS");
      return source.getConnection();
    } catch (Exception ex) {
      Syslog.fatal (this, "Exception getting database connection!");
      Syslog.fatal (this, ex);
      return null;
    }
  }

  /**
   * This method inserts a new register into the database
   */
  public String ejbCreate (String id) {
    toolId = id;
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("INSERT INTO tool (id) VALUES ('"
                             + toolId + "')");
      return id;
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbPostCreate (String id) { }

  /**
   * This method removes a previously existent register from the database
   */
  public void ejbRemove () {
    String primaryKey = (String) context.getPrimaryKey();
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("DELETE FROM tool WHERE id = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM toolproperty WHERE subid = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM toolindexproperty WHERE subid = '" +
                             primaryKey+"'");

    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the beginning of a transaction
   */
  public void ejbLoad() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                              "SELECT * FROM tool WHERE id = '" +
                              primaryKey+"'");

      if (results.next()) {
        // Get the name information from the tool table
        myName = new String (results.getString ("NAME"));
        // Get the name information from the tool table
        myDescription = new String (results.getString ("DESCRIPTION"));
        // Get the type information from the tool table
        myType = new String (results.getString ("TYPE"));
        // Get the id information from the tool table
        toolId = new String (results.getString ("ID"));

      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the end of the transaction, just before
   * the container sends all the changes to the database
   */
  public void ejbStore() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      PreparedStatement sqlPrep = conn.prepareStatement (
                                  "UPDATE tool SET " +
                                  "name = ?, description = ?, type = ? " +
                                  "WHERE id = ?");
      sqlPrep.setString (1, myName);
      sqlPrep.setString (2, myDescription);
      sqlPrep.setString (3, myType);
      sqlPrep.setString (4, toolId);
      sqlPrep.executeUpdate();
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method finds by primary key
   */
  public String ejbFindByPrimaryKey (String primaryKey)
                 throws ObjectNotFoundException {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT * FROM tool WHERE id = '" +
                            primaryKey+"'");
      if (results.next()) {
        return primaryKey;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method returns all primary keys
   */
  public Collection ejbFindByAll() throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT id FROM tool");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }


  }

  public void ejbActivate() {}
  public void ejbPassivate() {}



  public void setEntityContext (EntityContext cntx) {
    context = cntx;
  }

  public void unsetEntityContext() {
    context = null;
  }

  public String getName() {
    return myName;
  }

  public void setName (String name) {
    myName = name;
  }

  public String getDescription() {
    return myDescription;
  }

  public void setDescription (String description) {
    myDescription = description;
  }

  public String getType() {
    return myType;
  }

  public void setType (String type) {
    myType = type;
  }

  public String getId(){
  return toolId;
  }

  public String getProperty (String property) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM toolproperty " +
                            "WHERE subId ='"+toolId+"' and name='"+property+"'");
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setProperty (String property, String value)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE toolproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+toolId+"' and name='"+property+"'");
      if(results==0){
         //Property no exists --> add property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO toolproperty VALUES " +
                            "('"+toolId+"','"+property+"','"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public Collection getPropertyNames () throws Exception
  {

    Connection conn = null;
    Collection names = new ArrayList();
    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT name FROM toolproperty " +
                            "WHERE subId ='"+toolId+"'");
      if (results.next()) {
       names.add(results.getString("name"));
       while (results.next()){
              names.add(results.getString("name"));
       }
       return names;
      }
      else {
       return names;
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }



  public String getIndexedProperty (String property, int index) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM toolindexproperty " +
                            "WHERE subId ='"+toolId+"' and name='"+property+"' and index="+index );
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Indexed property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setIndexedProperty (String property, String value, int index)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE toolindexproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+toolId+"' and name='"+property+"' and index="+ index);
      if(results==0){
         //Property no exists --> add property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO toolindexproperty VALUES " +
                            "('"+toolId+"','"+property+"',"+index+",'"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

}
package ants.move.core.models.object;

import ants.core.*;
import java.util.*;
import ants.util.*;
import ants.comm.*;

/**
 * Implementation of OBJECT model
 * @author:      Oriol Montal� & Carles Pairot & Francesc Pi�as
 * @version 1.0 build 2002
 */
public class ObjectModel extends Thing implements ants.comm.RemoteEventListener{
  protected Vector listeners = new Vector();
  private Hashtable subs = new Hashtable();
  private Hashtable objectThings = new Hashtable();
  private String thingCatched= "";
  private String user=null;
/**
 * Initialize model
 */
  public void init() {
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","OBJECT.V01");
      user=this.getPlace().getUser();
      super.getPlace().addPlaceListener(this,subs);
      Vector thingKeys = super.getPlace().getThings("object.v01");
      loadObjectThings(thingKeys);
    } catch (Exception x) {
      x.printStackTrace();
    }
    System.err.println("[MOVE] - OBJECT model initialized.");
  }

  private void loadObjectThings(Vector thingKeys){
    ants.core.Thing key;
    for(Enumeration e=thingKeys.elements();e.hasMoreElements();){
      key=(ants.core.Thing)e.nextElement();
      loadThing(key.getThingId());
    }
  }

/**
 * Add Object Listener
 * @param objectL listener
 */
  public void addObjectListener (ObjectListener objectL) {
    listeners.addElement(objectL);
  }
/**
 * Remove Object listener
 * @return Listener
 */
  public Hashtable getObjectThings(){
    return (objectThings);
  }
/**
 * Catch thing
 * @param thingKey Key
 */
  public void catchThing(String thingKey){
    try{
      thingCatched=thingKey;
      //catch Thing
      for (int i = 0; i < listeners.size (); i++) {
        ((ObjectListener) listeners.elementAt (i)).catchThing(thingKey);
      }
      //removeThing from Place
      ObjectThing oTH=(ObjectThing)objectThings.get(thingKey);
      oTH.setProperty("catched",user);
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","OBJECT.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Refresh thing state
 * @param thingKey key
 */
  public void refreshThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((ObjectListener) listeners.elementAt (i)).refreshThing(thingKey);
      }
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Load object thing
 * @param thingKey key
 */
  public void loadThing(String thingKey){
  try{
   if(!objectThings.containsKey(thingKey)){
     ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
     ObjectThing oTH = new ObjectThing();
     oTH.init(ctx, super.getThingGateway());
     oTH.setModel(this);
     if((oTH.getProperty("catched").equalsIgnoreCase("false"))||
     (oTH.getProperty("catched").equalsIgnoreCase(user))){
       objectThings.put(thingKey,oTH);
       for (int i = 0; i < listeners.size (); i++) {
         ((ObjectListener) listeners.elementAt (i)).loadThing(oTH);
       }
     }else{
      oTH.destroy();
     }
   }else{
    System.err.println("Trying to load an existing OBJECT THING");
   }
  }catch(Exception ex){System.out.println("Load Thing Exception:"+ex);
                       System.err.println("Load Thing Exception:"+ex);}
  }

/**
 * Destroy thing
 * @param thingKey key
 */
  public void deployThing(String thingKey){
    try{
      for (int i = 0; i < listeners.size (); i++) {
        ((ObjectListener) listeners.elementAt (i)).deployThing(thingKey);
      }
      thingCatched="";
      ObjectThing oTH=(ObjectThing)objectThings.get(thingKey);
      oTH.setProperty("catched","false");
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","OBJECT.V01");
      subs.put("METHOD","LOADTHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}
  }
/**
 * Send remove thing event
 * @param thingKey key
 */
  public void sendRemoveThing(String thingKey){
    try{
      Hashtable subs = new Hashtable();
      subs.put(ants.core.Context.WORLD,super.getPlace().getWorld());
      subs.put(ants.core.Context.PLACE,super.getPlace().getPlaceId());
      subs.put("CLASS","OBJECT.V01");
      subs.put("METHOD","REMOVETHING");
      subs.put("THINGKEY",thingKey);
      getPlace().getSession().send(subs);
     }catch(Exception ex){ex.printStackTrace();}

  }

  public void eventArrived (Hashtable evt) {
    String method = (String)evt.get("METHOD");
    //adding a new thing
   try{
    if(method.equalsIgnoreCase("NEWTHING")){
      ANTSContext ctx = new ANTSContext(super.getPlace(), (String)evt.get("THINGKEY"));
      ObjectThing oTH = new ObjectThing();
      oTH.init(ctx, super.getThingGateway());
      oTH.setModel(this);
      oTH.setProperty("catched","false");
      objectThings.put((String)evt.get("THINGKEY"),oTH);
      for (int i = 0; i < listeners.size (); i++) {
        ((ObjectListener) listeners.elementAt (i)).newThing(oTH);
      }

    }else if(method.equalsIgnoreCase("REMOVETHING")){
      ObjectThing oT= (ObjectThing)objectThings.get((String)evt.get("THINGKEY"));
      if(!thingCatched.equalsIgnoreCase(oT.getThingId())){
        objectThings.remove((String)evt.get("THINGKEY"));
        for (int i = 0; i < listeners.size (); i++) {
          ((ObjectListener) listeners.elementAt (i)).removeThing(oT.getThingId());
        }
        oT.destroy();
      }
    }else if(method.equalsIgnoreCase("LOADTHING")){
       loadThing((String)evt.get("THINGKEY"));
    }
  }catch(Exception ex){System.out.println("Load Thing Exception:"+ex);
                       System.err.println("Load Thing Exception:"+ex);}
  }
/**
 * Tool type
 * @return OBJECT
 */
  public String getType() {
    return "OBJECT";
  }
/**
 * Destroy method
 */
  public void destroy() {
   try{
//    super.getPlace().removePlaceListener(subs);
    super.destroy();
   }catch(Exception ex){System.err.println("[MOVE] -- Unable to destroy OBJECT model");ex.printStackTrace();}
  }


}
package ants.comm.examples;

import java.applet.*;
import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;
import java.net.*;
import ants.util.Debug;

public class ConsumerApplet extends Applet implements RemoteEventListener
{
	public int n = 0;
	
	public void eventArrived(Hashtable evt)
	{
		if (n>=9998) System.out.println("SI!!!");
		else n++;
	}

	public void init()
	{
		try
		{
			String envFile   =  getParameter("ENVIRONMENT");	
			URL props = new URL("http://127.0.0.1:8080/"+envFile);
			ants.comm.Session conn = SessionFactory.createSession(props);
		
			Hashtable subs = new Hashtable();
			subs.put("type","evt");
			conn.addRemoteEventListener(this,subs);	

			conn.close();
		
		}catch (SessionException s1)
		{
			Debug.error(s1.getException());
		}catch (MalformedURLException ex2)
		{
			Debug.error(ex2);
		}
		
	}
	
	
	
}

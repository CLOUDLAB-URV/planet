<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, java.net.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;

%>

<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ToolManager tm=(ToolManager)session.getAttribute("toolManager");
 PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 Thing thing=null;
 Tool tool=null;
 Place place=null;

 if(request.getParameter("placeId")!=null){
   session.setAttribute("placeId",request.getParameter("placeId"));
 }
 String placeId=(String)session.getAttribute("placeId");

 place=pm.getPlace(placeId);

%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=false" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("thingsList")%> : </b></font></td></tr>
<tr>
  <td colspan="2">
  </td>
  <td align="right">

  <table border="0">
  <tr>
  <td>
        <FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%>:</FONT>&nbsp;
  </td>
  <%

  for (Iterator i=tm.getTools().iterator();i.hasNext();){
   tool=(Tool)i.next();

   if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
    if(tool.getId().equalsIgnoreCase("slides.v05")){
      %>
      <td>
       <a href="createSlides.jsp" title="<%=labels.getString("uploadSlides")%>"><img src="images/slides.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("s3d.v01")){
      %>
      <td>
       <a href="create3DSlides.jsp" title="<%=labels.getString("upload3DSlides")%>"><img src="images/s3d.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("video.v01")){
      %>
      <td>
       <a href="createVideo.jsp" title="<%=labels.getString("uploadVideo")%>"><img src="images/video.gif" border="0"></a>
      </td>
      <%

    }else if (tool.getId().equalsIgnoreCase("votation.v01")){
      %>
      <td>
       <a href="createVotation.jsp" title="<%=labels.getString("createVotation")%>"><img src="images/votation.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("audio.v01")){
      %>
      <td>
       <a href="createAudio.jsp" title="<%=labels.getString("uploadAudio")%>"><img src="images/audio.v01.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("banner.v01")){
      %>
      <td>
       <a href="createBanner.jsp" title="<%=labels.getString("uploadBanner")%>"><img src="images/banner.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("videoStream.v02")){
      %>
      <td>
       <a href="createVideoStream2.jsp" title="<%=labels.getString("createVideoStream2")%>"><img src="images/videoStream.v02.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("videoStream.v01")){
      %>
      <td>
       <a href="createVideoStream.jsp" title="<%=labels.getString("createVideoStream")%>"><img src="images/videoStream.v01.gif" border="0"></a>
      </td>
      <%
    }else if (tool.getId().equalsIgnoreCase("info.v01")){
      %>
      <td>
       <a href="createInfo.jsp" title="<%=labels.getString("uploadInfo")%>"><img src="images/info.gif" border="0"></a>
      </td>
      <%

    }
   }
 }
%>
    <td>
     <a href="configureTools.jsp" title="Configure Tools"><img src="images/tools2.gif" border="0"></a>
    </td>
  </tr>
  </table>
 </td>
</tr>
</table><br>
  <%
    if((thm.getThingsByPlaceAndTool(placeId,"video.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"votation.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"slides.v05").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"s3d.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"url.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"doc.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"audio.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"banner.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"info.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"object.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"videoStream.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"videoStream.v02").size()!=0)){

  %>
      <table border="0" bgcolor="teal" width="90%">
         <TR>
              <TH><font color="white">Thing</font></TH>
              <TH><font color="white"><%=labels.getString("nameTH")%></font></TH>
              <TH><font color="white"><%=labels.getString("descriptionTH")%></font></TH>
              <TH><font color="white"><%=labels.getString("creationTH")%></font></TH>
              <TH><font color="white"><%=labels.getString("createdTH")%></font></TH>

         </TR>
  <%


      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"video.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewVideo.jsp?thingId=<%=thing.getId()%>">
              <img src="images/videoSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteVideo.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }
      //Votation
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"votation.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewVotation.jsp?thingId=<%=thing.getId()%>">
              <img src="images/votationSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }
      //Slides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"slides.v05").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewSlides.jsp?thingId=<%=thing.getId()%>">
            <img src="images/slidesSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteSlides.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }
      //3DSlides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"s3d.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><img src="images/s3dSmall.gif" align="middle" border="0"></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="delete3DSlides.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }

      //URL
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"url.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getName()%>" target="_blank">
              <img src="images/urlSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>

        </tr><%
      }

      //DOC
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"doc.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        String worldId=(String)session.getAttribute("worldId");

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%="worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")%>" target="_blank">
              <img src="images/docSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>

        </tr><%
      }
      //Audio
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"audio.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="listenAudio.jsp?thingId=<%=thing.getId()%>">
              <img src="images/audioSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteAudio.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }

      //banner
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"banner.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewBanner.jsp?thingId=<%=thing.getId()%>">
              <img src="images/bannerSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteBanner.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }
      //Information
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"info.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="previewInfo.jsp?thingId=<%=thing.getId()%>">
              <img src="images/infoSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
         <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteInfo.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
         </td>
        </tr><%
      }
      //Object
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"object.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        String worldId=(String)session.getAttribute("worldId");
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%="worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")+"/main.wrl"%>" target="_blank">
              <img src="images/objectSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          
          
        </tr><%
      }
      
       //Videostreaming
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getProperty("url")%>" target="_blank">
              <img src="images/videoStreamSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr>        
       <%
       }          

      //Videostreaming2
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v02").iterator();i.hasNext();){
        thing=(Thing)i.next();


        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getProperty("url")%>" target="_blank">
              <img src="images/videoStream2Small.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
          <a href="deleteThing.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </td>
        </tr><%
      }



    %>
    </table>

  <%
     }
   } catch (Exception e) {
      Syslog.log (this, e);
   }
  %>


<br><br>
<a href="goToMove.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("go")%></font></a><br><br>
</center>
<jsp:include page="footer.jsp" flush="true"/>
</HTML>
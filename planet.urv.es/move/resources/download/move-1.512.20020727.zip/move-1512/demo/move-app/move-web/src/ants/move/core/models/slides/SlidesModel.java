// Package ants.move.core.models.slides
// SlidesModel.java
// Implementation of Slides Model
// 2002 Oriol Montal� & Carles Pairot & Francesc Pi�as
package ants.move.core.models.slides;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Slides Model.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class SlidesModel extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  // Vector containing all Slides
  private Vector pictures;
  private int index=-1;
  private Thing slidesThing=null;
  /** Sole & void constructor.
  */
  public SlidesModel() {
  }
/**
 * Initialize Model
 */
  public void init() {
    try{
      addPropertyChangeListener(this);
      String sk= getProperty("slidesKey");
      if(!sk.equalsIgnoreCase("----")){
        this.loadSlides(sk);
        String cs=getProperty("currentSlide");
        index=Integer.parseInt(cs);
        for (int i = 0; i < listeners.size (); ++ i) {
          ((SlidesListener) listeners.elementAt (i)).setPicture(getPicture());
        }
      }
      System.err.println("[MOVE] - Slides model initialized.");
    }catch(Exception e){e.printStackTrace();}
  }
/**
 * Add new slides listener
 * @param sList Class that implements SlidesModel interface
 */
  public void addSlidesListener (SlidesListener sList) {
    listeners.addElement(sList);
  }
/**
 * remove slide listener
 * @param sList Class that implements SlidesListener Interface
 */
  public void removeSlidesListener (SlidesListener sList) {
    listeners.removeElement(sList);
  }

  /**
   * Load new slides set in slides tool
   * @param thingKey Key of the slides set thing
   */
  public void setSlidesThing (String thingKey) {
    try {
      setProperty ("slidesKey", thingKey);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * retuns key of the slides set that is loaded in slides tool
 * @return Key of slides set thing
 */
  public String getSlidesThingId () {
    try {
      return getProperty("slidesKey");
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
/**
 * Thing that is loaded in slides tool
 * @return Thing instance of slides set
 */
  public Thing getSlidesThing () {
    return slidesThing;
  }

  /** Remotely go to first slide.
  */
  public void firstPicture() {
    if (pictures != null) {
      index=0;
    try {
      setProperty ("currentSlide", ""+index);
    } catch (Exception ex) { ex.printStackTrace(); }
    }
  }

  /** Remotely go back to previous slide.
  */
  public void prevPicture() {
    if (pictures != null) {
      index--;
      if(index<0){
        index=0;
      }
      try {
        setProperty ("currentSlide", ""+index);
      } catch (Exception ex) { ex.printStackTrace(); }
    }

  }

  public void loadSlides (String thingKey) {

    ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
    slidesThing = new Thing();
    slidesThing.init(ctx, super.getThingGateway());
    int size = 0;
    try {
      size = slidesThing.getIndexedPropertySize ("slides");
      pictures = new Vector();
      for (int i = 1; i <= size; i++) {
        pictures.addElement(slidesThing.getIndexedProperty("slides", i));
      }
      System.err.println("[MOVE] - New slides set loaded.");
      index=0;
//      this.setProperty("currentSlide",""+index);
    } catch (Exception ex) {
      System.err.println ("Exception getting IndexedProperties: ");
      ex.printStackTrace();
    }
  }


  /** Remotely go to next slide.
  */
  public void nextPicture() {
    if (pictures != null) {
      index++;
      if(index>=pictures.size()){
        index--;
      }
    try {
      setProperty ("currentSlide", ""+index);
    } catch (Exception ex) { ex.printStackTrace(); }

    }
  }

  /** Remotely go to last slide.
  */
  public void lastPicture() {
    if (pictures != null) {
        index = pictures.size()-1;
    try {
        setProperty ("currentSlide", ""+index);
    } catch (Exception ex) { ex.printStackTrace(); }
    }
  }

/**
 * return url of current slide
 * @return String that contains URL of current picture
 */
  public String getPicture(){
   if(index== -1){
    return "";
   }else{
    return((String)pictures.elementAt(index));
   }
  }


  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    // Load new Slides set
    if (propName.equals("slidesKey")) {
      loadSlides (evt.getPropValue());
    }else if (propName.equals("currentSlide")) {
      index=Integer.parseInt(evt.getPropValue());
      for (int i = 0; i < listeners.size (); ++ i) {
        ((SlidesListener) listeners.elementAt (i)).setPicture(getPicture());
      }
    }

  }
/**
 * Tool type
 * @return SLIDES
 */
  public String getType() {
    return "SLIDES";
  }

  /**
   * Destroy method
   */
  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((SlidesListener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}
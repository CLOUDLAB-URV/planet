package ants.move.ejb;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a Thing Manager
 */

public class ThingManagerBean implements SessionBean{

  ThingHome thingHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/ThingBean");
      thingHome =(ThingHome) PortableRemoteObject.narrow(objRef,ThingHome.class);
    }catch(Exception eC){eC.printStackTrace();}
  }

  public Collection getThings(String placeId){
    Collection things= new ArrayList();
    try{
      things=thingHome.findByPlace(placeId);
    }catch(Exception gwE){
        System.out.println("getThings("+placeId+") : "+gwE);
    }
    return things;
  }

  public Collection getThingsByTool(String placeId, String toolId){
    Collection things= new ArrayList();
    try{
      things=thingHome.findByPlaceAndTool(placeId,toolId);
    }catch(Exception gwE){
        System.out.println("getThings("+placeId+") : "+gwE);
    }
    return things;

  }

  public Thing getThing (String id){
    Thing thing=null;
    try{
      thing=thingHome.findByPrimaryKey(id);
    }catch(Exception gwE){System.out.println("getThing("+id+") : "+gwE);}
    return thing;
  }
  public Thing createThing(String id,String name,String placeId, String toolId){
    Thing thing=null;
    try{
      thing= thingHome.create(id);
      thing.setName(name);
      thing.setPlaceId(placeId);
      thing.setToolId(toolId);
    }catch(Exception gwE){System.out.println("createThing("+id+","+name+","+placeId+","+toolId+") : "+gwE);}
    return thing;
  }
  public void removeThing(String id){
    Thing thing=null;
    try{
      thing=thingHome.findByPrimaryKey(id);
      thing.remove();
    }catch(Exception gwE){System.out.println("removeThing("+id+") : "+gwE);}
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
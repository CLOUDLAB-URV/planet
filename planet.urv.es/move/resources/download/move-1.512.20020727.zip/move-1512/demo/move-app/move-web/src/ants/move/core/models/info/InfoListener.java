// Package ants.move.core.models.info
// InfoListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.info;

/** InfoListener interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2002
*/
public interface InfoListener {
  public void setInfo (String file);
  public void destroy();
}
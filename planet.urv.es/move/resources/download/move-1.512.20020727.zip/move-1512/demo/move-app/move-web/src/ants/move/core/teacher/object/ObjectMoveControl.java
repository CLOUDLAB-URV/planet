package ants.move.core.teacher.object;


import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.object.*;
import ants.move.core.views.object.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.*;

import java.util.*;
import java.net.*;
import java.awt.event.*;

import vrml.external.Browser;

/** Implementation of Object User Interface.
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @author Collaborator : Carles Pairot (cpairot@tinet.org)
    @version 1.00 Build 2002
*/
public class ObjectMoveControl extends Frame{
  private ObjectThing oT;
  private ObjectThingView oTV;
  private Label labelTranslationX;
  private Label labelTranslationY;
  private Label labelTranslationZ;
  private Scrollbar scrollX;
  private Scrollbar scrollY;
  private Scrollbar scrollZ;
  private Button okButton;
  private float aux[] = new float[3];
  private float aux2[] = new float[3];

  public ObjectMoveControl(){
    this.enableEvents(WindowEvent.WINDOW_EVENT_MASK);
    this.setLayout(new FlowLayout());
    labelTranslationX= new Label("X translation:");
    labelTranslationY= new Label("Y translation:");
    labelTranslationZ= new Label("Z translation:");
    scrollX= new Scrollbar(Scrollbar.HORIZONTAL,0,1,-100,100);
    scrollX.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        scrollX_adjustmentValueChanged(e);
      }
    });
    scrollY= new Scrollbar(Scrollbar.VERTICAL,0,1,-200,200);
    scrollY.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        scrollY_adjustmentValueChanged(e);
      }
    });
    scrollZ= new Scrollbar(Scrollbar.HORIZONTAL,0,1,-100,100);
    scrollZ.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        scrollZ_adjustmentValueChanged(e);
      }
    });

    okButton= new Button("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    Panel p1 = new Panel();
    p1.add(labelTranslationX);
    p1.add(scrollX);
    p1.setBackground(Color.lightGray);
    Panel p2 = new Panel();
    p2.add(labelTranslationY);
    p2.add(scrollY);
    p2.setBackground(Color.lightGray);
    Panel p3 = new Panel();
    p3.add(labelTranslationZ);
    p3.add(scrollZ);
    p3.setBackground(Color.lightGray);
    Panel p4 = new Panel();
    p4.add(okButton);
    this.setSize(250,300);
    this.setLocation(700,250);
    this.setResizable(false);
    this.add(p1);
    this.add(p2);
    this.add(p3);
    this.add(p4);
    this.setVisible(false);
    this.setTitle("Move! Object");
  }

  public void init(Hashtable ht){
  try{
    oT= (ObjectThing)ht.get("objectThing");
    oTV= (ObjectThingView)ht.get("objectThingView");
    StringTokenizer tokens = new StringTokenizer (oT.getProperty("translation"));
    aux[0]=Float.valueOf(tokens.nextToken()).floatValue();
    aux[1]=Float.valueOf(tokens.nextToken()).floatValue();
    aux[2]=Float.valueOf(tokens.nextToken()).floatValue();

    this.setVisible(true);
   }catch(Exception ex){ex.printStackTrace();}
  }

  void okButton_actionPerformed (ActionEvent e) {
    try{
     float tX=(float)scrollX.getValue()/(float)100.0;
     float tY=(float)scrollY.getValue()/(float)100.0;
     float tZ=(float)scrollZ.getValue()/(float)100.0;
     aux[0] -= tX;
     aux[1] -= tY;
     aux[2] -= tZ;
     oT.setProperty("translation",""+aux[0]+" "+aux[1]+" "+aux[2]);
    }catch(Exception ex){ex.printStackTrace();}
    this.dispose();
  }

  void scrollX_adjustmentValueChanged (AdjustmentEvent e) {
    try{
      float tX=(float)scrollX.getValue()/(float)100.0;
      float tY=(float)scrollY.getValue()/(float)100.0;
      float tZ=(float)scrollZ.getValue()/(float)100.0;
      aux2[0] =aux[0] - tX;
      aux2[1] =aux[1] - tY;
      aux2[2] =aux[2] - tZ;
      oTV.hook(aux2);
    }catch(Exception ex){ex.printStackTrace();}
  }

  void scrollY_adjustmentValueChanged (AdjustmentEvent e) {
    try{
      float tX=(float)scrollX.getValue()/(float)100.0;
      float tY=(float)scrollY.getValue()/(float)100.0;
      float tZ=(float)scrollZ.getValue()/(float)100.0;
      aux2[0] =aux[0] - tX;
      aux2[1] =aux[1] - tY;
      aux2[2] =aux[2] - tZ;
      oTV.hook(aux2);
    }catch(Exception ex){ex.printStackTrace();}
  }

  void scrollZ_adjustmentValueChanged (AdjustmentEvent e) {
    try{
      float tX=(float)scrollX.getValue()/(float)100.0;
      float tY=(float)scrollY.getValue()/(float)100.0;
      float tZ=(float)scrollZ.getValue()/(float)100.0;
      aux2[0] =aux[0] - tX;
      aux2[1] =aux[1] - tY;
      aux2[2] =aux[2] - tZ;
      oTV.hook(aux2);
    }catch(Exception ex){ex.printStackTrace();}
  }


  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.dispose();
    }
  }

}
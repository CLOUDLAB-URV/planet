<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");
%>
  <html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("createVot")%> : </b></font></td></tr>
</table>
<table width=90%>
   <tr>
    <td colspan="3">
    <b><%=messages.getString("createVotation")%></b>
    </td>
   </tr>
   <form method="post">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("topic")%> : </b><input type="text" size="50" maxlength="50" name="topic"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
    </td>
   </tr>
   </form>
  </table>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>
 </HTML>
<%
}else{
 try{
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  Thing thing=thm.createThing(""+System.currentTimeMillis(),"Votation",
                            (String)session.getAttribute("placeId"),"votation.v01");
  thing.setDescription(request.getParameter("topic"));
  thing.setProperty("yes","----");
  thing.setProperty("no","----");
  thing.setProperty("unknown","----");
  thing.setProperty("usersList","----");
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
//
//	Users list cal que sigui un indexedProperty. Actualmetnt mti no ho suporta per�
//	ho far� en la propera versi�
//
//

  response.sendRedirect("listThings.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}
%>


package ants.move.core;

import ants.core.Context;
import java.util.*;
import java.net.*;
import java.io.*;

public class Constants {
  // ANTS/CORE constants
  public static String WORLD = ants.core.Context.WORLD;
  public static String PLACE = ants.core.Context.PLACE;
  public static String USER = ants.core.Context.USER;
  public static String ROLE = ants.core.Context.ROLE;
  public static String PLACESERVER = ants.core.Context.PLACESERVER;
  public static String THINGSERVER = ants.core.Context.THINGSERVER;
  public static String USERSERVER = ants.core.Context.USERSERVER;
  public static String WORLDMANAGERID = ants.core.Context.WORLDMANAGERID;
  public static String TOOLMANAGERID = ants.core.Context.TOOLMANAGERID;
  public static String JLESESSIONMANAGERID = ants.core.Context.JLESESSIONMANAGERID;
  public static String SECURITYMANAGERID = ants.core.Context.SECURITYMANAGERID;
  public static String PERMISSIONCHECKERID = ants.core.Context.PERMISSIONCHECKERID;
  public static String PINGTIME = ants.core.Context.PINGTIME;
  public static String SYSLOGMASK = ants.core.Context.SYSLOGMASK;
  public static String NSPORT = "ants.comm.port";
  public static String SERVER = "java.naming.provider.url";
  public static String ANTSCLASS = "ants.comm.class";

  // ANTS/CORE variables
  private static String PGATERMI = null;
  private static String TGATERMI = null;
  private static String UGATERMI = null;
  private static String RMIPORT_VALUE = null;
  private static String WORLDMANAGERID_VALUE = null;
  private static String TOOLMANAGERID_VALUE = null;
  private static String JLESESSIONMANAGERID_VALUE = null;
  private static String SECURITYMANAGERID_VALUE = null;
  private static String PERMISSIONCHECKERID_VALUE = null;
  private static String PINGTIME_VALUE = "1";
  private static String SYSLOGMASK_VALUE = null;

  // MOVE! constants
  public static String PATH = "ants.move.path";
  public static String NOTIFICATIONSERVICE = "ants.move.notificationService";
  public static String RMIPORT = "ants.move.rmiport";

  // MOVE! RMI variables
  private static String MOVEBUILDERMI = null;

  // MOVE! variables
  private static String SERVER_VALUE = null;
  private static String NSPORT_VALUE = null;
  private static String ANTSCLASS_VALUE = null;
  private static String PATH_VALUE = null;
  private static String NOTIFICATIONSERVICE_VALUE = null;
  private static String POSITION_RESOLUTION = null;
  private static String ROTATION_RESOLUTION = null;
  private static String INFLUENCE_AREA = null;

  public static void init (String pathToFile) throws IllegalMOVEFileFormatException {
    try {
      FileInputStream fis = new FileInputStream (pathToFile + File.separator + "move.properties");
      Properties props = new Properties();
      props.load (fis);

      SERVER_VALUE = props.getProperty (SERVER);
      NSPORT_VALUE = props.getProperty (NSPORT);
      NOTIFICATIONSERVICE_VALUE = props.getProperty (NOTIFICATIONSERVICE);
      ANTSCLASS_VALUE = props.getProperty (ANTSCLASS);
      PATH_VALUE = pathToFile;
      RMIPORT_VALUE = props.getProperty (RMIPORT);
      PGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/PlaceGateway";
      TGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/ThingGateway";
      UGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/UserGateway";
      MOVEBUILDERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/move/MOVEBuilder";
      WORLDMANAGERID_VALUE = props.getProperty (WORLDMANAGERID);
      TOOLMANAGERID_VALUE = props.getProperty (TOOLMANAGERID);
      JLESESSIONMANAGERID_VALUE = props.getProperty (JLESESSIONMANAGERID);
      SECURITYMANAGERID_VALUE = props.getProperty (SECURITYMANAGERID);
      PERMISSIONCHECKERID_VALUE = props.getProperty (PERMISSIONCHECKERID);
      PINGTIME_VALUE = props.getProperty (PINGTIME);
      SYSLOGMASK_VALUE = props.getProperty (SYSLOGMASK);
      POSITION_RESOLUTION = props.getProperty ("positionResolution");
      ROTATION_RESOLUTION = props.getProperty ("rotationResolution");
      INFLUENCE_AREA= props.getProperty ("influenceArea");
    } catch (Exception ex) {
      throw new IllegalMOVEFileFormatException ();
    }
  }

  public static void init (URL u) throws IllegalMOVEFileFormatException {
    try {
      URL url = new URL (u + "move.properties");
      Properties props = new Properties();
      props.load (url.openStream());

      SERVER_VALUE = props.getProperty (SERVER);
      NSPORT_VALUE = props.getProperty (NSPORT);
      NOTIFICATIONSERVICE_VALUE = props.getProperty (NOTIFICATIONSERVICE);
      ANTSCLASS_VALUE = props.getProperty (ANTSCLASS);
      PATH_VALUE = u.toString();
      RMIPORT_VALUE = props.getProperty (RMIPORT);
      PGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/PlaceGateway";
      TGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/ThingGateway";
      UGATERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/core/UserGateway";
      MOVEBUILDERMI = "rmi://" + SERVER_VALUE + ":" + RMIPORT_VALUE + "/move/MOVEBuilder";
      WORLDMANAGERID_VALUE = props.getProperty (WORLDMANAGERID);
      TOOLMANAGERID_VALUE = props.getProperty (TOOLMANAGERID);
      JLESESSIONMANAGERID_VALUE = props.getProperty (JLESESSIONMANAGERID);
      SECURITYMANAGERID_VALUE = props.getProperty (SECURITYMANAGERID);
      PERMISSIONCHECKERID_VALUE = props.getProperty (PERMISSIONCHECKERID);
      PINGTIME_VALUE = props.getProperty (PINGTIME);
      SYSLOGMASK_VALUE = props.getProperty (SYSLOGMASK);
      POSITION_RESOLUTION = props.getProperty ("positionResolution");
      ROTATION_RESOLUTION = props.getProperty ("rotationResolution");
      INFLUENCE_AREA= props.getProperty ("influenceArea");
    } catch (Exception ex) {
      throw new IllegalMOVEFileFormatException ();
    }
  }

  // Getter methods
  public static String getServer() {
    return SERVER_VALUE;
  }

  public static String getNSPort() {
    return NSPORT_VALUE;
  }

  public static String getAntsClass() {
    return ANTSCLASS_VALUE;
  }

  public static String getPath() {
    return PATH_VALUE;
  }

  public static String getNS() {
    return NOTIFICATIONSERVICE_VALUE;
  }

  public static String getRMIPort() {
    return RMIPORT_VALUE;
  }

  public static String getPlaceGatewayRMIId() {
    return PGATERMI;
  }

  public static String getThingGatewayRMIId() {
    return TGATERMI;
  }
  public static String getUserGatewayRMIId() {
    return UGATERMI;
  }

  public static String getMoveBuilderRMIId() {
    return MOVEBUILDERMI;
  }

  public static String getWorldManagerId() {
    return WORLDMANAGERID_VALUE;
  }

  public static String getToolManagerId() {
    return TOOLMANAGERID_VALUE;
  }

  public static String getJLESessionManagerId() {
    return JLESESSIONMANAGERID_VALUE;
  }

  public static String getSecurityManagerId() {
    return SECURITYMANAGERID_VALUE;
  }

  public static String getPermissionCheckerId() {
    return PERMISSIONCHECKERID_VALUE;
  }

  public static String getPingTime() {
    return PINGTIME_VALUE;
  }

  public static String getSyslogMask() {
    return SYSLOGMASK_VALUE;
  }

  public static float getPositionResolution() {
    return (Float.valueOf(POSITION_RESOLUTION).floatValue());
  }

  public static float getRotationResolution() {
    return (Float.valueOf(ROTATION_RESOLUTION).floatValue());
  }

  public static float getInfluenceArea() {
    return (Float.valueOf(INFLUENCE_AREA).floatValue());
  }


}
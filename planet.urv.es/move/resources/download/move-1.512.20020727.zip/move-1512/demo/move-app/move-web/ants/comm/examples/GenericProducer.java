
package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;

public class GenericProducer{
	
	
	public static void main(String args[])
	{
		try
		{
			
			ants.comm.Session chatZone = SessionFactory.createSession(args[0]);
			Hashtable evt = new Hashtable();
			evt.put("arg1",args[1]);	
			
	
			
			chatZone.send(evt);
			chatZone.close();
		
		}catch (SessionException s1)
		{
			System.out.println(s1.getException().getMessage());
		}

	}

		
}
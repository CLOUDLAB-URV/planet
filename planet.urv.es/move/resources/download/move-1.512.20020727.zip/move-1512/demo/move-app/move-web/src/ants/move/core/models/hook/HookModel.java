// Package ants.move.core.models.hook
// HookModel.java
// Implementation of Hook Model
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.hook;

// Notification Service imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.*;

/** Implementation of Hook Model.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.30 Build 2000
*/
public class HookModel extends Thing implements PropertyChangeListener {

//  private Place conn;
  private Vector listeners = new Vector();
  // Hook's camera position
  private float[] HCamPos;
  // Hook's camera orientation
  private float[] HCamOri;
  // I want to hook or I want to be hooked?
  private boolean toHook = false;
  // Hooked or not
  private boolean hooked = false;

  /** Sole & void constructor.
  */
  public HookModel() {
  }
/**
 * Initialize model
 */
  public void init () {
    addPropertyChangeListener(this);

    HCamPos = new float[3];
    HCamOri = new float[4];

    // Get hook viewpoint position and orientation
    try {
      String p = getProperty("translation");
      String o = getProperty("rotation");

      StringTokenizer tokens = new StringTokenizer(p);
      HCamPos[0] = (new Float(tokens.nextToken()).floatValue());
      HCamPos[1] = (new Float(tokens.nextToken()).floatValue());
      HCamPos[2] = (new Float(tokens.nextToken()).floatValue());

      tokens = new StringTokenizer(o);
      HCamOri[0] = (new Float(tokens.nextToken()).floatValue());
      HCamOri[1] = (new Float(tokens.nextToken()).floatValue());
      HCamOri[2] = (new Float(tokens.nextToken()).floatValue());
      HCamOri[3] = (new Float(tokens.nextToken()).floatValue());
    }
    catch (Exception x) {
      System.err.println("Exception capturing translation & orientation properties of thing Hook");
    }
    System.err.println("[MOVE] - Hook model initialized.");
  }
/**
 * Add new Hook listener
 * @param hList Class that implements HookListener interface
 */
  public void addHookListener (HookListener hList) {
    listeners.addElement(hList);
  }
/**
 * Remove Hook listener
 * @param hList Class that implements HookListener interface
 */
  public void removeHookListener (HookListener hList) {
    listeners.removeElement(hList);
  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Remotely Bind / Unbind Camera's Viewpoint.
      @param value True if camera has to be bound
  */
  public void setBind (boolean value) {
    try {
      // Bind
      if (value) {
        setProperty ("hookBound", "true");
        // I want to hook all users
        toHook = true;
      }
      // Unbind
      else {
        setProperty ("hookBound", "false");
        // I don't want to hook users anymore
        toHook = false;
      }
    } catch (Exception e) {
      System.err.println("Exception changing hookBound property! (method HookModel.setBind)");
      e.printStackTrace();
    }
  }
/**
 * Set hook movemenr
 * @param posNow Position
 * @param oriNow camera orientation
 */
  public void movement (float[] posNow, float[] oriNow) {
    // If position[X, Y, Z] > 0.4m or orientation[X, Y, Z] > 0.2m then send
    // movement so as not to overload the entire network
    if (Math.abs(HCamPos[0] - posNow[0]) > 0.4 || Math.abs(HCamPos[1] -
        posNow[1]) > 0.4 || Math.abs(HCamPos[2] - posNow[2]) > 0.4 ||
        Math.abs(HCamOri[3] - oriNow[3]) > 0.2) {

      Hashtable evtp = new Hashtable();

      String pos = "" + posNow[0] + " " + posNow[1] + " " + posNow[2];
      String ori = "" + oriNow[0] + " " + oriNow[1] + " " + oriNow[2] + " " + oriNow[3];

      try {
        setProperty ("translation", pos);
        setProperty ("rotation", ori);
      } catch (Exception x) {
        System.err.println ("Exception updating hook movement! (method HookModel.movement)");
        x.printStackTrace();
      }

      // Update position & orientation values
      HCamPos = posNow;
      HCamOri = oriNow;
    }
  }

  public void propertyChange (PropertyChangeEvent evt) {
    // Bind Hook Camera's Viewpoint
    if (evt.getPropName().equals("hookBound")) {
      Vector listeners = (Vector) this.listeners.clone ();
      if (evt.getPropValue().equals("true")) {
        for (int i = 0; i < listeners.size (); ++ i) {
          String pos = "" + HCamPos[0] + " " + HCamPos[1] + " " + HCamPos[2];
          String ori = "" + HCamOri[0] + " " + HCamOri[1] + " " + HCamOri[2] + " " + HCamOri[3];
          ((HookListener) listeners.elementAt (i)).hook (pos, ori);
        }
        hooked = true;
      }
      else {    // Unbind Camera's Viewpoint
        for (int i = 0; i < listeners.size (); ++ i) {
          ((HookListener) listeners.elementAt (i)).unHook();
        }
        toHook = false;
        hooked = false;
      }
    }
    else if (evt.getPropName().equals("translation")) {
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((HookListener) listeners.elementAt (i)).hookPositionChanged (evt.getPropValue());
      }
    }
    else if (evt.getPropName().equals("rotation")) {
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((HookListener) listeners.elementAt (i)).hookOrientationChanged (evt.getPropValue());
      }
    }
  }

  /** Get Camera position given an index coordinate.
      @param index Coordinate
      @return Camera's position on that coordinate
      @exception exceptions No exceptions thrown
  */
  public float getHCamPos(int index) {
    return (HCamPos[index]);
  }

  /** Get Camera orientation given an index coordinate.
      @param index Coordinate
      @return Camera's orientation on that coordinate
      @exception exceptions No exceptions thrown
  */
  public float getHCamOri(int index) {
    return (HCamOri[index]);
  }

  /** Set Camera position.
      @param value Camera's new position
  */
  public void setHCamPos(float[] value) {
    HCamPos = value;
  }

  /** Set Camera orientation.
      @param value Camera's new orientation
  */
  public void setHCamOri(float[] value) {
    HCamOri = value;
  }

  public boolean getHookBoolean() {
    return toHook;
  }
/**
 * Get state
 * @return True=Hooked Halse=Free
 */
  public boolean getHooked() {
    return hooked;
  }
/**
 * Tool type
 * @return HOOK
 */
  public String getType() {
    return "HOOK";
  }
/**
 * Destroy method
 */
  public void destroy() {
//    removePlaceListener(this);
    // When place is left, hook should be released (only if I have hooked others)
    if (hooked && toHook) {
      setBind(false);
    }
    super.destroy();
  }
}

package ants.util;

import java.util.*;
import org.elvin.je4.*;
import org.elvin.util.*;
import java.util.Hashtable;

public class JSDTParser 
{

//OJO FALLO !!

public static Hashtable getEvt(String event)
{
	
	StringTokenizer sT = new StringTokenizer(event);
	Hashtable result = new Hashtable();
		
	String k1;
	String temp;
	String v1;
	
	while (sT.hasMoreTokens())
	{
			k1 = sT.nextToken();
			temp = sT.nextToken();
			v1 = sT.nextToken();

			result.put(k1,v1);
		
	}
	
	
	return result;
}
public static String getSubs (Hashtable evt)
{
	StringBuffer subs = new StringBuffer("");

	Enumeration keys = evt.keys();
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		String value = (String)evt.get(key);
		subs.append(" "+key+" = "+value +" AND ");
		evt.put(key,value);
		
	}
	String res = subs.toString();
	String result = res.substring(0,res.length()-4);
	return result;
	
}	



	

	
}
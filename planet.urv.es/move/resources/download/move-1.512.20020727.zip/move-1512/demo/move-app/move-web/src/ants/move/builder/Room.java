package ants.move.builder;

import java.net.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * This class stores all the contents of a 3D Place
 * (models, static objects, anchors, ...)
 */

public class Room implements java.io.Serializable {
  private String name;
  private Vector items;
  private Hashtable props;

  public Room (String name) {
    this.name = name;
    items = new Vector();
    props = new Hashtable();
  }

  public void setName (String name) {
    this.name = name;
  }

  public String getName() {
    return (name);
  }

  public void addItem (Item newItem) {
    items.addElement(newItem);
  }
  public boolean removeLastItem () {
    return (items.removeElement (items.lastElement()));
  }

  public Item getLastItem() {
    return ((Item) items.lastElement());
  }

  public Enumeration getItems () {
    return (items.elements());
  }

  public void addProperty (String key,String value) {
    props.put (key, value);
  }

  public String getProperty(String key) {
    return ((String) props.get(key));
  }

  public Hashtable getPropeties() {
    return props;
  }

  public void removeItem (Item item) {
    items.removeElement (item);
  }
}
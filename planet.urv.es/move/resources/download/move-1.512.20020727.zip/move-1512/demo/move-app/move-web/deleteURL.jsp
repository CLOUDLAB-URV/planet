<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%

   try {
      String key_string = request.getParameter("thingId");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      thm.removeThing(key_string);

   } catch (Exception e) {
      System.out.println(e);
   }
%>

<html>
<script>window.close();</script>
</html>
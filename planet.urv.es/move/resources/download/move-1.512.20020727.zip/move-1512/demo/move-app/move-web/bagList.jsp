<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, java.net.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;

%>

<%
lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
 Thing thing=null;
 User user=(User)session.getAttribute("user");

%>
<html>
<body>
<center>
<h3><%=messages.getString("things")%>:</h3> <br>

      <table border="0" bgcolor="teal" width="90%">
         <TR>
              <TH><font color="white">Thing</TH>
              <TH><font color="white"><%=labels.getString("nameTH")%></TH>
              <TH><font color="white"><%=labels.getString("descriptionTH")%></TH>
              <TH><font color="white"><%=labels.getString("creationTH")%></TH>
              <TH><font color="white"><%=labels.getString("createdTH")%></TH>
              <TH><font color="white"><%=labels.getString("deploy")%></TH>

         </TR>
  <%


    int size=Integer.parseInt(user.getProperty("BagSize"));
    String value;
    Vector items=new Vector();
    for(int i=0;i<size;i++){
      value=user.getIndexedProperty("Bag",i);
      items.addElement(value);
    }

    for(Enumeration e=items.elements(); e.hasMoreElements();){
      value=(String)e.nextElement();
      try{
        thing=thm.getThing(value);


      if(thing.getToolId().equalsIgnoreCase("url.v01")){
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%=thing.getName()%>" target="_blank">
              <img src="images/urlSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td><a href="deployURL.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("deploy")%></a></td>
          <td><a href="removeFromBag.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>
        </tr><%
      }else if(thing.getToolId().equalsIgnoreCase("doc.v01")){

         String placeId=thing.getPlaceId();
         String worldId=pm.getPlace(placeId).getWorldId();
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%="worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")%>" target="_blank">
              <img src="images/docSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td><a href="deployDoc.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("deploy")%></a></td>
          <td><a href="removeFromBag.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>

        </tr><%

      }else if(thing.getToolId().equalsIgnoreCase("object.v01")){

         String placeId=thing.getPlaceId();
         String worldId=pm.getPlace(placeId).getWorldId();
        %>
        <tr ALIGN=CENTER bgcolor="#E6E4DD">
          <td><a href="<%="worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")+"/main.wrl"%>" target="_blank">
              <img src="images/objectSmall.gif" align="middle" border="0"></a></td>
          <td><%=thing.getName()%></td>
          <td><%=thing.getDescription()%></td>
          <td><%=lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
          <td><%=thing.getProperty("owner")%></td>
          <td><a href="deployObject.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("deploy")%></a></td>
          <td><a href="removeFromBag.jsp?thingId=<%=thing.getId()%>"><%=labels.getString("remove")%></a></td>

        </tr><%

        }
      }catch(Exception ex){
        items.removeElement(value);
      }
     }
    user.setProperty("BagSize",""+items.size());
    for(int i=0;i<items.size();i++){
      user.setIndexedProperty("Bag",(String)items.elementAt(i),i);
    }


    %>
    </table>
  <%

   } catch (Exception e) {
      Syslog.log (this, e);
   }
  %>


</center>
</body>
</html>
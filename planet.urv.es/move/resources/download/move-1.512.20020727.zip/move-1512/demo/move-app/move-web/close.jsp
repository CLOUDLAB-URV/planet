<HTML>
<BODY onLoad="window.close()">
</BODY>
</HTML>
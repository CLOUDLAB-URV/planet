<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;%>
<%
if(request.getMethod().equalsIgnoreCase("get")){

   if((request.getParameter("lang")==null) && (request.getParameter("retry")==null)){
     //load the default LanguageUtilities
     Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"move.properties");
          props.load(fis);
        }catch(IOException e){System.out.println(e);}
     lang=new LanguageUtilities(props.getProperty("language"),props.getProperty("country"));
   try{
     labels=ResourceBundle.getBundle("ants.move.lang.LabelsBundle",lang.getLocale());
     messages=ResourceBundle.getBundle("ants.move.lang.MessagesBundle",lang.getLocale());
     lang.addResource(labels,"ants.move.lang.LabelsBundle");
     lang.addResource(messages,"ants.move.lang.MessagesBundle");


   }catch(Exception e){Syslog.error(this,"Resource not found");}

   }else if(request.getParameter("lang")!=null){

      //load LanguageUtilities
      if((request.getParameter("lang")).equals("CAT"))
        lang=new LanguageUtilities("ca","ES");
      else if((request.getParameter("lang")).equals("ESP"))
        lang=new LanguageUtilities("es","ES");
      else if((request.getParameter("lang")).equals("ENG"))
        lang=new LanguageUtilities("en","UK");

      try{
        labels=ResourceBundle.getBundle("ants.move.lang.LabelsBundle",lang.getLocale());
        messages=ResourceBundle.getBundle("ants.move.lang.MessagesBundle",lang.getLocale());
        lang.addResource(labels,"ants.move.lang.LabelsBundle");
        lang.addResource(messages,"ants.move.lang.MessagesBundle");


   }catch(Exception e){Syslog.error(this,"Resource not found");}
  }


%>

<html>
	<head>
		<title>MOVE! Multiuser Oriented Virtual Environment</title>
	</head>
<body <%if(request.getParameter("retry")!=null){
  %>onLoad="alert(document.alertString.logFailed.value);"<%}%>>
<br><br>
<center>
<table width=20%>
  <tr>
      <td><br><br><br><img src="images/move.jpg"></td><br><br>
  </tr>
  <tr>
  <td valign=top bgcolor="#E6E4DD">
   <form method="post">
      <font size=2 color="red" face="courier">
        <br><%=labels.getString("user1")%>:<br>
        <b>Login:</b><input type="text" name="login" size="10"><br>
        <b>Passw:</b><input type="password" name="pass" size="10"><br>
        <center><br>
        <input type="submit" size=10 type=BUTTON value="<%=labels.getString("join")%>">
        </center><br>
      </font>
   </form>
  </td>
  </tr>
</table><br><br>
<table width=20%>
  <tr>
  <tr>
   <td><a href="index.jsp?lang=CAT"><img src="images/cat.gif" border="0" width="50" height="50"></a>
   <td><a href="index.jsp?lang=ESP"><img src="images/esp.gif" border="0" width="50" height="50"></a>
   <td><a href="index.jsp?lang=ENG"><img src="images/uk.gif" border="0" width="50" height="50"></a>
  </tr>
  <tr align=center>
   <td valign=top><font size=2>catal�</font></td>
   <td><font size=2>castellano</font></td>
   <td><font size=2>english</font></td>
  </tr>
</table>
 </center>
 <!-- this form contains the alert string value that we obtain from current Language ResourceBundle-->
 <form name="alertString">
    <INPUT TYPE="HIDDEN" name="logFailed" VALUE="<%=messages.getString("alertLogging")%>">
 </form>
</body>
</html>

<%
}else{
      //load userManager
      Syslog.setLogMask("ERROR");
      Context initial = new InitialContext();
      Object obj = initial.lookup("java:comp/env/UserManagerBean");
      UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow (obj, UserManagerHome.class);
      UserManager um = home5.create();
      session.setAttribute("userManager",um);

      User user=um.getUser(request.getParameter("login"));
      if(user!=null){
        if(user.getPassword().equalsIgnoreCase(request.getParameter("pass"))){
          session.setAttribute("user",user);
          session.setAttribute("language",lang);
          response.sendRedirect("loadContext.jsp");
        }else{
          response.sendRedirect("index.jsp?retry=true");
        }
      }
      else{
          response.sendRedirect("index.jsp?retry=true");
      }
}
%>



package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import ants.util.Debug;
import java.io.*;

public class Receiver implements RemoteEventListener
{
	public int n = 0;
	
	public void eventArrived(Hashtable evt)
	{
		n++;
	}
	
	public static void main(String args[])
	{
		try{
			
	  Receiver rv =new Receiver();
		long conn1 = System.currentTimeMillis();
		Session conn = SessionFactory.createSession(args[0]);
		long conn2 = System.currentTimeMillis();
		System.out.println("CONN TIME = "+ (conn2-conn1));
		Hashtable subs = new Hashtable();
		subs.put("type","evt");
		conn.addRemoteEventListener(rv,subs);	
		
	  System.in.read();

		System.out.println(rv.n);	
		conn.close();	
		}catch (IOException e){
			Debug.error(e);
		}catch (SessionException sex){
				Debug.error(sex);

		}
	
	}
	
}
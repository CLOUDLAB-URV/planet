<%@ page session="true" import = "java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%

 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");

  
   try {

      String key_string = request.getParameter("thingId");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");

      Thing th = thm.getThing(key_string);

      String path_directory=pageContext.getServletContext().getRealPath
                            ("/worlds/"+worldKey+"/"+placeKey+"/")+th.getProperty("fileName");
      FileDeleter fd = new FileDeleter(path_directory);
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      
      fd.delete();
      Syslog.debug (this, "Track deleted from disk.");
      
      thm.removeThing(key_string);
      response.sendRedirect("listThings.jsp");

   } catch (Exception e) {
      System.out.println(e);
   }
%>
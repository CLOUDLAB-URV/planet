
package ants.util;

import java.util.*;
import org.elvin.je4.*;
import org.elvin.util.*;
import java.util.Hashtable;

public class EventParser 
{

public static Hashtable getEvt(Notification nt)
{
	Hashtable evt =  new Hashtable();
	Enumeration keys = nt.keys();
	
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		String value = (String)nt.get(key);
		evt.put(key,value);
	}
	return evt;
}
public static String getSubs (Hashtable evt)
{
	StringBuffer subs = new StringBuffer("");

	Enumeration keys = evt.keys();
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		String value = (String)evt.get(key);
		subs.append(" "+key+" == '"+value +"' && ");
		evt.put(key,value);
		
	}
	String res = subs.toString();
	String result = res.substring(0,res.length()-4);
	return result;
	
}	
	

	
}
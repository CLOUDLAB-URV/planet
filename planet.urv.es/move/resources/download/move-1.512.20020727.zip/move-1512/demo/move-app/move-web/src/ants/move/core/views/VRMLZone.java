// Package ants.move.core.dynamicObjects
// VRMLZone.java
// Implementation of EventOutObserver interface
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views;

// java.util Package import
import java.util.Hashtable;

// VRML Scene imports
import vrml.external.field.*;

/** Implementation of EventOutObserver interface. <BR>
    This class defines a VRML Zone where all objects inside of it will be
    controlled by the callback() method.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public class VRMLZone implements EventOutObserver {
  // Hashtable containing all objects in this zone
  Hashtable HT = new Hashtable();

  /** Executed when an EventOut is produced. <BR>
      The same method is used for all objects inside of this zone.<BR>
      Making use of the object's key, can be known which one has to be called
      using the eventArrived() method.
      @param event EventOut received
      @param time When the EventOut has been received
      @param key Object's key
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void callback(EventOut event, double time, Object key) {
    ((VRMLEventListener)HT.get(key)).eventPerformed();
  }

  /** Adds a VRMLEventListener object to the zone in order to be controlled.
      @param object Object to be added to the zone
      @param key Object's key
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void addVRMLEventListener(VRMLEventListener object, String key) {
    HT.put(key, object);
  }

  /** Removes a VRMLEventListener object from the zone.
      @param key Object's key
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void removeVRMLEventListener(String key) {
    HT.remove(key);
  }
}

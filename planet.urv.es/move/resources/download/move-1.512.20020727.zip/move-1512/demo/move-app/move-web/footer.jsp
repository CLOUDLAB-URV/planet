<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>
<center>
<table width=90% bgcolor="#00800F">
<tr>
  <td><br>
  </td>
</tr>
</table>
<font size="-2">Developers: <i>
<a href="mailto:omontala@tinet.org">Oriol Montal�</a>,
<a href="mailto:cpairot@tinet.org"> Carles Pairot</a>,
<a href="mailto:fpd@tinet.org"> Francesc Pi�as</a>
  2000 - 2002<br>
Departament d'Enginyeria Inform�tica i Matem�tiques<br>
Escola T�cnica Superior d'Enginyeria<br>
Universitat Rovira i Virgili</i></font>
</center>

package ants.move.core.models.avatar;

import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

import java.util.*;

public class PingResponder extends Thread implements RemoteEventListener {
  private String userName;
  private Thread thread;
  private Place conn;
  private String clss;
  private String src;
  private Hashtable subscription = new Hashtable();

  public PingResponder (String u, Place ch) {
    userName = u;

    conn = ch;

    clss = "PingResponder";
    src = "UserManager";

    // Add ping avatar event listener
    subscription.put("CLASS", clss);   // Avatar
    subscription.put("SRC", src);

    try {
      conn.addPlaceListener(this, subscription);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }

    thread = new Thread(this);
    thread.start();
  }

  public void eventArrived (Hashtable evt) {
    // Ping event received: Let's Answer
    if (((String)evt.get("METHOD")).equals("PING")) {
        Hashtable evtp = new Hashtable();
        evtp.put("CLASS", "Ping");
        evtp.put("SRC", "UserManager");
        evtp.put(ants.core.Context.WORLD, conn.getWorld());
        evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

        evtp.put("METHOD", "PING_OK");
        evtp.put("PING_TIMESTAMP", (String) evt.get("PING_TIMESTAMP"));
        evtp.put("PING_OK_TIMESTAMP", "" + System.currentTimeMillis());
        try {
          // Send ping response to PlaceGatewayImpl
          conn.send2("MOVEUsersServer", evtp);
//          System.err.println("[ MOVE! ] - User " + userName + " sending ping response.");
        }
        catch (SessionException s) {
          System.err.println("SessionException: Sending 'PING_OK' (AvatarControl) event: " + s);
        }
    }
  }

  public void destroy() {
    try {
      // Remove PingResponder Class subscription
      conn.removePlaceListener(subscription);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }
  }

}
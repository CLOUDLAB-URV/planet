<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, com.evermind.io.*, java.io.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>

<%
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 String userLogin = ((User)session.getAttribute("user")).getLogin();
 String toolKey = "info.v01";
 int port = 80;
 if (request.getMethod().equalsIgnoreCase("GET")) {
    String server=request.getServerName();
    port=request.getServerPort();
    

    lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");
%>

<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("uploadInfo")%> : </b></font></td></tr>
</table>
<table width=90%>
 <form enctype="multipart/form-data" method="POST">
 <tr>
  <td colspan="3">
    <br><%=messages.getString("uploadInfo")%>
     <br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
  <b><%=labels.getString("infoName")%> :</b> <input type="text" name="name" size="20"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("infoDescription")%> :</b>
    <input type="text" name="desc"  size="50"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("chooseInfo")%> :</b><input type="file" name="file"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <center><input type=submit name=action value="<%=labels.getString("upload")%>"> <input TYPE="reset" VALUE="<%=labels.getString("reset")%>" border="0" cellpadding="0" cellspacing="0">
    </center>
  </td>
 </tr>
</form>
</table>
</center>
<jsp:include page="footer.jsp" flush="true"/>
</BODY>
</HTML>
  <%
}else{

   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String fileName="";

    Enumeration enumeration = new FilePostParser(request.getInputStream(), 
                                                 request.getContentLength()); 
    while( enumeration.hasMoreElements() ) { 
         Object element = enumeration.nextElement(); 
         if( element instanceof Map.Entry ) { 
              Map.Entry entry = (Map.Entry)element; 

              if ((entry.getKey()).equals("name")){
	     	     thingName = (String)entry.getValue();
                     
	      }
	      if ((entry.getKey()).equals("desc")){
	             thingDesc = (String)entry.getValue();
	      }

                             
         } 
         else if( element instanceof PostFileInputStream ) { 
              PostFileInputStream in = (PostFileInputStream)element;
              String s=in.getFileName();
              int index=s.lastIndexOf("\\");
              if(index == -1){
                 //Unix platform
                 index=s.lastIndexOf("/");
              }
               
               
               
              fileName=thingKey+"_"+s.substring(index+1); 
			   
              FileOutputStream fout = new FileOutputStream
        		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);

              int bite;
              while((bite=in.read()) != -1)
                   fout.write(bite);

              in.close();
              fout.close();
         }

    }

     ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
     Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
     thing.setDescription(thingDesc);
     thing.setProperty("date",(new Date()).toGMTString());
     thing.setProperty("owner",userLogin);
     thing.setProperty ("fileName", fileName);

     Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
     response.sendRedirect("listThings.jsp");
}
%>
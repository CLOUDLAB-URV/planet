
package ants.comm.elvin;

import ants.comm.*;
import java.util.*;
import org.elvin.je4.*;
import org.elvin.util.*;
import ants.util.ElvinParser;
import ants.util.Debug;
import java.io.*;


public class Session implements ants.comm.Session
{
	private Hashtable env;	
	private Producer prod;
	private Consumer cons;
	private String sessionName="default";
	private Hashtable subscriptions;
	private Connection conn;
	
	
	
		
		
	public void open(Hashtable env) throws SessionException
	{
	 try{
			this.env = env;
			Connection.useServerDiscovery(false);
    	String port= (String)env.get("ants.comm.port");
			String host = (String)env.get("java.naming.provider.url");

			conn = new Connection(new ElvinURL("elvin://"+host+":"+port));
	 		prod = new Producer(conn); 
			cons = new Consumer(conn);
			subscriptions = new Hashtable();
			
		}catch (java.io.IOException ex)
		{
			throw new SessionException(ex);
	//		Debug.error(ex);
		}	
	}
	
	
	public void close() throws SessionException


	{
	
			conn.close();
	
	}
	
	
	public void send(Hashtable evt) throws SessionException

	{
		try
		{
	//	evt.put("principal", env.get("java.naming.security.principal"));
			prod.notify(evt);
		}catch (java.io.IOException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
		}
				
	}
	
	public void sendObj(Hashtable event,java.io.Serializable obj) throws SessionException
	{
	
		try
		{
			byte lista[];
	
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(bos);
			os.writeObject(obj);
			os.close();
			
			
			lista = bos.toByteArray();
		  Notification nt = ElvinParser.getNotif(event);
			nt.put("object",lista);
	
			//	event.put("object",lista);
	
			
			prod.notify(nt);
		}catch (java.io.IOException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
		}

	
	
	
	
	}

	public void addRemoteEventListener (RemoteEventListener sel, Hashtable event) throws SessionException

	{
	
		try
		{
			
		 if (subscriptions.containsKey(event))
			{

				Subscription sub = 	(Subscription)subscriptions.get(event);
					NotificationParser npar = new NotificationParser(sel);
					sub.addNotificationListener(npar);
				
			}else 
			{

			NotificationParser npar = new NotificationParser(sel);

				Subscription sub = new Subscription(ElvinParser.getSubs(event),npar);

				cons.addSubscription(sub);

				subscriptions.put(event,sub);


			}

		}catch (java.io.IOException ex){
						throw new SessionException(ex);
			// Debug.error(ex);
	
		};
		
 
	}
	public void addRemoteEventListener (RemoteEventListener sel, String subscription) throws SessionException

	{
		try
		{
			if (subscriptions.containsKey(subscription))
			{
					Subscription sub = 	(Subscription)subscriptions.get(subscription);
					NotificationParser npar = new NotificationParser(sel);
					sub.addNotificationListener(npar);
				
			}else 
			{

	
				NotificationParser npar = new NotificationParser(sel);
				Subscription sub = new Subscription(subscription,npar);
				cons.addSubscription(sub);
				subscriptions.put(subscription,sub);
			}
		}catch (java.io.IOException ex){
					throw new SessionException(ex);
			// Debug.error(ex);

		};
	}
// con.removeSubscription(sub); Como guardar sub ?
	public void removeRemoteEventListener(Hashtable event) throws SessionException

		{
			try
			{

				
				Subscription sub = 	(Subscription)subscriptions.get(event);

				cons.removeSubscription(sub);

			  subscriptions.remove(event);

			}catch (java.io.IOException ex){
						throw new SessionException(ex);
			// Debug.error(ex);
				};

		
		}
	public void removeRemoteEventListener(String subscription) throws SessionException

		{
			try
			{
	
				Subscription sub = 	(Subscription)subscriptions.get(subscription);

				cons.removeSubscription(sub);

				subscriptions.remove(subscription);

		
			}catch (java.io.IOException ex){
				
				throw new SessionException(ex);
			// Debug.error(ex);

				};

		}

}
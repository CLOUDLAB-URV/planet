package ants.move.builder;

// java.Applet Package import
import java.applet.Applet;

// java.awt Package imports
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Button;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;

public class InfoWindow extends Applet {
  /** Frame window.
  */
  public Frame window;

  /** Window layout.
  */
  public GridBagLayout gbLayout;

  /** Window layout's constraints.
  */
  public GridBagConstraints gc;

  Label l;
  Button b;


  /** Void constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public InfoWindow() {
  }

  /** Main constructor.
      @param s Window title
      @exception exceptions No exceptions thrown
  */
  public InfoWindow (String s, String text) {
    window = new Frame (s);
    l = new Label (text);
    this.init();
    this.start();
  }


  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;
    window.setSize(200, 150);
    window.setLocation(400, 400);
    window.setResizable(false);
    window.setLayout(gbLayout);
    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(l, gc);
    window.add(l);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 2;
    gc.gridheight = 1;
    gbLayout.setConstraints(b = new Button("OK"), gc);
    window.add(b);
    p = new Panel();
    p.setLayout(null);
    p.setSize(145, 50);
    gc.gridy = 2;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);

    b.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        b_actionPerformed(e);
      }
    });

  }

  public void b_actionPerformed(ActionEvent e) {
    window.hide();
  }

  public void front() {
    window.toFront();
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
   	window.setVisible(true);
  }

  public void setText(String text) {
    l.setText(text);
  }

  public void setEnabledButton (boolean act) {
    b.setEnabled(act);
  }

  public void close() {
    window.hide();
  }
}

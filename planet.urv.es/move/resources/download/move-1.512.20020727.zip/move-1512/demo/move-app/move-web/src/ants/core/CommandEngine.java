package ants.core;

import java.net.*;
import java.util.*;
import java.io.*;
import ants.util.Debug;
import ants.comm.*;

public class CommandEngine
{

	protected Place place= null;
	private PlaceCommand zone;
	private String userName ="";
	private String baseURL ="";
	protected Hashtable env = null;

	Hashtable commands = new Hashtable();


	public CommandEngine(Hashtable env)
	{


			userName = (String)env.get(Context.USER);
			baseURL = (String)env.get(Context.BASE);
			this.env = env;


	}
	public CommandEngine(URL fileURL)
	{


	 	try
			{

				Properties env = new Properties();
				env.load(fileURL.openStream());

				userName = (String)env.get(Context.USER);
				baseURL = (String)env.get(Context.BASE);
				this.env = env;





				}catch (Exception e5)
			{
				 Debug.error(e5);
			}



	}

	public CommandEngine(String envFile)
	{

			try
			{
				FileInputStream  fis = new FileInputStream(envFile);
				Properties env = new Properties();
				env.load(fis);

				userName = (String)env.get(Context.USER);
				baseURL = (String)env.get(Context.BASE);
				this.env = env;
			}catch(IOException ex){

				Debug.error(ex);

		}


	}




/*	public void loadCommands() throws SessionException
{

		try
		{
			commands.clear();
			place.loadModels();

                        Properties props;
			Properties props = place.getProps();

			zone = new PlaceCommand(place);

			int numModels = Integer.parseInt(props.getProperty("models"));

			for (int i = 0;i<numModels;i++)
			{
				String src = props.getProperty("src"+i);

				String classi = props.getProperty("class"+i);
                                Properties tooli;
				Properties tooli = ThingUtil.getProperties(baseURL,"tools/"+classi);
				String commandi = 	tooli.getProperty("command");

				Command obj = (Command)Class.forName(commandi).newInstance();

				obj.init((Model)place.getModel(src));


				commands.put(src,obj);

			}

		}catch (Exception e)
	{
		throw new SessionException (e);
	}

	}
*/
	public String parse(String command)
	{
		try
		{

			StringTokenizer sT = new StringTokenizer(command);
			int cnt = sT.countTokens();
			String obj = sT.nextToken();
			if (obj.equals("go"))
			{
				goCommand(command);

				return place.getDescription();
			}else if (place!=null)
			{
				if (obj.equals("look"))
				{
					if (cnt==2)
							return lookCommand(sT.nextToken());
					else
						return lookCommand();
				} else if (commands.containsKey(obj))
						return ((Command)commands.get(obj)).parseCommand(command);
					else return zone.parseCommand(command);

			} else return "Not connected to any place";


		}catch(Exception ses)
		{
			ses.printStackTrace();
			return "not possible";
		}

	}

	public String parseCommand(String command)
	{
		return "";
		/*	StringTokenizer sT = new StringTokenizer(command);


			String obj = sT.nextToken();

				if (obj.equals("look"))
				{
					if (cnt==2)
							return lookCommand(sT.nextToken());
					else
						return lookCommand();
				} else return "";
		*/
	}

	public void goCommand(String link)  throws SessionException
	{
//	try
	//	{
			String lk = link.substring(3);
			StringTokenizer sT = new StringTokenizer(lk,"/");

//			StringTokenizer sT = new StringTokenizer(link);
			int cnt = sT.countTokens();
 			String cmd;
			String worldName;
			String placeName;


			if (cnt==2)
			{
					worldName = (String)sT.nextToken();
					placeName = (String)sT.nextToken();

			} else {

					if (place!=null)
								worldName = place.getWorld();
					else
								worldName= "ants";

					placeName = (String)sT.nextToken();
			}



				Hashtable newPlace = (Hashtable)env.clone();
				newPlace.put(Context.WORLD,worldName);
				newPlace.put(Context.PLACE,placeName);
				if (place!=null)
				{
					place.leave();
					place = PlaceFactory.createPlace(newPlace,place);

				}
				else
					place = PlaceFactory.createPlace(newPlace);
//				loadCommands();
				place.loadLinks();

/*		}catch(Exception ex2){
				Debug.error(ex2);
		}*/

	}


	public String lookCommand()
	{

			StringBuffer buf = new StringBuffer();
			buf.append("Objects in place:\n");
			buf.append("----------------------\n");

			if (place!=null)
			{
				Hashtable models = (Hashtable)place.getModels().clone();
				Enumeration keys = models.keys();

				while (keys.hasMoreElements())
				{
					String key = (String)keys.nextElement();
					Model model = (Model)models.get(key);
					String type = model.getType();

					buf.append(key+"("+type+")\n");


				}

			buf.append("----------------------\n");

			buf.append(listLinks());


			}
		return buf.toString();

	}

	public String lookCommand(String id)
	{

		if (commands.containsKey(id))
		{

			Command cmd = (Command)commands.get(id);
			return cmd.getDescription();
		}else return "not found";

	}

	public void close()
		throws SessionException
	{
		if (place!=null)
			place.leave();


	}

	public String listLinks()
	{
			StringBuffer buf = new StringBuffer();
			buf.append("Links to other places:\n");
			Enumeration enum = place.getLinks();
			while(enum.hasMoreElements())
			{
					Link lnk = (Link)enum.nextElement();
					buf.append(">"+lnk.getPlace()+"\n");
			}

		return buf.toString();
	}


}
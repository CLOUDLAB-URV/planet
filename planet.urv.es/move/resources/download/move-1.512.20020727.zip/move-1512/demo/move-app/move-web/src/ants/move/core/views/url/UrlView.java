package ants.move.core.views.url;
/**
* Package ants.move.core.views.url
* UrlView.java
* Implementation of URL Tool
* (C) 2002 Oriol Montal� & Carles Pairot
*/

// ANTS imports
import ants.move.core.views.*;
import ants.move.core.models.*;
import ants.move.core.models.url.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of Documentation Repository.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 0.01 Build 2002
*/
public class UrlView extends DynamicObject implements ViewInterface,UrlListener {
  private Hashtable urlThingViews;
  private Place place;
  private UrlModel uM;
  private DynamicObject root;
  private Node proximitySensor;
  // EventOut avatar position
  private EventOutSFVec3f positionChanged;
  // EventOut avatar orientation
  private EventOutSFRotation orientationChanged;


   /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public UrlView () {
  }

  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));
    root=(DynamicObject)ht.get("root");
    place=(Place)ht.get("place");
    uM = (UrlModel) place.getModel(super.getName());
    if (uM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: URL");
    }
    uM.addUrlListener(this);
    urlThingViews= new Hashtable();
    Hashtable urlThings=uM.getUrlThings();
    String urlKey;
    for(Enumeration en=urlThings.keys();en.hasMoreElements();){
      urlKey=(String)en.nextElement();
      ht.put("urlThing",urlThings.get(urlKey));
      UrlThingView uTV= new UrlThingView (ht);
      urlThingViews.put(urlKey,uTV);
    }

    proximitySensor = getBrowser().getNode("PS");   // catch the scene's ProximitySensor

    System.err.println ("[MOVE] - Object URL VRML view initialized.");
  }
  public void newThing(UrlThing uT){
   try{
     if(uT.getProperty("owner").equalsIgnoreCase(uM.getPlace().getUser())){
        // Capture VRML position & orientation of avatar
        float[] t = new float[3];
        float[] r = new float[4];
        positionChanged=(EventOutSFVec3f)proximitySensor.getEventOut("position_changed");
        orientationChanged=(EventOutSFRotation)proximitySensor.getEventOut("orientation_changed");
        t = positionChanged.getValue();
        r = orientationChanged.getValue();
        uT.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
        uT.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
     }
     Hashtable params = new Hashtable();
     params.put("urlThing",uT);
     params.put("browser",getBrowser());
     params.put("root",root);
     UrlThingView uTV= new UrlThingView (params);
     urlThingViews.put(uT.getThingId(),uTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Url Thing");ex.printStackTrace();}
  }

  public void loadThing(UrlThing uT){
   try{
     Hashtable params = new Hashtable();
     params.put("urlThing",uT);
     params.put("browser",getBrowser());
     params.put("root",root);
     UrlThingView uTV= new UrlThingView (params);
     urlThingViews.put(uT.getThingId(),uTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Url Thing");ex.printStackTrace();}
  }


  public void refreshThing(String urlThingId){
    ((UrlThingView)urlThingViews.get(urlThingId)).show();
  }

  public void removeThing(String urlThingId){
    UrlThingView utv =(UrlThingView)urlThingViews.get(urlThingId);
    urlThingViews.remove(urlThingId);
    utv.destroy();
  }

  public void catchThing(String urlThingId){
    ((UrlThingView)urlThingViews.get(urlThingId)).catchMe();
  }

  public void deployThing(String urlThingId){
    ((UrlThingView)urlThingViews.get(urlThingId)).deploy();
  }


  }

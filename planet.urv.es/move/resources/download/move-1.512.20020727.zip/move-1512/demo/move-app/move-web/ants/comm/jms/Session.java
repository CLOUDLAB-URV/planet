
package ants.comm.jms;

import ants.comm.*;
import java.util.*;
import ants.util.JmsParser;
import ants.util.Debug;
import javax.jms.*;
import javax.naming.*;



public class Session implements ants.comm.Session
{
	private Hashtable env;	
	private String sessionName="default";
	private Hashtable subscriptions = new Hashtable();
	
	protected TopicConnection connection;
	protected Topic topic;
	protected TopicSession session;
	protected TopicSubscriber subscriber;
	protected TopicPublisher publisher;

	

	public void open(Hashtable env) throws SessionException

	{
		try
		{
	
			javax.naming.Context ctx = new InitialContext(env);

			TopicConnectionFactory factory = (TopicConnectionFactory)ctx.lookup((String)env.get("ants.comm.connectionfactory"));

			connection = factory.createTopicConnection();
			session = connection.createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
			topic = (Topic)ctx.lookup((String)env.get("ants.comm.topic"));
	  	publisher = session.createPublisher(topic);
	
	 		// subscriber = session.createSubscriber(topic);
   		// subscriber.setMessageListener(this);

			connection.start();		
		} catch(NamingException ex) {
				throw new SessionException(ex);
			// Debug.error(ex);
		} catch (JMSException ex2) {
			throw new SessionException(ex2);
			// Debug.error(ex);

		}
		
	}
	
	public void close() throws SessionException

	{
	try
		{
			//SessionProxy.delUser(this);

				
			publisher.close();
    	session.close();
    	connection.close();

		}catch (JMSException ex)
		{
					throw new SessionException(ex);
			// Debug.error(ex);
		}
		
	
	}
	
	
	public void send(Hashtable evt) throws SessionException
	{
		try
		{
			publisher.publish(JmsParser.getMsg(session,evt));
		}catch (JMSException ex)
		{
				throw new SessionException(ex);
			// Debug.error(ex);
		}

		
	}

		public void sendObj(Hashtable event,java.io.Serializable obj) throws SessionException
	{
	
		try
		{
			publisher.publish(JmsParser.getObjMsg(session,event,obj));
		}catch (JMSException ex)
		{
				throw new SessionException(ex);
			// Debug.error(ex);
		}

	
	
	}


	public void addRemoteEventListener (RemoteEventListener sel, Hashtable event) throws SessionException

	{
	// OJO, SOLO SOPORTA UN LISTENER POR SUBSCRIPCION
		try
		{
			
			NotificationParser npar = new NotificationParser(sel);
		  TopicSubscriber sub  = session.createSubscriber(topic,JmsParser.getSubs(event),false);
			sub.setMessageListener(npar);

			subscriptions.put(event,sub);
		} catch (JMSException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
		}
 
	}
	public void addRemoteEventListener (RemoteEventListener sel, String subscription) throws SessionException
	{
		try
		{
			NotificationParser npar = new NotificationParser(sel);
		  TopicSubscriber sub  = session.createSubscriber(topic,subscription,false);
			sub.setMessageListener(npar);
			if (subscriptions ==null) 
				System.out.println("NULL!");
	   if (sub ==null) 
				System.out.println("NULL222!");
  	if (subscription ==null) 
				System.out.println("NULL3333!");


			subscriptions.put(subscription,sub);
		} catch (JMSException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
	
		}


	}
// con.removeSubscription(sub); Como guardar sub ?
	public void removeRemoteEventListener(Hashtable event) throws SessionException
		{
			try
			{
			
				TopicSubscriber sub  = (TopicSubscriber)subscriptions.get(event);
				sub.close();
				subscriptions.remove(event);
				} catch (JMSException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
		
				}

				
		}
	public void removeRemoteEventListener(String subscription) throws SessionException
		{
			try
			{
				TopicSubscriber sub  = (TopicSubscriber)subscriptions.get(subscription);
				sub.close();
				subscriptions.remove(subscription);
			} catch (JMSException ex){
				throw new SessionException(ex);
			// Debug.error(ex);
		
			}

		

		}

}
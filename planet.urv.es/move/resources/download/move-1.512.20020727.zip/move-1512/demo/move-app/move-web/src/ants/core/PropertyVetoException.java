
package ants.core;


/**
*		Inspired in the Constraint properties of the JavaBean component model, 
* this exception is thrown by Coordination and Policy Managers.*/


public class PropertyVetoException extends Exception
{
	public PropertyVetoException(String msg)
	{
		super(msg);
	}
	public PropertyVetoException()
	{
		super("NOT POSSIBLE");
	}

}
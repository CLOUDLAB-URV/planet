<%@ page session="true" import = "java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
   try {
      String key_string = request.getParameter("thingId");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");

      Thing th = thm.getThing(key_string);
      
      String path_directory = application.getRealPath("") + File.separator +
                              "worlds" + File.separator + session.getAttribute("worldId") + File.separator +
                              session.getAttribute("placeId")+File.separator+ key_string;
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      FileDeleter fd = new FileDeleter (path_directory);
      fd.delete();

      String path_bakdirectory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "things" + File.separator +
                              "objbak"+File.separator+th.getProperty("fileName");
      Syslog.debug (this, "Let's delete ->" + path_bakdirectory +"<-");
      FileDeleter fd2 = new FileDeleter (path_bakdirectory);
      fd2.delete();



      Syslog.debug (this, "Object file deleted from disk.");
     
      thm.removeThing(key_string);
      response.sendRedirect ("close.jsp");
   } catch (Exception e) {
      System.out.println(e);
   }
%>
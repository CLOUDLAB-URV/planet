
	
package ants.comm;

import java.net.URL;
import java.util.Hashtable;

/**
*		The session interface stablishes a simple contract to access publish/subscribe 
*		middleware. It mimics the delegation event model to smooth the transition from 
*   local to remote events for Java programmers
*
*/

public interface Session 
{
	
	/**
	*	  The open method is mainly used by the facility class SessionFactory, so
	*   normally should not be used by programmers.
	* @param env key/value pairs representing connection parameters
	* @see ants.comm.Context
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems in the connection phase. 
	*/
	
	public void open(Hashtable env) throws SessionException;
	
	/**
	*		The close method safety frees resources and closes the connection.
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection. 
	*/
		
	public void close() throws SessionException;
	
	/**
	*		The send method produces notifications in a simple and straightforward style.
	* @param event event uses the well-known java.util.Hashtable for creating key-value pairs notifications
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and Notification. 
	*/
	public void send(Hashtable event) throws SessionException;
	
	
		/**
	*	Sender method that accepts a Serializable Java object as parameter. It will be received 
	* in the client with the key "object" in the Hashtable event parameter. 
	* @param event event uses the well-known java.util.Hashtable for creating key-value pairs notifications
	* @param obj Java serializable object
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and Notification. 
	*/
	public void sendObj(Hashtable event,java.io.Serializable obj) throws SessionException;

	
	/**
	*	This method creates a listener of remote events that match the subscription specified in subscription param.
	* @param sel the Listener of remote events, it will handle incoming events matching the subscription
	* @param subscription The subscription is represented using a Hashtable. It creates a equality selector of all key-value pairs using the AND operator.
	* @see ants.comm.RemoteEventListener
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and subscription. 
	*/

	public void addRemoteEventListener (RemoteEventListener sel, Hashtable subscription) throws SessionException;
	
	/**
	*	This method creates a listener of remote events that matches the subscription specified in subscription param.
	* @param sel the Listener of remote events, it will handle incoming events matching the subscription
	* @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
	* @see ants.comm.RemoteEventListener
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and subscription. 
	*/

	public void addRemoteEventListener (RemoteEventListener sel, String subscription) throws SessionException;
	
	/**
	*	This method removes the subscription specified in subscription param.
	* @param subscription the subscription to be removed (using specific constraint filter language)
	* @see ants.comm.RemoteEventListener
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and removal of subscriptions. 
	*/
	
	public void removeRemoteEventListener(String subscription) throws SessionException;
	
	/**
	*	This method removes the subscription specified in subscription param.
	* @param subscription the subscription to be removed (using a Hashtable)
	* @see ants.comm.RemoteEventListener
	* @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
	*  all posible problems with the connection and removal of subscriptions. 
	*/

	
	public void removeRemoteEventListener(Hashtable subscription) throws SessionException;

}
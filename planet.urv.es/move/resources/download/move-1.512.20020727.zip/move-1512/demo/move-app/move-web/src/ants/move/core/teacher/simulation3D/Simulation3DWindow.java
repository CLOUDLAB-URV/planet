// Package ants.move.core.teacher.simulation3D
// Simulation3DWindow.java
// Implementation of Simulation3D User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.simulation3D;

// dynamicObjects.Simulation3D import
import ants.move.core.models.simulation3D.*;
import ants.move.core.views.simulation3D.*;
import ants.move.core.models.*;
import ants.core.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;

import java.net.URL;
import java.util.*;

/** Implementation of Simulation3D User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.80 Build 2000
*/
public class Simulation3DWindow extends Windows implements TeacherInterface,
                                                           Simulation3DListener {
  // Buttons
  private Button loadButton;
  private Button RemButton;
  private Button ScaleUpButton;
  private Button ScaleDnButton;
  private Button MoveUpButton;
  private Button MoveDnButton;
  private Button MoveLtButton;
  private Button MoveRtButton;
  private Button NearButton;
  private Button FarButton;
  private Button startButton;
  private Button prevButton;
  private Button nextButton;
  private Button endButton;
  // Labels
  private Label FileLabel;
  private Label s3DLabel;
  // Choice
  private Choice s3DChoice;
  // Simulation3D internal model
  private Simulation3DModel internalModel;
  // Applet's current codeBase
  private String codeBase;
  // Simulation3D name
  private String s3DName;
  // Simulation3D's initial orientation
  private float[] oriIni;
  // Simulation3D's initial position
  private float[] posIni;
  // Simulation3D's initial scale factor
  private float[] scaleIni;
  private Place conn;
  private String dispName;

  // All things of type Simulation3D in that place
  Vector s3DThings = new Vector();

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public Simulation3DWindow() {
    super();
    oriIni = new float[4];
    posIni = new float[3];
    scaleIni = new float[3];
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Simulation3D");
    s3DName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (Simulation3DModel) conn.getModel(s3DName);
    codeBase = conn.getBaseURL() + "worlds/" + conn.getWorld() + "/" + conn.getPlaceId() + "/";

    // Obtain all things of type Simulation3D in that place
    s3DThings = conn.getThings("s3d.v01");

    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);
    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setLocation(392, 0);
    window.setSize(300, 240);
    window.setResizable(false);
    window.setLayout(gbLayout);

    p = new Panel();
    p.setLayout(null);
    p.setSize(230, 182);

    s3DLabel = new Label("Simulation3D Set:");
    s3DLabel.setBounds(0, 0, 144, 24);
    p.add(s3DLabel);
    s3DChoice = new Choice();
    s3DChoice.setBounds(0, 24, 108, 24);
    p.add(s3DChoice);
    loadButton = new Button("Load");
    loadButton.setBounds(117, 23, 50, 24);
    p.add(loadButton);
    RemButton = new Button("Remove");
    RemButton.setBounds(178, 23, 50, 24);
    p.add(RemButton);
    ScaleUpButton = new Button("+");
    ScaleUpButton.setBounds(0, 52, 35, 24);
    p.add(ScaleUpButton);
    ScaleDnButton = new Button("-");
    ScaleDnButton.setBounds(0, 100, 35, 24);
    p.add(ScaleDnButton);
    NearButton = new Button("Near");
    NearButton.setBounds(38, 52, 35, 24);
    p.add(NearButton);
    FarButton = new Button("Far");
    FarButton.setBounds(38, 100, 35, 24);
    p.add(FarButton);
    MoveUpButton = new Button("Up");
    MoveUpButton.setBounds(128, 52, 50, 24);
    p.add(MoveUpButton);
    MoveDnButton = new Button("Down");
    MoveDnButton.setBounds(128, 100, 50, 24);
    p.add(MoveDnButton);
    MoveLtButton = new Button("Left");
    MoveLtButton.setBounds(78, 76, 50, 24);
    p.add(MoveLtButton);
    MoveRtButton = new Button("Right");
    MoveRtButton.setBounds(178, 76, 50, 24);
    p.add(MoveRtButton);
    startButton = new Button("<<");
    startButton.setBounds(38, 132, 40, 24);
    p.add(startButton);
    prevButton = new Button("<");
    prevButton.setBounds(78, 132, 40, 24);
    p.add(prevButton);
    nextButton = new Button(">");
    nextButton.setBounds(118, 132, 40, 24);
    p.add(nextButton);
    endButton = new Button(">>");
    endButton.setBounds(158, 132, 40, 24);
    p.add(endButton);
    FileLabel = new Label("Current set: None");
    FileLabel.setBounds(0, 156, 225, 24);
    p.add(FileLabel);
    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 8;
    gc.gridheight = 8;
    gbLayout.setConstraints(p, gc);
    window.add(p);

    internalModel.addSimulation3DListener (this);
    if(internalModel.getS3DThing()==null){
      FileLabel.setText("Current set: None ");
    }else{
      FileLabel.setText("Current set: " + (internalModel.getS3DThing()).getName());
    }
  // Add things to choice
  try {
    Enumeration e = s3DThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      s3DChoice.addItem(th.getName());
    }

  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Simulation3D to choice"); e.printStackTrace();}

    loadButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loadButton_actionPerformed(e);
      }
    });

    RemButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        RemButton_actionPerformed(e);
      }
    });

    ScaleUpButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ScaleUpButton_actionPerformed(e);
      }
    });

    ScaleDnButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ScaleDnButton_actionPerformed(e);
      }
    });

    MoveUpButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MoveUpButton_actionPerformed(e);
      }
    });

    MoveDnButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MoveDnButton_actionPerformed(e);
      }
    });

    MoveRtButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MoveRtButton_actionPerformed(e);
      }
    });

    MoveLtButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MoveLtButton_actionPerformed(e);
      }
    });

    NearButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        NearButton_actionPerformed(e);
      }
    });

    FarButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        FarButton_actionPerformed(e);
      }
    });

    startButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        startButton_actionPerformed(e);
      }
    });

    prevButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        prevButton_actionPerformed(e);
      }
    });

    nextButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        nextButton_actionPerformed(e);
      }
    });

    endButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        endButton_actionPerformed(e);
      }
    });
    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });

    System.err.println("[MOVE] - Simulation3D control window initialized.");
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  /** loadButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void loadButton_actionPerformed (ActionEvent e) {
    try {  // Set up Simulation3D in right place
      ants.core.Thing t = (ants.core.Thing) s3DThings.elementAt(s3DChoice.getSelectedIndex());
      internalModel.setS3DThing(t.getThingId());
      FileLabel.setText("Current set: " + t.getName());
    }catch (Exception ex) {
      System.err.println("Exception when trying to load 3D slides");
    }
  }
/*
  public String getThingId (String thg) {
    Enumeration e = s3DThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getName().equalsIgnoreCase(thg)) {
        return (t.getThingId());
      }
    }
    return null;
  }
*/

  /** RemButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void RemButton_actionPerformed (ActionEvent e) {
    internalModel.removeS3D();
    FileLabel.setText("Current set: None");
  }

  /** ScaleUpButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void ScaleUpButton_actionPerformed (ActionEvent e) {
    String scaleFactor = internalModel.getScale();

    StringTokenizer tokens = new StringTokenizer (scaleFactor);
    float s0 = (float) ((new Float(tokens.nextToken())).floatValue() * 1.5);
    float s1 = (float) ((new Float(tokens.nextToken())).floatValue() * 1.5);
    float s2 = (float) ((new Float(tokens.nextToken())).floatValue() * 1.5);
    internalModel.scaleS3D("" + s0 + " " + s1 + " " + s2);
  }

  /** ScaleDnButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void ScaleDnButton_actionPerformed (ActionEvent e) {
    String scaleFactor = internalModel.getScale();

    StringTokenizer tokens = new StringTokenizer (scaleFactor);
    float s0 = (float) ((new Float(tokens.nextToken())).floatValue() / 1.5);
    float s1 = (float) ((new Float(tokens.nextToken())).floatValue() / 1.5);
    float s2 = (float) ((new Float(tokens.nextToken())).floatValue() / 1.5);
    internalModel.scaleS3D("" + s0 + " " + s1 + " " + s2);
  }

  /** MoveUpButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void MoveUpButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) (new Float(tokens.nextToken())).floatValue();
    float p1 = (float) ((new Float(tokens.nextToken())).floatValue() + 0.5);
    float p2 = (float) (new Float(tokens.nextToken())).floatValue();
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** MoveDnButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void MoveDnButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) (new Float(tokens.nextToken())).floatValue();
    float p1 = (float) ((new Float(tokens.nextToken())).floatValue() - 0.5);
    float p2 = (float) (new Float(tokens.nextToken())).floatValue();
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** MoveLtButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void MoveLtButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) ((new Float(tokens.nextToken())).floatValue() - 0.5);
    float p1 = (float) (new Float(tokens.nextToken())).floatValue();
    float p2 = (float) (new Float(tokens.nextToken())).floatValue();
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** MoveRtButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void MoveRtButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) ((new Float(tokens.nextToken())).floatValue() + 0.5);
    float p1 = (float) (new Float(tokens.nextToken())).floatValue();
    float p2 = (float) (new Float(tokens.nextToken())).floatValue();
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** NearButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void NearButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) (new Float(tokens.nextToken())).floatValue();
    float p1 = (float) (new Float(tokens.nextToken())).floatValue();
    float p2 = (float) ((new Float(tokens.nextToken())).floatValue() + 0.5);
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** FarButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void FarButton_actionPerformed (ActionEvent e) {
    String translation = internalModel.getTranslation();

    StringTokenizer tokens = new StringTokenizer (translation);
    float p0 = (float) (new Float(tokens.nextToken())).floatValue();
    float p1 = (float) (new Float(tokens.nextToken())).floatValue();
    float p2 = (float) ((new Float(tokens.nextToken())).floatValue() - 0.5);
    internalModel.moveS3D("" + p0 + " " + p1 + " " + p2);
  }

  /** startButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void startButton_actionPerformed (ActionEvent e) {
    internalModel.firstS3D();
  }

  /** prevButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void prevButton_actionPerformed (ActionEvent e) {
    internalModel.prevS3D();
  }

  /** nextButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void nextButton_actionPerformed (ActionEvent e) {
    internalModel.nextS3D();
  }

  /** endButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void endButton_actionPerformed (ActionEvent e) {
    internalModel.lastS3D();
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Simulation3D";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }


  public void createSimulation (String url) {
    FileLabel.setText("Current set: " + (internalModel.getS3DThing()).getName());
  }

  public void removeSimulation () {
    FileLabel.setText("Current set: None");
  }

  public void moveSimulation (String values) { }

  public void scaleSimulation (String values) { }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }
}

// Package ants.move.core.views.audio
// AudioView.java
// Implementation of DynamicObject Audio
// (C) 2000 Carles Pairot & Oriol Montal� & Francesc Pi�as
package ants.move.core.views.audio;

// ANTS imports
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.audio.*;
import ants.move.core.teacher.audio.*;
import ants.move.core.*;


// java.io Package imports
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of DynamicObject Audio.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.30 Build 2000
*/
public class AudioView extends DynamicObject implements AudioListener, ViewInterface, VRMLEventListener {

  // VRML Node
  private Node[] node;
  // Audio URL Node EventIn
  private EventInMFString urlTrack;
  // Current audio's URL
  private String[] track = new String [1];
  // model
  private AudioModel aM;
  // current place
  private Place place;
  // browser
  private Browser browser;
  // VRML root node
  private DynamicObject root;
  //src
  private String src;
  //codeBase
  private String codeBase;
  //Touchsensor
  private EventOutSFBool TS;


   /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public AudioView () {
  }

  public void init (Hashtable ht) {
   try{
    browser=  (Browser)ht.get("browser");
    src=      (String)ht.get("src");
    place=    (Place)ht.get("place");
    root=     (DynamicObject)ht.get("root");
    MOVECoreApplet mc=(MOVECoreApplet)ht.get("MOVECoreApplet");
    codeBase=mc.getCodeBase().toString();
    aM = (AudioModel) place.getModel(src);
    if (aM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: AUDIO");
    }

    this.loadVRMLRepresentation();

    //Actualize Audio track
    if((aM.getProperty("playing")).equalsIgnoreCase("true"))
        this.playAudio(aM.getAudioTrack());
    aM.addAudioListener(this);
    System.err.println ("[MOVE] - Audio VRML view initialized.");
   }catch(Exception e){System.err.println("[MOVE] - Error initializing audio view:"+e);}
  }

  public void loadVRMLRepresentation(){
    String str = new String();
    String auxstr = new String();

    byte[] buffer = new byte[1024];
    int i;

    // Add avatar to VRML scene
    try {
      URL slURL = new URL (codeBase+"resources/things/audio.v01.wrl");
      BufferedInputStream bis = new BufferedInputStream(slURL.openStream());

      while((i = bis.read(buffer, 0, 1024)) != -1) {
          auxstr = new String (buffer);
          if (i != 1024) {
            byte[] buf2 = new byte[i];
            for (int k=0; k<i; k++) {
              buf2[k]=buffer[k];
            }
            auxstr = new String (buf2);
          }
          str = str + auxstr;
      }

      bis.close();

      str=str+"  \nDEF script Script{\n" +
                "  eventIn MFString src\n" +
                "  eventOut MFString track\n"+
                "  url \"javascript: \n" +
                "    function src()\n" +
                "    {track=src;}\"" +
                "}\n" +
                "ROUTE script.track TO SRC.set_url\n" +
                "\n";
      node = browser.createVrmlFromString(str);
      urlTrack = (EventInMFString) node[(node.length)-1].getEventIn("src");

      // Create audio's shape node

      str=" Transform\n" +
                "{\n" +
		"translation "+aM.getProperty("translation")+"\n" +
                "rotation "+aM.getProperty("rotation")+"\n" +
		"scale "+aM.getProperty("scale")+"\n" +
  		"children [\n" +
                "       DEF TS1 TouchSensor{}\n" +
  		"]\n" +
	    	"}\n"+
                "DEF TS2 Script{\n" +
                "  eventIn SFBool active\n" +
                "  eventOut SFBool eOut\n" +
                "  url \"javascript: \n" +
                " function active(value)\n" +
                " { if (eOut == TRUE) eOut=FALSE;\n" +
                "     else eOut=TRUE;}\"" +
                "}\n" +
                "ROUTE TS1.isActive TO TS2.active\n" +
                "\n";

      Node[] nodeBase = browser.createVrmlFromString(str);
      TS = (EventOutSFBool)nodeBase[1].getEventOut("eOut");
      VRMLZone zone= new VRMLZone();
      zone.addVRMLEventListener(this,src);
      TS.advise(zone, src);

      root.setaddChValue(nodeBase);
      EventInMFNode ein=(EventInMFNode)nodeBase[0].getEventIn("addChildren");
      ein.setValue(node);

    } catch (Exception e) {System.err.println("Exception occured loading audio representation file: " ); e.printStackTrace();}
  }


  /** Executed when a VRML Event is received.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */

  public void playAudio (String audioTrack) {
    System.out.println(audioTrack);
    track[0] = audioTrack;
    urlTrack.setValue(track);

  }

  public void loadAudio() {

  }

  public void stopAudio() {
    track[0] = " ";
    urlTrack.setValue(track);


  }

  public AudioModel getModel() {
    return aM;
  }

  public void destroy(){
    aM.removeAudioListener(this);

  }


  public void eventPerformed() {
    if (TS.getValue()) {
      if(place.hasPermission("audio.v01")){
       Hashtable params = new Hashtable();
       params.put("src",src);
       params.put("place",place);
       params.put("dispName","AUDIO");

       AudioWindow aw = new AudioWindow();
       aw.init(params);
       aw.showWin();
      }
    }
  }

}

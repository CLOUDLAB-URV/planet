
package ants.core;

public class IndexedProperty
{
	private String[] values;
	private String name;
	
	public IndexedProperty(String name, int size)
	{
	
		this.name = name;
    values = new String[size];		
	}
	
	public IndexedProperty(String name, String[] values)
	{
		
		this.name = name;
    this.values = values;
    
	}

  public String [] getValues()
	{	
		return values;
	}

	public int size()
	{
		return values.length;	
	}
	
	public String getValue(int index)
	{
		return values[index];
			
	}
	
	public void setValue(int index, String value)
	{
		values[index] = value;
	}
	
	public void setValues(String[] values)
	{
		this.values = values;
	}
		
	
	
}

package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class GenericObjectConsumer {
	
	
	public GenericObjectConsumer(String envFile)
	{
	 try
		{
			ants.comm.Session chatZone = SessionFactory.createSession(envFile);

	
			ListenerX l1 = new ListenerX();
			Listenerd l2 = new Listenerd();
		

			Hashtable evt = new Hashtable ();
			evt.put("arg1","terrance");
			chatZone.addRemoteEventListener(l1,evt);

			Hashtable evt2 = new Hashtable ();
			evt2.put("arg1","filip");
			chatZone.addRemoteEventListener(l2,evt2);
			
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	
	public class Listenerd implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("Filip event !!!");
			Persona x = (Persona)evt.get("object");
			System.out.println(x.edad);


		}
	}

	public static void main(String args[])
	{
			GenericObjectConsumer tc = new GenericObjectConsumer(args[0]);
			System.out.println("Ready !  (Press CTRL+C to exit)");
			
	
		
		try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
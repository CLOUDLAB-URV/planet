
package ants.comm.mcast;

import ants.comm.*;
import java.util.*;
import ants.util.JmsParser;
import ants.comm.jms.NotificationParser;
import ants.util.Debug;
import javax.jms.*;
import javax.naming.*;
//import fiorano.jms.multicastrtl.FioranoMulticastInitialContext;
import ch.softwired.jms.*;




public class Session implements ants.comm.Session
{
	private Hashtable env;	
	private String sessionName="default";
	private Hashtable subscriptions = new Hashtable();
	
	protected TopicConnection connection;
	protected IBusTopic topic;
	protected TopicSession session;
	protected TopicSubscriber subscriber;
	protected TopicPublisher publisher;

	
	public void open(Hashtable environment)
	{
	try
		{
			
			
			session =  IBusJMSContext.createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
			topic = (IBusTopic ) IBusJMSContext.getTopic("/quotes/zrh");
			topic.setQOS("DISPATCH:IPMCAST");
			publisher = session.createPublisher(topic);
	
	

			IBusJMSContext.getTopicConnection().start();		
	
		} catch (JMSException ex2) {
			Debug.error(ex2);

		} catch (javax.naming.NamingException  ex3){
						Debug.error(ex3);

		}
	 
	}	
		
		
	
	public void close()
	{
	try
		{
			//SessionProxy.delUser(this);

		
			Hashtable evt = new Hashtable();
			evt.put("class","Session");
			evt.put("obj",sessionName);
			evt.put("method","deluser");
	
			send(evt);
		
			publisher.close();
    	session.close();
    	IBusJMSContext.getTopicConnection().close();

		}catch (JMSException ex)
		{
			Debug.error(ex);
		}	 catch (javax.naming.NamingException  ex3){
						Debug.error(ex3);

		}

		
	
	}
	
	
	public void send(Hashtable evt)
	{
		try
		{
			publisher.publish(JmsParser.getMsg(session,evt));
		}catch (JMSException ex)
		{
			Debug.error(ex);
		}

		
	}

	public void send2Others(Hashtable msg){}
	
	public void send2User(String userId, Hashtable evt)
	{
/*		try
		{

			evt.put("class","Session");
			evt.put("obj",sessionName);
			evt.put("principal", env.get("principal"));
			evt.put("to",userId);
			prod.notify(evt);
		}catch (java.io.IOException ex){
			Debug.error(ex);
	
		}*/

	}
	public void addRemoteEventListener (RemoteEventListener sel, Hashtable event)
	{
	// OJO, SOLO SOPORTA UN LISTENER POR SUBSCRIPCION
		try
		{
			
			ants.comm.jms.NotificationParser npar = new ants.comm.jms.NotificationParser(sel);
		  TopicSubscriber sub  = session.createSubscriber(topic,JmsParser.getSubs(event),false);
			sub.setMessageListener(npar);

			subscriptions.put(event,sub);
		} catch (JMSException ex){
			Debug.error(ex);		
		}
 
	}
	public void addRemoteEventListener (RemoteEventListener sel, String subscription)
	{
		try
		{
			NotificationParser npar = new NotificationParser(sel);
		  TopicSubscriber sub  = session.createSubscriber(topic,subscription,false);
			sub.setMessageListener(npar);
			if (subscriptions ==null) 
				System.out.println("NULL!");
	   if (sub ==null) 
				System.out.println("NULL222!");
  	if (subscription ==null) 
				System.out.println("NULL3333!");


			subscriptions.put(subscription,sub);
		} catch (JMSException ex){
			Debug.error(ex);		
		}


	}
// con.removeSubscription(sub); Como guardar sub ?
	public void removeRemoteEventListener(Hashtable event)
		{
			try
			{
			
				TopicSubscriber sub  = (TopicSubscriber)subscriptions.get(event);
				sub.close();
				subscriptions.remove(event);
				} catch (JMSException ex){
					Debug.error(ex);		
				}

				
		}
	public void removeRemoteEventListener(String subscription)
		{
			try
			{
				TopicSubscriber sub  = (TopicSubscriber)subscriptions.get(subscription);
				sub.close();
				subscriptions.remove(subscription);
			} catch (JMSException ex){
						Debug.error(ex);		
			}

		

		}
/*	
	public void addSessionListener(SessionListener sL)
	{
		Subscription subs = new Subscription ("src=room obj="+sessionId"+"action=LEAVE"||"src=room obj="+sessionId"+"action=JOIN");	
		cons.addSubscription(subs,	}	
*/
	public Iterator getUsers()
	{
		//Proxy.getUsers()
		return null;
	}
	
	
	public Iterator getObjects()
	{
			//Proxy.getUsers()
			return null;
		}
/*private TextMessage getMsg(Hashtable evt)
{
	
		TextMessage message = session.createTextMessage();
		message.setText("MSG");

	 	Enumeration keys = evt.keys();
	
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			String value = (String)nt.get(key);
			message.setStringProperty(key, value);

		}
		return message;
	}

private Hashtable getEvt(TextMessage  message)
{
	
		Enumeration keys = message.getPropertyNames();
		Hashtable evt = new Hashtable();
		
	
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			String value = (String)message.getStringProperty(key);
			evt.put(key,value);

		}
		return evt;
	}
*/

}
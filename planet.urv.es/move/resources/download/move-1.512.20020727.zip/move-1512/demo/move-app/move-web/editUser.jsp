<%@ page session="true" import = "javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! User user;%>
<%
      try{
        UserManager um = (UserManager)session.getAttribute("userManager");

        String u=request.getParameter("user");
        if (u==null){
          user=(User)session.getAttribute("user");
        }else{
          user=um.getUser(u);
        }

      }catch(Exception e){
         Syslog.error(this,"Unable to get the user");
      }
%>

<HTML>
<FRAMESET cols="70%, 30%" name="root">
     <frameset  >
        <FRAME NORESIZE SRC="editUserProps.jsp?user=<%=user.getLogin()%>" name="jsp">
        <FRAME NORESIZE SRC="resources/avatars/uncompressed/avatarPreview.wrl" name="vrml">
     </frameset>


</FRAMESET>

</HTML>
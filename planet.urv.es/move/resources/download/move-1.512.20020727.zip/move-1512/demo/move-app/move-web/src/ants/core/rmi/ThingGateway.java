package ants.core.rmi;

import java.util.*;

public interface ThingGateway extends java.rmi.Remote {
  public String getName (String tKey) throws java.rmi.RemoteException;
  public String getDescription (String tKey) throws java.rmi.RemoteException;
  public String getToolId (String tKey) throws java.rmi.RemoteException;
  public String getPlaceId (String tKey) throws java.rmi.RemoteException;
  public void setProperty (String tKey, String propName, String propValue) throws java.rmi.RemoteException;
  public String getProperty (String tKey, String propName) throws java.rmi.RemoteException;
  public String[] getPropertyNames (String tKey) throws java.rmi.RemoteException;
  public String getIndexedProperty (String tKey, String propName, int index) throws java.rmi.RemoteException;
  public void setIndexedProperty(String tKey, String propName, String value, int index) throws java.rmi.RemoteException;
  public int getIndexedPropertySize (String tKey,String propName) throws java.rmi.RemoteException;
  public String[] getIndexedPropertyNames (String tKey) throws java.rmi.RemoteException;
}
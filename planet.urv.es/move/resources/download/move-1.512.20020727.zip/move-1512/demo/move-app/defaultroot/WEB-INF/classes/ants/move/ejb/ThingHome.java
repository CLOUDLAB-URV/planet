package ants.move.ejb;


import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBHome;
import java.util.*;
/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Thing Entity Bean Home interface
 */
public interface ThingHome extends EJBHome {

  public Thing create(String id) throws CreateException,RemoteException;
  public Thing findByPrimaryKey (String id) throws FinderException,RemoteException;
  public Collection findByAll() throws FinderException, RemoteException;
  public Collection findByPlace(String placeId) throws FinderException, RemoteException;
  public Collection findByPlaceAndTool(String placeId, String toolId) throws FinderException, RemoteException;
}


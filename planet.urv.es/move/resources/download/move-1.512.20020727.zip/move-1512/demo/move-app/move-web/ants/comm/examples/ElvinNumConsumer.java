
package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class ElvinNumConsumer {
	
	
	public ElvinNumConsumer()
	{
	 try
		{
			Hashtable env = new Hashtable();
			env.put(Context.PROVIDER_URL, "elvin://pgarcia.etse.urv.es:2917");
			env.put(Context.PROVIDER_CLASS, "ants.comm.elvin.Session");

		
			ants.comm.Session chatZone = SessionFactory.createSession(env);

	
			Listener1 l1 = new Listener1();
		
			String subs = "num > 7 && num < 14";
			chatZone.addRemoteEventListener(l1,subs);

		
	
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	public class Listener1 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			System.out.println("event arrived !!!  " + evt);
		}
	}
	

	public static void main(String args[])
	{
			ElvinNumConsumer tc = new ElvinNumConsumer();
			System.out.println("Ready !  (Press CTRL+C to exit)");

			try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
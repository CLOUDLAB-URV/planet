<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*, com.evermind.io.*"%>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>
<%
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 String userLogin = ((User)session.getAttribute("user")).getLogin();
 String toolKey = "video.v01";

 if (request.getMethod().equalsIgnoreCase("GET")) {

    lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");
 %>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("uploadVideo")%> : </b></font></td></tr>
</table>
<table width=90%>
 <form enctype="multipart/form-data" method="POST">
 <tr>
  <td colspan="3">
    <br><%=messages.getString("uploadVideo")%>
    <br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
  <b><%=labels.getString("videoName")%> :</b> <input type="text" name="Name" size="20"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("videoDescription")%> :</b>
    <input type="text" name="Desc"  size="50"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <b><%=labels.getString("chooseVideo")%> :</b><input type="file" name="file"><br><br>
  </td>
 </tr>
 <tr>
  <td colspan="3">
    <center><input type=submit name=action value="<%=labels.getString("upload")%>"> <input TYPE="reset" VALUE="<%=labels.getString("reset")%>" border="0" cellpadding="0" cellspacing="0">
    </center>
  </td>
 </tr>
</form>
</table>
</center>
<jsp:include page="footer.jsp" flush="true"/>
</BODY>
</HTML>
<%
}else{

   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String fileName="";
   Vector thingFiles=new Vector();

   Enumeration enumeration = new FilePostParser(request.getInputStream(),
                                                request.getContentLength());
   while( enumeration.hasMoreElements() ) {
          Object element = enumeration.nextElement();
          if( element instanceof Map.Entry ) {
               Map.Entry entry = (Map.Entry)element;

               if ((entry.getKey()).equals("Name"))
		   thingName = (String)entry.getValue();
               if ((entry.getKey()).equals("Desc"))
		   thingDesc = (String)entry.getValue();



           }
           else if( element instanceof PostFileInputStream ) {
               PostFileInputStream in = (PostFileInputStream)element;
               File file=new File(in.getFileName());

               fileName=file.getName();
               FileOutputStream fout = new FileOutputStream
       		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+thingKey+".avi");
               int bite;
               while((bite=in.read()) != -1)
                   fout.write(bite);

               in.close();
               fout.close();

           }
    }

     ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
     Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
     thing.setDescription(thingDesc);
     thing.setProperty("date",(new Date()).toGMTString());
     thing.setProperty("owner",userLogin);

     Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
     response.sendRedirect("listThings.jsp");
}
%>
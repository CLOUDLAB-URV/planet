package ants.move.ejb;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for User Entity Bean
 */
public interface User extends EJBObject{

  public String getLogin() throws RemoteException;
  public String getPassword() throws RemoteException;
  public String getRole() throws RemoteException;
  public void setPassword(String password) throws RemoteException;
  public void setRole (String role) throws RemoteException;
  public String getProperty(String property) throws RemoteException,Exception;
  public void setProperty(String property, String value) throws RemoteException;
  public String getIndexedProperty(String property,int index) throws RemoteException,Exception;
  public void setIndexedProperty(String property, String value, int index) throws RemoteException;

}
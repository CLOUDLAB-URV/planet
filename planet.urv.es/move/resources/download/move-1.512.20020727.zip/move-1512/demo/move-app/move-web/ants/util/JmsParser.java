
package ants.util;

import java.util.*;
import org.elvin.util.*;
import java.util.Hashtable;
import javax.jms.*;


public class JmsParser 
{

public static ObjectMessage getMsg(TopicSession session,Hashtable evt) throws JMSException
{
	
		ObjectMessage message = session.createObjectMessage();
		message.setObject(null);

	 	Enumeration keys = evt.keys();
	
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
		//	String value = (String)evt.get(key);
		//	message.setStringProperty(key, value);
			message.setObjectProperty(key, evt.get(key));

		}
		return message;
	}

public static ObjectMessage getObjMsg(TopicSession session,Hashtable evt,java.io.Serializable obj) throws JMSException
{
    	
		ObjectMessage message = session.createObjectMessage();
		message.setObject(obj);

	 	Enumeration keys = evt.keys();
	
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
		//	String value = (String)evt.get(key);
		//	message.setStringProperty(key, value);
			message.setObjectProperty(key, evt.get(key));

		}
		return message;
	}
	
	
	
	
public static Hashtable getEvt(Message  message) throws JMSException

{
	ObjectMessage msg = (ObjectMessage)message;
	
		Enumeration keys = msg.getPropertyNames();
		Hashtable evt = new Hashtable();
		
	
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
	// Object key = keys.nextElement();
	//		String value = (String)message.getStringProperty(key);
			evt.put(key,msg.getObjectProperty(key));

		}
	
	Object obj = msg.getObject();
	if (obj!=null)
		evt.put("object",obj);
	
	
		return evt;
	}
public static String getSubs (Hashtable evt)
{
	StringBuffer subs = new StringBuffer("");

	Enumeration keys = evt.keys();
	while (keys.hasMoreElements())
	{
		String key = (String)keys.nextElement();
		String value = (String)evt.get(key);
		subs.append(" "+key+" = '"+value +"' AND ");
		evt.put(key,value);
		
	}
	String res = subs.toString();
	String result = res.substring(0,res.length()-4);
	return result;
	
}	

	
}
<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>
<%  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");
%>

<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS&linked=false" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("chooseWorld")%> : </b></font></td></tr>
<tr>
  <td align="right" >
    <FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%>:</FONT>&nbsp;

    <a href="createWorld.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue">World</font></a>&nbsp;&nbsp;&nbsp;&nbsp;
    <%
    if(((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
    %>
      <a href="listUsers.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("user1")%></font></a>
    <%}%><br><br>
  </td>
</tr>
</table>


  <%

   try {
      WorldManager wm = (WorldManager)session.getAttribute("worldManager");
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");

     if((wm.getWorlds().size())!=0){ %>
       <table border="0" bgcolor="teal" width="90%">
         <TR>

              <TH><font color="white"><%=labels.getString("nameTH")%></TH>
              <TH><font color="white"><%=labels.getString("typeTH")%></TH>
              <TH><font color="white"><%=labels.getString("descriptionTH")%></TH>
              <TH><font color="white">Places</TH>
              <TH><font color="white"><%=labels.getString("creationTH")%></TH>
              <TH><font color="white"><%=labels.getString("createdTH")%></TH>

         </TR>
      <%
       Collection worlds=wm.getWorlds();

       int placeNum;
       World world=null;
       for (Iterator i=worlds.iterator();i.hasNext();){
         world=(World)i.next();
         if(pm.getPlaces(world.getId())!=null){
           placeNum=pm.getPlaces(world.getId()).size();
         }else{
           placeNum=0;
         }
         %>
         <TR ALIGN=CENTER bgcolor="#E6E4DD">
          <TD align="left"><A href="listPlaces.jsp?worldId=<%=world.getId()%>"><B><%=world.getName()%></B></A></TD><TD><%=world.getType()%></TD><TD><%=world.getDescription()%></TD>
          <TD><%=placeNum%></TD><TD><%=lang.translateDateTime(new Date(world.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></TD><TD><%=world.getProperty("owner")%></TD>
          <TD bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(world.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
            <a href="removeWorld.jsp?worldId=<%=world.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
          </TD>
         </TR>



        <%
      }
     }
   } catch (Exception e) {
      Syslog.log (this, e);
   }
  %>        </table>

<br><br>


</center>
<jsp:include page="footer.jsp" flush="true"/>
</body>
<HTML>
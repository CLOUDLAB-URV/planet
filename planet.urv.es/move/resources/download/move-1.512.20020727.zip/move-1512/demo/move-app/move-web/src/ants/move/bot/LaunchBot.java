package ants.move.bot;

import java.util.*;
import java.io.*;
import java.lang.reflect.Constructor;


public class LaunchBot{


  public static void main(String[] args) {
    
      String worldKey;
      String placeKey;
      String userName;
      String url;
      String avatar;
      String src;

   try{ 
      Properties p = new Properties();
      p.load(new FileInputStream("bot.properties"));
      placeKey=p.getProperty("place");
      worldKey=p.getProperty("world");
      userName=p.getProperty("name");
      url=p.getProperty("host");
      avatar=p.getProperty("avatarUrl");
      
      src=p.getProperty("botClass");  

      Class[] params=new Class[2];
      
      params[0]=(new String()).getClass();
      params[1]=(new String()).getClass();

      Object[] initArgs={userName,avatar};
      
      Class cl=Class.forName(src);

      Constructor c=cl.getConstructor(params);
      Bot bot=(Bot)c.newInstance(initArgs);

      
            
      bot.joinToPlace(url,worldKey,placeKey);
      
      java.lang.Thread.sleep(6000);
      float[] pos={0.0f,2.5f,0.0f};
      bot.setPosition(pos); 
      
      
      java.lang.Thread t=new java.lang.Thread(bot);
      t.setPriority(java.lang.Thread.MIN_PRIORITY);
      t.start();

    }catch(Exception e){e.printStackTrace();}
  }
}




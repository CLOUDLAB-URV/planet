package ants.core;


/**
*   Important class of the ANTS client container. It is the access point to
*   the shared session (Place), user information, and Coordination Managers.
*
*
*/



public class ANTSContext
{

	private Place thePlace;
        private String theThing;
	private PolicyManager poli;



	public ANTSContext(Place thePlace, String theThing)
	{
		this.thePlace = thePlace;
                this.theThing = theThing;
	}

	public ANTSContext(Place thePlace, PolicyManager poli)
	{
		this.thePlace = thePlace;
		this.poli = poli;

	}

	/**
	*	 Method returning a reference to the shared session (Place).
	* @return ants.core.Place returns a reference to the shared session (Place)
	*/


	public Place getPlace()
	{
			return thePlace;

	}

        public String getThing() {
            return theThing;
        }

		/**
	*
	* Method returning a reference to the Policy Manager. Essential class for coordination policies.
	* @return ants.core.PolicyManager return a reference to the place Policy Manager
	*/

	public PolicyManager getManager()
	{
		return poli;
	}

		/**
	*
	* Method returning user name.
	* @return String user name
	*/


	public String getUser()
	{
		return thePlace.getUser();

	}

		/**
	*
	* Method returning user role.
	* @return String user role
	*/

	public String getRole()
	{
		return thePlace.getRole();

	}
}
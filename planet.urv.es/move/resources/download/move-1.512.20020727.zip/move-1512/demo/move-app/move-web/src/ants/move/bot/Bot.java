// Package ants.move.bot
// Bot.java
// Implementation of MOVE! Bot
// 2002 Carles Pairot & Oriol Montal� & Francesc Pi�as
package ants.move.bot;

// Notification Service imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.*;
import ants.move.core.models.avatar.PingResponder;

//java.util Package imports
import java.util.*;

//java.net Package imports
import java.net.*;

//java.io package imports
import java.io.*;


/** Implementation of MOVE! Bot.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as(fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class Bot implements Runnable {
	
	//name of the bot
	private String name;
        private String avatar;
        private Place currentPlace=null;
        private Session session;
  	private float[] currentPosition;
  	private float currentOrientation;
        private PingResponder pingThread;

/** Bot's constructor.
    @param name Bot's name
    @param avatar Bot's avatar representation
*/
public Bot(String name, String avatar)
{
	this.name = new String(name);
        this.avatar=new String(avatar);
        currentPosition=new float[3];
        currentPosition[0]=0f;
        currentPosition[1]=0f;
        currentPosition[2]=0f;

        currentOrientation=(float)Math.PI;

}

/** 
   * Sets a new position for the bot.
   * @param pos position
*/
public void setPosition(float[] pos){

        currentPosition[0]=pos[0];
        currentPosition[1]=pos[1];
        currentPosition[2]=pos[2];


}

/** 
   * Sets a new orientation for the bot.
   * @param ori orientation
*/
public void setOrientation(float ori){

        currentOrientation=ori;

}

/** 
   * Returns the current place where bot's joined.
   * @return place
*/
public Place getPlace(){
	return currentPlace;
}

/** 
   * Returns the bot's name.
   * @return name
*/
public String getName(){

	return name;
}

/** 
   * Returns the current position of bot.
   * @return position
*/
public float[] getPosition(){
	return currentPosition;
}

/** 
   * Returns the current orientation of bot.
   * @return orientation
*/
public float getOrientation(){
	return currentOrientation;
}

/** 
   * Joins bot to place.
   * @param host MOVE! host
   * @param worldKey world's key
   * @param placeKey place's key
*/
public void joinToPlace(String host, String worldKey, String placeKey) throws Exception{
      Constants.init (new URL(host));
      Properties env = new Properties();

      env.put(Constants.WORLD, worldKey);
      env.put(Constants.PLACE, placeKey);
      env.put(Constants.NSPORT, Constants.getNSPort());
      env.put(Constants.ANTSCLASS, Constants.getAntsClass());
      env.put(Constants.PLACESERVER, Constants.getPlaceGatewayRMIId());
      env.put(Constants.THINGSERVER, Constants.getThingGatewayRMIId());
      env.put(Constants.USERSERVER, Constants.getUserGatewayRMIId());
      env.put(Constants.SERVER, Constants.getServer());
      env.put("BASE",Constants.getPath());

      // Put user's name & role
      env.put(Constants.USER, name);
      env.put(Constants.ROLE, "teacher");
      session = SessionFactory.createSession (env);
      currentPlace = new Place (session, env);
      currentPlace.join();
      currentPlace.setBot();
      currentPlace.loadModels();      
      
      // Add user to place
      PlaceParser plp = new PlaceParser(currentPlace);

      // Immediately initialize ping responder class for this user
      pingThread = new PingResponder (name, currentPlace);

      Hashtable evtp = new Hashtable();
      evtp.put("CLASS", "AvatarControl");
      evtp.put("SRC", "MOVEAvatars");
      evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
      evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());

     
      evtp.put("METHOD", "newUser");
      evtp.put("USER", name);
      evtp.put("AVTREP", avatar);
      evtp.put("PX", ""+currentPosition[0]);
      evtp.put("PY", ""+currentPosition[1]);
      evtp.put("PZ", ""+currentPosition[2]);
      evtp.put("OX", ""+0.0f);
      evtp.put("OY", ""+1.0f);
      evtp.put("OZ", ""+0.0f);
      evtp.put("OA", ""+currentOrientation);

    // Send a 'newuser' event containing avatar's name, photo, position
    // and orientation, so as AvatarControl class can add it as a new
    // user
    try {
      currentPlace.send(evtp);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
}

/** 
   * Move bot from his current position to another position, in the direction of his orientation
   * @param meters number of meters to move
*/
public void move(float meters){

          double angle=(double)currentOrientation;
          
          currentPosition[0]=currentPosition[0]+meters*(float)Math.sin(angle);
          currentPosition[2]=currentPosition[2]+meters*(float)Math.cos(angle);


          Hashtable evtp = new Hashtable();
          evtp.put("CLASS", "AVATAR");
          evtp.put("SRC", "MOVE");
          evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
          evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());

          evtp.put("METHOD", "move");
          evtp.put("USER", name);
          evtp.put("PX", ""+currentPosition[0]);
          evtp.put("PY", ""+currentPosition[1]);
          evtp.put("PZ", ""+currentPosition[2]);
          evtp.put("OY", ""+1.0f);

          evtp.put("OA", ""+currentOrientation);

          // Send avatar's position and/or orientation change
          try {
                 currentPlace.send(evtp);

          }catch (Exception ex) {
            ex.printStackTrace();
          }
          

}

/** 
   * teleports bot to a new position
   * @param position new position of bot
*/
public void go(float[] position) 
{
          Hashtable evtp = new Hashtable();
          evtp.put("CLASS", "AVATAR");
          evtp.put("SRC", "MOVE");
          evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
          evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());

          evtp.put("METHOD", "move");
          evtp.put("USER", name);
          evtp.put("PX", ""+position[0]);
          evtp.put("PY", ""+position[1]);
          evtp.put("PZ", ""+position[2]);
          evtp.put("OY", ""+1.0f);

          evtp.put("OA", ""+currentOrientation);

          // Send avatar's position and/or orientation change
          try {
                 currentPlace.send(evtp);

          }catch (Exception ex) {
            ex.printStackTrace();
          }

          currentPosition[0]=position[0];
          currentPosition[1]=position[1];
          currentPosition[2]=position[2];
}

/** 
   * Bot turns to left
*/
public void turnLeft() 
{
          float radians=(float)Math.PI/2;
          currentOrientation=currentOrientation+radians;
         
          Hashtable evtp = new Hashtable();
          evtp.put("CLASS", "AVATAR");
          evtp.put("SRC", "MOVE");
          evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
          evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());

          evtp.put("METHOD", "move");
          evtp.put("USER", name);
          evtp.put("PX", ""+currentPosition[0]);
          evtp.put("PY", ""+currentPosition[1]);
          evtp.put("PZ", ""+currentPosition[2]);
          
          evtp.put("OY", ""+1.0f);
          evtp.put("OA", ""+currentOrientation);

          // Send avatar's position and/or orientation change
          try {
                 currentPlace.send(evtp);

          }catch (Exception ex) {
            ex.printStackTrace();
          }

          


}

/** 
   * Bot turns to right
*/
public void turnRight() 
{
          float radians=(float)(-Math.PI/2);
          currentOrientation=currentOrientation+radians;

          Hashtable evtp = new Hashtable();
          evtp.put("CLASS", "AVATAR");
          evtp.put("SRC", "MOVE");
          evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
          evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());

          evtp.put("METHOD", "move");
          evtp.put("USER", name);
          evtp.put("PX", ""+currentPosition[0]);
          evtp.put("PY", ""+currentPosition[1]);
          evtp.put("PZ", ""+currentPosition[2]);

          evtp.put("OY", ""+1.0f);
          evtp.put("OA", ""+currentOrientation);

          // Send avatar's position and/or orientation change
          try {
                 currentPlace.send(evtp);

          }catch (Exception ex) {
            ex.printStackTrace();
          }


}

/** 
   * Bot sleeps a number of milliseconds
   * @param millis milliseconds
*/
public void wait(int millis){
  
  try{
    Thread.sleep(millis);
  }catch(Exception e){}
}

/** 
   * Bot sends a message to all users in this place
   * @param msg message
*/
public void talk (String msg) {
    
    try {
      currentPlace.send(name + ": " + msg + "\n");
    }
    catch (SessionException s) {
      System.err.println("SessionException: Bot.talk " + s);
    }
}

/** 
   * Bot leaves the current place
*/
public void leavePlace(){

    pingThread.destroy();
      
    
    Hashtable evtkk = new Hashtable();
    evtkk.put("CLASS", "AvatarControl");
    evtkk.put("SRC", "MOVEAvatars");
    evtkk.put(ants.core.Context.WORLD, currentPlace.getWorld());
    evtkk.put(ants.core.Context.PLACE, currentPlace.getPlaceId());
    evtkk.put("USER", name);
    evtkk.put("METHOD", "delUser");
    try {
      currentPlace.send(evtkk);
    }
    catch (SessionException s) {
      System.err.println("SessionException: Sending 'delUser' (AvatarControl) event: " + s);
    }

    Hashtable evtp = new Hashtable();
    evtp.put("CLASS", "Avatar");
    evtp.put("SRC", "MOVEAvatars");
    evtp.put(ants.core.Context.WORLD, currentPlace.getWorld());
    evtp.put(ants.core.Context.PLACE, currentPlace.getPlaceId());
    evtp.put("USER", name);
    evtp.put("METHOD", "delUser");
    try {
      currentPlace.send(evtp);
    }
    catch (SessionException s) {
      System.err.println("SessionException: Sending 'delUser' (Avatar) event: " + s);
    }

  
    try {
      currentPlace.leave();
    }
    catch (Exception ss) {
      System.err.println("[MOVE] - Place already left.");
      ss.printStackTrace();
    }
    

}


public final void run() {
        ai();
}

/** 
   * Bot's artificial intelligence (all the movements of bot)
*/
public void ai() {

  //here goes the movments of the bot
}


}

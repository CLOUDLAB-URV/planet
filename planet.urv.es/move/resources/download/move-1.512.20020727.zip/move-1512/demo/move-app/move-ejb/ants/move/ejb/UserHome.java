package ants.move.ejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBHome;
import java.util.*;
/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the User Entity Bean Home interface
 */
public interface UserHome extends EJBHome {

  public User create(String login) throws CreateException,RemoteException;
  public User findByPrimaryKey (String login) throws FinderException,RemoteException;
  public Collection findByAll() throws FinderException, RemoteException;
}


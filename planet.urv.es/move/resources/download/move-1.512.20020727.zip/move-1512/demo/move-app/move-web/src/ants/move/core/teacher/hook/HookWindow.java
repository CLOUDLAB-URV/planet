// Package ants.move.core.teacher.hook
// HookWindow.java
// Implementation of Hook User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.hook;

// dynamicObjects.Hook import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.hook.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Button;
import java.awt.Panel;
import java.awt.event.ActionEvent;

import java.util.Hashtable;

/** Implementation of Hook User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.10 Build 2000
*/
public class HookWindow extends Windows implements TeacherInterface,
                                                   HookListener {
  // Button
  private Button hookButton;
  // Hook name
  private String hookName;
  private HookModel internalModel;
  private Place conn;
  private String dispName;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public HookWindow () {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Hook");
    hookName = (String) ht.get ("src");
    conn = (Place) ht.get ("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (HookModel) conn.getModel((hookName));
    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;
    window.setSize(125, 125);
    window.setLocation(624, 593);
    window.setResizable(false);
    window.setLayout(gbLayout);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 2;
    gc.gridheight = 1;
    p = new Panel();
    p.setLayout(null);
    p.setSize(70, 40);
    hookButton = new Button("Hook");
    hookButton.setBounds(7, 7, 55, 24);
    p.add(hookButton);

    gbLayout.setConstraints(p, gc);
    window.add(p);

    hookButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        hookButton_actionPerformed(e);
      }
    });

    try {
      if (internalModel.getProperty("hookBound").equals("true")) {
        hookButton.setLabel("UnHook");
      }
    }
    catch (Exception x) {
      x.printStackTrace();
    }

    internalModel.addHookListener(this);
    System.err.println ("[MOVE] - Hook control window initialized.");
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  /** hookButton's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void hookButton_actionPerformed (ActionEvent e) {
    try {
      if (internalModel.getProperty("hookBound").equals("true")) {
        internalModel.setBind(false);
      }
      else {
        internalModel.setBind(true);
      }
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Hook";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void hook (String pos, String ori) {
    hookButton.setLabel("UnHook");
  }

  public void unHook() {
    hookButton.setLabel("Hook");
  }

  public void hookPositionChanged (String value) {}
  public void hookOrientationChanged (String value) {}
}

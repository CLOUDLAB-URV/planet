package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import ants.util.Debug;

public class Sender 
{

	public static void main(String args[])
	{
		try{
			
	
		long conn1 = System.currentTimeMillis();
		Session conn = SessionFactory.createSession(args[0]);
		long conn2 = System.currentTimeMillis();
		System.out.println("CONN TIME = "+ (conn2-conn1));
			
		Hashtable evt= new Hashtable();
		evt.put("type","evt");
		evt.put("msg","sdsds");
		long send1 = System.currentTimeMillis();
		for (int i= 0;i<10000;i++)
				conn.send(evt);
		long send2 = System.currentTimeMillis();
		
		System.out.println("SEND TIME = "+ (send2-send1));

		conn.close();
		
		}catch (SessionException e){
			Debug.error(e);
		}
	
	}
	
}

package ants.comm.examples;

import ants.comm.*;
import java.util.Hashtable;
import java.io.*;

public class ObjectConsumer {
	
	
	public ObjectConsumer(String envFile)
	{
	 try
		{
			ants.comm.Session chatZone = SessionFactory.createSession(envFile);

	
			Listener1 l1 = new Listener1();
		

			Hashtable evt = new Hashtable ();
			evt.put("arg1","value1");

			chatZone.addRemoteEventListener(l1,evt);
	
			
		}catch (SessionException e1)
		{
			e1.getException().printStackTrace();
		}	
		}
	
	public class Listener1 implements RemoteEventListener
	{
		public void eventArrived(Hashtable evt)
		{
			JavaObject si = (JavaObject)evt.get("object");	
			System.out.println("event arrived !!!  " + si.getName());

		//	System.out.println("event arrived !!!  " + evt);
		}
	}
	

	public static void main(String args[])
	{
			NumConsumer tc = new NumConsumer(args[0]);
			System.out.println("Ready !  (Press CTRL+C to exit)");

			try
			{
				System.in.read();
			}catch (java.io.IOException e1){}
	}
	


	
	
}
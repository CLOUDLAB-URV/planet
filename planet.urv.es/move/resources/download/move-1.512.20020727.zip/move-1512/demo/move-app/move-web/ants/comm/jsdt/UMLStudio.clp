(UMLStudio "4.1" clipboard)
(masters 
 (master 438 1 3 "ants.comm.jms.Session
" "" "" "" "" "" 1 nil nil nil 10 0))
(drawables 0 
           (place 438 (1) "" 10 437 (179 156 347 180) (174 151 352 185) 
                  (181 156 344 179) 1 0 (nil 1 -12 32 18 12 18 18) 0))

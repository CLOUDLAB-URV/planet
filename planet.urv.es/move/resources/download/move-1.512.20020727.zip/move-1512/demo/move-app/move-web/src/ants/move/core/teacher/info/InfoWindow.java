//  2002 Oriol Montal� & Carles Pairot & Francesc Pi�as
package ants.move.core.teacher.info;

// dynamicObjects.Slides import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.info.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.net.*;


/** Implementation of Info User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2002
*/
public class InfoWindow extends Windows implements TeacherInterface{
  // Buttons
  private Button iButton;
  // Labels
  private Label iLabel;
  // Choice
  private Choice iChoice;
  // Information name
  private String iName;
  // Applet's current codeBase
  private String codeBase;
  private InfoModel internalModel;
  private Place conn;
  private String dispName;

  // All things of type Info in that place
  Vector iThings = new Vector();

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public InfoWindow() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Information: " + (String) ht.get("src"));
    iName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (InfoModel) conn.getModel(iName);
    if (internalModel == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: INFORMATION (from InfoWindow)");
    }
    codeBase = conn.getBaseURL() + "worlds/" + conn.getWorld() + "/" + conn.getPlaceId() + "/";

    // Obtain all things of type Information in that place
    iThings = conn.getThings("info.v01");


    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(210, 175);
    window.setLocation(190, 0);
    window.setResizable(false);
    window.setLayout(gbLayout);

    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(iLabel = new Label("Informations:"), gc);
    window.add(iLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(iChoice = new Choice(), gc);

    gc.gridy = 1;
    gc.gridx = 1;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(iButton = new Button("Load"), gc);
    window.add(iButton);


  // Add things to choice
  try {
    Enumeration e = iThings.elements();
    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      iChoice.addItem(th.getName());
    }
  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Info to choice"); e.printStackTrace();}

  window.add(iChoice);

    iButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        iButton_actionPerformed(e);
      }
    });


    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });

    System.err.println("[MOVE] - Info control window initialized.");
  }


  // Locks the Slides Thing onto the Slides Model
  public void lockThing (int index) {
    ants.core.Thing t = (ants.core.Thing) iThings.elementAt(index);
    internalModel.setInfoThing(t.getThingId());
    setButtonStatus (true);
   
  }

  private void setButtonStatus (boolean status) {
    iChoice.setEnabled (status);
    iButton.setEnabled (status);
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
//    super.hideWin();
  }

  public String getThingId (String thg) {
    Enumeration e = iThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getName().equalsIgnoreCase(thg)) {
        return (t.getThingId());
      }
    }
    return null;
  }

  public void slideChange (String url) { }


  /** slidesField's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void iButton_actionPerformed (ActionEvent e) {
    lockThing(iChoice.getSelectedIndex());
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Information";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }
}

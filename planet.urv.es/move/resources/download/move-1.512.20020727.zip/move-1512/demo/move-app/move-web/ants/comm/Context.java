package ants.comm;

/**
*		This interface represents a naming context, which consists of a set of name-to-object bindings
*   These constants will be used for connecting to different Notification services.
*/


public class Context
{
	
	/**
	*  Constant that holds the name of the environment property for specifying configuration information for the class factory  provider
  *  to use. (Examples are ants.comm.elvin.Session and ants.comm.jms.Session).
	*/
	
	public static final String PROVIDER_CLASS = "ants.comm.class";
	
	/**
	*  Constant that holds the name of the environment property for specifying configuration information for the service provider
  *  to use.
	*/
	public static final String PROVIDER_URL = "java.naming.provider.url";
	
/**
	*  Constant that holds the name of the environment property for specifying configuration information for the port numberof the  provider
  *  to use.
	*/

	public static final String PROVIDER_PORT = "ants.comm.port";

/**
*    Constant that holds the name of the environment property for specifying the initial context factory to use. The value of the
*    property should be the fully qualified class name of the factory class that will create an initial context. 
*    It coincides with the javax.naming.Context value for compatibility reasons. It is JMS specific.
*/
	public static final String INITIAL_CONTEXT_FACTORY = "java.naming.factory.initial";

/**
	* Constant that holds the name of the environment property for specifying the TopicConnection Factory class.
  * It is Jms specific.
  *
  */

	public static final String CONNECTION_FACTORY = "ants.comm.connectionfactory";
	
	/**
	* Constant that holds the name of the environment property for specifying the Topic name to connect to.
  * It is Jms specific.
  *
  */
	
	public static final String TOPIC = "ants.comm.topic";
	
	/**
	* Constant that holds the name of the environment property for specifying the connection type or transport protocol.
  * It is JSDT specific.
  *
  */

	public static final String CONNECTION_TYPE = "ants.comm.type";
	
	
	/**
	* Constant that holds the name of the environment property for specifying the JSDT Session name to connect to.
  * It is JSDT specific.
  *
  */
	
	public static final String SESSION_NAME = "ants.comm.session";
	
	/**
	* Constant that holds the name of the environment property for specifying the JSDT Channel name to connect to.
  * It is JSDT specific.
  *
  */
	
	public static final String CHANNEL_NAME = "ants.comm.channel";

	
}
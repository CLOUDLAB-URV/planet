// Package ants.move.core.teacher.audio
// AudioWindow.java
// Implementation of Audio User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal� & Francesc Pi�as
package ants.move.core.teacher.audio;

// dynamicObjects.Audio import
import ants.move.core.models.audio.*;
import ants.move.core.models.*;
import ants.core.*;
import ants.move.core.teacher.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/** Implementation of Audio User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.30 Build 2000
*/
public class AudioWindow extends Windows implements TeacherInterface {
  // Labels
  private Label FileLabel;
  private Label audioLabel;

  private Button loadButton;
  private Button playButton;
  private Button stopButton;
  
  private Choice audioChoice;

  // audio internal model
  private AudioModel internalModel;
  // Audio name
  private String audioName;
  private boolean URLentered = false;
  private boolean playing = false;
  private Place conn;
  private Vector audioThings = new Vector();
  private String codeBase;
  private String dispName;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public AudioWindow () {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("Audio: " + (String) ht.get("src"));
    audioName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (AudioModel) conn.getModel(audioName);

    // Obtain all things of type Slides in that place
    audioThings = conn.getThings("audio.v01");

    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;
    window.setSize(200, 175);
    window.setLocation(400, 400);
    window.setResizable(false);
    window.setLayout(gbLayout);
    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(audioLabel = new Label("Audio Name:"), gc);
    window.add(audioLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 4;
    gc.gridheight = 1;
    gbLayout.setConstraints(audioChoice = new Choice(), gc);
    p = new Panel();
    p.setLayout(null);
    p.setSize(145, 50);

    loadButton = new Button("Load");
    loadButton.setBounds(90, 0, 40, 24);
    p.add(loadButton);

    playButton = new Button("Play");
    playButton.setBounds(50, 0, 40, 24);
    p.add(playButton);
    stopButton = new Button("Stop");
    stopButton.setBounds(10, 0, 40, 24);
    p.add(stopButton);
    FileLabel = new Label("Current: < none > ");
    FileLabel.setBounds(0, 25, 144, 24);
    p.add(FileLabel);
    gc.gridy = 2;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);

    // Add things to choice
    try {
      Enumeration e = audioThings.elements();

      while (e.hasMoreElements()) {
        ants.core.Thing th = (ants.core.Thing) e.nextElement();
        audioChoice.addItem(th.getName());
      }
      if (audioChoice.countItems() == 0)  {
	loadButton.setEnabled(false);
        stopButton.setEnabled(false);
        playButton.setEnabled(false);
      }

    } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type Audio to choice"); e.printStackTrace();}

    window.add(audioChoice);

    loadButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loadButton_actionPerformed(e);
      }
    });    

    playButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        playButton_actionPerformed(e);
      }
    });

    stopButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stopButton_actionPerformed(e);
      }
    });

    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });

    // Check if there is any audio track loaded
    String thingKey = internalModel.getAudioThingId();
    if (thingKey != null) {
      if (!thingKey.equals("----")) {
        Thing t = internalModel.getAudioThing();
        if (t != null) {
          FileLabel.setText("Current: < " + t.getName() + " >");
        }
        setButtonStatus (true);
      }
    }
  
    System.err.println("[MOVE] - Audio control window initialized.");
  }


  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  private void setButtonStatus (boolean status) {
    loadButton.setEnabled (status);
    playButton.setEnabled (status);
    stopButton.setEnabled (status);
    
  }
  
  private String getAudioThingName (String thingKey) {
    Enumeration e = audioThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getThingId().equals(thingKey)) {
        return t.getName();
      }
    }
    System.err.println("Thing with ID = " + thingKey + " not found in this place!");
    return null;
  }
 
  public void loadButton_actionPerformed (ActionEvent e) {
    if (audioChoice.getItemCount() != 0) {
      ants.core.Thing t = (ants.core.Thing) audioThings.elementAt(audioChoice.getSelectedIndex());
      internalModel.setAudioThing(t.getThingId());
      loadAudio(); 
      
    }
  }

  public void playButton_actionPerformed (ActionEvent e) {
    
      internalModel.controlAudio(true);
    
    
  }

  public void stopButton_actionPerformed (ActionEvent e) {

    internalModel.controlAudio(false);

     

  }

  public void loadAudio () {
    FileLabel.setText("Current: < " + getAudioThingName(internalModel.getAudioThingId())+ " >");
  }

 
  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "Audio";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }

}



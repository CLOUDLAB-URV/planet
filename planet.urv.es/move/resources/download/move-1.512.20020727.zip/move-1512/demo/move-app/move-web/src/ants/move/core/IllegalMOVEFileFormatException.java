package ants.move.core;

public class IllegalMOVEFileFormatException extends Exception {
  public IllegalMOVEFileFormatException () {
  }
}
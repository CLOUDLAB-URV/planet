package ants.core;

import java.util.*;

/**
*		Inspired in the Constrained properties of the JavaBean component model, 
* this class contains information about a Vetoable Action. Coordination and policy managers
* will receive here the required information for vetoing the action.
*
*/


public class VetoableActionEvent
{
	private String src;
	private String userName;
	private String roleName;
	private String mode;
	private String methodName;
	private Vector params= new Vector();
	
	
	public VetoableActionEvent(String objId,String userName, String roleName,String mode, String methodName,Vector params)
	{
		this.src = objId;
		this.userName = userName;
		this.roleName = roleName;
		this.mode = mode;
		this.methodName = methodName;
		this.params = params;
	}
	
	public VetoableActionEvent(String objId,String userName, String roleName,String mode, String methodName)
	{
		this.src = objId;
		this.userName = userName;
		this.roleName = roleName;
		this.mode = mode;
		this.methodName = methodName;

		
	}

	
	/**
	*	
	* Method returning the Thing id.
	* @return java.lang.String Thing Id.
	*/

	public String getObjId()
	{
		return src;
	}

	/**
	*	
	* Method returning the user name.
	* @return java.lang.String User name.
	*/

	
	public String getUser()
	{
		return userName;
	}
	
		/**
	*	
	* Method returning the role name.
	* @return java.lang.String Role name.
	*/

	
	public String getRole()
	{
		return roleName;
	}

		/**
	*	
	* Method returning the action mode (READ or WRITE).
	* @return java.lang.String Action mode.
	*/

	
	public String getMode()
	{
		return mode;	
	}
	
		/**
	*	
	* Method returning the method name of the specified action.
	* @return java.lang.String Method name.
	*/

	
	public String getMethodName()
	{
		return methodName;
	}
	
	/**
	*	
	* Method returning the method parameter list.
	* @return java.util.Vector Parameter list.
	*/

	
	public Vector getParams()
	{
		return params;
	}

	
	
}
<%@ page session="true" import = "java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
try {
      String placeId = request.getParameter("placeId");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
      Place place=pm.getPlace(placeId);
      Thing thing=null;
      String path_directory=null;
      for( Iterator i=thm.getThingsByPlace(placeId).iterator();i.hasNext();){
        thing=(Thing)i.next();

        if(thing.getToolId().equalsIgnoreCase("s3d.v06")){
           //delete 3DSlides
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "3dslides" + File.separator +
                              thing.getId();
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
        }else if(thing.getToolId().equalsIgnoreCase("slides.v05")){
           //delete slides
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "slides" + File.separator +
                              thing.getId();
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
           Syslog.debug (this, "Slides files deleted from disk.");
        }else if(thing.getToolId().equalsIgnoreCase("video.v01")){
           //delete video
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "videos" + File.separator +
                              thing.getId() + ".avi";
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
           Syslog.debug (this, "Video file deleted from disk.");
        }
        thing.remove();
      }
      //delete place directory: .wrl ...
      path_directory = application.getRealPath("") + File.separator +
                              "worlds" + File.separator + place.getWorldId() + File.separator +
                              place.getId();
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      FileDeleter fd = new FileDeleter (path_directory);
      fd.delete();
      //Delete EJB
      place.remove();
      response.sendRedirect("listPlaces.jsp");
} catch (Exception e) {
   Syslog.error(this,"Unable to remove place"+e);
}
%>
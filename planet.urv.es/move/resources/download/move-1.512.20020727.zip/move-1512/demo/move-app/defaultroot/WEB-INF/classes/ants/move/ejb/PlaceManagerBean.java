package ants.move.ejb;



import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a Place Manager
 */

public class PlaceManagerBean implements SessionBean{

  PlaceHome placeHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/PlaceBean");
      placeHome =(PlaceHome) PortableRemoteObject.narrow(objRef,PlaceHome.class);
    }catch(Exception eC){eC.printStackTrace();}
  }
  public Collection getPlaces(String worldId){
    Collection places=new ArrayList();
    try{
      places=placeHome.findByWorld(worldId);
    }catch(Exception gwE){
        System.out.println("getPlaces("+worldId+") : "+gwE);
    }
    return places;
  }

  public Place getPlace(String id){
    Place place=null;
    try{
      place=placeHome.findByPrimaryKey(id);
    }catch(Exception gwE){System.out.println("getPlace("+id+") : "+gwE);}
    return place;
  }
  public Place createPlace(String id,String name,String type,String worldId){
    Place place=null;
    try{
      place= placeHome.create(id);
      place.setName(name);
      place.setType(type);
      place.setWorldId(worldId);

    }catch(Exception gwE){System.out.println("createPlace("+id+","+name+","+type+","+worldId+") : "+gwE);}
    return place;
  }
  public void removePlace(String id){
    Place place=null;
    try{
      place=placeHome.findByPrimaryKey(id);
      place.remove();
    }catch(Exception gwE){System.out.println("removePlace("+id+") : "+gwE);}
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
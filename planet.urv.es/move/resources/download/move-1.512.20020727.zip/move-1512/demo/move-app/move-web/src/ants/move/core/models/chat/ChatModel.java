// Package ants.move.core.models.chat
// ChatModel.java
// Implementation of DynamicObject Chat
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.chat;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.util Package import
import java.util.*;

/** Implementation of DynamicObject Chat.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.20 Build 2000
*/
public class ChatModel implements PlaceListener {
  private Place conn;
  // User name
  private String username;
  // ChatListener reference
  private ChatListener cL;
  private String clss;
  private String src;

/**
 * Sole contructor
 * @param ch place
 */
  public ChatModel (Place ch) {
//    clss = (String) env.get("CLASS");
//    src = (String) env.get("SRC");
    conn = ch;

/*    Hashtable subs = new Hashtable();
    subs.put("CLASS", clss);
*/    try {
      conn.addPlaceListener(this);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }
    username = ch.getUser();

//    conn.addPlaceListener((PlaceListener) this);
  }
/**
 * Chat listener
 * @param cList Listener
 */
  public void addChatListener (ChatListener cList) {
    this.cL = cList;
  }

  /** Remotely send message to Chat Window.
      @param msg Message to be sent
  */
  public void sendMsg (String msg) {
/*    Hashtable evtp = new Hashtable();

    evtp.put("CLASS","Chat");
    evtp.put("SRC", "ChatUsers");
    evtp.put("ACTION", "sendMessage");
    evtp.put("USERS", "ALL");
    evtp.put("MSG", msg + "\n");
*/    try {
      conn.send(username + ": " + msg + "\n");
    }
    catch (Exception s) {
      System.err.println("Exception: Chat.sendMsg " + s);
    }
  }
/**
 * Send private message
 * @param toUser Destination user
 * @param msg text
 */
  public void sendPrivateMsg (String toUser, String msg) {
/*    Hashtable evtp = new Hashtable();

    evtp.put("CLASS","Chat");
    evtp.put("SRC", "ChatUsers");
    evtp.put("ACTION", "sendMessage");
    evtp.put("USERS", toUser);
    evtp.put("MSG", "MESSAGE FROM " + username + ": " + msg + "\n");
*/
    try {
      conn.send2(toUser, "MESSAGE FROM " + username + ":  " + msg + "\n");
    }
    catch (Exception s) {
      System.err.println("Exception: Chat.sendPrivateMsg " + s);
    }
  }

  /** Get User name.
      @return User name
  */
  public String getUserName() {
    return username;
  }

  /** Get Place
      @return Place
  */
  public Place getPlace() {
    return conn;
  }
/**
 * Write "User " + u + " has left this place." in chat
 * @param u userName
 */
  public void userLeft (String u) {
    cL.writeLine("User " + u + " has left this place.\n");
  }
/**
 * Write "User " + u + " has joined this place." in chat
 * @param u userName
 */
  public void userJoined (String u) {
    cL.writeLine("User " + u + " has joined this place.\n");
  }

  public void onMessage (Hashtable ht) {
  }
/**
 * Write "Users list has been updated." in chat
 * @param u none
 */
  public void usersChanged (String u) {
    cL.writeLine("Users list has been updated.\n");
  }
  public void addThing (String thingKey){}
  public void removeThing (String thingKey){}
}

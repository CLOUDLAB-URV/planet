// Package ants.move.core.models.avatar
// AvatarMovsModel.java
// Implementation of Avatar's Common Movements Model
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.avatar;

// ANTS imports
import ants.comm.*;
import ants.core.*;

import java.awt.Button;
import java.awt.event.ActionEvent;

// java.util Package import
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Avatar's Common Movements Model.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.30 Build 2000
*/

// THIS CLASS ONLY THROWS EVENTS (PRODUCER)

public class AvatarMovsModel {
  private Place conn;
  private Vector listeners;
  private String username;
  private Button greetButton;
  private Button danceButton;
  private String clss;
  private String src;

  /** Sole & void constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public AvatarMovsModel (Place ch, Hashtable env) {
    clss = (String) env.get("CLASS");
    src = (String) env.get("SRC");
    conn = ch;
    username = (String) env.get("USER");
    greetButton = (Button) env.get("greetButton");
    danceButton = (Button) env.get("danceButton");

    listeners = new Vector();

    greetButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        greetButton_actionPerformed(e);
      }
    });

    danceButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        danceButton_actionPerformed(e);
      }
    });
  }

  public void greetButton_actionPerformed (ActionEvent e) {
    this.greet();
  }

  public void danceButton_actionPerformed (ActionEvent e) {
    this.dance();
  }

  public void greet () {
    try {
      Hashtable evtp = new Hashtable();
      evtp.put("CLASS", clss);
      evtp.put("SRC", src);
      evtp.put(ants.core.Context.WORLD, conn.getWorld());
      evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

      evtp.put("METHOD", "greet");
      evtp.put("USER", username);

      // Send wave event
      conn.send(evtp);
    } catch (SessionException sex) {
      System.err.println ("Session Exception: AvatarMovsModel.greet() " + sex);
    }
  }

    public void dance () {
    try {
      Hashtable evtp = new Hashtable();
      evtp.put("CLASS", clss);
      evtp.put("SRC", src);
      evtp.put(ants.core.Context.WORLD, conn.getWorld());
      evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

      evtp.put("METHOD", "dance");
      evtp.put("USER", username);

      // Send wave event
      conn.send(evtp);
    } catch (SessionException sex) {
      System.err.println ("Session Exception: AvatarMovsModel.greet() " + sex);
    }
  }
}
// Package ants.move.core.models.info
// infoModel.java
// Implementation of info Model
// 2002 Oriol Montal� & Carles Pairot & Francesc Pi�as

package ants.move.core.models.info;

// ANTS imports
import ants.comm.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Information Model.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class InfoModel extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  private String thingKey=null;
  private Thing thing;
  private String file="";

  /** Sole & void constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public InfoModel() {
  }

  public void init() {
    try{
      addPropertyChangeListener(this);
      String it= getProperty("infoThing");
      if(!it.equalsIgnoreCase("----")){
        loadInfo(it);
        for (int i = 0; i < listeners.size (); ++ i) {
          ((InfoListener) listeners.elementAt (i)).setInfo(getInformationFile());
        }
      }
      System.err.println("[MOVE] - Info model initialized.");
    }catch(Exception e){e.printStackTrace();}
  }

  public void addInfoListener (InfoListener iList) {
    listeners.addElement(iList);
  }

  public void removeInfoListener (InfoListener iList) {
    listeners.remove(iList);
  }

  public void setInfoThing (String thingKey) {
    try {

      setProperty ("infoThing", thingKey);

    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public void loadInfo (String thingKey) {
   try{
    if(thingKey.equalsIgnoreCase("----")){
      file="";
    }else{
      ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
      thing = new Thing();
      thing.init(ctx, super.getThingGateway());
      file=thing.getProperty("fileName");
    }
   }catch(Exception e){System.err.println("[MOVE] - Error Loading Info");e.printStackTrace();}
  }



  public String getInformationFile(){
    return(file);
  }


  /** Property change listener.
      @param evt Context
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    // Load new Info
    if (propName.equals("infoThing")) {
      loadInfo(evt.getPropValue());
      for (int i = 0; i < listeners.size (); ++ i) {
        ((InfoListener) listeners.elementAt (i)).setInfo(getInformationFile());
      }
    }

  }

  public String getType() {
    return "INFO";
  }

  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((InfoListener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}
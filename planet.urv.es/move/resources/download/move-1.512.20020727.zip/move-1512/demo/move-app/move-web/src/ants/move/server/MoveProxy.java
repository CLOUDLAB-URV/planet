package ants.move.server;

import ants.comm.*;
import java.util.*;
import java.net.*;

public class MoveProxy {
  Session session;
  Hashtable env;

  public MoveProxy() {
    try{
      env = new Hashtable();
      env.put("ants.comm.port","2917" );
      env.put("java.naming.provider.url",InetAddress.getLocalHost().getHostName());
      env.put("ants.comm.class", "ants.comm.elvin.Session");
      session = ants.comm.SessionFactory.createSession(env);
      AvatarControlProxy acp = new AvatarControlProxy(session);
    }catch(Exception ex) {}
  }

  public static void main(String[] args) {
     System.out.println("MOVE! Proxy 1.0 initialized");
     MoveProxy moveProxy1 = new MoveProxy();
  }
}
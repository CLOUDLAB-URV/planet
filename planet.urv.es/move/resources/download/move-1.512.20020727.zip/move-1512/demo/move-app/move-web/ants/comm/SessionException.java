package ants.comm;

/**
*		Wrapper Exception class to different Exceptions in Jms, Elvin, ...
*   It simply stores the incoming Exception and provides a method for obtaining the *real* exception.
*/

public class SessionException extends Exception
{
	private Exception ex;
	
	
	public SessionException(Exception ex)
	{
		super("Session Exception");
		this.ex = ex;
	}

	/**
	*		Return the Exception produces in the specific Notification service.
	* @return Exception the Esxception occured in the underlying Notificacion Service.
	*/
	
	public Exception getException()
	{
		return ex;
	}

}

package ants.core;

import java.util.*;
/**
*   Important wrapping class defining method access to the remote component facilitating
*   a remote property based mechanisms.
*
*/


public interface IThing
{
 public void setProperty(String propName, String propValue) throws java.rmi.RemoteException;

 public String getProperty(String propName) throws java.rmi.RemoteException;
 public String[] getPropertyNames() throws java.rmi.RemoteException;
 public String[] getIndexedProperty(String propName) throws java.rmi.RemoteException;
 public void setIndexedProperty(String propName,String [] values) throws java.rmi.RemoteException;
 public String getIndexedProperty(String propName,int index) throws java.rmi.RemoteException;
 public void setIndexedProperty(String propName, int index,String value) throws java.rmi.RemoteException;
 public int getIndexedPropertyLength(String propName) throws java.rmi.RemoteException;
 public String[] getIndexedPropertyNames() throws java.rmi.RemoteException;
 public void setObjectProperty(String propName,java.io.Serializable obj) throws java.rmi.RemoteException;
 public Object getObjectProperty(String propName) throws java.rmi.RemoteException;
 public String getTool() throws java.rmi.RemoteException;
 public String getSrc() throws java.rmi.RemoteException;


}
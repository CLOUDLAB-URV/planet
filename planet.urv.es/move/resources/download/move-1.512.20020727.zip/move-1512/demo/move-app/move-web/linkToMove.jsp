<%@ page session="true" import="ants.move.lang.*, ants.move.ejb.*, com.protomatter.syslog.*, ants.comm.*, ants.move.core.*,ants.core.rmi.*, java.util.*, java.net.*, java.rmi.*" %>

<%
  String worldId=(String)request.getParameter("worldId");
  String placeId=(String)request.getParameter("placeId");
  session.setAttribute("worldId",worldId);
  session.setAttribute("placeId",placeId);
  response.sendRedirect("goToMove.jsp");
%>
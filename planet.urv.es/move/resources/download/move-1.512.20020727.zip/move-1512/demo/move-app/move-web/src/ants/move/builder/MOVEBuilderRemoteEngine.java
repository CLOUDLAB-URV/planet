/**
 * MOVEBuilderRemoteEngine.java
 * Oriol Montal�, Carles Pairot '2001
 */

package ants.move.builder;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import ants.move.ejb.*;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;
import com.protomatter.syslog.*;

public class MOVEBuilderRemoteEngine extends UnicastRemoteObject
                                     implements MOVEBuilderRemote {
  // Items number
  int i = 0;

  Context initial = null;
  String path = null;
  WorldManager worldManager = null;
  ToolManager toolManager = null;
  ThingManager thingManager = null;
  PlaceManager placeManager = null;

  // Template properties: Translation of every model
  Properties templateProps;

  public MOVEBuilderRemoteEngine (Hashtable env) throws RemoteException {
    path = (String) env.get ("PATH");

    try {
      Syslog.debug (this, "Getting InitialContext reference...");
      initial = new InitialContext (env);
      Syslog.debug (this, "Looking up WorldManager...");
      Object obj = initial.lookup ("java:comp/env/WorldManagerBean");
      Syslog.debug (this, "Looking up ToolManager...");
      Object obj2 = initial.lookup ("java:comp/env/ToolManagerBean");
      Syslog.debug (this, "Looking up ThingManager...");
      Object obj3 = initial.lookup ("java:comp/env/ThingManagerBean");
      Syslog.debug (this, "Looking up PlaceManager...");
      Object obj4 = initial.lookup ("java:comp/env/PlaceManagerBean");

      Syslog.debug (this, "Creating WorldManager reference...");
      WorldManagerHome home = (WorldManagerHome)
                              PortableRemoteObject.narrow (obj, WorldManagerHome.class);
      worldManager = home.create();
      Syslog.debug (this, "WorldManager reference created.");
      Syslog.debug (this, "Creating ToolManager reference...");
      ToolManagerHome tHome = (ToolManagerHome)
                              PortableRemoteObject.narrow (obj2, ToolManagerHome.class);
      toolManager = tHome.create();
      Syslog.debug (this, "ToolManager reference created.");
      Syslog.debug (this, "Creating ThingManager reference...");
      ThingManagerHome thHome = (ThingManagerHome)
                              PortableRemoteObject.narrow (obj3, ThingManagerHome.class);
      thingManager = thHome.create();
      Syslog.debug (this, "ThingManager reference created.");
      PlaceManagerHome pHome = (PlaceManagerHome)
                              PortableRemoteObject.narrow (obj4, PlaceManagerHome.class);
      placeManager = pHome.create();
      Syslog.debug (this, "PlaceManager reference created.");

      Syslog.debug (this, "InitialContext for MOVE! Builder remote object gotten OK.");
    } catch (Exception x) {
      Syslog.error(this, x);
    }
  }

  /**
  * Method that creates the *.wrl file. It is created in directory:
  * ./move/worlds/<worldKey>/<placeKey>/<placeKey>.wrl
  */
  private void createWRL (Room hab) {
    try {
      // Create directory ./move/worlds/<worldKey>/<placeKey>/
      File f = new File (path + File.separator + "worlds" + File.separator +
                         hab.getProperty("worldKey") + File.separator + hab.getName());
      f.mkdirs();

      // Create *.wrl file
      Syslog.debug (this, "Creating VRML file: " + f + File.separator + hab.getName() + ".wrl ...");
      FileOutputStream fitxer = new FileOutputStream (f + File.separator + hab.getName()+".wrl", false);
      Syslog.debug (this, "VRML file created.");
      BufferedOutputStream Buffer = new BufferedOutputStream (fitxer);
      DataOutputStream Data = new DataOutputStream(Buffer);

      // Open 'proto.wrl' file: it contains the common sentences
      Syslog.debug (this, "Looking for 'proto.wrl' file: contains the common PROTOs ...");
      FileInputStream in = new FileInputStream (path + "/resources/util/proto.wrl");
      BufferedReader inData = new BufferedReader (new InputStreamReader(in));

      // String that will contain all of the *.wrl file
      String ROOM = new String();

      // Insert all 'proto.wrl' lines
      String line;
      while ((line = inData.readLine()) != null) {
        ROOM += line +"\n";
      }
      // Close 'proto.wrl' file
      in.close();
      inData.close();

      // Inline the file that defines the room
      ROOM = ROOM + "# ROOM " + hab.getName() +"\n";

      Item itemSelected;

      // Insert all other objects
      for (Enumeration e = hab.getItems(); e.hasMoreElements() ;) {
        itemSelected = (Item) e.nextElement();
        String url = new String (itemSelected.getName() + ".wrl");
        float[] sc = itemSelected.getScale();
        float[] rot = itemSelected.getRotation();
        float[] trans= itemSelected.getTranslation();

        // Insert all static objects (of type == thing)
        if ((itemSelected.getType()).equalsIgnoreCase ("thing")) {
          if((itemSelected.getName()).equals("main")){
            ROOM = ROOM + "# STATIC OBJECT " + itemSelected.getName() + "\nTransform{\n" +
              "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
              "     scale " + sc[0] + " " + sc[1] + " " + sc[2] + "\n" +
              "     rotation " + rot[0] + " " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
              "        children[\n" +
              "                  Inline {url \"../../../resources/things/places/"+itemSelected.getProperty("placeType")+"/" + url + "\"}  ]\n" +
              "}\n\n";
          }else{
            ROOM = ROOM + "# STATIC OBJECT " + itemSelected.getName() + "\nTransform{\n" +
              "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
              "     scale " + sc[0] + " " + sc[1] + " " + sc[2] + "\n" +
              "     rotation " + rot[0] + " " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
              "        children[\n" +
              "                  Inline {url \"../../../resources/things/" + url + "\"}  ]\n" +
              "}\n\n";
          }
        }else if ((itemSelected.getType()).equalsIgnoreCase ("link")) {
          String worldId=getWorldId(itemSelected.getProperty("world"));
          String placeId=getPlaceId(worldId,itemSelected.getProperty("place"));
          ROOM = ROOM + "# LINK " + itemSelected.getName() + "\nTransform{\n" +
            "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
            "     scale " + sc[0] + " " + sc[1] + " " + sc[2] + "\n" +
            "     rotation " + rot[0] + " " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
            "        children[\n" +
        "                     Inline {url \"../../../resources/things/link.v01.wrl\"}\n" +
            "                 Anchor{\n"+
            "                   url \"../../../linkToMove.jsp?worldId="+worldId+"&placeId="+placeId+"\"\n"+
            "                   children[\n" +
            "Transform { translation -0.55 0 0.1 children [ Shape { appearance Appearance { material Material { diffuseColor 1 0 0 } " +
            " } geometry Text { string \"World :" +itemSelected.getProperty("world")  + "\" fontStyle FontStyle { horizontal TRUE " +
            " size 0.15 } } } ] }\n"+
            "Transform { translation -0.55 -0.2 0.1 children [ Shape { appearance Appearance { material Material { diffuseColor 1 0 0 } " +
            " } geometry Text { string \"Place :" +itemSelected.getProperty("place")  + "\" fontStyle FontStyle { horizontal TRUE " +
            " size 0.15 } } } ] }\n"+
            "]}]\n"+
            "}\n\n";
        }

        // Insert all dynamic objects (models) (of type == tool)
/*        else if ((itemSelected.getType()).equalsIgnoreCase("tool")) {
          // Open the file that contains the VRML source code of the object
          // These files are located in ./move/resources/util/ and the files are called
          // 'toolKey.wrl.dobj'
          try {
            Syslog.debug (this, "Inserting thing in VRML file: " + itemSelected.getName() + "...");
            FileInputStream fileIn = new FileInputStream (path + "/resources/util/" + itemSelected.getName() + ".wrl.dobj");
            BufferedReader dataIn = new BufferedReader (new InputStreamReader (fileIn));

            // Insert the source object the correct position
            ROOM = ROOM + "# MODEL " + itemSelected.getName() + "\nTransform{\n" +
              "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
              "     scale " + sc[0] + " " + sc[1] +" " + sc[2] + "\n" +
              "     rotation " + rot[0] +" " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
              "        children[\n";
            String line2;
            while ((line2 = dataIn.readLine()) != null) {
              ROOM = ROOM + line2 + "\n";
            }
            ROOM = ROOM + "]}\n\n";  // Tancar children i Transform
            dataIn.close();
            Syslog.debug (this, "Thing " + itemSelected.getName() + " node inserted OK.");
          } catch (IOException io) {
            Syslog.debug (this, "File is inaccessible or non-existent: Skipping addition of VRML code for: " + itemSelected.getName());
          }

        }
        */
      }

      // Write file to disk
      Data.writeBytes (ROOM);

      // Close file
      Data.close();
      Buffer.close();
      fitxer.close();
    } catch (Exception wE) {
        Syslog.error (this, "Error creating VRML file.");
        Syslog.error (this, wE);
    }
  }



  /**
  * Method that stores a Static Object in move.ejb in the right place
  */
  private void setStaticObjects (Place p, Item thingSelected, String user) {
    try {
      long key = System.currentTimeMillis();
      Thing thing = thingManager.createThing(""+i+""+key,thingSelected.getName(),p.getId(),"3DObject");


      float[] t = thingSelected.getTranslation();
      String desc = new String("translation " + t[0] + " " + t[1] + " " + t[2]);
      float[] r = thingSelected.getRotation();
      desc = desc + " rotation " + r[0] + " " + r[1] + " " + r[2] + " " + r[3];
      float[] s = thingSelected.getScale();
      desc = desc + " scale " + s[0] + " " + s[1] + " " + s[2];
      thing.setDescription (desc);
      thing.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
      thing.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
      thing.setProperty("scale",""+s[0]+" "+s[1]+" "+s[2]);

      Syslog.debug (this, "Static thing added to MOVE-EJB (" + thingSelected.getName() + "): OK.");
    } catch (Exception tE) {
      Syslog.error (this, "Exception creating static thing: " + thingSelected.getName());
      Syslog.error (this, tE);
    }

  }


  /**
  * Method that stores a Links in move.ejb  in the right place
  */
  private void setLinks (Place p, Item link, String user) {
    try {
      long key = System.currentTimeMillis();
      Thing thing = thingManager.createThing(""+i+""+key,link.getName(),p.getId(),"link");

      float[] t = link.getTranslation();
      String desc = new String("translation " + t[0] + " " + t[1] + " " + t[2]);
      float[] r = link.getRotation();
      desc = desc + " rotation " + r[0] + " " + r[1] + " " + r[2] + " " + r[3];
      float[] s = link.getScale();
      desc = desc + " scale " + s[0] + " " + s[1] + " " + s[2];
      thing.setDescription (desc);
      thing.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
      thing.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
      thing.setProperty("scale",""+s[0]+" "+s[1]+" "+s[2]);
      String worldName=link.getProperty("world");
      String placeName=link.getProperty("place");
      thing.setProperty("world",worldName);
      thing.setProperty("place",placeName);

      Syslog.debug (this, "Link added to MOVE-EJB (" + link.getName() + "): OK.");
    } catch (Exception tE) {
      Syslog.error (this, "Exception creating static thing: " + link.getName());
      Syslog.error (this, tE);
    }

  }

  /**
  * Method that stores models in move.ejb. Models are things that store the status
  * of a tool in each place.
  */
   private void setDynamicObjects (Place p, Item toolSelected, String user) {

    Thing thing;

    try {
/*      for (Iterator iThings = thingManager.getThingsByPlace(p.getId()).iterator(); iThings.hasNext(); ) {
          thing = (Thing) iThings.next();
          if (thing.getToolId().equalsIgnoreCase ("model")){
            // Delete all things of type Model
            Syslog.debug (this, "Deleting existing thing from place: " + thing.getId());
            thing.remove();
          }
      }*/
      Syslog.debug (this, "creating Model (" + toolSelected.getName() + ") ");
      // Add the model to the place
      Collection c=thingManager.getThingsByPlaceAndTool(p.getId(),toolSelected.getToolId());
      int size=0;

      for(Iterator i=c.iterator();i.hasNext();){
        thing=(Thing)i.next();
        if(thing.getName().equalsIgnoreCase(toolSelected.getName())){
          size++;
        }
      }
      String key = ""+size+"_"+p.getId();
      // Add thing to MOVE-EJB Core
      String id = (new StringTokenizer (toolSelected.getName()).nextToken()) + "_" + key;
      Thing model=thingManager.createThing(id,toolSelected.getName(),p.getId(),toolSelected.getToolId());

      float[] t = toolSelected.getTranslation();
//        String desc = new String ("translation " + t[0] + " " + t[1] + " " + t[2]);
      float[] r = toolSelected.getRotation();
//        desc = desc + " rotation " + r[0] + " " + r[1] + " " + r[2] + " " + r[3];
      float[] s = toolSelected.getScale();
//        desc = desc + " scale " + s[0] + " " + s[1] + " " + s[2];
      model.setDescription ("Model from tool"+toolSelected.getName());
      model.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
      model.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
      model.setProperty("scale",""+s[0]+" "+s[1]+" "+s[2]);

      // The Model will inherit all the properties of the Tool it belongs to.
      Tool currentTool=toolManager.getTool(toolSelected.getName());
      Collection col = currentTool.getPropertyNames();
      if (!col.isEmpty()) {
          String pn;
          for (Iterator it = col.iterator(); it.hasNext(); ) {
             pn = (String) it.next();
             model.setProperty (pn, (String)currentTool.getProperty(pn));
          }
       }

/*        // The Model will inherit all the properties of the Tool it belongs to.
        Hashtable hash = toolSelected.getProperties();
        String prop;
        if (!hash.isEmpty()) {
           for (Enumeration en = hash.keys(); en.hasMoreElements(); ) {
              prop = (String) en.nextElement();
              model.setProperty (prop, (String)hash.get(prop));
           }
        }
*/
/*
      // The model is already inside this place, so only description and modification
      // date fields will be updated
      }else {
        Syslog.debug (this, "Updating Model (" + toolSelected.getName() + ") ");
        thing = thingManager.getThing (toolSelected.getProperty ("id"));
        float[] t = toolSelected.getTranslation();
        String desc = new String ("translation " + t[0] + " " + t[1] + " " + t[2]);
        float[] r = toolSelected.getRotation();
        desc = desc + " rotation " + r[0] + " " + r[1] + " " + r[2] + " " + r[3];
        float[] s = toolSelected.getScale();
        desc = desc + " scale " + s[0] + " " + s[1] + " " + s[2];
        thing.setDescription (desc);
        thing.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
        thing.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
        thing.setProperty("scale",""+s[0]+" "+s[1]+" "+s[2]);

      }
*/
      Syslog.debug (this, "Model added to MOVE-EJB (" + toolSelected.getName() + "): OK.");
    } catch (Exception dE) {
      Syslog.error(this, dE);
    }

  }



  /**
   * Method that stores the 3D Place in MOO Core and creates the *.wrl file
   */
  public synchronized String store3DPlaceInMOO (Room hab, String user) throws  IOException, RemoteException {
    Place p=placeManager.getPlace(hab.getName());
    try {

      for (Iterator iThings = thingManager.getThingsByPlace(hab.getName()).iterator(); iThings.hasNext(); ) {
          Thing thing = (Thing) iThings.next();
          if (thing.getToolId().equalsIgnoreCase ("3DObject")||
          thing.getToolId().equalsIgnoreCase ("link")||
          thing.getToolId().equalsIgnoreCase ("model")){
            // Delete all things of type 3DObject
            Syslog.debug (this, "Deleting existing thing from place: " + thing.getName());
            thing.remove();
          }

      }

      appendTools(hab);

      Item item;
      for (Enumeration e = hab.getItems(); e.hasMoreElements(); ) {
        item = (Item) e.nextElement();

        // Insert Static Objects in MOO Core
        //else
         if (item.getType().equalsIgnoreCase("thing")) {
          setStaticObjects (p, item, user);
        }

        // Insert Models in MOO Core
        else if (item.getType().equalsIgnoreCase("tool")) {
          setDynamicObjects(p, item, user);
        }
        // Insert Links in MOO Core
        else if (item.getType().equalsIgnoreCase("link")) {
          setLinks(p, item, user);
        }

      }
      i++;
    } catch(Exception e) {
      Syslog.error (this, "An exception occured while storing data in Move-EJB...");
      Syslog.error (this, e);
    }

    // Create WRL file
    createWRL (hab);

    return ("Conversion Complete.");
  }
  /**
   * Methot that includes all tools in place
   */
  private synchronized void appendTools(Room hab){
   try{

    Tool currentTool=null;
    Item it;
    Vector modelsIn=new Vector();
    Syslog.debug (this, "Append tools");
    for (Enumeration e = hab.getItems(); e.hasMoreElements();) {
      it=(Item)e.nextElement();
      if(it.getToolId()!=null){
        if (it.getToolId().equalsIgnoreCase("Model")){
          modelsIn.addElement(it.getName());
        }
      }
    }
    Syslog.debug (this, "Included tools list OK");
    for (Iterator itera = toolManager.getTools().iterator(); itera.hasNext();) {
          currentTool = (Tool)itera.next();
          if(!modelsIn.contains(currentTool.getId())){
            Item item = new Item();
            item.setToolId ("Model");
            item.setName (currentTool.getId());
            float[] t = new float[3];
            t[1] = (float) 1.0;
            t[0] = t[2] = (float) 0.0;
            item.setTranslation (t);
            item.setType ("tool");
            hab.addItem(item);
          }
     }
    Syslog.debug (this, "Append tools OK");
    } catch(Exception ex) {
        Syslog.error (this, ex);
    }

  }


  /**
   * Method that creates the 3D Place's representation automatically. Depending on the
   * place type, the environment will be different
   */
  public synchronized String create3DPlace (String worldKey, String placeKey, String userRole,
                               String userLogin, String placeType) throws RemoteException {
    Room room = new Room ("room");
    boolean create = true;
    World world = null;
    Tool currentTool=null;

    try {
      room.setName (placeKey);
      room.addProperty ("worldKey", worldKey);
      //Depenent del tipus de place hem de carregar un place o un altre
//      loadTranslationFromTemplate ("mainRoom0");
      for (Iterator itera = toolManager.getTools().iterator(); itera.hasNext();) {
          currentTool = (Tool)itera.next();
          Syslog.debug (this, "Creating model by using tool: " + currentTool.getId());
          Item item = new Item();
          item.setToolId ("Model");
          item.setName (currentTool.getId());
          float[] t = new float[3];
          t[1] = (float) 1.0;
          t[0] = t[2] = (float) 0.0;

          item.setTranslation (t);
          item.setType ("tool");
          room.addItem(item);

      }
      // En la generaci� autom�tica no posem objectes decoratius.
    } catch(Exception gP) {
        Syslog.error (this, gP);
        create = false;
    }

    if (create) {
      Item item= new Item();
      item.setName("main");
      item.addProperty("placeType",placeType);
      room.addItem(item);
      try {
        store3DPlaceInMOO (room, userLogin);
      } catch(Exception iOEx) {
        Syslog.error (this, "Unable to create VRML file.");
        Syslog.error (this, iOEx);
      }

      return("create");

    } else {
      return ("Error");
    }
  }

 /**
  * Method that loads the contents of a 3D Place into a variable of the class 'Room'
  */
  public synchronized Room load3DPlace (String worldKey, String placeKey, String userRole,
                          String userLogin, String placeType) throws RemoteException {


    Room room = new Room("room");

    room.setName (placeKey);

    try {
      Place place = placeManager.getPlace (placeKey);
      room.addProperty("worldKey", worldKey);

      Collection c = thingManager.getThingsByPlace(placeKey);
      Thing thing;

      for (Iterator itera = c.iterator(); itera.hasNext();) {
        thing = (Thing) itera.next();
        if (thing.getToolId().endsWith ("Model") ||
            thing.getToolId().equalsIgnoreCase ("3DObject") ||
            thing.getToolId().equalsIgnoreCase ("link")) {
          Item item = new Item();
          item.setName (thing.getName());
          item.setToolId (thing.getToolId());
          if((thing.getName()).equals("main"))
              item.addProperty("placeType",placeType);
          // Gets all translation, scaling and orientation factors
          String trans = thing.getProperty("translation");
          StringTokenizer stok = new StringTokenizer (trans);
          float[] t = new float[3];
          for (int tokens = 0; tokens < 3; tokens++) {
            t[tokens] = Float.valueOf (stok.nextToken()).floatValue();
          }

          String rota = thing.getProperty("rotation");
          stok = new StringTokenizer (rota);
          float[] r = new float[4];
          for (int tokens = 0; tokens <4; tokens++) {
            r[tokens] = Float.valueOf (stok.nextToken()).floatValue();
          }

          String scal = thing.getProperty("scale");
          stok = new StringTokenizer (scal);
          float[] s = new float[3];
          for (int tokens = 0; tokens < 3; tokens++) {
            s[tokens] = Float.valueOf (stok.nextToken()).floatValue();
          }
          item.setTranslation (t);
          item.setRotation (r);
          item.setScale (s);

          item.addProperty ("id", thing.getId());

          // Set the Item type
          if (thing.getToolId().endsWith("Model")) {
            item.setType ("tool");
          }
          else if (thing.getToolId().endsWith("link")) {
             item.setType("link");
             item.addProperty("world",thing.getProperty("world"));
             item.addProperty("place",thing.getProperty("place"));
             item.setToolId (item.getName());
          }else{
            item.setType ("thing");
            // Static objects need the name in this field
            item.setToolId (item.getName());
          }

          // Add this Item to the Room
          if ((thing.getToolId().endsWith("Model"))&& thing.getProperty("translation").equalsIgnoreCase("0.0 1.0 0.0")) {
            Syslog.debug (this, "Initial Model not show in builder.");
          }else{
            room.addItem (item);
          }
        }
      }
    } catch (Exception gP) {
      Syslog.error (this, "Error loading VRML place.");
      Syslog.error (this, gP);
    }


    return (room);
  }


  public synchronized Vector getWorlds() throws RemoteException {
      Vector worldsName=new Vector();
      Collection c= worldManager.getWorlds ();
      World world;
      for (Iterator itera = c.iterator(); itera.hasNext();) {
        world = (World) itera.next();
        worldsName.addElement(world.getName());
      }
      return worldsName;
  }

  public synchronized Vector getPlaces(String w) throws RemoteException {
      Vector placesName=new Vector();
      Collection c= worldManager.getWorlds ();
      World world;
      for (Iterator itera = c.iterator(); itera.hasNext();) {
        world = (World) itera.next();
        if(world.getName().equalsIgnoreCase(w)){
           Collection c2= placeManager.getPlaces (world.getId());
           Place place;
           for (Iterator itera2 = c2.iterator(); itera2.hasNext();) {
             place = (Place) itera2.next();
             placesName.addElement(place.getName());
           }
        }
      }
      return placesName;
  }

  private String getWorldId(String w){
    try{
      Collection c= worldManager.getWorlds();
      World world;
      for (Iterator itera = c.iterator(); itera.hasNext();) {
        world = (World) itera.next();
        if(world.getName().equalsIgnoreCase(w)){
           return world.getId();
        }
      }
    }catch(Exception e){Syslog.error (this, e);}
    return "";
  }

  private String getPlaceId(String wId,String p) {
    try{
      Collection c= placeManager.getPlaces(wId);
      Place place;
      for (Iterator itera = c.iterator(); itera.hasNext();) {
        place = (Place) itera.next();
        if(place.getName().equalsIgnoreCase(p)){
           return place.getId();
        }
      }
    }catch(Exception e){Syslog.error (this, e);}
    return "";
  }



/*
  private String getModelPrefix (String toolId) {
    String upperToolId = toolId.toUpperCase();
    StringTokenizer tokens = new StringTokenizer (toolId, ".");
    int length = (tokens.nextToken()).length();
    char[] aux = new char[length];

    aux[0] = upperToolId.charAt(0);

    int idx = 1;
    while (idx < length) {
      aux[idx] = toolId.charAt(idx);
      idx++;
    }

    return (new String (aux)).trim();
  }*/
}
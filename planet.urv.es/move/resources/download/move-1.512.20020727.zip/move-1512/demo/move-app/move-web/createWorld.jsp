<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels;
    LanguageUtilities lang;%>
<%
if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS&linked=true" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("createWorld")%> : </b></font></td></tr>
</table>

<table width=90%>
<form method="post">
   <tr>
    <td colspan="3">
      <b><%=labels.getString("worldName")%> : </b><input type="text" size="30" maxlength="30" name="name"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("worldDescription")%> : </b><input type="text" size="50" maxlength="50" name="description"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3">
      <b><%=labels.getString("worldType")%> : </b><input type="text" size="20" maxlength="20" name="type"><br><br>
    </td>
   </tr>
   <tr>
    <td colspan="3" align="center">
      <input type="submit" value="<%=labels.getString("create")%>"> <input type="reset" value="<%=labels.getString("reset")%>">
    </td>
   </tr>
   </form>
  </table>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>
 </HTML>
<%
}else{
 try{
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  int num=wm.getWorlds().size();
  if(num!=0){
    World w;
    for(Iterator i=wm.getWorlds().iterator();i.hasNext();){
      w=(World)i.next();
      if(w.getProperty("lastCreated").equalsIgnoreCase("true")){
        num=Integer.parseInt(w.getId().substring(1));
	num++;
        w.setProperty("lastCreated","false");
      }
    }
  }
  World world=wm.createWorld("W"+num,request.getParameter("name"),request.getParameter("type"));
  world.setDescription(request.getParameter("description"));
  world.setProperty("date",(new Date()).toGMTString());
  world.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  Collection tools=tm.getTools();
  world.setProperty("teachersize",""+tools.size());
  world.setProperty("rootsize",""+tools.size());
  world.setProperty("studentsize",""+tools.size());
  world.setProperty("lastCreated","true");
  Tool tool;
  int count=0;
  for(Iterator i=tools.iterator();i.hasNext();){
    tool=(Tool)i.next();
    world.setIndexedProperty("teacher",tool.getId(),count);
    world.setIndexedProperty("student",tool.getId(),count);
    world.setIndexedProperty("root",tool.getId(),count);
    count++;
  }
  response.sendRedirect("listWorlds.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create World");
 }
}
%>
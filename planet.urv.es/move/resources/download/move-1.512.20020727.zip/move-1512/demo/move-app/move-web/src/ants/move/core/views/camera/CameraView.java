// Package ants.move.core.views.camera
// CameraView.java
// Implementation of DynamicObject Camera
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.camera;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.camera.*;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of DynamicObject Camera.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.30 Build 2000
*/
public class CameraView extends DynamicObject implements ViewInterface,
                                                         CameraListener,
                                                         VRMLEventListener {
  // DynamicObject used to dynamically add the Camera to the scene
  private DynamicObject root;
  // Camera's VRML Node
  private Node[] auxNode;
  // NavigationInfo VRML Node
  private Node NavigationInfo;
  // VRML Scene's ProximitySensor EventIn
  private EventInSFBool PSEnabled;
  // VRML Scene's NavigationInfo EventIn
  private EventInMFString NavigationType;
  // Elvin4 session
  private Place conn;
  private CameraModel cM;
  private EventOutSFVec3f PSposition_changed;
  private EventOutSFRotation PSorientation_changed;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public CameraView() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement a dynamicObject through DObjectInterface interface.
      @param z Zone name
      @param b Reference to VRML browser
      @param n VRML Node name
      @param d Object name
      @param s Elvin4 session
      @param r Used to dynamically add VRML objects to the scene
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));

    this.conn = (Place) ht.get("place");

    cM = (CameraModel) conn.getModel(super.getName());
    if (cM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: CAMERA");
    }
    cM.addCameraListener(this);

    root = (DynamicObject) ht.get("root");
    auxNode = (super.getBrowser()).createVrmlFromString("Viewpoint {\n"+
                         	"description \"" + super.getName() + "\"\n"+
				"position " +
  			        cM.getCamPos(0) + " " +
				cM.getCamPos(1) + " " +
				cM.getCamPos(2) + "\n" +
				"orientation " +
                                cM.getCamOri(0) + " " +
				cM.getCamOri(1) + " " +
                                cM.getCamOri(2) + " " +
                                cM.getCamOri(3) + "\n" +
				"}\n");

    root.setChNodes();
    root.setaddChValue(auxNode);
    // Catch Scene's ProximitySensor
//    cM.setVRMLPS((super.getBrowser()).getNode("PS"));
    // Catch NavigationInfo Node
    NavigationInfo = (super.getBrowser()).getNode("NavInfo");
    PSEnabled = (EventInSFBool)((super.getBrowser()).getNode("PS")).getEventIn("enabled");
    NavigationType = (EventInMFString)NavigationInfo.getEventIn("type");

    VRMLZone vrmlZone = new VRMLZone();
    vrmlZone.addVRMLEventListener(this, "camera");

    PSposition_changed = (EventOutSFVec3f)(super.getBrowser().getNode("PS")).getEventOut("position_changed");
    PSorientation_changed = (EventOutSFRotation)(super.getBrowser().getNode("PS")).getEventOut("orientation_changed");
    PSposition_changed.advise(vrmlZone, "camera");
    PSorientation_changed.advise(vrmlZone, "camera");

    try {

      // Check whether camera is bound or not
      if ((cM.getProperty("cameraBound")).equals("true")) {
        this.bind(cM.getProperty("translation"), cM.getProperty("orientation"));
        ants.move.core.MOVECoreApplet mbr = (ants.move.core.MOVECoreApplet) ht.get("MOVECoreApplet");
        mbr.setNavigationAllowed(false);
      }
    } catch (Exception x) { x.printStackTrace(); }

    System.err.println ("[MOVE] - Camera VRML view initialized.");
  }

  public void bind (String pos, String ori) {
    PSEnabled.setValue(false);
    String[] NType = new String[1];
    // So pilot avatar can't move
    NType[0] = "NONE";
    NavigationType.setValue(NType);
    root.setreChValue(auxNode);
    StringTokenizer tokensPos = new StringTokenizer(pos);
    StringTokenizer tokensOri = new StringTokenizer(ori);
    auxNode = (super.getBrowser()).createVrmlFromString("Viewpoint {\n"+
                         	"description \"" + super.getName() + "\"\n"+
				"position " +
				tokensPos.nextToken() + " " +
				tokensPos.nextToken() + " " +
				tokensPos.nextToken() + "\n" +
				"orientation " +
                                tokensOri.nextToken() + " " +
				tokensOri.nextToken() + " " +
                                tokensOri.nextToken() + " " +
                                tokensOri.nextToken() + "\n" +
				"}\n");
    root.setaddChValue(auxNode);
    ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(true);
  }

  public void unBind() {
    String[] NType = new String[1];
    // Avatar will produce moves again
    NType[0] = "WALK";
    NavigationType.setValue(NType);
    ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(false);
    PSEnabled.setValue(true);
  }

  public void eventPerformed() {
    cM.setCamPos(PSposition_changed.getValue());
    cM.setCamOri(PSorientation_changed.getValue());
  }

  public CameraModel getModel() {
    return cM;
  }
}
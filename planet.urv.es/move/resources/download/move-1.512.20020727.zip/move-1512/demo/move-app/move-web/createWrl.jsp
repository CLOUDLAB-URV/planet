<%@ page import="ants.move.ejb.*, ants.move.builder.*, java.net.*, java.util.*, com.protomatter.syslog.*, java.rmi.*" %>

<%
try {
 try{
  Syslog.debug (this, "Capturing MOVE! Builder object...");
  MOVEBuilderRemote comp = (MOVEBuilderRemote) Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  Syslog.debug (this, "creating WRL...");
  String create = comp.create3DPlace ((String)session.getAttribute("worldId"),request.getParameter("placeId"),
                  "role","login",request.getParameter("placeType"));
  Syslog.debug (this, "WRL created successfully...");
 }catch(Exception ex){
  //Object not bound --> Bound object
  Hashtable env= new Hashtable();
  env.put ("PATH", (pageContext.getServletContext()).getRealPath(""));
  Syslog.debug (this, "Initializing MOVE! Builder object...");
  MOVEBuilderRemoteEngine engine = new MOVEBuilderRemoteEngine (env);
  Syslog.debug (this, "MOVE! Builder remote object initialized.");
  Syslog.debug (this, "//" + InetAddress.getLocalHost().getHostName() + ":1152/MoveBuilder");
  Naming.rebind ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder", engine);
  Syslog.debug(this, "MOVE! Builder remote object bound on rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  MOVEBuilderRemote comp = (MOVEBuilderRemote) Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  String create = comp.create3DPlace ((String)session.getAttribute("worldId"),request.getParameter("placeId"),
                  "role","login",request.getParameter("placeType"));
 }
} catch (Exception x) {
 Syslog.log (this, x);
}
response.sendRedirect("listPlaces.jsp");
%>

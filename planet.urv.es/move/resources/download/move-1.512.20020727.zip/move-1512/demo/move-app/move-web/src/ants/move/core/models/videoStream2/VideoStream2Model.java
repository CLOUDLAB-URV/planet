// Package ants.move.core.models.videoStream2
// videoStream2Model.java
// Implementation of videoStream2 Model
// 2002 Oriol Montal� & Carles Pairot & Francesc Pi�as

package ants.move.core.models.videoStream2;

// ANTS imports
import ants.comm.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Video Stream 2 Model.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class VideoStream2Model extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  private String thingKey=null;
  private Thing thing;
  private String url="";

  /** Sole & void constructor.
  */
  public VideoStream2Model() {
  }
  /**
   * Initialize Model
   */
  public void init() {
    try{
      addPropertyChangeListener(this);
      String vs= getProperty("vsThing");
      if(!vs.equalsIgnoreCase("----")){
        loadVideoStream(vs);
        for (int i = 0; i < listeners.size (); ++ i) {
          ((VideoStream2Listener) listeners.elementAt (i)).setVideoStream(getVideoStreamURL());
        }
      }
      System.err.println("[MOVE] - VideoStream2 model initialized.");
    }catch(Exception e){e.printStackTrace();}
  }
/**
 * Add VideoStream2 listener
 * @param sList Class that implements VideoStream2Listener interface
 */
  public void addVideoStream2Listener (VideoStream2Listener sList) {
    listeners.addElement(sList);
  }
/**
 * Removes VideoStream2 listener
 * @param sList Class that implements VideoStream2Listener interface
 */
  public void removeVideoStream2Listener (VideoStream2Listener sList) {
    listeners.removeElement(sList);
  }
/**
 * Set a new VideoStream2 thing in tool
 * @param thingKey Key of a new videoStream2 thing
 */
  public void setVideoStream (String thingKey) {
    try {

      setProperty ("vsThing", thingKey);

    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/*
  public String getSlidesThingId () {
    try {
      return getProperty("slidesKey");
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
*/
/*
  public Thing getSlidesThing () {
    return slidesThing;
  }
*/

  // Loads new slides set
  private void loadVideoStream (String thingKey) {
   try{
    if(thingKey.equalsIgnoreCase("----")){
      url="";
    }else{
      ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
      thing = new Thing();
      thing.init(ctx, super.getThingGateway());
      url=thing.getProperty("url");
    }
   }catch(Exception e){System.err.println("[MOVE] - Error Loading VideoStream2");e.printStackTrace();}
  }


/**
 * get VideoStream2 URL
 * @return String that contains url of videoStream2 source
 */
  public String getVideoStreamURL(){
    return(url);
  }

  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    // Load new videoStream
    if (propName.equals("vsThing")) {
      loadVideoStream(evt.getPropValue());
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoStream2Listener) listeners.elementAt (i)).setVideoStream(getVideoStreamURL());
      }
    }

  }
/**
 * Tool type
 * @return VIDEOSTREAM
 */
  public String getType() {
    return "VIDEOSTREAM";
  }
/**
 * Destroy model
 */
  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((VideoStream2Listener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}
<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang;%>
<%  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");
%>

<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES&linked=false" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("choosePlace")%> : </b></font></td></tr>
<tr>
  <td align="right">
    <FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%>:</FONT>&nbsp;
    <a href="createPlace.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue">Place</font></a>
    <%if(((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
    %>
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="configurePermissions.jsp?role=teacher"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("permission")%></font></a>
    <%}%>
    <br><br>
  </td>
</tr>
</table>


  <%
   try {
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      ToolManager tm = (ToolManager)session.getAttribute("toolManager");
      if(request.getParameter("worldId")!=null){
        session.setAttribute("worldId",request.getParameter("worldId"));
      }
      String worldId=(String)session.getAttribute("worldId");
      
      int thingsNum;
      Place place=null;

      if((pm.getPlaces(worldId).size())!=0){
         
   %>

      <table border="0" bgcolor="teal" width="90%">
         <TR>

              <TH><font color="white"><%=labels.getString("nameTH")%></TH>
              <TH><font color="white"><%=labels.getString("typeTH")%></TH>
              <TH><font color="white"><%=labels.getString("descriptionTH")%></TH>
              <TH><font color="white">Things</TH>
              <TH><font color="white"><%=labels.getString("creationTH")%></TH>
              <TH><font color="white"><%=labels.getString("createdTH")%></TH>

         </TR>
     <%
      for (Iterator i=pm.getPlaces((String)session.getAttribute("worldId")).iterator();i.hasNext();){
        place=(Place)i.next();
        thingsNum=thm.getThingsByPlaceAndTool(place.getId(),"video.v01").size() +
       		   thm.getThingsByPlaceAndTool(place.getId(),"votation.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"slides.v05").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"s3d.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"url.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"doc.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"audio.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"banner.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"info.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"object.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"videoStream.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"videoStream.v02").size();

        %>
         <TR ALIGN=CENTER bgcolor="#E6E4DD">
          <TD align="left"><a href="listThings.jsp?placeId=<%=place.getId()%>"><B><%=place.getName()%></B></A></TD><TD><%=(place.getType()).substring(0,(place.getType()).lastIndexOf("_"))%></TD><TD><%=place.getDescription()%></TD>
          <td><%=thingsNum%><TD><%=lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></TD><TD><%=place.getProperty("owner")%></TD>
          <TD bgcolor="white">
          <%
          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(place.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          %>
           <a href="removePlace.jsp?placeId=<%=place.getId()%>"><%=labels.getString("remove")%></a>
          <%
          }
          %>
	 </TD>
         </TR>


        <%
      }
    }

   } catch (Exception e) {
      Syslog.log (this, e);
   }
  %>        </table>

<br><br>


</center>
<jsp:include page="footer.jsp" flush="true"/>
</HTML>
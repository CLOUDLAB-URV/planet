
package ants.comm.examples;

import ants.comm.*;
import ants.comm.elvin.*;
import java.util.Hashtable;

public class ObjectProducer{
	
	
	public static void main(String args[])
	{
	
	 try
	 	{	
	
	  	ants.comm.Session chatZone = SessionFactory.createSession(args[0]);
			JavaObject example = new JavaObject("TONTO");
					
			Hashtable evt = new Hashtable();
			evt.put("object",example);	
			evt.put("arg1","value1");

			chatZone.send(evt);
		
		
			chatZone.close();
			
	 	}catch (SessionException ex)
		{
			ex.getException().printStackTrace();
			
		}

	}

		
}
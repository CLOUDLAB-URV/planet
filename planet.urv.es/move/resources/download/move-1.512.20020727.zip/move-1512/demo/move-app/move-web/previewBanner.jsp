<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
String worldKey=(String)session.getAttribute("worldId");
String placeKey=(String)session.getAttribute("placeId");
String thingId = request.getParameter("thingId");
String server = request.getServerName ();
int port = request.getServerPort ();
Tool tool=null;
Thing thing=null;
int index=1;


LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

try{
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  tool=tm.getTool("banner.v01");
  thing=thm.getThing(thingId);
  


} catch (Exception e) {
    Syslog.log (this, e);
}

%>
<html>
<head>
<SCRIPT LANGUAGE="JavaScript">
  var g = <%=tool.getProperty("delay")%>;
  var images = new Array();
  var j = 0;
  
  function animateBanner(){
    
    document.currentImage.src = images[j].src 
   
    j++;
    if (j == images.length )
	j = 0;
    setTimeout('animateBanner()',g);
   
  }

  
</script>
</head>
<%
String path = application.getRealPath("/worlds/"+worldKey+"/"+placeKey+"/") + thingId;
  File f = new File(path);

  File files[]=f.listFiles();

  for( int i=0 ; i<files.length ; i++){
      f=files[i];
      
 %>
      <script>

         index = <%=i%>;
                 
         images[index] = new Image();
         images[index].src = "worlds/<%=worldKey%>/<%=placeKey%>/<%=thingId%>/<%=f.getName()%>";    
      </script>
<%     
    }
%>

<body onLoad="animateBanner()">
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("previewBanner")%> : </b></font></td></tr>
</table>
<br>
<br>
<table width="500" height="200" border="3" fgcolor="black">
  <tr><td><img name="currentImage" width="500" height="200" src="worlds/<%=worldKey%>/<%=placeKey%>/<%=thingId%>/<%=files[0].getName()%>"></td></tr>
</table>
<br><br>

</center>
<jsp:include page="footer.jsp" flush="true"/>
</BODY>
</HTML>


// Package ants.move.core.views
// DynamicObject.java
// Implementation of a generic DynamicObject
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of a generic DynamicObject.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.3 Build 2000
*/
public class DynamicObject implements VRMLEventListener {
  // VRML Node name
  private String VRMLNodeName;
  // DynamicObject name
  private String objectName;
  // Reference to VRML browser
  private Browser browser;
  // Zone name
  private String zone;
  // VRML Zone
  private VRMLZone vrmlZone;
  // VRML Node
  private Node node;
  // addChildren / removeChildren EventIns
  private EventInMFNode addCh,reCh;

  /** Void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public DynamicObject() {
  }

  /** Real constructor.
      @param z Zone name
      @param b Reference to VRML browser
      @exception exceptions No exceptions thrown
  */
  public DynamicObject (String z, Browser b) {
    browser = b;
    zone = z;
  }

  /** Real constructor.
      @param z Zone name
      @param b Reference to VRML browser
      @param n VRML Node name
      @exception exceptions No exceptions thrown
  */
  public DynamicObject (String z, Browser b, String n) {
    VRMLNodeName = n;
    browser = b;
    zone = z;

    try {
      // Get VRML Node by name
      node = browser.getNode(VRMLNodeName);
    } catch (Exception e) {
        System.err.println("Node " + VRMLNodeName + " not found!!!");
    }
    // Add VRMLEventListener to this DynamicObject
    addListener();
  }

  /** Creates a new VRML Zone and 'listens' to VRML Events.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void addListener() {
    vrmlZone = new VRMLZone();
    vrmlZone.addVRMLEventListener(this, VRMLNodeName);
  }

  /** Catch VRML Node using name stored in VRMLNodeName field.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void catchNode() {
    try {
      // Get VRML Node by name
      node = browser.getNode(VRMLNodeName);
    } catch (Exception e) {
        System.err.println("Node " + VRMLNodeName + " not found!!!");
    }
    // Add VRMLEventListener to this DynamicObject
    addListener();
 }

  /** Link add/removeChildren EventIns.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setChNodes() {
    addCh = (EventInMFNode)node.getEventIn("addChildren");
    reCh = (EventInMFNode)node.getEventIn("removeChildren");
  }

  /** Set DynamicObject name.
      @param d DynamicObject name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setName (String d) {
    objectName = d;
  }

  /** Set Zone name.
      @param z Zone name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setZoneName (String z) {
    zone = z;
  }

  /** Set VRML browser.
      @param b VRML browser
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setBrowser (Browser b) {
    browser = b;
  }

  /** Set VRML Node name.
      @param n VRML Node name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setVRMLNodeName (String n) {
    VRMLNodeName = n;
  }

  /** Set addChildren field value.
      @param i Node index
      @param object VRML Node
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setaddChValue (int i, Node object) {
    addCh.set1Value(i, object);
  }

  /** Set addChildren field value.
      @param object VRML Node[]
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setaddChValue (Node[] object) {
    addCh.setValue(object);
  }

  /** Set removeChildren field value.
      @param i Node index
      @param object VRML Node
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setreChValue (int i, Node object) {
    reCh.set1Value(i, object);
  }

  /** Set removeChildren field value.
      @param object VRML Node[]
      @exception exceptions No exceptions thrown
  */
  public void setreChValue (Node[] object) {
    reCh.setValue(object);
  }

  /** Get VRML node.
      @param params None
      @return VRML node
      @exception exceptions No exceptions thrown
  */
  public Node getNode() {
    return node;
  }

  /** Get VRML Zone.
      @param params None
      @return VRML Zone
      @exception exceptions No exceptions thrown
  */
  public VRMLZone getZone() {
    return vrmlZone;
  }

  /** Get Zone name.
      @param params None
      @return Zone name
      @exception exceptions No exceptions thrown
  */
  public String getZoneName() {
    return zone;
  }

  /** Get VRML browser.
      @param params None
      @return VRML browser
      @exception exceptions No exceptions thrown
  */
  public Browser getBrowser() {
    return browser;
  }

  /** Get VRML Node name.
      @param params None
      @return VRML Node name
      @exception exceptions No exceptions thrown
  */
  public String getVRMLNodeName() {
    return VRMLNodeName;
  }

  /** Get DynamicObject name.
      @param params None
      @return DynamicObject name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return objectName;
  }

  /** Executed when a VRML Event is received. Not used here.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventPerformed() {
  }

  public void printMsg (String msg) {
    System.err.println ("[MOVE] - " + msg);
  }

}

// Package ants.move.core.views.link
// LinkManager.java
// Manages all links in the VRML Scene
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.link;

// VRML Scene imports
import vrml.external.Browser;

// java.util Package import
import java.util.Properties;

// MOVEBrowser applet import
import ants.move.core.MOVECoreApplet;

/** Manages all links in the VRML Scene.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public class LinkManager {

  /** Sole constructor.
      @param b Reference to VRML browser
      @param z Zone name
      @param p Information about links
      @param w MUWorld applet reference
      @exception exceptions No exceptions thrown
  */
  public LinkManager (Browser b, String z, Properties p, MOVECoreApplet mbr) {
    Properties props = p;

    for (int i = 1; i <= Integer.parseInt(props.getProperty("links")) ; i++) {
      Link l = new Link(z, b, props.getProperty("link" + i), mbr);
    }
  }
}
// Package ants.move.core.models.chat
// ChatListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.chat;

/** ChatListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface ChatListener {
/**
 * Write new text line in chat
 * @param msg text
 */
  public void writeLine (String msg);
}
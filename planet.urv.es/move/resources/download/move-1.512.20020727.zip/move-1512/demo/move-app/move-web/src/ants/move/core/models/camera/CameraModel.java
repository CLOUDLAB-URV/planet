package ants.move.core.models.camera;

import ants.core.*;
import java.util.*;

/** Implementation of DynamicObject Camera.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.20 Build 2000
*/
public class CameraModel extends Thing implements PropertyChangeListener {

  // Camera position
  private float[] CamPos;
  // Camera orientation
  private float[] CamOri;
  // Listeners vector
  private Vector listeners = new Vector();
  private boolean iHaveBound = false;
/**
 * Void constructor
 */
  public CameraModel () {
  }
/**
 * Initialize model
 */
  public void init() {
    addPropertyChangeListener (this);
    CamPos = new float[3];
    CamOri = new float[4];

    // Get hook viewpoint position and orientation
    try {
      String p = getProperty("translation");
      String o = getProperty("rotation");

      StringTokenizer tokens = new StringTokenizer(p);
      CamPos[0] = (new Float(tokens.nextToken()).floatValue());
      CamPos[1] = (new Float(tokens.nextToken()).floatValue());
      CamPos[2] = (new Float(tokens.nextToken()).floatValue());

      tokens = new StringTokenizer(o);
      CamOri[0] = (new Float(tokens.nextToken()).floatValue());
      CamOri[1] = (new Float(tokens.nextToken()).floatValue());
      CamOri[2] = (new Float(tokens.nextToken()).floatValue());
      CamOri[3] = (new Float(tokens.nextToken()).floatValue());
    }
    catch (Exception x) {
      System.err.println("Exception capturing translation & orientation properties of thing Camera");
    }
    System.err.println("[MOVE] - Camera model initialized.");
  }
/**
 * Add new cameraListener
 * @param cList Listener
 */
  public void addCameraListener (CameraListener cList) {
    listeners.addElement(cList);
  }
/**
 * Remove Cameralistener
 * @param cList listener
 */
  public void removeCameraListener (CameraListener cList) {
    listeners.removeElement(cList);
  }
/**
 * Lock camera position
 */
  public void lockPosition () {
    try {
      setProperty ("translation", "" + CamPos[0] + " " + CamPos[1] + " " + CamPos[2]);
      setProperty ("rotation", "" + CamOri[0] + " " + CamOri[1] + " " + CamOri[2] + " " + CamOri[3]);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Remotely Bind / Unbind Camera's Viewpoint.
      @param value True if camera has to be bound
  */
  public void setBind (boolean value) {
    try {
      // Bind
      if (value) {
        iHaveBound = true;
        setProperty ("cameraBound", "true");
      }
      // Unbind
      else {
        iHaveBound = false;
        setProperty ("cameraBound", "false");
      }
    } catch (Exception e) {
      System.err.println("Exception changing cameraBound property! (method CameraModel.setBind)");
      e.printStackTrace();
    }
  }
/**
 * Get Bound
 * @return Return if camera is bound "true" or "false"
 */
  public String getBound () {
    try {
      return getProperty("cameraBound");
    }
    catch (Exception x) {
      x.printStackTrace();
      return null;
    }
  }

  public void propertyChange (PropertyChangeEvent evt) {
    // Bind Camera's Viewpoint
    if (evt.getPropName().equals("cameraBound")) {
      Vector listeners = (Vector) this.listeners.clone ();
      if (evt.getPropValue().equals("true")) {
        for (int i = 0; i < listeners.size (); ++ i) {
          try {
            StringTokenizer tokensP = new StringTokenizer (getProperty("translation"));
            StringTokenizer tokensO = new StringTokenizer (getProperty("rotation"));
            String pos = "" + tokensP.nextToken() + " " + tokensP.nextToken() + " " + tokensP.nextToken();
            String ori = "" + tokensO.nextToken() + " " + tokensO.nextToken() + " " + tokensO.nextToken() + " " + tokensO.nextToken();
            ((CameraListener) listeners.elementAt (i)).bind (pos, ori);
          } catch (Exception x) {
            x.printStackTrace();
          }
        }
      }
      else {    // Unbind Camera's Viewpoint
        for (int i = 0; i < listeners.size (); ++ i) {
          ((CameraListener) listeners.elementAt (i)).unBind();
        }
      }
    }
  }

  /** Get Camera position given an index coordinate.
      @param index Coordinate
      @return Camera's position on that coordinate
  */
  public float getCamPos(int index) {
    return (CamPos[index]);
  }

  /** Get Camera orientation given an index coordinate.
      @param index Coordinate
      @return Camera's orientation on that coordinate
  */
  public float getCamOri(int index) {
    return (CamOri[index]);
  }

  /** Set Camera position.
      @param value Camera's new position
  */
  public void setCamPos(float[] value) {
    CamPos = value;
  }

  /** Set Camera orientation.
      @param value Camera's new orientation
  */
  public void setCamOri(float[] value) {
    CamOri = value;
  }
/**
 * Tool type
 * @return CAMERA
 */
  public String getType() {
    return "CAMERA";
  }
/**
 * Destroy method
 */
  public void destroy() {
    // When place is left, camera should be unbound (only if I have bound others)
    try {
      if ((getProperty("cameraBound")).equals("true") && iHaveBound) {
        setBind(false);
      }
//      removePropertyChangeListener (this);
      super.destroy();
    } catch (Exception ex) {
      System.err.println("Exception while destroying CameraModel: ");
      ex.printStackTrace();
    }
  }
}

package ants.comm.jsdt;

import com.sun.media.jsdt.*;

public class ServerRun
{

    private static String sessionName = "VRMLSession";

    public static void main(String args[]) 
    {
    CreateClient client      = null;
		com.sun.media.jsdt.Session    VRMLSession = null;
		//jsdt1.5:
		//String     url         = null;
		URLString  url = null;
		//
		
		String     sessionType = null;
		String     hostname    = null;
		int        hostport    = 0;


    hostname    = getHost(args);
  //  System.out.println(hostname);
		hostport    = getPort(args);
		sessionType = getType(args);
		com.sun.media.jsdt.impl.JSDTObject.showMessage = true;
    com.sun.media.jsdt.impl.JSDTObject.showStack   = true;
		String urlAux="jsdt://"+hostname+":"+hostport+"/"+sessionType+"/Session/"+sessionName;
	//	System.out.println(urlAux);
		//jsdt1.5:
		//url="jsdt://"+hostname+":"+hostport+"/"+sessionType+"/Session/"+sessionName;
		url=URLString.createSessionURL(hostname,hostport,sessionType,sessionName);
		//
	//	System.out.println(url.toString());

		try 
		{
	//		System.err.println("Starting server");
			com.sun.media.jsdt.impl.JSDTObject.timeoutPeriod = 30000;

			/* Registry running?  Start it if it isn't. */
		    if (RegistryFactory.registryExists(sessionType) == false) 
		    {
		//		System.out.println("Registry doesn't exist\n");
				RegistryFactory.startRegistry(sessionType);
				System.out.println("Registry created\n");
	    	}
	    	else
	    		System.out.println("Registry exists\n");

			/* Create a session, [re]bind it and create a channel. */
 
	    	client = new CreateClient("Server");
	    	VRMLSession = SessionFactory.createSession(client, url, false);
	   // 	System.err.println("Session created\n");
	    	//System.out.println(VRMLSession.toString());
          
	  	VRMLSession.createChannel(client, "slidesChannel", true, true, false);
	  //	System.err.println("Slides channel created");

			VRMLSession.createChannel(client,"barrasChannel",true,true,false);
	//		System.err.println("Bars channel created");

  		VRMLSession.createChannel(client,"pasilloChannel",true,true,false);
		//	System.err.println("Corridor channel created");
			
			VRMLSession.createChannel(client,"teleChannel",true,true,false);
		//	System.err.println("TV channel created");

		//	System.err.println("Setup and bound VRML server.");
			System.out.println("Connected to JSDT");

        } 
        catch (Exception e) 
        {
            System.err.println("Excepci�n en Server: " + e+"\n");
            e.printStackTrace();
	    }
    }



    private static String getHost(String args[]) 
    {
        String defHost = "stard";   /* Default host name for connections. */
        int length = args.length;

        for (int i = 0; i < length; i++) 
        {
            if (args[i].equals("-server")) 
            {
                if (++i < length) 
                {
                    return(args[i]);
                }
            }
        }
        return(defHost);
    }


    private static int getPort(String args[]) 
    {
        int defPort = 4461;   /* Default port number for connections. */
        int length = args.length;

        for (int i = 0; i < length; i++) 
        {
            if (args[i].equals("-port")) 
            {
                if (++i < length) 
                {
                    return(Integer.parseInt(args[i]));
                }
            }    
        }
        return(defPort);
    }


    private static String getType(String args[]) 
    {
        String defType = "socket";   /* Default Session type. */
        int length = args.length;

        for (int i = 0; i < length; i++) 
        {
            if (args[i].equals("-type")) 
            {
                if (++i < length) 
                {
                    return(args[i]);
                }
            }    
        }
        return(defType);
    }
}
// Package ants.move.core.models.banner
// BannerModel.java
// Implementation of banner Model
// 2002 Francesc Pi�as & Oriol Montal�
package ants.move.core.models.banner;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.io Package imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of banner Model.
    @author Francesc Pi�as (fpd@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2002
*/
public class BannerModel extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  // Vector containing all images of the banner
  private Vector pictures;
  private int index=-1;
  private Thing bannerThing=null;
  private BannerEngine bE=null;

  /** Sole & void constructor.
  */
  public BannerModel() {
  }
/**
 * Initialize model
 */
  public void init() {
   try{
    addPropertyChangeListener(this);
    bE = new BannerEngine();
    Hashtable ht = new Hashtable();
    ht.put("model",this);
    bE.init(ht);
    bE.setPriority(Thread.MIN_PRIORITY);

    String bk= getProperty("bannerKey");

    if(!bk.equalsIgnoreCase("----")){


       this.loadBanner(bk);
    }
    System.err.println("[MOVE] - Banner model initialized.");
   }catch(Exception e){e.printStackTrace();}
  }
/**
 * Add banner listener
 * @param bList listener
 */
  public void addBannerListener (BannerListener bList) {
    listeners.addElement(bList);
  }
/**
 * Remove banner listener
 * @param bList listener
 */
  public void removeBannerListener (BannerListener bList) {
    listeners.removeElement(bList);
  }
/**
 * Set Banner thing in tool
 * @param thingKey key
 */
  public void setBannerThing (String thingKey) {
    try {
      setProperty ("bannerKey", thingKey);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * get banner key
 * @return key
 */
  public String getBannerThingId () {
    try {
      return getProperty("bannerKey");
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
/**
 * get banner thing
 * @return thing instance
 */
  public Thing getBannerThing () {
    return bannerThing;
  }



  // Loads new banner
  public void loadBanner (String thingKey) {

    ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
    bannerThing = new Thing();
    bannerThing.init(ctx, super.getThingGateway());
    int size = 0;
    try {
      size = Integer.parseInt(bannerThing.getProperty("bannerSize"));
      pictures = new Vector();
      for (int i = 1; i <= size; i++) {
        pictures.addElement(bannerThing.getIndexedProperty("images", i));
      }
      System.err.println("[MOVE] - New Banner loaded.");
      index=0;

    } catch (Exception ex) {
      System.err.println ("Exception getting IndexedProperties: ");
      ex.printStackTrace();
    }


       bE.start();



  }
/**
 * Update banner image
 * @param image image source
 */
  public void updateBanner(String image){

      for (int i = 0; i < listeners.size (); ++ i) {
        ((BannerListener) listeners.elementAt (i)).setImage(image);
      }
  }

  /** Remotely go to next image of banner.
  */
  public void nextImage() {
    if (pictures != null) {
        index++;
        if(index>=pictures.size()){
          index=0;
        }

     updateBanner(getImage());
    }
  }

/**
 * Get banner image url
 * @return image source url
 */
  public String getImage(){
   if(index== -1){
    return "";
   }else{
    return((String)pictures.elementAt(index));
   }
  }

  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    // Load new banner
    if (propName.equals("bannerKey")) {
      loadBanner(evt.getPropValue());

    }
  }
/**
 * Tool type
 * @return BANNER
 */
  public String getType() {
    return "BANNER";
  }
/**
 * Destroy method
 */
  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((BannerListener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}
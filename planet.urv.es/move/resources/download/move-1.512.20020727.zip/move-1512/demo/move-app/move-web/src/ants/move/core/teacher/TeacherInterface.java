// Package ants.move.core.teacher
// TeacherInterface.java
// Teacher dynamic interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher;

import ants.move.core.models.*;
import java.util.Hashtable;

/** DObjectsUI dynamic interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.1 Build 2000
*/
public interface TeacherInterface {
  /** Initializes necessary parameters to use this class.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht);

  /** Show window.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void showWin();

  /** Hide window.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void hideWin();

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType();

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName();

  /** Get if Window is visible.
      @param params None
      @return True if Window is visible
      @exception exceptions No exceptions thrown
  */
  public boolean isVisible();
}
// Package ants.move.core.models.hook
// HookListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.hook;

/** HookListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface HookListener {
/**
 * Hook
 * @param pos position "x y z"
 * @param ori rotation "x y z o"
 */
  public void hook (String pos, String ori);
  /**
   * Unhook
   */
  public void unHook();
  /**
   * Change hook position
   * @param value position "x y z"
   */
  public void hookPositionChanged (String value);
  /**
   * Change hook orientation
   * @param value rotation "x y z o"
   */
  public void hookOrientationChanged (String value);
}
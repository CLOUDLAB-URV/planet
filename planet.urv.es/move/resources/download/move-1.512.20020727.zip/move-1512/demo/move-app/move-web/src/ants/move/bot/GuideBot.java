package ants.move.bot;

import ants.core.*;
import ants.move.core.models.slides.*;
import ants.move.core.models.audio.*;
import ants.move.core.models.voter.*;


public class GuideBot extends Bot {

	public GuideBot(String name, String avatar)
        {
           super(name,avatar);
        }




        public void ai()
        {
         Place p=getPlace();
         SlidesModel sM=(SlidesModel)(p.getModel("slides.v05_0_W0_P0"));
         AudioModel aM=(AudioModel)(p.getModel("audio.v01_0_W0_P0"));
         VoterModel vM=(VoterModel)(p.getModel("votation.v01_0_W0_P0"));
         vM.loadVotation("1029336546425");
         VoterThing vT=vM.getVoterThing();
         
         
         try {
      
            
            turnLeft();
            wait(200);
            move(0.4f);                  
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);                
            move(0.4f);               
            wait(200);                
            turnRight();

            talk("Benvinguts al MOVE!, Multiuser Oriented virtual Enviroments\n");
            wait(7000);
            talk("S�c el robot guia que us ensenyar� com" +
               "n'�s de f�cil la utilitzaci� de les eines que" +
               "ens ofereix MOVE!. El meu prop�sit es que us familiaritzeu"+
               "amb l'entorn on ens trobem i comenceu a aprendre a usar les"+
               "eines que tenim a la nostra disposici� dins d'aquest place.\n");
            wait(10000);
            talk("Si us sembla comen�arem per l'eina TRANSP�RENCIES.\n");
            wait(5000);            
            turnLeft();
            wait(200);
            turnLeft();
            
            wait(200);
            move(0.4f);
            wait(200);
            move(0.4f);
            wait(200);
            move(0.4f);
            wait(200);
            move(0.4f);
            wait(200);
            turnRight();
            wait(200);
            turnRight();  
            wait(5000);
            talk("Com podeu veure ja tenim un conjunt de transper�ncies carregat.\n");
            wait(5000);
            talk("Passem a la seg�ent transper�ncia doncs!.\n");
            wait(4000);
            turnLeft();
            wait(200);
            turnLeft();
            wait(4000);
            sM.nextPicture();
            wait(5000);
            turnRight();
            wait(200);
            turnRight();  
            wait(4000);
            talk("Com podeu veure la pantalla de transpar�ncies ha canviat.\n");
            wait(4000);
            talk("Vinga!!, passem a una altra transper�ncia!\n");
            wait(4000);
            turnLeft();
            wait(200);
            turnLeft();
            wait(4000);
            sM.nextPicture();
            wait(5000);
            turnRight();
            wait(200);
            turnRight();  
            wait(5000);
            talk("Com podeu veure es tracta d'una eina molt util i senzilla d'usar.\n");
            wait(6000);
            talk("Una altra eina interessant es la AUDIO.\n");
            wait(6000);
            talk("Anem a examinar-la de m�s a prop.\n");
            move(0.4f);
            wait(200);
            move(0.4f);
            wait(200);
            turnLeft();
            wait(200);
            move(0.4f);
            wait(200);
            move(0.4f);
            wait(200);
            turnRight();
            wait(4000);
            talk("Amb aquesta eina es poden pujar pistes d'audio al MOVE!"+
                 "i escoltar-les dins al place com a so 3D.\n");
            wait(6000);
            talk("Perfecte, ja hi ha una pista d'audio carregada.\n");
            wait(6000);
            talk("Escoltem, doncs, el nostre himne.\n");
            aM.controlAudio(true);
            wait(12000);
            talk("Fant�stic!!. Com podeu escoltar el so �s 3D.\n");
            talk("Aix� fa que tinguem la sensaci� de que realment ens trobem dins el place.\n");
            wait(6000);
            talk("B�, ja n'hi ha prou.\n");
            aM.controlAudio(false);
            wait(6000);
            talk("B�, acabar� aquesta petita simulaci� mostrant-vos una de les altres eines interessants.\n");
            talk("L'eina VOTACI�.\n");
            wait(6000);
            turnRight();
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            turnLeft();
            wait(4000);
            talk("Com podeu observar ja hi ha una votaci� carregada.\n");
	    wait(4000);
            talk("El tema d'aquesta votaci� �s: \n");
            wait(4000);
            talk("La votaci� consta de 3 barres, cada una de les quals indica el nombre de vots"+
                 " que porta acumulats.\n");
            wait(6000);
            talk("Podrem votar a favor(SI), en contra(NO) o en blanc(NsNc).\n");
            wait(5000);
            talk("Per tal que vegeu com funciona, donar� la meva votaci�.\n");
            wait(5000);
            talk("Permeteu-me que voti en blanc, per temor a represalies.\n");
            wait(5000);
            talk("El meu vot �s per al NSNC!!.\n");
            vT.voteUnknown();
            wait(6000);
            talk("Mireu com han variat les barres degut a la meva votaci�.\n");
            wait(5000);
            talk("Cal que us recordi que solament podeu votar una sola vegada, "+
                 "aix� que no intenteu passar-vos de llestos.\n");
            wait(6000);
            turnLeft();
            wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            move(0.4f);
	    wait(200);
            turnRight();
            wait(4000); 
            talk("B�, la meva participaci� acaba aqui.\n");
            wait(4000);            
            talk("Espero veure'ls de nou en una altra simulaci�!!!!\n");
            wait(4000);
            leavePlace();
	
      
	}catch(Exception e){}
      
     }
}
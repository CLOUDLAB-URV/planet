package ants.core.rmi;

import ants.core.*;
import ants.comm.*;
import ants.move.ejb.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;
import com.protomatter.syslog.*;


public class PlaceGatewayImpl extends UnicastRemoteObject implements PlaceGateway {
    private ants.move.ejb.Place currentPlace = null;
    private ants.move.ejb.Thing currentThing = null;
    private javax.naming.Context initial = null;
    private PlaceManager placeManager = null;
    private ThingManager thingManager = null;
    private ToolManager toolManager = null;

    public PlaceGatewayImpl (Hashtable env) throws java.rmi.RemoteException {

      try {
        Syslog.debug (this, "Getting InitialContext reference...");
        initial = new InitialContext(env);
        Object obj = initial.lookup ("java:comp/env/PlaceManagerBean");
        PlaceManagerHome home = (PlaceManagerHome) PortableRemoteObject.narrow(obj, PlaceManagerHome.class);
        placeManager = home.create();
        obj = initial.lookup ("java:comp/env/ThingManagerBean");
        ThingManagerHome thingHome = (ThingManagerHome) PortableRemoteObject.narrow(obj, ThingManagerHome.class);
        thingManager = thingHome.create();
        Object obj2 = initial.lookup ("java:comp/env/ToolManagerBean");
        ToolManagerHome tHome = (ToolManagerHome)PortableRemoteObject.narrow (obj2, ToolManagerHome.class);
        toolManager = tHome.create();
        Syslog.debug (this, "InitialContext for ants.core.rmi.ThingGateway remote object gotten OK.");
      } catch (Exception x) {
        Syslog.error(this, x);
      }

    }


    public Vector getThings (String pKey, String toolKey) throws java.rmi.RemoteException {

      Vector v = new Vector();
      try {
        Collection c = thingManager.getThingsByPlaceAndTool(pKey,toolKey);
        Syslog.debug(this, "Things in place " + pKey + " gotten OK.");
        Iterator i = c.iterator();
        while (i.hasNext()) {
          currentThing = (ants.move.ejb.Thing) i.next();
          v.addElement(currentThing.getId());
        }
      } catch (Exception d) {
            Syslog.debug (this, "Exception in getThings() returning NULL!!");
            Syslog.log (this, d);
            return null;
      }
      return v;
    }

    private boolean toolIsActiveInPlace (String pKey,String toolKey) {
      try {
        currentPlace=placeManager.getPlace(pKey);
        String status=currentPlace.getProperty(toolKey);
        if(status.equalsIgnoreCase("active")){
          return true;
        }else{
          return false;   // Tool is not active
        }
      } catch (Exception ex) {
        Syslog.debug(this, "Exception getting active tools from place.");
        Syslog.log(this, ex);
        return false;
      }
    }

    public Hashtable loadModels (String pKey) throws java.rmi.RemoteException {


      Hashtable models = new Hashtable();


      try {
        for(Iterator i=thingManager.getThingsByPlaceAndTool(pKey,"Model").iterator();i.hasNext();){
          ants.move.ejb.Thing thing = (ants.move.ejb.Thing) i.next();
          String toolId = thing.getName();
          Syslog.debug (this, "Tool Id = " + toolId);
          try {
            ants.move.ejb.Tool tool = toolManager.getTool(toolId);
            if (this.toolIsActiveInPlace (pKey,toolId)) {
              String modelId = tool.getProperty("model");
              // Initialize the model if this object has it
              if (!(modelId.equals("----"))) {
                Syslog.debug (this, "Model class to be loaded: " + modelId);
                Model obj = (Model) Class.forName (modelId).newInstance();
                Vector modelInfo = new Vector();

                // Add model identifier
                modelInfo.addElement (modelId);
                // Add thing model id
                modelInfo.addElement (thing.getId());
                Syslog.debug (this, "Model Id: " + thing.getId());
                // Add model thing type
                modelInfo.addElement (tool.getType());
                Syslog.debug (this, "Model thing Type: " + tool.getType());
                // Add model display name
                modelInfo.addElement (tool.getName());
                Syslog.debug (this, "Model name: " + tool.getName());
                // Add teacher property
                modelInfo.addElement(tool.getProperty("teacher"));

                // Add VRML property
                modelInfo.addElement(tool.getProperty("VRML"));

                // Add node property
                modelInfo.addElement(tool.getProperty("node"));


                models.put (modelInfo, obj);
              }
              else {  // If the object has no model, put a String instead of a Model
                      // This will throw a java.lang.ClassCastException that will be
                      // caught in Runtime

                Vector modelInfo = new Vector();

                // Add model identifier
                modelInfo.addElement (modelId);
                // Add tool id
                modelInfo.addElement (thing.getId());
                // Add model thing type
                modelInfo.addElement (tool.getType());
                // Add model display name
                modelInfo.addElement (tool.getName());

                models.put (modelInfo, new String(""));
              }
            }
            else {
              Syslog.debug(this, "Tool " + toolId + " is not active in this place.");
            }
          } catch (Exception tnf) {
            Syslog.debug(this, "Tool " + toolId + " has been deactivated:"+tnf);
          }
        }

      } catch (Exception ex) {
          Syslog.log(this, ex);
      }

      return models;
    }

}
package ants.core;

import java.util.*;
import ants.comm.*;
import ants.util.Debug;

public class PlaceCommand
{
	private Place model;

	public PlaceCommand(Place model)
	{

		this.model = model;
	}

	public String parseCommand(String command)
	{
		StringTokenizer tokens = new StringTokenizer(command);
		String cmd = tokens.nextToken();

		if (cmd.equals("who"))
				return getUsers();
		else
		{

			try{
				model.send2Others(command);

			}catch(SessionException ex){
				Debug.error(ex.getException());
			}


			return "";
		}


	}

	public String getUsers()
	{
//		try
//		{

// MALAMENT:
Vector list = new Vector();

//			Vector  list= (Vector)model.getUsers().clone ();
			StringBuffer buf= new StringBuffer();
			buf.append("Online users: \n");

			for (int i = 0; i < list.size (); ++ i) {
        String user = (String)list.elementAt (i);
				buf.append(user+"\n");
			}
			return buf.toString();
/*		}catch(ants.comm.SessionException ex)
		{

				return "not possible";

		}
*/
	}

}
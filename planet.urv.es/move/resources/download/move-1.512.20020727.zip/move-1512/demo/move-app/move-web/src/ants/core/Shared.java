
package ants.core;

import ants.comm.*;
import java.util.*;

public interface Shared 
{
	
	
	public void join() throws SessionException;
	public void leave() throws SessionException;
	public void send(String  msg) throws SessionException;
	public void send(Hashtable evt) throws SessionException;
	public void send2(String user,String msg) throws SessionException;
	public void send2(String user,Hashtable evt) throws SessionException;
	public void addPlaceListener(PlaceListener cl) throws SessionException;
	public void removePlaceListener(PlaceListener cl) throws SessionException;
	public String getUser();
	public String getPlaceName();
	
	
}
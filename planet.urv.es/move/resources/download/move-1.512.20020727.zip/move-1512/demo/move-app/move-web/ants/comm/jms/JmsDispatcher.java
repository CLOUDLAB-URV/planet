package ants.comm.jms;

import java.util.Hashtable;
import ants.comm.*;
import ants.util.*;
import javax.jms.*;

public class JmsDispatcher extends Thread
{
	private RemoteEventListener caller;
	private Message event;
	
	public JmsDispatcher(RemoteEventListener caller, Message msg)
	{
		this.caller = caller;
		this.event = msg;
	}
	

	
	public void run()
	{
	try
		{
		caller.eventArrived(JmsParser.getEvt(event));	
	}catch (JMSException ex){Debug.error(ex);}	
	}
	
	
}
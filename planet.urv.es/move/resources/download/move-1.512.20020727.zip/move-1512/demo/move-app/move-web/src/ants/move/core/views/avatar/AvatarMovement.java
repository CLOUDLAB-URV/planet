// Package ants.move.core.views.avatar
// AvatarMovement.java
// Avatar Movement class
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views.avatar;

// java.util Package import
import java.util.Vector;

/** Avatar Movement class.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.2 Build 2000
*/
public class AvatarMovement extends Thread {
  // Current thread
//  private Thread thread;
  // Movements Vector
//  private Vector movements;
  // Temporary AvatarInformation field
  private AvatarInformation ai;
  /** If thread is suspended or not.
  */
//  public boolean threadSuspended = true;
//  public boolean avatarEnabled = true;

  /** Sole constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public AvatarMovement ( AvatarInformation aInf) {
//    movements = new Vector();
    this.setPriority(Thread.MAX_PRIORITY);
//    movements.addElement(aInf);
    this.ai=aInf;
    this.run();
//    thread = new Thread (this);   // Initialize thread
//    thread.start();               // Start thread
  }

  /** Get Movements Vector.
      @param params None
      @return Movements Vector
      @exception exceptions No exceptions thrown
  */
//  public Vector getMovements() {
//    return (movements);
//  }

  /** Wakes up thread.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
//  public void restart() {
//    notify();
//  }

  /** Destroys current thread.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
//  public void destroy() {
//    thread.destroy();
//  }

  /** Current thread's body.
      Changes avatar's position.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public synchronized void run() {
//    while(true) {                                 // Loop forever
//      if (Thread.currentThread() == thread) {
//   	  while (!movements.isEmpty()) {            // If there is any movement left
  //        if (avatarEnabled) {
            try {

//              ai = (AvatarInformation) movements.firstElement();
              // Start walking movement (NOW!)
              if (ai.getStartTime() != null) {
                (ai.getStartTime()).setValue(System.currentTimeMillis() / 1000);
              }
              // Stop walking movement after 1 seconds of none events received
              if (ai.getStopTime() != null) {
                (ai.getStopTime()).setValue((System.currentTimeMillis() / 1000) + 1);
              }
//              if(ai.getAvatarPosition() != null) {          // Avatar representation loaded OK
                (ai.getAvatarPosition()).setValue(ai.getPosition());
//              }
//              if(ai.getAvatarRotation() != null) {          // Avatar representation loaded OK
                (ai.getAvatarRotation()).setValue(ai.getOrientation());
//              }

            }catch (Exception e) {
              System.err.println("Exception trying to move avatar");
            }
//          }
//            movements.removeElementAt(0);
//          threadSuspended = true;                       // Suspend thread
  //        }
/*
        try {
          synchronized(this) {
            while (threadSuspended) {
              wait();
            }
          }
        }
        catch (InterruptedException e) {
          System.err.println("Seems there has been an InterruptedException: ");
        }
        */
//      }
//       this.yield();
//      }
    }
}
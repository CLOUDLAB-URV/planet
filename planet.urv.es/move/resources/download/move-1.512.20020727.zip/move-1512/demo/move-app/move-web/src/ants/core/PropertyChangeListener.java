package ants.core;


/**
*		Interface for subscribing to event changes in bound properties.
*/

public interface PropertyChangeListener
{
	
		/**
	*	
	* Method triggered in response to a property change.
	* @return ants.core.PropertyChangeEvent A PropertyChangeEvent with property change information.
	*/

	
	public void propertyChange(PropertyChangeEvent e);
	
	
}
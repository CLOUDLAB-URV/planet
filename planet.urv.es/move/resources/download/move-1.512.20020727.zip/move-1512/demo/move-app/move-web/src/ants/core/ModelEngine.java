package ants.core;

import ants.comm.*;
import java.util.*;

public interface ModelEngine 
{
	
	public void loadModels() throws Exception;
	public Hashtable getModels();
	public Object getModel(String id);
}
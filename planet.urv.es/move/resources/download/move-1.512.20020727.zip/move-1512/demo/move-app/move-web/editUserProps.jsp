<%@ page session="true" import = "ants.move.lang.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*" %>



<%! User user;
    UserManager um;
    ResourceBundle labels,messages;
    LanguageUtilities lang;%>
<%

try{
  um = (UserManager)session.getAttribute("userManager");
}catch(Exception e){
  Syslog.error(this,"Unable to create UserManager");
}

if(request.getMethod().equalsIgnoreCase("GET")){
          lang = (LanguageUtilities)session.getAttribute("language");
          labels=lang.getResource("ants.move.lang.LabelsBundle");
          messages=lang.getResource("ants.move.lang.MessagesBundle");
	  user=um.getUser(request.getParameter("user"));
%>
<html>
  <head>
  <script>
    <!--

    function changeAvatar(){
      var avatarString=document.user.avatar.options[document.user.avatar.selectedIndex].text
      var vrmlString="NavigationInfo{\n"+"type \"NONE\"\n"+"}\n"+
                     "DEF PreviewViewpoint Viewpoint{\n"+"position 0 -0.8 2\n"+"}\n"+
                     "SpotLight{\n"+"location 0 -0.8 2\n"+"intensity 2.0\n"+"color 1.0 1.0 1.0\n"+"}\n"+
                     "DEF Movment TimeSensor{\n"+"cycleInterval 5\n"+"loop TRUE\n"+"startTime  1\n"+"}\n"+
		     "DEF AvatarMovment OrientationInterpolator{\n"+"key [ 0 0.5 1 ]\n"+"keyValue [0 1 0 0, 0 1 0 3.14, 0 1 0 6.28 ]\n"+"}\n"+
                     "DEF Avatar Transform{\n"+"children[\n"+"DEF source Inline{\n"+"url ["+avatarString+"]\n"+"}\n"+"]\n"+"}\n"+
                     "ROUTE Movment.fraction_changed TO AvatarMovment.set_fraction\n"+
                     "ROUTE AvatarMovment.value_changed TO Avatar.set_rotation\n"

      var browser=parent.frames[1].document.embeds[0]
      browser.replaceWorld(browser.createVrmlFromString(vrmlString))

    }

    function testObligatoryField(field){
	if(field.value.length==0) return false
	return true
    }

    function testPasswordFields(field1,field2){
	if(field1.value!=field2.value) return false
        return true
    }

    function testOK(form){
       var ok=false
       if(testObligatoryField(form.name)){
	  if(testObligatoryField(form.surname)){
 	     if(testObligatoryField(form.password)){
	        if(testObligatoryField(form.password2)){
	           if(testPasswordFields(form.password,form.password2))
		      ok=true
                   else alert(document.alertStrings.twoPass.value)
	        }else alert(document.alertStrings.password2.value)
             }else alert(document.alertStrings.password1.value)
          }else alert(document.alertStrings.surname.value)
       }else alert(document.alertStrings.name.value)

       return ok

    }
    
     // -->
  </script>
  </head>
  <body onLoad="changeAvatar();">
<%
   if ((user.getRole()).equalsIgnoreCase("root")){
%>
<jsp:include page="header.jsp?string=/WORLDS/USERS&linked=true" flush="true"/>
<% }else{ %>
<jsp:include page="header.jsp?string=/WORLDS&linked=true" flush="true"/>
<% } %>
<center>
<table width=90%>
   <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("editUser")%> :</b></font></td></tr>
   <tr>
    <td colspan="3"><br>
    </td>
   <tr>
    <td colspan="3"><b><%=(labels.getString("loginIT")).toUpperCase()%>: </b><big><i><%=request.getParameter("user")%></i></big></td>
   </tr>
  </table>
  <hr noshade width=90%>
  <form name="user" onSubmit="return testOK(user)" method="post">

   <table  width=90%>
   <tr>
    <td>
      <b><%=labels.getString("nameUserIT")%> : </b><input type="text" size="20" maxlength="20" name="name" value="<%=user.getProperty("name")%>">
    </td>
   <tr>
    <td>
      <b><%=labels.getString("surnameIT")%> : </b><input type="text" size="40" maxlength="40" name="surname" value="<%=user.getProperty("surname")%>">
    </td>
   </tr>
   <tr>
    <td>
      <b><%=labels.getString("emailIT")%> : </b><input type="text" size="30" maxlength="30" name="email" value="<%=user.getProperty("email")%>">*
    </td>
   </tr>
   <tr>
    <td>
      <b><%=labels.getString("passwordIT")%> : </b><input type="password" size="20" maxlength="20" name="password" value="<%=user.getPassword()%>">
    </td>
   </tr>
   <tr>
    <td>
      <b><%=labels.getString("passwordConfirmation")%> : </b><input type="password" size="20" maxlength="20" name="password2" value="<%=user.getPassword()%>">
    </td>
   </tr>
   <% if((((User)session.getAttribute("user")).getRole()).equalsIgnoreCase("root")){  %>
   <tr>
    <td>
      <b><%=labels.getString("roleTH")%> : </b><select name="role">
              <%      if(user.getRole().equals("root")){%>
                                <option value="root"><%=lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option value="teacher"><%=lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option value="student"><%=lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
	      <%      }else if(user.getRole().equals("teacher")){%>
                                <option value="root"><%=lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option selected value="teacher"><%=lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option value="student"><%=lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
	      <%      }else if(user.getRole().equals("student")){%>
      			        <option value="root"><%=lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option value="teacher"><%=lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
      			        <option selected value="student"><%=lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))%>
              <%      } %>

      		    </select>

    </td>
   </tr>
   <tr>
    <td>
      <b><%=labels.getString("world")%> : </b><select name="world">
      <%
      try{
        WorldManager wm=(WorldManager)session.getAttribute("worldManager");
        Collection wl=wm.getWorlds();
        World world;
        for(Iterator it=wl.iterator();it.hasNext();){
           world=(World)it.next();
           if(!world.getName().equals(user.getProperty("world"))){

      %>
                        <option><%=world.getName()%>
      <%   }else{%>
                        <option selected><%=world.getName()%>
      <%   }
        }
      } catch (Exception e) {
         Syslog.log (this,e);
      }
      %>
      		     </select>

    </td>
   </tr>
   <% } %>
   <tr>
    <td>
      <b><%=labels.getString("avatar")%> : </b><select name="avatar" onChange="changeAvatar()">
      <%
        Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"resources/avatars/avatars.properties");
          props.load(fis);
        }catch(IOException e){
           Syslog.error(this,"Unable to read the \"avatars.properties file\"");
        }
        try{
          for(int i=1;i<=Integer.parseInt(props.getProperty("avatarsNum"));i++){
             if(!props.getProperty("avatar"+Integer.toString(i)).equals(user.getProperty("avatar"))){

      %>
                        <option><%=props.getProperty("avatar"+Integer.toString(i))%>
      <%     }else{%>
                        <option selected><%=props.getProperty("avatar"+Integer.toString(i))%>

       <%    }
          }
        }catch(Exception e){
           Syslog.error(this,"Incorrect file format: \"avatars.properties\"");
        }
       %>
	              </select>

    </td>
   </tr>
   <tr>
     <td colspan="3"><font size="-1"><i>(*) <%=labels.getString("optional")%></i></font></td>
   </tr>
   <tr>
    <td align="center"><input type="submit" value="<%=labels.getString("update")%>" ></td>
   </tr>
  </table>
  </form>
  </center>
  <jsp:include page="footer.jsp" flush="true"/>

  <!-- this form contains the alert string values that we obtain from current Language ResourceBundle-->
  <form name="alertStrings">
    <INPUT TYPE="HIDDEN" name="name" VALUE="<%=messages.getString("alertName")%>">
    <INPUT TYPE="HIDDEN" name="surname" VALUE="<%=messages.getString("alertSurname")%>">
    <INPUT TYPE="HIDDEN" name="login" VALUE="<%=messages.getString("alertLogin")%>">
    <INPUT TYPE="HIDDEN" name="password1" VALUE="<%=messages.getString("alertPass1")%>">
    <INPUT TYPE="HIDDEN" name="password2" VALUE="<%=messages.getString("alertPass2")%>">
    <INPUT TYPE="HIDDEN" name="twoPass" VALUE="<%=messages.getString("alertTwoPass")%>">
  </form>
 </body>
</html>
<%
}else{


        user.setPassword(request.getParameter("password"));
//        user.setRole(request.getParameter("role"));


        user.setProperty("name",request.getParameter("name"));
        user.setProperty("surname",request.getParameter("surname"));
        user.setProperty("email",request.getParameter("email"));
//        user.setProperty("world",request.getParameter("world"));
        user.setProperty("avatar",request.getParameter("avatar"));

%>
        <script>
          <!--
             parent.location="listUsers.jsp"
          // -->
        </script>


<%
}
%>

package ants.move.core.models.url;

import ants.core.*;

public class UrlThing extends Thing implements PropertyChangeListener {
  private UrlModel uM;
  private String myId;

  public void init() {
    addPropertyChangeListener(this);
    myId=getContext().getThing();
//    System.err.println("[MOVE] - Url " + getContext().getThing() + " initialized.");
  }

  public void setModel (UrlModel m) {
    uM = m;
  }

  public UrlModel getModel () {
    return uM;
  }


  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();
    try {
      // Translation change
      if (propName.equals("translation")) {
        uM.refreshThing(myId);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void destroy () {
    super.destroy();
  }
}
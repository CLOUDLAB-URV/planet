<%@ page session="true" import="ants.move.lang.*, ants.move.ejb.*, com.protomatter.syslog.*, ants.comm.*, ants.move.core.*,ants.core.rmi.*, java.util.*, java.net.*, java.rmi.*" %>

<%
  session.invalidate();
  response.sendRedirect("index.jsp");
%>
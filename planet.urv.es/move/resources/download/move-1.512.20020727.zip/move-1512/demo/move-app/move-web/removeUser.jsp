<%@ page session="true" import = "javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
try {
      UserManager um = (UserManager)session.getAttribute("userManager");

      um.removeUser(request.getParameter("user"));

      response.sendRedirect("listUsers.jsp");
} catch (Exception e) {
   Syslog.error(this,"Unable to remove user"+e);
}
%>
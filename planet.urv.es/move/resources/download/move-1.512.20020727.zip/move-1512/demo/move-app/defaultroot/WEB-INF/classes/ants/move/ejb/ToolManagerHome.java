package ants.move.ejb;


import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Tool Manager Session Bean Home interface
 */
public interface ToolManagerHome extends EJBHome {

  public ToolManager create() throws CreateException,RemoteException;

}
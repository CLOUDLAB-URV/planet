package ants.move.ejb;

import javax.ejb.EJBObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for User Manager Session Bean
 */

public interface UserManager extends EJBObject {

  public Collection getUsers() throws RemoteException;
  public User getUser(String login) throws RemoteException;
  public User createUser(String login,String password, String role) throws RemoteException;
  public void removeUser(String login) throws RemoteException;


}


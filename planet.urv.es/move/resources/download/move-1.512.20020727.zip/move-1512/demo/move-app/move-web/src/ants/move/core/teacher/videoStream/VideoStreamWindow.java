//  2002 Oriol Montal� & Carles Pairot & Francesc Pi�as
package ants.move.core.teacher.videoStream;

// dynamicObjects.Slides import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.videoStream.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.net.*;


/** Implementation of VideoStream User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2002
*/
public class VideoStreamWindow extends Windows implements TeacherInterface{
  // Buttons
  private Button vsButton;
  // Labels
  private Label vsLabel;
  // Choice
  private Choice vsChoice;
  // Slides name
  private String vsName;
  // Applet's current codeBase
  private String codeBase;
  private VideoStreamModel internalModel;
  private Place conn;
  private String dispName;

  // All things of type VideoStream in that place
  Vector vsThings = new Vector();

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public VideoStreamWindow() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("VideoStream: " + (String) ht.get("src"));
    vsName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (VideoStreamModel) conn.getModel(vsName);
    if (internalModel == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: VIDEOSTREAM (from VideoStreamWindow)");
    }
    codeBase = conn.getBaseURL() + "worlds/" + conn.getWorld() + "/" + conn.getPlaceId() + "/";

    // Obtain all things of type VideoStream in that place
    vsThings = conn.getThings("videoStream.v01");


    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(210, 175);
    window.setLocation(190, 0);
    window.setResizable(false);
    window.setLayout(gbLayout);

    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(vsLabel = new Label("Video Streams:"), gc);
    window.add(vsLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(vsChoice = new Choice(), gc);

    gc.gridy = 1;
    gc.gridx = 1;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(vsButton = new Button("Load"), gc);
    window.add(vsButton);


  // Add things to choice
  try {
    Enumeration e = vsThings.elements();
    vsChoice.addItem("NONE");
    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      vsChoice.addItem(th.getName());
    }
  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type VideoStream to choice"); e.printStackTrace();}

  window.add(vsChoice);

    vsButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        vsButton_actionPerformed(e);
      }
    });


    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });
    // Check if there is any slides set loaded
/*    String thingKey = internalModel.getSlidesThingId();
    if (thingKey != null) {
      if (!thingKey.equals("----")) {
        Thing t = internalModel.getSlidesThing();
        if (t != null) {
          FileLabel.setText("Current Set: " + t.getName());
        }
        setButtonStatus (true);
      }
    }
  */
    System.err.println("[MOVE] - VideoStream control window initialized.");
  }



  public void lockThing (int index) {
   if(index>0){
    ants.core.Thing t = (ants.core.Thing) vsThings.elementAt(index-1);
    internalModel.setVideoStream(t.getThingId());
    setButtonStatus (true);
   }else if(index==0){  //NONE
     internalModel.setVideoStream("----");
   }
  }

  private void setButtonStatus (boolean status) {
    vsChoice.setEnabled (status);
    vsButton.setEnabled (status);
  }

  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
//    super.hideWin();
  }

  public String getThingId (String thg) {
    Enumeration e = vsThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getName().equalsIgnoreCase(thg)) {
        return (t.getThingId());
      }
    }
    return null;
  }




  /** actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void vsButton_actionPerformed (ActionEvent e) {
    lockThing(vsChoice.getSelectedIndex());
  }

  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "VideoStream";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }
}

<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%


LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

    // Add control for users who have voted!!!!!!

    String worldKey = null;
    String placeKey = null;
    String server = null;
    int port = 80;
    Thing objectInfo = null;
    String topic = null;
    int yes = 0;
    int no = 0;
    int unknown = 0;
    int total = 0;
    float yesPixel =0;
    float noPixel = 0;
    float unknownPixel = 0;
    float yesPC = 0;
    float noPC = 0;
    float unknownPC = 0;
    String userLogin = "Arohil";

    if (request.getMethod().equalsIgnoreCase("GET")) {

      server = request.getServerName();
      port = request.getServerPort();
      objectInfo =((ThingManager)session.getAttribute("thingManager")).getThing(request.getParameter("thingId"));
      topic = objectInfo.getDescription();
      String syes = objectInfo.getProperty("yes");

      // Parse 'yes' votes
      if (syes.equalsIgnoreCase ("----")) {
        yes = 0;
      }
      else {
        yes = Integer.parseInt (syes);
      }

      // Parse 'no' votes
      String sno = objectInfo.getProperty ("no");
      if (sno.equalsIgnoreCase ("----")) {
        no = 0;
      }
      else {
        no = Integer.parseInt (sno);
      }

      // Parse 'unknown' votes
      String sunknown = objectInfo.getProperty ("unknown");
      if (sunknown.equalsIgnoreCase ("----")) {
        unknown = 0;
      }
      else {
        unknown = Integer.parseInt (sunknown);
      }

      // Total number of votes
      total = yes + no + unknown;

      // Calculate % and bars sizes of votes
      if (total != 0) {
        if (yes != 0) {
          yesPC = ((float) yes / (float) total) * (float) 100.0;
          yesPixel= ((float) yes / (float) total) * (float) 470.0;
        }
        else {
	  yesPC = 0;
	  yesPixel = 1;
        }

        if (no != 0) {
 	  noPC = ((float) no / (float) total) * (float)100.0;
          noPixel = ((float) no / (float) total) * (float)470.0;
        } else {
	  noPC = 0;
	  noPixel = 1;
        }

        if(unknown != 0){
          unknownPC = ((float) unknown / (float) total) * (float) 100.0;
          unknownPixel = ((float) unknown / (float) total) * (float) 470.0;

        }
        else {
	  unknownPC = 0;
	  unknownPixel = 1;
        }

      }
      else {
        yesPixel = 1;
 	noPixel = 1;
 	unknownPixel = 1;

	yesPC = 0;
	noPC = 0;
	unknownPC = 0;
      }

%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("previewVot")%> : </b></font></td></tr>
</table>
<table width=90%>
 <tr>
  <td colspan="3">
  <center><h1><%=labels.getString("topic")%>:  <%=topic%></h1></center>
  <table width="500" border="0" align="center">
    <tr>
    <td width="6%">
      <div align="right"><b><%=labels.getString("yes")%></b></div>
    </td>
    <td colspan="10"><img src="resources/things/column.jpg" width="<%=yesPixel%>" height="50"</td>
  </tr>
  <tr>
    <td width="6%">
      <div align="right"><b><%=labels.getString("no")%></b></div>
    </td>
    <td colspan="10"><img src="resources/things/column.jpg" width="<%=noPixel%>" height="50"></td>
  </tr>
  <tr>
    <td width="6%">
      <div align="right"><b><%=labels.getString("unknown")%></b></div>
    </td>
    <td colspan="10"><img src="resources/things/column.jpg" width="<%=unknownPixel%>" height="50"></td>
  </tr>
  <tr>
  <tr>

  </tr>
</table>

<table width="28%" border="1" align="center" height="108">
  <tr>
    <td width="29%"><font color="#FF0000"><b><%=labels.getString("yes")%></b></font></td>
    <td width="71%"><b>:<%=yes%> <%=labels.getString("votes")%> <%=(int)yesPC%>%</b></td>
  </tr>
  <tr>
    <td width="29%"><font color="#FF0000"><b><%=labels.getString("no")%></b></font></td>
    <td width="71%"><b>:<%=no%> <%=labels.getString("votes")%> <%=(int)noPC%>%</b></td>
  </tr>
  <tr>
    <td width="29%"><font color="#FF0000"><b><%=labels.getString("unknown")%></b></font></td>
    <td width="71%"><b>:<%=unknown%> <%=labels.getString("votes")%> <%=(int)unknownPC%>%</b></td>
  </tr>
  <tr>
    <td width="29%"><font color="#FF0000"><b><%=labels.getString("total")%></b></font></td>
    <td width="71%"><b>:<%=total%> <%=labels.getString("votes")%></b></td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
<jsp:include page="footer.jsp" flush="true"/>
</html>

<%}
%>
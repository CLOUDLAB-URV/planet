package ants.move.lang;

import java.util.*;
import java.text.*;
/**
 * Title: LanguageUtilities
 * Description: Utilities for a specific Language
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Oriol Montal� , Carles Pairot  & Francesc Pi�as
 * @version 1.0
 */

public class LanguageUtilities {

  //location for this language utilities
  private Locale locale;
  // ResourceBundle references that i need for my utilities
  private Hashtable resources;

  //constructs a LanguageUtilities for the specified language and country
  public LanguageUtilities(String language, String country){
    locale=new Locale(language,country);
    resources=new Hashtable();
  }
  //returns the Locale for this LanguageUtilities
  public Locale getLocale(){
    return(locale);
  }
  //adds a ResourceBundle for my Location sense objects
  public void addResource(ResourceBundle r, String id){
    resources.put(id,r);
  }
  //returns a ResourceBundle from my table
  public ResourceBundle getResource(String id){
    return((ResourceBundle)resources.get(id));
  }

  //returns the current date with the correct format for my location.
  //style says the date style
  public String getCurrentDate(int style){
    Date today;
    DateFormat dateFormatter;

    dateFormatter=DateFormat.getDateInstance(style, locale);
    today=new Date();
    return(dateFormatter.format(today));

  }
  //returns the current time with the correct format for my location.
  //style says the time style
  public String getCurrentTime(int style){
    Date today;
    DateFormat dateFormatter;

    dateFormatter=DateFormat.getTimeInstance(style, locale);
    today=new Date();
    return(dateFormatter.format(today));

  }
  //returns the current date and time with the correct format for my location.
  //dateStyle and timeStyle say the date and time styles
  public String getCurrentDateTime(int dateStyle, int timeStyle){
    Date today;
    DateFormat dateFormatter;
    dateFormatter=DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
    today=new Date();
    return(dateFormatter.format(today));

  }

  public String translateDate(Date date, int dateStyle){
    DateFormat dateFormatter;
    dateFormatter=DateFormat.getDateInstance(dateStyle, locale);

    return(dateFormatter.format(date));
  }

  public String translateTime(Date time, int dateStyle){
    DateFormat dateFormatter;
    dateFormatter=DateFormat.getTimeInstance(dateStyle, locale);
    return(dateFormatter.format(time));
  }

  public String translateDateTime(Date dateTime, int dateStyle, int timeStyle){
    DateFormat dateFormatter;
        
    dateFormatter=DateFormat.getDateTimeInstance(dateStyle,timeStyle,locale);

    return(dateFormatter.format(dateTime));
  }
  //translates the foreign text in the ResourceBundle named resource to the
  //local text
  public String translateText(String text, String resource, Locale lang){
    ResourceBundle foreign=ResourceBundle.getBundle(resource,lang);
    String key=null;
    String value=null;

    for (Enumeration keys = foreign.getKeys() ; keys.hasMoreElements() ;) {
        key=(String)keys.nextElement();
        value=foreign.getString(key);
        if((value).equals(text))
        {
           break;
        }
    }

    return(((ResourceBundle)(getResource(resource))).getString(key));
  }

  //formats the message identified by key in the ResourceBundle resource with
  //this arguments
  public String formatMessage(String key,String resource,Object[] arguments){
    MessageFormat formatter = new MessageFormat("");
    formatter.setLocale(locale);

    formatter.applyPattern((getResource(resource)).getString(key));
    return(formatter.format(arguments));
  }

  //formats a message with the pattern identified by key in the ResourceBundle resource with
  //this patternFormats and with the corresponding arguments
  public String formatPluralMessage(String key, String resource, Format[] patternFormats, Object[] arguments){
    MessageFormat messageForm = new MessageFormat("");
    messageForm.setLocale(locale);

    String pattern = (getResource(resource)).getString(key);
    messageForm.applyPattern(pattern);

    messageForm.setFormats(patternFormats);
    return(messageForm.format(arguments));
  }
  //returns a double number with the correct format for my location
  public String getNumber(double number){
    NumberFormat numberFormatter;

    numberFormatter = NumberFormat.getNumberInstance(locale);
    return(numberFormatter.format(number));
  }
  //returns a long number with the correct format for my location
   public String getNumber(long number){
    NumberFormat numberFormatter;

    numberFormatter = NumberFormat.getNumberInstance(locale);
    return(numberFormatter.format(number));
  }

}
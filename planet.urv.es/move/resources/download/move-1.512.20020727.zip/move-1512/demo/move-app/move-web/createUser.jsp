<%@ page session="true" import = "java.util.*, java.io.*" %>

<% 
        Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"resources/avatars/avatars.properties");
          props.load(fis);
        }catch(IOException e){System.out.println(e);}        
%>
<HTML>
<FRAMESET cols="70%, 30%" name="root">
     <frameset  >
        <FRAME NORESIZE SRC="newUser.jsp" name="jsp">
        <FRAME NORESIZE SRC="resources/avatars/uncompressed/avatarPreview.wrl" name="vrml">
     </frameset>
     
     
</FRAMESET>
      
</HTML>
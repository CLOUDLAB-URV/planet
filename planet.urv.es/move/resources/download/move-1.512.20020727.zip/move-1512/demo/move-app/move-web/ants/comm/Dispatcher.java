package ants.comm;

import java.util.Hashtable;

public class Dispatcher extends Thread
{
	private RemoteEventListener caller;
	private Hashtable event;
	
	public Dispatcher(RemoteEventListener caller, Hashtable event)
	{
		this.caller = caller;
		this.event = event;
	}
	

	
	public void run()
	{

		caller.eventArrived(event);		
	}
	
	
}

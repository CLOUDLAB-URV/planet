package ants.move.ejb;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for World Entity Bean
 */
public interface World extends EJBObject{

  public String getName() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setDescription (String description) throws RemoteException;
  public String getType() throws RemoteException;
  public void setType(String type) throws RemoteException;
  public String getId() throws RemoteException;
  public String getProperty(String property) throws RemoteException,Exception;
  public void setProperty(String property, String value) throws RemoteException;
  public String getIndexedProperty(String property,int index) throws RemoteException,Exception;
  public void setIndexedProperty(String property, String value, int index) throws RemoteException;

}
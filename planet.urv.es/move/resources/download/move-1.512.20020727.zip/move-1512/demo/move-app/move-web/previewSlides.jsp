<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
String thingId = request.getParameter("thingId");
String worldKey=(String)session.getAttribute("worldId");
String placeKey=(String)session.getAttribute("placeId");

/*
String server = request.getServerName ();
int port = request.getServerPort ();
*/
LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

%>
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/PLACES/THINGS&linked=true" flush="true"/>
<center>
<table width=90%>
 <tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("previewSlides")%> : </b></font></td></tr>
</table>
<table width=90%>
 <tr>
  <td colspan="3">
  <table bgcolor="teal" align="center" width="80%">
   <%
    String path = pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+thingId;

    File f = new File(path);
    File files[]=f.listFiles();
    boolean brk=true;
    for( int i=files.length-1 ; i>=0 ; i--){
      f=files[i];
      if(brk){%><tr><%}
      %><td align="center">
      <img  height="200" src="<%=request.getContextPath()%>/worlds/<%=worldKey%>/<%=placeKey%>/<%=thingId%>/<%=f.getName()%>">
      </td>
      <%
      if(!brk){%></tr><%}
      if(brk){ brk=false;}
      else {brk=true;}
    }
   %>
  </table>
  </td>
 </tr>
</form>
</table>
</center>
<jsp:include page="footer.jsp" flush="true"/>
</BODY>
</HTML>


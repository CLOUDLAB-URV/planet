
package ants.core;

public class Link
{
	private String location;
	private String world;
	private String place;
	
	public Link(String location,String world,String place){
		this.world = world;
		this.location = location;
		this.place = place;
		
	}
	
	public Link(String place){
		this.location = "default";
		this.world="ants";
		this.place = place;
		
	}

	public Link(String world,String place){
		this.location = "default";
		this.world=world;
		this.place = place;
		
	}

	public String getPlace()
	{
		return place;	
	}
		public String getWorld()
	{
		return place;	
	}

}
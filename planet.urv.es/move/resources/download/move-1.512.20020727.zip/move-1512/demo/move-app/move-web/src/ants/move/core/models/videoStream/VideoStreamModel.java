// Package ants.move.core.models.videoStream
// videoStreamModel.java
// Implementation of videoStream Model
// 2002 Oriol Montal� & Carles Pairot & Francesc Pi�as

package ants.move.core.models.videoStream;

// ANTS imports
import ants.comm.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Video Stream  Model.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class VideoStreamModel extends Thing {

  private Vector listeners = new Vector();
  private String thingKey=null;
  private Thing thing;
  private String url="";

  /** Sole & void constructor.
  */
  public VideoStreamModel() {
  }
  /**
   * Initialize Model
   */
  public void init() {
    try{
      System.err.println("[MOVE] - VideoStream model initialized.");
    }catch(Exception e){e.printStackTrace();}
  }
/**
 * Add VideoStream listener
 * @param sList Class that implements VideoStream2Listener interface
 */
  public void addVideoStreamListener (VideoStreamListener sList) {
    listeners.addElement(sList);
  }
/**
 * Removes VideoStream listener
 * @param sList Class that implements VideoStreamListener interface
 */
  public void removeVideoStreamListener (VideoStreamListener sList) {
    listeners.removeElement(sList);
  }
/**
 * Set a new VideoStream thing in tool
 * @param thingKey Key of a new videoStream thing
 */
  public void setVideoStream (String thingKey) {
      this.thingKey=thingKey;
      loadVideoStream(thingKey);
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VideoStreamListener) listeners.elementAt (i)).setVideoStream(getVideoStreamURL());
      }
  }

  private void loadVideoStream (String thingKey) {
   try{
    if(thingKey.equalsIgnoreCase("----")){
      url="";
    }else{
      ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
      thing = new Thing();
      thing.init(ctx, super.getThingGateway());
      url=thing.getProperty("url");
    }
   }catch(Exception e){System.err.println("[MOVE] - Error Loading VideoStream");e.printStackTrace();}
  }


/**
 * get VideoStream URL
 * @return String that contains url of videoStream source
 */
  public String getVideoStreamURL(){
    return(url);
  }

/**
 * Tool type
 * @return VIDEOSTREAM
 */
  public String getType() {
    return "VIDEOSTREAM";
  }
/**
 * Destroy model
 */
  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((VideoStreamListener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}







package ants.core.rmi;

public class UserInfo {
    private String userName;
    private String IP;
    private boolean alive;
    private boolean isBot=false;

    public UserInfo (String uname) {
      userName = uname;
      alive = true;
    }

    public String getUserName () {
      return userName;
    }

    public String getUserIP () {
      return IP;
    }

    public void setUserIP (String IP) {
      this.IP = IP ;
    }

    public void setBot () {
      this.isBot = true ;
    }

    public boolean isAlive () {
      return alive;
    }

    public boolean isBot () {
      return isBot;
    }


    public void setAlive (boolean alive) {
      this.alive=alive;
    }

}
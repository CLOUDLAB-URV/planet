// Package ants.move.core.teacher.banner
// BannerWindow.java
// Implementation of banner User Interface
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.teacher.banner;

// dynamicObjects.banner import
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.models.banner.*;
import ants.move.core.teacher.*;

// java.awt Package imports
import java.awt.Button;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Choice;
import java.awt.event.*;

import java.util.*;
import java.io.*;
import java.net.*;

/** Implementation of banner User Interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.70 Build 2000
*/
public class BannerWindow extends Windows implements TeacherInterface {
  // Buttons
  private Button bannerButton;
  // Labels
  private Label FileLabel;
  private Label bannerLabel;
  // Choice
  private Choice bannerChoice;
  // banner name
  private String bannerName;
  // Applet's current codeBase
  private String codeBase;
  private BannerModel internalModel;
  private Place conn;
  private String dispName;

  // All things of type banner in that place
  Vector bannerThings = new Vector();

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public BannerWindow() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement any User Interface object through DObjectUInterface interface.
      @param iclass Internal class to be used
      @param cb Applet's current codeBase
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setNewWindow("banner: " + (String) ht.get("src"));
    bannerName = (String) ht.get("src");
    conn = (Place) ht.get("place");
    dispName = (String) ht.get ("dispName");
    internalModel = (BannerModel) conn.getModel(bannerName);
    if (internalModel == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: banner (from bannerWindow)");
    }
    codeBase = conn.getBaseURL() + "worlds/" + conn.getWorld() + "/" + conn.getPlaceId() + "/";

    // Obtain all things of type banner in that place
    bannerThings = conn.getThings("banner.v01");

    this.init();
    this.start();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Panel p;
    Font lbl = new Font("Helvetica", Font.BOLD, 14);

    gbLayout = new GridBagLayout();
    gc = new GridBagConstraints();
    gc.fill = GridBagConstraints.HORIZONTAL;

    window.setSize(210, 175);
    window.setLocation(190, 0);
    window.setResizable(false);
    window.setLayout(gbLayout);

    gc.gridy = 0;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(bannerLabel = new Label("banner:"), gc);
    window.add(bannerLabel);
    gc.gridy = 1;
    gc.gridx = 0;
    gc.gridwidth = 1;
    gc.gridheight = 1;
    gbLayout.setConstraints(bannerChoice = new Choice(), gc);

    gc.gridy = 1;
    gc.gridx = 1;
    gc.gridwidth = 1;
    gc.gridheight = 1;

    gbLayout.setConstraints(bannerButton = new Button("Load"), gc);
    window.add(bannerButton);


    p = new Panel();
    p.setLayout(null);
    p.setSize(185, 50);
    FileLabel = new Label("Current: < none >");
    FileLabel.setBounds(0, 25, 144, 24);
    p.add(FileLabel);
    gc.gridy = 2;
    gc.gridx = 0;
    gc.gridwidth = 3;
    gc.gridheight = 1;
    gbLayout.setConstraints(p, gc);
    window.add(p);



  // Add things to choice
  try {
    Enumeration e = bannerThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing th = (ants.core.Thing) e.nextElement();
      bannerChoice.addItem(th.getName());
    }
    if (bannerChoice.countItems() == 0)
	bannerButton.setEnabled(false);

  } catch (Exception e) { System.err.println("EXCEPTION: Adding things of type banner to choice"); e.printStackTrace();}

  window.add(bannerChoice);

    bannerButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        bannerButton_actionPerformed(e);
      }
    });

    window.addWindowListener(new java.awt.event.WindowListener(){
      public void windowClosing(WindowEvent e) {
        windowSlide_actionPerformed(e);
      }
      public void windowDeactivated(WindowEvent e) {}
      public void windowActivated(WindowEvent e) {}
      public void windowClosed(WindowEvent e) {}
      public void windowDeiconified(WindowEvent e) {}
      public void windowIconified(WindowEvent e) {}
      public void windowOpened(WindowEvent e) {}
    });
    // Check if there is any banner loaded
    String thingKey = internalModel.getBannerThingId();
    if (thingKey != null) {
      if (!thingKey.equals("----")) {
        Thing t = internalModel.getBannerThing();
        if (t != null) {
          FileLabel.setText("Current: < " + t.getName() + " >");
        }

      }
    }
    System.err.println("[MOVE] - Banner control window initialized.");
  }




  // Locks the banner Thing onto the banner Model
  public void lockThing (int index) {
    ants.core.Thing t = (ants.core.Thing) bannerThings.elementAt(index);
    internalModel.setBannerThing(t.getThingId());

  }


  /** Applet's start method.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    super.hideWin();
  }

  public String getThingId (String thg) {
    Enumeration e = bannerThings.elements();

    while (e.hasMoreElements()) {
      ants.core.Thing t = (ants.core.Thing) e.nextElement();
      if (t.getName().equalsIgnoreCase(thg)) {
        return (t.getThingId());
      }
    }
    return null;
  }

  public void imageChange (String url) { }

/*  public void setBannerThing (BannerThing bT) {
    FileLabel.setText("Current Banner: " + bT.getName());
  }
  */

  /** bannerField's actionPerformed() method.
      @param e Event
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void bannerButton_actionPerformed (ActionEvent e) {
    lockThing(bannerChoice.getSelectedIndex());
    FileLabel.setText("Current: < " + bannerChoice.getSelectedItem() +" >");
  }





  /** Get DObjectUI type.
      @param params None
      @return DObjectUI type
      @exception exceptions No exceptions thrown
  */
  public String getType() {
    return "BANNER";
  }

  /** Get DObjectUI name.
      @param params None
      @return DObjectUI name
      @exception exceptions No exceptions thrown
  */
  public String getName() {
    return dispName;
  }

  public void windowSlide_actionPerformed (WindowEvent evt){
        window.dispose();
  }

}

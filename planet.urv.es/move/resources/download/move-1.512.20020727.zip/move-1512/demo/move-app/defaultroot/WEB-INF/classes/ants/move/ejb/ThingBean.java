package ants.move.ejb;


import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;
import com.protomatter.syslog.*;
import java.util.*;


/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Entity Bean for a Thing
 *  It is a BMP (Bean Managed Persistence) EJB (Enterprise JavaBean)
 */
public class ThingBean implements EntityBean {
  // Primary key
  private String          thingId;
  private String          placeId;
  private String          myName;
  private String          myDescription;
  private String          toolId;
  protected EntityContext context;
  /**
   * This method gets a connection to the database
   */
  private Connection getConnection() throws SQLException {
    try {
      InitialContext jndiContext = new InitialContext();

      DataSource source = (DataSource) jndiContext.lookup (
                          "jdbc/DefaultPooledDS");
      return source.getConnection();
    } catch (Exception ex) {
      Syslog.fatal (this, "Exception getting database connection!");
      Syslog.fatal (this, ex);
      return null;
    }
  }

  /**
   * This method inserts a new register into the database
   */
  public String ejbCreate (String id) {
    thingId = id;
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("INSERT INTO thing (id) VALUES ('"
                             + thingId + "')");
      return id;
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbPostCreate (String id) { }

  /**
   * This method removes a previously existent register from the database
   */
  public void ejbRemove () {
    String primaryKey = (String) context.getPrimaryKey();
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("DELETE FROM thing WHERE id = '" +
                             primaryKey+"'");
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the beginning of a transaction
   */
  public void ejbLoad() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                              "SELECT * FROM thing WHERE id = '" +
                              primaryKey+"'");

      if (results.next()) {
        // Get the name information from the thing table
        myName = new String (results.getString ("NAME"));
        // Get the description information from the thing table
        myDescription = new String (results.getString ("DESCRIPTION"));
        // Get the placeId information from the thing table
        placeId = new String (results.getString ("PLACEID"));
        // Get the toolId information from the thing table
        toolId = new String (results.getString ("TOOLID"));
        // Get the thingId information from the thing table
        thingId = new String (results.getString ("ID"));

      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the end of the transaction, just before
   * the container sends all the changes to the database
   */
  public void ejbStore() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      PreparedStatement sqlPrep = conn.prepareStatement (
                                  "UPDATE thing SET " +
                                  "name = ?, description = ?, placeId = ?,toolId = ? " +
                                  "WHERE id = ?");
      sqlPrep.setString (1, myName);
      sqlPrep.setString (2, myDescription);
      sqlPrep.setString (3, placeId);
      sqlPrep.setString (4, toolId);
      sqlPrep.setString (5, thingId);
      sqlPrep.executeUpdate();
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method finds by primary key
   */
  public String ejbFindByPrimaryKey (String primaryKey)
                 throws ObjectNotFoundException {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT * FROM thing WHERE id = '" +
                            primaryKey+"'");
      if (results.next()) {
        return primaryKey;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method returns all primary keys
   */
  public Collection ejbFindByAll() throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT id FROM thing");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }


  }

  /**
   * This method returns all things primary key in placeId
   */
  public Collection ejbFindByPlace(String placeId) throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT id FROM thing WHERE placeid ='"+ placeId+"'");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method returns all things primary key in placeId
   */
  public Collection ejbFindByPlaceAndTool(String placeId, String toolId) throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT id FROM thing WHERE placeid ="+ placeId + "AND toolid="+toolId);
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbActivate() {}
  public void ejbPassivate() {}



  public void setEntityContext (EntityContext cntx) {
    context = cntx;
  }

  public void unsetEntityContext() {
    context = null;
  }

  public String getName() {
    return myName;
  }

  public void setName (String name) {
    myName = name;
  }

  public String getDescription() {
    return myDescription;
  }

  public void setDescription (String description) {
    myDescription = description;
  }

  public String getToolId() {
    return toolId;
  }

  public void setToolId (String id) {
    toolId = id;
  }

  public String getId(){
  return thingId;
  }

  public String getPlaceId() {
    return placeId;
  }

  public void setPlaceId (String id) {
    placeId = id;
  }

  public String getProperty (String property) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM property " +
                            "WHERE subId ='"+thingId+"' and name='"+property+"'");
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setProperty (String property, String value)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE property SET value ='"+value+"' "+
                            "WHERE subId ='"+thingId+"' and name='"+property+"'");
      if(results==0){
         //Property no exists --> add property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO property VALUES " +
                            "('"+thingId+"','"+property+"','"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

}
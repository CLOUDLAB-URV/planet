package ants.core;

import java.util.*;
import ants.comm.*;
import ants.util.*;
import java.io.Serializable;
import java.rmi.*;
import ants.core.rmi.*;

/**
*		Core class of the ANTS framework; it transparently facades advanced middleware services in order
*   to ease development of CSCW components. It mimics the JavaBeans component model using a remote
* and persistent property based mechanism and subscription to remote events in a straightforward fashion.
*
*/


public class Thing implements Model, RemoteEventListener, Serializable
{
	private Properties props;
	private Hashtable iprops;
	private String clss;
	private String src;
	private Place conn;
	private Vector listeners = new Vector();
        private ThingGateway tgate;
	private ANTSContext ctx;
        private Hashtable subs = new Hashtable();

public void init (ANTSContext ctx, ThingGateway tg) {
		this.conn = ctx.getPlace();
		this.ctx = ctx;
                this.tgate = tg;

		subs.put(Context.WORLD, conn.getWorld());
		subs.put(Context.PLACE, conn.getPlaceId());
		subs.put (Context.CLASS, ctx.getThing());

		try {
		  conn.addPlaceListener (this, subs);
		} catch(SessionException ex) {
                  Debug.error(ex);
                }

		init();
}

/**
*		Initialization method for CSCW components in the ANTS container.
*/

public void init()
{
}


/**
*		Finalization method for CSCW components in the ANTS container.
*/


public void destroy()
{
  System.err.println("[ MOVE! ] - Destroying thing " + getThingId());
  try {
    conn.removePlaceListener(subs);
  } catch (SessionException ex) {
    Debug.error(ex);
  }
}

/**
* Important method returning a reference to the container context.
* @return ants.core.ANTSContext return a reference to the ANTS container context.
*/

public ANTSContext getContext() {
  return ctx;
}

public String getThingId() {
  return ctx.getThing();
}

public Place getPlace() {
  return conn;
}

public ThingGateway getThingGateway() {
  return tgate;
}

public String getName() {
  try {
    return (tgate.getName(getThingId()));
  } catch (java.rmi.RemoteException rex) {
    Debug.error (rex);
    System.err.println("Error getting name field for thing: " + getThingId());
    return null;
  }
}

public String getDescription() {
  try {
    return tgate.getDescription(getThingId());
  } catch (java.rmi.RemoteException rex) {
    Debug.error(rex);
    System.err.println ("Error getting description field for thing: " + getThingId());
    return null;
  }
}

public String getType()
{
	return "";
}

	/**
	*	 Sets a property value in the remote object.
	* @param propName key value for the remote property
	* @param propValue new value to set in the named property
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/

// Make it synchronized to avoid data loss

  public synchronized void setProperty (String propName, String propValue) throws PropertyVetoException {
    try {
      tgate.setProperty (getThingId(), propName, propValue);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }

    Hashtable evt = new Hashtable();
    evt.put(Context.METHOD,"SETPROPERTY");
    evt.put("PROPNAME",propName);
    evt.put("PROPVALUE",propValue);
    evt.put("INDEX","-1");

    triggerEvent(evt);
  }

        /**
	*	 Gets a property value in the remote object.
	* @param propName key value for the remote property
	* return java.lang.string value of the named property
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/

  public String getProperty(String propName) throws PropertyVetoException {
    try {
      return tgate.getProperty (getThingId(), propName);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
    return "";
  }

  // Atomically increments the value of a property (integer). It prevents data loss
  public synchronized void incrementProperty (String propName) throws PropertyVetoException {
    int num = 0;
    try {
      String val = tgate.getProperty(getThingId(), propName);

      try {
        num = new Integer(val).intValue();
        num++;
      } catch (NumberFormatException nfe) {
        num = 1;
      }

      tgate.setProperty(getThingId(), propName, "" + num);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }

    // Trigger event
    Hashtable evt = new Hashtable();
    evt.put(Context.METHOD,"SETPROPERTY");
    evt.put("PROPNAME",propName);
    evt.put("PROPVALUE", "" + num);
    evt.put("INDEX","-1");
    triggerEvent(evt);
  }

  // Atomically adds a token to a property, without data loss
  public synchronized void addTokenToProperty (String propName, String propValue) throws PropertyVetoException {
    try {
      String val = tgate.getProperty(getThingId(), propName);

      if (val.equals("----")) {
        val = new String();
      }

      val += " " + propValue;

      tgate.setProperty(getThingId(), propName, val);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
  }

        /**
	*	 Gets all property names.
	* @return String[] Array containing property names.
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/
  public String[] getPropertyNames() {
    try {
      return tgate.getPropertyNames (getThingId());
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
    return null;
  }

/**
	*	 Gets an indexed property value in the remote object.
	* @param propName key value for the remote indexed property
	* @return String[] Array containing indexed property values
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


  public String[] getIndexedProperty(String propName) throws PropertyVetoException {
/*    try {
      return tgate.getIndexedProperty (conn.getWorld(), conn.getPlaceName(), getThingId(), propName);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
    */
    return null;
  }

/**
	*	 Sets all values in an indexed property.
	* @param propName key value for the remote property
	* @param values list of values
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


/*public void setIndexedProperty(String propName,String [] values)
throws PropertyVetoException

{
		try
	{
				thing.setIndexedProperty(propName,values);
			}catch (java.rmi.RemoteException rex)
		{
			Debug.error(rex);
		}

}
*/

/**
	*	 Gets a value in an indexed property.
	* @param propName key value for the remote property
	* @param index property index
	* @return java.lang.String Property value
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


  public String getIndexedProperty (String propName, int index) throws PropertyVetoException {
    try {
      return tgate.getIndexedProperty (getThingId(), propName, index);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
    return "";
  }

	/**
	*	 Sets a value in an indexed property.
	* @param propName key value for the remote property
	* @param index property index
	* @param value new value to set in the named property
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


/*public void setIndexedProperty(String propName, int index,String value)
throws PropertyVetoException

{
		try
		{
			thing.setIndexedProperty(propName,index,value);

		}catch (java.rmi.RemoteException rex)
		{
			Debug.error(rex);
		}


		Hashtable evt = new Hashtable();
		evt.put(Context.METHOD,"SETPROPERTY");
		evt.put("PROPNAME",propName);
		evt.put("INDEX",String.valueOf(index));
		evt.put("PROPVALUE",String.valueOf(value));

		triggerEvent(evt);


}*/

	/**
	*	 Gets the length of an indexed property.
	* @param propName key value for the remote property
	* @return int Indexed property length
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


  public int getIndexedPropertySize (String propName) throws PropertyVetoException {
   try {
     return tgate.getIndexedPropertySize (ctx.getThing(), propName);
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }

    return 0;
  }

	/**
	*	 Gets a list of all indexed property names.
	* @param String[] list containing all indexed property names.
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/


  public String[] getIndexedPropertyNames() throws PropertyVetoException {
/*    try {
      return tgate.getIndexedPropertyNames(conn.getWorld(), conn.getPlaceName(), ctx.getThing());
    } catch (java.rmi.RemoteException rex) {
      Debug.error(rex);
    }
    */
    return null;
  }

/**
	*	 Setthe value of a object property.
	* @param propName key value for the remote property
	* @param obj Serializable java object to be set to the remote property
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/



/*public void setObjectProperty(String propName,java.io.Serializable obj)
throws PropertyVetoException

{
		try
		{
			thing.setObjectProperty(propName,obj);

			}catch (java.rmi.RemoteException rex)
		{
			Debug.error(rex);
		}

		Hashtable evt = new Hashtable();
		evt.put(Context.METHOD,"SETPROPERTY");
		evt.put("PROPNAME",propName);
		evt.put("INDEX","0");
		evt.put("PROPVALUE","OBJECT");
		evt.put("object",obj);
		triggerEvent(evt);


	}
*/
	/**
	*	 Gets the value of an object property
	* @param propName key value for the remote property
	* @return java.lang.Object Object property value
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/



/* public Object getObjectProperty(String propName)
throws PropertyVetoException
	{

		try
		{
			return thing.getObjectProperty(propName);

			}catch (java.rmi.RemoteException rex)
		{
			Debug.error(rex);
		}
		return null;


	}
*/
	/**
	* Method for triggering events in the current namespace.
	* @param evt Hashtable event to be sent.
	*/

  public void triggerEvent(Hashtable evt) {
    try {
      evt.put(Context.CLASS, getThingId());
      conn.send(evt);
    } catch (SessionException ex) {
      Debug.error(ex.getException());
    }
  }

  public void eventArrived (Hashtable evt) {
    String method = (String)evt.get(Context.METHOD);

    if (method.equals("SETPROPERTY")) {
      String propName = (String)evt.get("PROPNAME");
      String propValue = (String)evt.get("PROPVALUE");
      int propIndex = Integer.parseInt((String)evt.get("INDEX"));

      Object obj = (Object)evt.get("object");

      PropertyChangeEvent pE;
      if (propValue.equals("OBJECT")) {
        pE = new PropertyChangeEvent(propName,obj,ctx.getUser());
      }
      else {
        pE = new PropertyChangeEvent(propName,propValue,propIndex,ctx.getUser());
      }

      Vector list2 = (Vector) this.listeners.clone ();

      for (int i = 0; i < list2.size (); ++ i) {
        ((PropertyChangeListener) list2.elementAt (i)).propertyChange(pE);
      }
    }
  }


	/**
	* Method for registering a new PropertyChangeListener for this component.
	* @param l Listener of Property changes
	*/


    public void addPropertyChangeListener (PropertyChangeListener l) {
      listeners.addElement(l);
    }


    /**
    * Method for deregistering to property changes in  this component.
    * @param l Listener of Property changes
    */

    public void removePropertyChangeListener (PropertyChangeListener l) {
      listeners.removeElement(l);
    }


}
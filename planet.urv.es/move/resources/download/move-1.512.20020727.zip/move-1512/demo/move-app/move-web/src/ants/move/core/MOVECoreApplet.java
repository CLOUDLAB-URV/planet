// Package ants.move.core
// MOVECoreApplet.java
// Multiuser Oriented Virtual Environments Core Applet
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core;

// Notification Service imports
import ants.comm.*;
import ants.core.*;

import java.awt.*;
import java.util.Enumeration;
import java.net.*;

import ants.move.core.teacher.*;
import ants.move.core.teacher.chat.*;

import ants.move.core.models.*;
import ants.move.core.models.avatar.*;
import ants.move.core.models.chat.*;
import ants.move.core.views.*;
import ants.move.core.views.link.*;

// java.applet Package import
import java.applet.Applet;

// java.net Package import
import java.net.URL;

// java.util Package imports
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

// VRML Scene imports
import vrml.external.Node;
import vrml.external.Browser;
import vrml.external.field.*;

/** MOVE! Core class. Main applet.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.400 Build 2001
*/
public class MOVECoreApplet extends Applet {

  /** Reference to the VRML browser.
  */
  public Browser browser = null;

  /** Username String.
  */
  public String username;

  /** User Photo File String.
  */
  public String photofile;

  /** Properties File String.
  */
  public String propertiesFile;

  /** Is current user a teacher ?
  */
  public boolean isTeacher = false;

  /** Has it been a zone change ?
  */
  public boolean zoneChange = false;

  /** Notification Service's session.
  */
  public ants.comm.Session session;

  /** Place.
  */
  public Place MOVEPlace;

  /** Notification Service's Host.
      Must be the same as applet's codeBase.
      By default is 127.0.0.1 (localhost)
  */
  public String host;

  /** Notification Service's Port.
      By default is 2917 (Elvin4)
  */
  public String port;

  /** Notification Service's Session class.
      By default is ants.comm.elvin.Session (Elvin4)
  */
  public String provider_class;

  /** The name of the VRML place we are viewing.
  */
  public String placeName;
  public String roleName;
  public String placeType;
  public String worldName;
  public String avatar;

  /** Root DynamicObject.
      The VRML Node where avatars, bots & 3D Simulations will be added
  */
  public DynamicObject root;

  /** Controls addition/removal of users.
  */
  public AvatarControl avatarCtrl;

  /** Chat Event Producer.
  */
  public ChatModel chatObject;

  /** Chat Event Consumer & Chat Window Interface.
  */
  public ChatWindow chatWin;

  /** Link Manager: it manages all links in this Zone.
  */
// public LinkManager linkMngr;

  /** DObjectsUI Container.
  */
  public DObjectContainer dObjCont;

  /** Vector containing all dynamicObjects User Windows.
  */
  public Vector dynamicObjectsUIVector;

//  public String antsClass;

  // Label
  private Label chatLabel;
  // TextArea
  private TextArea chatArea;
  // TextField
  private TextField chatField;
  private List chatUsers;
  // Chat internal class
  private Button greetButton;
  private Button addDocButton;
  private Button handUpButton;
  private ScrollPane p;
  private Image moveBack = null;
  private MediaTracker tracker = new MediaTracker(this);
  private AvatarMovsModel avtMovs;
  private PingResponder pingThread;
  private boolean navigationAllowed = true;
//  String antsClass;

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    this.setBackground(java.awt.Color.black);
    this.setForeground(java.awt.Color.green);
    this.setSize(800, 150);
    this.setLayout(null);

    try {
      URL url = new URL (this.getCodeBase().toString());
      Constants.init (url);

      moveBack = this.getImage (new URL (this.getDocumentBase(),"resources/images/back.jpg"));
      tracker.addImage(moveBack, 1, 0, 0);
      tracker.waitForID(1);

      getOptions(null);                       // Get applet parameters
      dynamicObjectsUIVector = new Vector();  // Initialize dynamic objects Vector

      StringTokenizer tokens = new StringTokenizer(username);
      this.connect();
    } catch (Exception muE) {
        System.err.println("Exception in MOVECoreApplet's init() method.");
        muE.printStackTrace();
    }
  }

  /** Applet's start method: Nothing to be done.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void start() {
    System.err.println("[MOVE] -                         MOVE! initialized");
    System.err.println("[MOVE] - =================================");
  }

  public void paint (Graphics g) {
    // Paint MOVE! background
    g.drawImage(moveBack, 0, 0, this);
  }

  /** Applet's stop method: Controls when applet is about to be destroyed.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void stop() {
    System.err.println("\n[MOVE] - MOVE! stopped.");

    pingThread.destroy();
    System.err.println("[MOVE] - Ping thread destroyed.");

    if (avatarCtrl != null) {
      avatarCtrl.destroyPilotUser();
      System.err.println("[MOVE] - Pilot user destroyed.");
      System.err.println("[MOVE] - Avatar thread destroyed.");
    }

    try {
      MOVEPlace.leave();
    }
    catch (Exception ss) {
      System.err.println("[MOVE] - Place already left.");
      ss.printStackTrace();
    }
    System.err.println("[MOVE] - Place left.");

    chatObject = null;
    browser = null;
    System.err.println("[MOVE] - Browser reference destroyed.\n");


/*    if (zoneChange) {       // If it was a zone change, then call destroy()
      this.destroy();
      zoneChange = false;
    } */
  }

  /** Applet's destroy method: Free all resources.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void destroy() {
    System.err.println("[MOVE] - Entering destroy() method...");
    System.err.println("[MOVE] - Applet definitely destroyed.");
  }

  /** Set user's name.
      @param uname User's name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setName (String uname) {
    username = uname;
  }

  /** Set photo file name.
      @param file Photo file name
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setPhoto (String file) {
    photofile = file;
  }

  public void setNavigationAllowed (boolean value) {
    navigationAllowed = value;
  }

  /** Set if user is a teacher.
      @param t True if teacher
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void setTeacher (boolean t) {
    isTeacher = t;
  }

  /** Get applet's parameters.
      @param args Array of string arguments
      @return No return value
      @exception exceptions No exceptions thrown
  */
  private void getOptions (String args[]) {

    if (getParameter("worldKey") != null) {
      worldName = getParameter("worldKey");
    }
    else {
      System.err.println("Fatal Error: Unable to get world key. Aborting...");
      this.destroy();
    }

    if (getParameter("placeKey") != null) {
      placeName = getParameter("placeKey");
    }
    else {
      System.err.println("Fatal Error: Unable to get place key. Aborting...");
      this.destroy();
    }

    if (getParameter("userLogin") != null) {
      username = getParameter("userLogin");
    }
    else {
      System.err.println("Fatal Error: Unable to get user login. Aborting...");
      this.destroy();
    }

    if (getParameter("userRole") != null) {
      roleName = getParameter("userRole");
    }
    else {
      System.err.println("Fatal Error: Unable to get user's role. Aborting...");
      this.destroy();
    }

    if (getParameter("placeType") != null) {
      placeType = getParameter("placeType");
    }
    else {
      System.err.println("Fatal Error: Unable to get place type. Aborting...");
      this.destroy();
    }

    if (getParameter("avatar") != null) {
      avatar = getParameter("avatar");
    }
    else {
      System.err.println("Fatal Error: Unable to get avatar representation. Aborting...");
      this.destroy();
    }


  }

  public void drawInterface() {
    Font lbl = new Font("Helvetica", Font.PLAIN, 10);
    chatField = new TextField(30);
    chatField.setBounds(220, 125, 280, 24);
    chatField.setFont(lbl);
    this.add(chatField);
    chatArea = new TextArea("", 10, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
    chatArea.setBounds(220, 2, 280, 123);
    chatArea.setEditable(false);
    chatArea.setFont(lbl);
    this.add(chatArea);

    chatUsers = new List();
    chatUsers.setBackground(java.awt.Color.black);
    chatUsers.setForeground(java.awt.Color.green);
    chatUsers.setBounds(500, 2, 80, 147);
    this.add(chatUsers);

    greetButton = new Button ("Greet");
    addDocButton = new Button ("Dance");
    handUpButton = new Button ("HandUp");

    greetButton.setForeground(java.awt.Color.black);
    addDocButton.setForeground(java.awt.Color.black);
    handUpButton.setForeground(java.awt.Color.black);

    greetButton.setBounds(585, 80, 60, 32);
    addDocButton.setBounds(655, 80, 60, 32);
    handUpButton.setBounds(725, 80, 60, 32);

    greetButton.setEnabled(false);
    addDocButton.setEnabled(false);
    handUpButton.setEnabled(false);

    this.add(greetButton);
    this.add(addDocButton);
    this.add(handUpButton);
    p = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
//    p.setBounds(2, 2, 217, 148);
    p.setBounds(2, 2,200, 148);
    p.setBackground(java.awt.Color.gray);
    p.setForeground(java.awt.Color.black);
    p.repaint();
    p.setVisible(false);
    this.add(p);
  }

  /** Create a session & get reference to the VRML browser.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void connect() {
    this.drawInterface();
    try {
      System.err.println("\n[MOVE] - =================================");
      System.err.println("[MOVE] -                       MOVE! is initializing");
      Version.printVersion();
      System.err.println("[MOVE] - Connecting to host: " + Constants.getServer());

      Properties env = new Properties();

      env.put(Constants.WORLD, worldName);
      env.put(Constants.PLACE, placeName);
      env.put(Constants.NSPORT, Constants.getNSPort());
      env.put(Constants.ANTSCLASS, Constants.getAntsClass());
      env.put(Constants.PLACESERVER, Constants.getPlaceGatewayRMIId());
      env.put(Constants.THINGSERVER, Constants.getThingGatewayRMIId());
      env.put(Constants.USERSERVER, Constants.getUserGatewayRMIId());
      env.put(Constants.SERVER, Constants.getServer());
      env.put("BASE",Constants.getPath());
	System.out.println(Constants.getUserGatewayRMIId());
      // Put user's name & role
      env.put(Constants.USER, username);
      
      env.put(Constants.ROLE, roleName);
      session = SessionFactory.createSession (env);
      MOVEPlace = new Place (session, env);
      MOVEPlace.join();

      // Add user to place
      PlaceParser plp = new PlaceParser(MOVEPlace);

      // Immediately initialize ping responder class for this user
      pingThread = new PingResponder (username, MOVEPlace);

      addUsers();

    } catch (Exception ss) {
        System.err.println("Exception trying to connect: (MOVECoreApplet.connect())");
        ss.printStackTrace();
    }

    try {
      java.lang.Thread.sleep(2000);     // Wait for 2 seconds so that the browser
                                        // can load all of the VRML world
    } catch (InterruptedException e) {}

    browser = (Browser) Browser.getBrowser (this);

    this.addObjects();                  // Let's start adding dynamicObjects (if any)
  }

  public void addUsers() {
      Vector users = MOVEPlace.getUsers();
      if (users != null) {
        Enumeration enum = users.elements();

        while (enum.hasMoreElements()) {
          chatUsers.add((String) enum.nextElement());
        }
      }
  }

  /** Add all dynamicObjects & initialize interfaces.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void addObjects() {

    try {
      chatObject = new ChatModel (MOVEPlace);
      chatWin = new ChatWindow (chatObject, chatField, chatArea, chatUsers, MOVEPlace);

      chatWin.consoleMessage("Welcome to MOVE!");
      chatWin.consoleMessage("Multiuser Oriented Virtual Environments");
      chatWin.consoleMessage("-----------------------------------------------------------------------------------");

      // Root Node will always exist in our VRML file
      root = new DynamicObject (placeName, browser, "ROOT");

      // Initialize addition/removal of users
      Hashtable ht = new Hashtable();
      ht.put("CLASS", "AvatarControl");
      ht.put("SRC", "MOVEAvatars");
      ht.put("browser", browser);
      ht.put("root", root);
//    ht.put("USER", username);
      ht.put("avatar", avatar);

      ht.put("chatWin", chatWin);
      ht.put("codeBase", (this.getCodeBase()).toString());
//    ht.put("teacher", new Boolean(isTeacher));

      avatarCtrl = new AvatarControl (MOVEPlace, ht);

      ht = new Hashtable();
      ht.put("CLASS", "Avatar");
      ht.put("SRC", "MOVEAvatars");
      ht.put("USER", username);
      ht.put("greetButton", greetButton);
      ht.put("danceButton", addDocButton);

      avtMovs = new AvatarMovsModel (MOVEPlace, ht);

      Hashtable models = new Hashtable();

      // Initialize Model Engine
      models = MOVEPlace.loadModels();

/*      // Manages all links
      MOVEPlace.loadLinks();
      linkMngr = new LinkManager (browser, placeName, props, this);
*/
      Hashtable htable = new Hashtable();
      htable.put("browser", browser);
      htable.put("models", models);
      htable.put("place", MOVEPlace);
      htable.put("root", root);
      htable.put("chatWin", chatWin);
      htable.put("MOVECoreApplet", this);

      ViewEngine vE = new ViewEngine (htable);
      vE.loadViews();

      TeacherViews tV = new TeacherViews(MOVEPlace, chatWin, models);
      dynamicObjectsUIVector = tV.getTeacherViews();

    } catch (Exception e) {
        chatWin.consoleMessage("Exception: " + e);
        e.printStackTrace();
    }

    dObjCont = new DObjectContainer(dynamicObjectsUIVector, p);


    chatWin.consoleMessage("MOVE! Initialized OK.");
    chatWin.consoleMessage("-----------------------------------------------------------------------------------");

    // Entire world is initialized!

    if (navigationAllowed) {
      // Allow navigation
      String[] NType = new String[1];
      NType[0] = "WALK";
      ((EventInMFString)((browser.getNode("NavInfo")).getEventIn("set_type"))).setValue(NType);
      ((EventInSFFloat)((browser.getNode("NavInfo")).getEventIn("set_speed"))).setValue((float)0.5);
    }

  }
}

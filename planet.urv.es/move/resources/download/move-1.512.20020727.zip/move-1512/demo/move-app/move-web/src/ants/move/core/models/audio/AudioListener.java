// Package ants.move.core.models.audio
// AudioListener.java
// (C) 2000 Carles Pairot & Oriol Montal� & Francesc Pi�as
package ants.move.core.models.audio;

/** AudioListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as (fpd@tinet.org)
    @version 1.0 Build 2000
*/
public interface AudioListener {
/**
 * Load audio
 */
  public void loadAudio ();
  /**
   * Play audio
   * @param track track
   */
  public void playAudio (String track);
  /**
   * Stop
   */
  public void stopAudio ();
  /**
   * destroy
   */
  public void destroy();
}

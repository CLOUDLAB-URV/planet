package ants.comm.examples;

import java.io.*;


public class Persona implements Serializable

{
	public String name;
	public int edad;
	
	
	
	
	
}
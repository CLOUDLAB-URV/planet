package ants.core.rmi;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.rmi.server.*;
import ants.core.*;
import java.rmi.*;
import java.util.*;
import ants.move.ejb.*;
import com.protomatter.syslog.*;

public class ThingGatewayImpl extends UnicastRemoteObject implements ThingGateway {

    private ants.move.ejb.Thing currentThing;
    private javax.naming.Context initial;
    private ThingManager thingManager = null;


    public ThingGatewayImpl (Hashtable env) throws java.rmi.RemoteException {
      try {
      Syslog.debug (this, "Getting InitialContext reference...");
      initial = new InitialContext (env);
      Syslog.debug (this, "Looking up ThingManager...");
      Object obj3 = initial.lookup ("java:comp/env/ThingManagerBean");
      Syslog.debug (this, "Creating ThingManager reference...");
      ThingManagerHome thHome = (ThingManagerHome)
                              PortableRemoteObject.narrow (obj3, ThingManagerHome.class);
      thingManager = thHome.create();
      Syslog.debug (this, "InitialContext for ants.core.rmi.ThingGateway remote object gotten OK.");
      } catch (Exception ex) {
        Syslog.debug (this, "Error Initializing context.");
        Syslog.log (this, ex);
      }
    }
    public synchronized String getName (String tKey) throws java.rmi.RemoteException{
      try{
        currentThing=thingManager.getThing(tKey);
        return(currentThing.getName());
      } catch (Exception ex){
        Syslog.error (this, ex);
      }
      return null;
    }
    public synchronized String getDescription (String tKey) throws java.rmi.RemoteException{
      try{
        currentThing=thingManager.getThing(tKey);
        return(currentThing.getDescription());
      } catch (Exception ex){
        Syslog.error (this, ex);
      }
      return null;
    }
    public synchronized String getPlaceId (String tKey) throws java.rmi.RemoteException{
      try{
        currentThing=thingManager.getThing(tKey);
        return(currentThing.getPlaceId());
      } catch (Exception ex){
        Syslog.error (this, ex);
      }
      return null;
    }
    public synchronized String getToolId (String tKey) throws java.rmi.RemoteException{
      try{
        currentThing=thingManager.getThing(tKey);
        return(currentThing.getToolId());
      } catch (Exception ex){
        Syslog.error (this, ex);
      }
      return null;
    }

    public synchronized void setProperty(String tKey, String propName, String propValue)throws java.rmi.RemoteException{

      try {
        currentThing=thingManager.getThing(tKey);
        currentThing.setProperty (propName, propValue);
      }
      catch (Exception ex) {
        Syslog.error(this, ex);
      }
    }

     public synchronized String getProperty (String tKey, String propName) throws java.rmi.RemoteException {

      try {
        currentThing=thingManager.getThing(tKey);
        return(currentThing.getProperty(propName));
      }
      catch (Exception ex) {
        Syslog.error(this, ex+" : "+propName);
      }
      return null;
    }

    public String[] getPropertyNames (String tKey) throws java.rmi.RemoteException {
      Collection c;
/*
      try {
        c = currentThing.getProperties();
        String[] properties = new String[c.size()];

        Iterator i = c.iterator();

        int idx = 0;
        while (i.hasNext()) {
          properties[idx] = ((ants.moo.Property)i.next()).getName();
        }
        return properties;
      }
      catch (Exception ex) {
        Syslog.log(this, ex);
      }
*/
      return null;
    }

    public String[] getIndexedPropertyNames (String tKey) throws java.rmi.RemoteException {
/*      this.getEJBReference(wName, pName, tName);

      Collection c;

      try {
        c = currentThing.getIndexedProperties();
        String[] properties = new String[c.size()];

        Iterator i = c.iterator();

        int idx = 0;
        while (i.hasNext()) {
          properties[idx] = ((ants.moo.IndexedPropertyModel)i.next()).getName();
          idx++;
        }
        return properties;
      }
      catch (Exception ex) {
        Syslog.log(this, ex);
      }
      */
      return null;
    }

    public int getIndexedPropertySize (String tKey, String propName) throws java.rmi.RemoteException {
      try {
        currentThing=thingManager.getThing(tKey);
        return (Integer.parseInt(currentThing.getProperty (propName+"Size")));
      } catch (Exception ex) {
        Syslog.log(this, ex);
      }
      return 0;
    }

    public synchronized String getIndexedProperty (String tKey, String propName, int index) throws java.rmi.RemoteException {

      try{
        currentThing=thingManager.getThing(tKey);
        return (currentThing.getIndexedProperty(propName,index));
      }catch (Exception ex) {
        Syslog.error(this, ex);
      }
      return null;
    }

    public synchronized void setIndexedProperty (String tKey, String propName, String value, int index) throws java.rmi.RemoteException{

      try {
        currentThing=thingManager.getThing(tKey);
        currentThing.setIndexedProperty(propName,value,index);
      } catch (Exception x) {
        Syslog.error(this, x);
      }
    }

}
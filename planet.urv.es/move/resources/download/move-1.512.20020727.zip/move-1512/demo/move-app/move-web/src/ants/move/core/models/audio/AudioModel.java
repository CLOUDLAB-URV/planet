// Package ants.move.core.models.audio
// AudioModel.java
// Implementation of Audio Model
// 2002 Carles Pairot & Oriol Montal� & Francesc Pi�as
package ants.move.core.models.audio;

// Notification Service imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Audio Model.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @author Francesc Pi�as(fpd@tinet.org)
    @version 1.0 Build 2002
*/
public class AudioModel extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  private String thingKey=null;
  private Thing thing;
  private String track="";

  /** Sole & void constructor.
  */
  public AudioModel() {
  }

/**
 * Initialize model
 */
  public void init() {
    try{
      addPropertyChangeListener(this);
      String a= getProperty("audioThing");
      if(!a.equalsIgnoreCase("----")){
        loadAudio(a);
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AudioListener) listeners.elementAt (i)).loadAudio();

        }
      }
      System.err.println("[MOVE] - Audio model initialized.");
    }catch(Exception e){e.printStackTrace();}
  }
/**
 * Add Audio listener
 * @param aList listener
 */
  public void addAudioListener (AudioListener aList) {
    listeners.addElement(aList);
  }
/**
 * Remove audio listener
 * @param aList listener
 */
  public void removeAudioListener (AudioListener aList) {
    listeners.removeElement(aList);
  }


/**
 * Set audio thing in tool
 * @param thingKey key
 */
  public void setAudioThing (String thingKey) {
    try {
      setProperty ("audioThing", thingKey);

    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * Get audio thing key
 * @return key
 */
  public String getAudioThingId () {
    try {
      return getProperty("audioThing");
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
/**
 * Get audio thing
 * @return Thing instance
 */
  public Thing getAudioThing () {
    return thing;
  }
  /**
   * Set audio play or stop
   * @param p true=play false=stop
   */
  public void controlAudio (boolean p) {
    try {
      if (p) {
        setProperty ("playing", "true");
      }
      else {
        if ((getProperty("playing")).equals("true")){
          setProperty ("playing", "false");
        }
      }
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * Is playing
 * @return state
 */
  public String isPlaying() {
    try {
      return getProperty("playing");
    } catch (Exception x) {
      System.err.println("Exception capturing property \"playing\" from ThingTool");
      return null;
    }
  }

  // Loads new audio track
  public void loadAudio (String thingKey) {
   try{
    if(thingKey.equalsIgnoreCase("----")){
      track="";
    }else{
      ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
      thing = new Thing();
      thing.init(ctx, super.getThingGateway());
      track=thing.getProperty("fileName");
    }
   }catch(Exception e){System.err.println("[MOVE] - Error Loading VideoStream2");e.printStackTrace();}
  }


/**
 * Get audio track
 * @return track source url
 */
  public String getAudioTrack(){
    return(track);
  }


  public void propertyChange (PropertyChangeEvent evt) {

    String propName = evt.getPropName();
    // load Audio
    if (propName.equals("audioThing")) {
      loadAudio(evt.getPropValue());
      for (int i = 0; i < listeners.size (); ++ i) {
        ((AudioListener) listeners.elementAt (i)).loadAudio();
      }
    }
    else if (propName.equals("playing")) {
      // Audio must start to be played
      if (evt.getPropValue().equals("true")) {
        for (int i = 0; i < listeners.size (); ++ i) {
          try {
            ((AudioListener) listeners.elementAt (i)).playAudio(getAudioTrack());
          } catch (Exception x) {
            x.printStackTrace();
          }
        }
      }
      // Audio must be stopped
      else {
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AudioListener) listeners.elementAt (i)).stopAudio();
        }
      }
    }
  }

/**
 * tool type
 * @return AUDIO
 */
  public String getType() {
    return "AUDIO";
  }
/**
 * Destroy method
 */
  public void destroy() {
   for (int i = 0; i < listeners.size (); ++ i) {
     ((AudioListener) listeners.elementAt (i)).destroy();
   }
   super.destroy();
  }
}

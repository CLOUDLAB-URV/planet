// Package ants.move.core.models.camera
// CameraListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.camera;

/** CameraListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface CameraListener {
/**
 * Bind camera
 * @param pos position "x y z"
 * @param ori rotation "x y z o"
 */
  public void bind (String pos, String ori);
  /**
   * Unbind camera
   */
  public void unBind();
}

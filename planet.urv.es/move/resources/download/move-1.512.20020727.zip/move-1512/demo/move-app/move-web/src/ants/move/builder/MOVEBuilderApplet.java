package ants.move.builder;

import ants.move.core.*;
import ants.move.core.views.*;
import vrml.external.Node;
import vrml.external.Browser;
import vrml.external.field.*;
import vrml.external.field.EventOutObserver;
import java.applet.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.math.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.*;

/** MOVE! Builder. Main applet.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
*/
public class MOVEBuilderApplet extends Applet implements VRMLEventListener,
                                                         MouseListener {
 // VRMLEventListener is implemented so as to capture all events in
 // VRML browser

  // VRML Browser: it contains the VRML world
  Browser browser = null;

  // Node that locates the avatar position
  private Node[] positionSensor;

  // Main node where objects will be added
  private Node root = null;

  // Nodes for add and remove children objects
  private EventInMFNode addCh,reCh;

  // Variable to capture avatar position
  public static EventOutSFVec3f positionChanged;

  //Variable to capture avatar orientation
  public static EventOutSFRotation orientationChanged;

  // The name of the properties file
  public String propertiesItem;

  // Node that contains avatar's last known position
  Node[] lastNode = null;

  // Applet's images
  private Image undoImage =null;
  private Image addImage = null;
  private Image generateImage = null;
  private Image undoImage2 =null;
  private Image addImage2 = null;
  private Image generateImage2 = null;
  private Image upImage = null;
  private Image downImage = null;
  private Image leftImage = null;
  private Image rightImage = null;
  private Image bigImage = null;
  private Image smallImage = null;
  private Image xyzImage = null;
  private Image x2Image = null;
  private Image y2Image = null;
  private Image z2Image = null;

  //Variables that control scale, rotation and translation of the objects
  private EventInSFVec3f itemTranslation = null;
  private EventInSFVec3f itemScale = null;
  private EventInSFRotation itemRotation = null;
  float[] tempRotate = new float[4];
  float[] lastPos;
  float indexScale = (float) 1.0;
  // Selected axis to rotate: X=1; Y=2; Z=3
  int rotateSelected = 1;
  float indexRotate =(float) 0.0;

  // Mouse pressed indicator
  int pressed = 0;

  // Selected item's icon
  Image itemSelectedImage = null;

  // Choice containing all things names
  java.awt.Choice choiceList;

  // Selected item
  Item itemSelected;

  // Contains all inserted things
  public Room room;

  // Defines the mainRoom WRL
  //  String mainRoom;

  // Information window
  InfoWindow iW;

  // Applet's parameters
  String worldKey;
  String placeKey;
  String userRole;
  String userLogin;
  String placeType;

  // Relation between touchSensors and Nodes
  Hashtable touchesNodes;

  // Relation between touchSensors and Items
  Hashtable touchesItems;
  //Tools in system
  Properties tools;
  // Connect to MOVEBuilderRemoteEngine
  MOVEBuilderRemote comp = null;



  // Applet's initialization method
  public void init() {
    // Initialize components
    printMsg("Welcome to MOVE! Builder.");
    printMsg("Created by Oriol Montal�, Carles Pairot 1999-2002");
    choiceList = new java.awt.Choice ();
    touchesNodes = new Hashtable ();
    touchesItems = new Hashtable ();
    MediaTracker tracker = new MediaTracker (this);

    worldKey= this.getParameter("worldKey");
    placeKey= this.getParameter("placeKey");
    userRole= this.getParameter("userRole");
    userLogin= this.getParameter("userLogin");
    placeType= this.getParameter("placeType");

    // Load properties file
    // This file contains all the available static objects
    // These are the objects that can be inserted in the world
    propertiesItem = "resources/util/item.properties";
    String propertiesTools = "resources/util/tools.properties";

    try {
      URL url = new URL ((this.getCodeBase()).toString() + propertiesItem);
      java.util.Properties props = new java.util.Properties ();
      props.load (url.openStream());

      url = new URL ((this.getCodeBase()).toString() + propertiesTools);
      tools = new java.util.Properties ();
      tools.load(url.openStream());

      for (int i = 0; i < Integer.parseInt (props.getProperty ("ObjectsNum")); i++) {
        String addToList = props.getProperty ("ObjName" + i);
        addToList = addToList.substring (0, addToList.length()-4);
        // Add all static objects to the list
        choiceList.addItem (addToList);
      }

      for (Enumeration en=tools.elements();en.hasMoreElements();) {
        // Add all tool  to the list
        choiceList.addItem ((String)en.nextElement());
      }


      // Initialize MOVE!'s Constants file
      url = new URL (this.getCodeBase() + "..");

      // Load all images
      undoImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/undo.jpg"));
      tracker.addImage (undoImage, 1);
      addImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/add.jpg"));
      tracker.addImage (addImage, 1);
      generateImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/generate.jpg"));
      tracker.addImage (generateImage, 1);
      undoImage2 = getImage (new URL (this.getDocumentBase(), "resources/builderImages/undo2.jpg"));
      tracker.addImage (undoImage2, 1);
      addImage2 = getImage (new URL (this.getDocumentBase(), "resources/builderImages/add2.jpg"));
      tracker.addImage (addImage2, 1);
      generateImage2 = getImage (new URL (this.getDocumentBase(), "resources/builderImages/generate2.jpg"));
      tracker.addImage (generateImage2, 1);
      upImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/up.jpg"));
      tracker.addImage (upImage, 1);
      downImage = getImage (new URL (this.getDocumentBase() ,"resources/builderImages/down.jpg"));
      tracker.addImage (downImage, 1);
      leftImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/left.jpg"));
      tracker.addImage (leftImage, 1);
      rightImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/right.jpg"));
      tracker.addImage (rightImage, 1);
      bigImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/big.jpg"));
      tracker.addImage (bigImage, 1);
      smallImage = getImage(new URL (this.getDocumentBase(), "resources/builderImages/small.jpg"));
      tracker.addImage (smallImage, 1);
      xyzImage = getImage (new URL (this.getDocumentBase(), "resources/builderImages/xyz.jpg"));
      tracker.addImage (xyzImage, 1);
      x2Image = getImage (new URL (this.getDocumentBase(), "resources/builderImages/x2.jpg"));
      tracker.addImage (x2Image, 1);
      y2Image = getImage (new URL (this.getDocumentBase(), "resources/builderImages/y2.jpg"));
      tracker.addImage (y2Image, 1);
      z2Image = getImage (new URL (this.getDocumentBase(), "resources/builderImages/z2.jpg"));
      tracker.addImage (z2Image, 1);

      tracker.waitForAll ();

      // Add itemList ActionListener
      choiceList.addItemListener (new java.awt.event.ItemListener() {
        public void itemStateChanged (ItemEvent e) {
          choiceList_actionPerformed (e);
        }
      });

      // Add MouseListener
      addMouseListener (this);

    } catch (Exception e) {
      printMsg ("Exception occured in Applet's init() method: " + e);
    }

    // Wait for 2 seconds to allow VRML Browser to be completely loaded
    try {
      java.lang.Thread.sleep(2000);
    } catch (InterruptedException e) {}




    try {
      comp = (MOVEBuilderRemote) Naming.lookup ("//"+this.getCodeBase().getHost()+":1152/move/MoveBuilder");
   //   printMsg ("Connection to MOVEBuilder Remote Engine is OK.");
    } catch (Exception wN) {
      printMsg ("Unable to locate MOVEBuilder Remote Engine: " + wN);
    }

   // Let's load the place. All things will be stored in 'room' variable
    try {
      room = comp.load3DPlace (worldKey, placeKey, userRole, userLogin, placeType);
    } catch (Exception x) {
      printMsg ("Unable to load place's VRML representation: " + x);
    }


    // Capture the VRML browser
    browser = (Browser) vrml.external.Browser.getBrowser (this);

    // Capture Root node
    root = browser.getNode ("ROOT");

    // Capture Nodes

    addCh = (EventInMFNode) root.getEventIn ("addChildren");
    reCh = (EventInMFNode) root.getEventIn ("removeChildren");

    // Insert a proximity sensor to capture avatar's position
    positionSensor = browser.createVrmlFromString (vrmlPS());
    addCh.setValue (positionSensor);

    // Capture position & orientation Nodes
    positionChanged = (EventOutSFVec3f) positionSensor[0].getEventOut ("position_changed");
    orientationChanged = (EventOutSFRotation) positionSensor[0].getEventOut ("orientation_changed");

    setLayout (new BorderLayout());

    // Add things list
    add (BorderLayout.SOUTH, choiceList);



    // Add the contents of the place to the VRML browser
    setVRMLPlace (room);

    // At this point, the applet is loaded and ready to use. The contents of the place
    // are loaded in the VRML browser
  }

  // Applet's start method: does nothing
  public void start() {}

  // Applet's paint method
  public void paint (Graphics g) {
    // Paint images
    try {
      this.setBackground(Color.white);
      g.drawRect(1,1,98,347);
      g.setFont(new Font("Arial",Font.BOLD,12));
      g.drawString("Preview:",4,230);
      g.drawString("Translation:",4,70);
      g.drawString("Scale:",4,135);
      g.drawString("Rotation:",4,175);
      g.drawImage (undoImage, 50, 30, this);
      g.drawImage (addImage, 10, 30, this);
      g.drawImage (generateImage, 25, 5, this);
      if (itemSelectedImage != null)
        g.drawImage (itemSelectedImage, 1, 235, this);
      g.drawImage (upImage, 30, 80, this);
      g.drawImage (downImage, 30, 100, this);
      g.drawImage (rightImage, 50, 90, this);
      g.drawImage (leftImage, 10, 90, this);
      g.drawImage (bigImage, 20, 140, this);
      g.drawImage (smallImage, 50, 140, this);
      g.drawImage (upImage, 70, 80, this);
      g.drawImage (downImage, 70, 100, this);
      g.drawImage (xyzImage, 20, 180, this);
      g.drawImage (leftImage, 20, 200, this);
      g.drawImage (rightImage, 50, 200, this);

      switch (rotateSelected) {
        case 1: g.drawImage (x2Image, 20, 180, this);
                break;
        case 2: g.drawImage (y2Image, 20, 180, this);
                break;
        case 3: g.drawImage (z2Image, 20, 180, this);
                break;
        default: break;
      }

      switch (pressed) {
        case 1: g.drawImage (addImage2, 10, 30, this);
                break;
        case 2: g.drawImage (undoImage2, 50, 30, this);
                break;
        case 3: g.drawImage (generateImage2, 25, 5, this);
                break;
        default: break;
      }
    } catch (Exception e) {
      printMsg ("Applet's paint method failure.");
    }
  }

  private boolean isTool(String in){
    Enumeration en=tools.elements();
    while(en.hasMoreElements()){
      if(((String)en.nextElement()).equalsIgnoreCase(in)){
        return true;
      }
    }
    return false;
  }

  private boolean isLink(String in){
    if(in.equalsIgnoreCase("link.v01")){
      return true;
    }
    return false;
  }

  // ItemList event handler
  public void choiceList_actionPerformed (ItemEvent e) {
    // Capture the selected thing

      try {
        // Load selected thing's icon
        URL url = new URL ((this.getCodeBase()).toString() +
                            "resources/things/" + (choiceList.getSelectedItem()).trim() + ".jpg");
        itemSelectedImage = this.getImage(url);
      } catch (Exception ex) {
          printMsg ("Error getting thing's icon");
      }
      repaint();
  }

  // MouseDown event handler
  public void mousePressed (MouseEvent e) {
    // Capture which button is pressed
    int i = e.getX();
    int j = e.getY();

    // Case addButton
    if (((i > 1) && (i < 50)) && ((j > 30) && (j < 50))) {
      itemSelected = new Item();
      // Delete spaces
      itemSelected.setName ((choiceList.getSelectedItem()).trim());
      if(isTool(itemSelected.getName())){
        if(isLink(itemSelected.getName())){
          addToVRML (itemSelected);
          itemSelected.setType("link");
          SelectWorldWindow sww=new SelectWorldWindow(itemSelected,comp);
          addThing (itemSelected);
        }else{
          addToVRML (itemSelected);
          addTool (itemSelected);
        }
      }else{
        addToVRML (itemSelected);
        addThing (itemSelected);
      }

      pressed = 1;
      repaint();

    // Case removeButton
    } else if (((i > 51) && (i < 100)) && ((j > 30) && (j < 50))) {
//      if (!(itemSelected.getType().equalsIgnoreCase ("tool"))) {
      reCh.setValue (lastNode);
      room.removeItem (itemSelected);
//      }
      pressed = 2;
      repaint();

    // Case save
    } else if (((i > 25) && (i < 75)) && ((j > 5) && (j < 25))) {
      try {
        // Connect to server and store all information
        iW = new InfoWindow ("World Builder Dialog", "----Please Wait----");
        iW.setEnabledButton (false);

        // Locate RMI Object
//        MOVEBuilderRemote comp = (MOVEBuilderRemote)
//                                  Naming.lookup ("//"+this.getCodeBase().getHost()+":1152/move/MoveBuilder");
        comp.store3DPlaceInMOO (room, userLogin);
        iW.setText ("=== World updated ===");
        iW.setEnabledButton (true);
      } catch (Exception ex) {
          iW.close();
          ex.printStackTrace();
          iW = new InfoWindow("World Builder Error", "Unable to locate RMI Server.");
      }
      pressed = 3;
      repaint ();

    // Case upButton
    } else if (((i > 30) && (i < 50)) && ((j > 80) && (j < 100))) {
      lastPos[1] += (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case downButton
    } else if (((i > 30) && (i < 50)) && ((j > 100) && (j < 120))) {
      lastPos[1] -= (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case rightButton
    } else if (((i > 50) && (i < 70)) && ((j > 90) && (j < 110))) {
      lastPos[0] += (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case leftButton
    } else if (((i > 10) && (i < 30)) && ((j > 90) && (j < 110))) {
      lastPos[0] -= (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case scaleUpButton
    } else if (((i > 20) && (i < 40)) && ((j > 140) && (j < 160))) {
      indexScale += (float) 0.2;
      float[] upScale = new float[3];
      upScale[0] = indexScale;
      upScale[1] = indexScale;
      upScale[2] = indexScale;
      itemScale.setValue (upScale);
      itemSelected.setScale (upScale);

    // Case scaleDownButton
    } else if (((i > 50) && (i < 70)) && ((j > 140) && (j < 160))) {
      if (indexScale >= 0.4) {
        indexScale -= (float) 0.2;
        float[] downScale = new float[3];
        downScale[0] = indexScale;
        downScale[1] = indexScale;
        downScale[2] = indexScale;
        itemScale.setValue(downScale);
        itemSelected.setScale(downScale);
      }

    // Case nearButton
    } else if (((i > 70) && (i < 90)) && ((j > 80) && (j < 100))) {
      lastPos[2] -= (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case farButton
    } else if (((i > 70) && (i < 90)) && ((j > 100) && (j < 120))) {
      lastPos[2] += (float) 0.1;
      itemTranslation.setValue (lastPos);
      itemSelected.setTranslation (lastPos);

    // Case XButton
    } else if (((i > 22) && (i < 40)) && ((j > 180) && (j < 200))) {
      rotateSelected = 1;
      indexRotate = (float) 0.0;

    // Case YButton
    } else if (((i > 40) && (i < 58)) && ((j > 180) && (j < 200))) {
      rotateSelected = 2;
      indexRotate = (float) 0.0;

    // Case ZButton
    } else if (((i > 58) && (i < 80)) && ((j > 180) && (j < 200))) {
      rotateSelected = 3;
      indexRotate = (float) 0.0;

    // Case RotateRightButton
    } else if (((i > 50) && (i < 70)) && ((j > 200) && (j < 220))) {
      indexRotate += (float) 0.2;
      if (indexRotate >= 6.28)
        indexRotate -= 6.28;

      switch (rotateSelected) {
        case 1: tempRotate[0] = (float) 1.0;
                tempRotate[1] = (float) 0.0;
                tempRotate[2] = (float) 0.0;
                tempRotate[3] = indexRotate;
                break;
        case 2: tempRotate[0] = (float) 0.0;
                tempRotate[1] = (float) 1.0;
                tempRotate[2] = (float) 0.0;
                tempRotate[3] = indexRotate;
                break;
        case 3: tempRotate[0] = (float) 0.0;
                tempRotate[1] = (float) 0.0;
                tempRotate[2] = (float) 1.0;
                tempRotate[3] = indexRotate;
                break;
        default: break;
      }

      itemRotation.setValue (tempRotate);
      itemSelected.setRotation (tempRotate);

    // Case RotateLeftButton
    } else if (((i > 20) && (i < 40)) && ((j > 200) && (j < 220))) {
      indexRotate -= (float) 0.2;
      if (indexRotate <= -6.28)
        indexRotate += 6.28;

      switch (rotateSelected) {
        case 1: tempRotate[0] = (float) 1.0;
                tempRotate[1] = (float) 0.0;
                tempRotate[2] = (float) 0.0;
                tempRotate[3] = indexRotate;
                break;
        case 2: tempRotate[0] = (float) 0.0;
                tempRotate[1] = (float) 1.0;
                tempRotate[2] = (float) 0.0;
                tempRotate[3] = indexRotate;
                break;
        case 3: tempRotate[0] = (float) 0.0;
                tempRotate[1] = (float) 0.0;
                tempRotate[2] = (float) 1.0;
                tempRotate[3] = indexRotate;
                break;
        default: break;
      }

      itemRotation.setValue (tempRotate);
      itemSelected.setRotation (tempRotate);
    }
  }

  // MouseUp event handler
  public void mouseReleased (MouseEvent e) {
    pressed = 0;
    repaint ();
  }

  // Not used mouse event handlers
  public void mouseClicked (MouseEvent e) {}
  public void mouseEntered (MouseEvent e) {}
  public void mouseExited (MouseEvent e) {}

  /**
   * Method that returns a string containing a ProximitySensor in VRML code
   */
   public String vrmlPS() {
    return("\nDEF PS ProximitySensor {\n"+
           "                          center 0 0 0\n"+
           "                          size 10000 10000 10000\n"+
           "                          enabled TRUE}\n");
  }


  /**
  * Method that inserts the room in the VRML browser
  */
  public void setVRMLPlace (Room room) {
    int count = 0;
    for (Enumeration e = room.getItems(); e.hasMoreElements(); ) {
      Item itemSelected = (Item) e.nextElement();
      String url = new String (itemSelected.getName() + ".wrl");
      float[] sc = itemSelected.getScale();
      float[] rot = itemSelected.getRotation();
      float[] trans = itemSelected.getTranslation();

      // This object will we the template, so no TouchSensor is linked to it
      // All templates must start wit the keyword 'main'
         
      if ((itemSelected.getName()).equals("main")) {

        String main =
          "\nTransform{\n" +
          "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
          "     scale " + sc[0] + " " + sc[1] + " " + sc[2] + "\n" +
          "     rotation " + rot[0] + " " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
          "        children[\n" +
          "                  Inline { url \""+this.getCodeBase().toString()+"resources/things/places/"+placeType+"/"+url+"\"}  ]\n" +
          "}\n\n";
        addCh.setValue (browser.createVrmlFromString(main));

      // Every object is linked to a TouchSensor so as it is selectable.
      // This TouchSensor is Routed to a Script so as catching the VRML is possible
       }else {
        String vrml =
          "\nTransform{\n" +
          "     translation " + trans[0] + " " + trans[1] + " " + trans[2] + "\n" +
          "     scale " + sc[0] + " " + sc[1] + " " + sc[2] + "\n" +
          "     rotation " + rot[0] + " " + rot[1] + " " + rot[2] + " " + rot[3] + "\n" +
          "        children[\n" +
          "                  DEF TS1 TouchSensor{}\n" +
          "                  Inline {url \""+this.getCodeBase().toString()+"resources/things/" + url + "\"}  ]\n" +
          "}\n" +
          "DEF TS2 Script{\n" +
          " eventIn SFBool active\n" +
          " eventOut SFBool eOut\n" +
          " url \"javascript: \n" +
          " function active(value)\n" +
          " { if (eOut == TRUE) eOut=FALSE;\n" +
          "     else eOut=TRUE;}\"" +
          "}\n" +
          "ROUTE TS1.isActive TO TS2.active\n" +
          "\n";
        lastNode = browser.createVrmlFromString (vrml);
        addCh.setValue (lastNode);

        // Let's capture the node that will tell us if the TouchSensor
        // has been pressed or not
        EventOutSFBool TS = (EventOutSFBool) (lastNode[1]).getEventOut ("eOut");
        VRMLZone zone = new VRMLZone ();
        zone.addVRMLEventListener (this, "T" + count);
        TS.advise (zone, "T" + count);
        // Add the TouchSensor and the matching VRML node to touchesNodes Hashtable
        touchesNodes.put (TS, lastNode);
        // Add the TouchSensor and the matching Item to touchesItems Hashtable
        touchesItems.put (TS, itemSelected);
      }
      count++;
    }
  }

  // This method is the VRML event handler
  public void eventPerformed() {
    // Any of the TouchSensors has been pressed here
    EventOutSFBool TS;
    for (Enumeration enum = touchesNodes.keys(); enum.hasMoreElements();) {
      TS = (EventOutSFBool) enum.nextElement();
      // Search the Hashtable to see which TouchSensor is active
      if (TS.getValue() == true) {
        // Get the VRML node
        Node[] n = (Node[]) touchesNodes.get (TS);
        // Get VRML-selected Item
        itemSelected = (Item) touchesItems.get (TS);
        // Get Item's translation, rotation and scaling factor
        itemTranslation = (EventInSFVec3f) n[0].getEventIn ("translation");
        itemRotation=(EventInSFRotation) n[0].getEventIn ("rotation");
        itemScale=(EventInSFVec3f) n[0].getEventIn ("scale");
        // Update position
        lastPos = itemSelected.getTranslation();
        //Update rotation
        indexRotate=(itemSelected.getRotation())[3];
        //Update Scale
        indexScale=(itemSelected.getScale())[2];
        // Update VRML node
        lastNode = n;
//        System.err.println("Selected Item NODE: Pos:"+lastPos[0]+" "+lastPos[1]+" "+lastPos[2]);

        try {
          // Load selected Item's icon
          URL url = new URL ((this.getCodeBase()).toString() +
                             "resources/things/" + itemSelected.getName() + ".jpg");

          itemSelectedImage = getImage (url);
        } catch (Exception e) {
          // The object had no icon
        }
        repaint();
        return;
      }
    }
  }

  /**
  * Method that adds a VRML representation of an object to the VRML browser
  */
  public void addToVRML (Item item) {
    float[] posNow = new float[3];
    float[] oriNow = new float[4];

    posNow = positionChanged.getValue();
    oriNow = orientationChanged.getValue();
    oriNow[3] += 3.1416;
    posNow[2] += Math.cos ((double)oriNow[3]);
    posNow[0] += Math.sin ((double)oriNow[3]);
    lastPos = posNow;

    // Create VRML code and insert it in the VRML Browser
    String stringInline =
      "\nTransform{\n" +
      "     translation " + posNow[0] + " " + posNow[1] + " " + posNow[2] + "\n" +
      "        children[\n" +
      "                  DEF TS1 TouchSensor{}\n" +
      "                  Inline {url \""+this.getCodeBase().toString()+"resources/things/" + item.getName() + ".wrl\"}  ]\n" +
      "}\n" +
      "DEF TS2 Script{\n" +
      " eventIn SFBool active\n" +
      " eventOut SFBool eOut\n" +
      " url \"javascript: \n" +
      " function active(value)\n" +
      " { if (eOut == TRUE) eOut=FALSE;\n" +
      "     else eOut=TRUE;}\"" +
      "}\n" +
      "ROUTE TS1.isActive TO TS2.active\n" +
      "\n";

    indexScale = 1;
    indexRotate = 0;
    lastNode = browser.createVrmlFromString (stringInline);
    itemTranslation = (EventInSFVec3f) lastNode[0].getEventIn ("translation");
    itemRotation = (EventInSFRotation) lastNode[0].getEventIn ("rotation");
    itemScale = (EventInSFVec3f) lastNode[0].getEventIn ("scale");
    addCh.setValue (lastNode);
    EventOutSFBool TS = (EventOutSFBool) (lastNode[1]).getEventOut ("eOut");
    VRMLZone zone = new VRMLZone();
    zone.addVRMLEventListener (this, "T" + posNow[0]);
    TS.advise (zone, "T" + posNow[0]);
    touchesNodes.put (TS, lastNode);
    touchesItems.put (TS, item);
  }


  /**
  * Method that adds a new object to variable 'room', which is the container
  * of all the objects in a 3D place
  */
  public void addThing (Item item) {
    item.setTranslation (lastPos);
    item.setRotation (tempRotate);
    float[] sc = new float[3];
    sc[0] = sc[1] = sc[2] = indexScale;
    item.setScale (sc);
//    item.setType ("thing");
    room.addItem (item);
    indexRotate = 0;
    indexScale = 1;
    tempRotate[0] = (float) 1.0;
    tempRotate[1] = (float) 0.0;
    tempRotate[2] = (float) 0.0;
    tempRotate[3] = (float) 0.0;
  }

  public void addTool (Item item) {
    item.setTranslation (lastPos);
    item.setRotation (tempRotate);
    float[] sc = new float[3];
    sc[0] = sc[1] = sc[2] = indexScale;
    item.setScale (sc);
    item.setType ("tool");
    item.setToolId("Model");
    room.addItem (item);
    indexRotate = 0;
    indexScale = 1;
    tempRotate[0] = (float) 1.0;
    tempRotate[1] = (float) 0.0;
    tempRotate[2] = (float) 0.0;
    tempRotate[3] = (float) 0.0;
  }


  /**
  * Applet's destroy method
  */
  public void destroy() {
    browser.destroy();
  }

  /**
  * Prints a message to the Java Console
  */
  private void printMsg (String msg) {
    System.err.println ("[MOVEBuilder] - " + msg);
  }
}

package ants.move.core.models.doc;

import ants.core.*;

public class DocThing extends Thing implements PropertyChangeListener {
  private DocModel dM;
  private String myId;

  public void init() {
    addPropertyChangeListener(this);
    myId=getContext().getThing();
//    System.err.println("[MOVE] - Doc " + getContext().getThing() + " initialized.");
  }

  public void setModel (DocModel m) {
    dM = m;
  }

  public DocModel getModel () {
    return dM;
  }


  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();
    try {
      // Translation change
      if (propName.equals("translation")) {
        dM.refreshThing(myId);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void destroy () {
    super.destroy();
  }
}
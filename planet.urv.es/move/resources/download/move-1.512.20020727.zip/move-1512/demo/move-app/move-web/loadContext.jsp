<%@ page session="true" import = "java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>
<%

//load to session all SessionBean
   try {
      Context initial = new InitialContext();
      //load worldManager
      Object obj = initial.lookup("java:comp/env/WorldManagerBean");
      WorldManagerHome home1 = (WorldManagerHome) PortableRemoteObject.narrow (obj, WorldManagerHome.class);
      WorldManager wm = home1.create();
      session.setAttribute("worldManager",wm);

      //load placeManager
      obj = initial.lookup("java:comp/env/PlaceManagerBean");
      PlaceManagerHome home2 = (PlaceManagerHome) PortableRemoteObject.narrow (obj, PlaceManagerHome.class);
      PlaceManager pm = home2.create();
      session.setAttribute("placeManager",pm);


      //load toolManager
      obj = initial.lookup("java:comp/env/ToolManagerBean");
      ToolManagerHome home3 = (ToolManagerHome) PortableRemoteObject.narrow (obj, ToolManagerHome.class);
      ToolManager tm = home3.create();
      session.setAttribute("toolManager",tm);


      //load thingManager
      obj = initial.lookup("java:comp/env/ThingManagerBean");
      ThingManagerHome home4 = (ThingManagerHome) PortableRemoteObject.narrow (obj, ThingManagerHome.class);
      ThingManager thm = home4.create();
      session.setAttribute("thingManager",thm);

      //load userManager
      obj = initial.lookup("java:comp/env/UserManagerBean");
      UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow (obj, UserManagerHome.class);
      UserManager um = home5.create();
      session.setAttribute("userManager",um);

      response.sendRedirect("listWorlds.jsp");
   } catch (Exception e) {
      Syslog.log (this, e);
   }
%>
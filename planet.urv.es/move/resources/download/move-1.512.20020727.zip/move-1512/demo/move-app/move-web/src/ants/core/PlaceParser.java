package ants.core;

import ants.comm.*;
import java.util.*;

public class PlaceParser implements RemoteEventListener
{
	private Place place;


	public PlaceParser(Place ch)
	{
		this.place = ch;
	}

	public void eventArrived(Hashtable evt)
	{
		String action = (String)evt.get(Context.METHOD);
		Vector listeners = (Vector)place.getListeners().clone ();


		if (action.equals("JOIN"))
		{

			String user = (String)evt.get(Context.USER);
			if (!user.equals(place.getUser()))
			{
//		              place.addUser(user);
//			      place.sendUsers();

				for (int i = 0; i < listeners.size (); ++ i)
				{
      	  ((PlaceListener) listeners.elementAt (i)).userJoined(user);
				}
			}
		} else if (action.equals("LEAVE"))
		{
			String user = (String)evt.get(Context.USER);
			if (!user.equals(place.getUser()))
			{
//                        place.removeUser(user);

			for (int i = 0; i < listeners.size (); ++i) {
        ((PlaceListener) listeners.elementAt (i)).userLeft(user);
				}
                      }
/*                }
      else if (action.equals("ASK")) {  // We are asked for our name
        String user = (String)evt.get(Context.USER);
        if (!user.equals(place.getUser())) {  // I don't answer if it is me
          Hashtable evtp = new Hashtable();
          evtp.put(Context.WORLD, place.getWorld());
          evtp.put(Context.PLACE, place.getPlaceName());
          evtp.put(Context.CLASS, "PLACE");
          evtp.put(Context.METHOD, "ANSWER");
          evtp.put(Context.USER, user);

          // We answer sending our name
          try {
            place.send(evtp);
          }
          catch (Exception s) {
            System.err.println("Exception sending 'answer' event: " + s);
          }
        }
    // Answer received: add old, previously-existing avatar
    else if (action.equals("ANSWER")) {
      // If avatar has not been added yet
      if (!(place.contains((String)evt.get("USER")))) {
        place.addUser((String)evt.get("USER"));
      }
    }
*/

		}	else if (action.equals("USERS"))
                {	for (int i = 0; i < listeners.size (); ++ i) {
        ((PlaceListener) listeners.elementAt (i)).usersChanged((String) evt.get("USERS"));

					}

/*		{

			if (!place.isOn())
			{
					place.cleanUsers();
					String list = (String)evt.get("USERS");
					StringTokenizer sT = new StringTokenizer(list);

					while (sT.hasMoreTokens())
					{
							place.addUser(sT.nextToken());
					}
					place.on();
			}
*/
		}  else if (action.equals("MSG"))
		{

			String to = (String)evt.get("TO");
			String usr = (String)evt.get(Context.USER);



			if (to.equals("ALL"))
			{

					for (int i = 0; i < listeners.size (); ++ i) {
        ((PlaceListener) listeners.elementAt (i)).onMessage(evt);

					}
			}else if(to.equals("REST")&&!usr.equals(place.getUser()))
			{

					for (int i = 0; i < listeners.size (); ++ i)
					{
      		  ((PlaceListener) listeners.elementAt (i)).onMessage(evt);

					}

			}else {

					if (to.equals(place.getUser()))
							for (int i = 0; i < listeners.size (); ++ i)
					     		  ((PlaceListener) listeners.elementAt (i)).onMessage(evt);

				}

		}	else if (action.equals("BAN"))
		{
					String user = place.getUser();
					String target = (String)evt.get("TARGET");
			if (user.equals(target))
			{

				try{
						place.close();
					}catch(SessionException e){}
			}
		}



	}


}
package ants.core;

import java.util.*;

/**
*		Key class responsible for coordination purposes. It checks if a specific action can be performed
* by consulting all registered managers in current session.
*
*/


public class PolicyManager
{
	
	
	private Hashtable managers= new Hashtable();
//	private Vector listeners = new Vector();
	
	public boolean checkValid(VetoableActionEvent vE)
	throws PropertyVetoException
	{

				
		Hashtable managers = (Hashtable) this.managers.clone ();
		Enumeration e = managers.elements();
		
		while (e.hasMoreElements ())
				((VetoableActionListener) e.nextElement()).vetoableAction(vE);
		return true;
	}
	

/**
*	 Adds a new Coordination manager with a specified Id.
* @param id Manager Id
* @param vL Coordination manager
*
*/

	public void addVetoableActionListener(String id, VetoableActionListener vL)
	{
		managers.put(id,vL);
	}
	
/**
*	 Removes a  Coordination manager with a specified Id.
* @param id Manager Id
*
*/


	public void removeVetoableActionListener(String id)
	{
		managers.remove(id);
	}

/**
*	 Gets a Hashtable containing all Coordination Managers.
* @return java.util.Hashtable Dictionary containing ids and coordination managers for this session.
*
*/

	public Hashtable getManagers()
	{
		return managers;	
	}
	
/**
*	 Gets a Coordination Manager with a specified Id.
* @return ants.core.VetoableActionListener A Coordination manager 
*
*/


	public VetoableActionListener getManager(String id)
	{
		return (VetoableActionListener)managers.get(id);
	}
	
}
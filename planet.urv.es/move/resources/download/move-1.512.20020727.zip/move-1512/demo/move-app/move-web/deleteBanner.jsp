<%@ page session="true" import = "java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
  String worldKey=(String)session.getAttribute("worldId");
  String placeKey=(String)session.getAttribute("placeId");

   try {
      String key_string = request.getParameter("thingId");
      
      String path_directory = pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+key_string;

      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      FileDeleter fd = new FileDeleter (path_directory);
      fd.delete();
      Syslog.debug (this, "Banner deleted from disk.");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      thm.removeThing(key_string);
      response.sendRedirect("listThings.jsp");

   } catch (Exception e) {
      System.out.println(e);
   }
%>
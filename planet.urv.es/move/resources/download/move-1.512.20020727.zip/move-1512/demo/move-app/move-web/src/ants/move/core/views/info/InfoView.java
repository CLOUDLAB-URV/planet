// 2002 Carles Pairot & Oriol Montal� & Carles Pairot & Francesc Pi�as

package ants.move.core.views.info;

import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.info.*;
import ants.move.core.teacher.info.*;
import ants.move.core.*;

// java.io Package imports
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of information.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 1.0 Build 2002
*/
public class InfoView  implements ViewInterface, InfoListener, VRMLEventListener{

  // VRML Node
  private Node[] node;
  // Texture URL Node EventIn
  private EventInMFString urlTex;
  // Current texture's URL
  private String[] tex = new String [1];
  // model
  private InfoModel iM;
  // current place
  private Place place;
  // browser
  private Browser browser;
  // VRML root node
  private DynamicObject root;
  //src
  private String src;
  //codeBase
  private String codeBase;
  //Touchsensor
  private EventOutSFBool TS;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public InfoView() {
  }

  /** Initializes necessary parameters to use this class.
      This is the way to implement a dynamicObject through DObjectInterface interface.
      @param ht Parameters
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
   try{
    browser=  (Browser)ht.get("browser");
    src=      (String)ht.get("src");
    place=    (Place)ht.get("place");
    root=     (DynamicObject)ht.get("root");
    MOVECoreApplet mc=(MOVECoreApplet)ht.get("MOVECoreApplet");
    codeBase=mc.getCodeBase().toString();
    iM = (InfoModel) place.getModel(src);
    if (iM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: INFORMATION");
    }

    this.loadVRMLRepresentation();

    //Actualize Texture
    this.setInfo(iM.getInformationFile());
    iM.addInfoListener(this);
    System.err.println ("[MOVE] - Info VRML view initialized.");
   }catch(Exception e){System.err.println("[MOVE] - Error initializing info view:"+e);}
  }


    public void loadVRMLRepresentation(){
    String str = new String();
    String auxstr = new String();

    byte[] buffer = new byte[1024];
    int i;

    // Add avatar to VRML scene
    try {
      URL slURL = new URL (codeBase+"resources/things/info.v01.wrl");
      BufferedInputStream bis = new BufferedInputStream(slURL.openStream());

      while((i = bis.read(buffer, 0, 1024)) != -1) {
          auxstr = new String (buffer);
          if (i != 1024) {
            byte[] buf2 = new byte[i];
            for (int k=0; k<i; k++) {
              buf2[k]=buffer[k];
            }
            auxstr = new String (buf2);
          }
          str = str + auxstr;
      }

      bis.close();

      str=str+"  \nDEF script Script{\n" +
                "  eventIn MFString tex\n" +
                "  eventOut MFString picture\n"+
                "  url \"javascript: \n" +
                "    function tex()\n" +
                "    {picture=tex;}\"" +
                "}\n" +
                "ROUTE script.picture TO TEX.set_url\n" +
                "\n";
      node = browser.createVrmlFromString(str);
      urlTex = (EventInMFString) node[(node.length)-1].getEventIn("tex");

      // Create slide's shape node

      str=" Transform\n" +
                "{\n" +
		"translation "+iM.getProperty("translation")+"\n" +
                "rotation "+iM.getProperty("rotation")+"\n" +
		"scale "+iM.getProperty("scale")+"\n" +
  		"children [\n" +
                "       DEF TS1 TouchSensor{}\n" +
  		"]\n" +
	    	"}\n"+
                "DEF TS2 Script{\n" +
                "  eventIn SFBool active\n" +
                "  eventOut SFBool eOut\n" +
                "  url \"javascript: \n" +
                " function active(value)\n" +
                " { if (eOut == TRUE) eOut=FALSE;\n" +
                "     else eOut=TRUE;}\"" +
                "}\n" +
                "ROUTE TS1.isActive TO TS2.active\n" +
                "\n";

      Node[] nodeBase = browser.createVrmlFromString(str);
      TS = (EventOutSFBool)nodeBase[1].getEventOut("eOut");
      VRMLZone zone= new VRMLZone();
      zone.addVRMLEventListener(this,src);
      TS.advise(zone, src);

      root.setaddChValue(nodeBase);
      EventInMFNode ein=(EventInMFNode)nodeBase[0].getEventIn("addChildren");
      ein.setValue(node);

    } catch (Exception e) {System.err.println("Exception occured loading information representation file: " ); e.printStackTrace();}
  }


  public void setInfo (String file) {
    tex[0] = file;
    urlTex.setValue(tex);
  }


  public InfoModel getModel() {
    return iM;
  }

  public void destroy(){
    iM.removeInfoListener(this);

  }

  public void eventPerformed() {
    if (TS.getValue()) {
      if(place.hasPermission("info.v01")){
       Hashtable params = new Hashtable();
       params.put("src",src);
       params.put("place",place);
       params.put("dispName","INFORMATION");

       InfoWindow iw = new InfoWindow();
       iw.init(params);
       iw.showWin();
      }
    }
  }

}

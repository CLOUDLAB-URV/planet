package ants.move.core.models.voter;

import ants.core.*;
import java.util.*;
import ants.util.*;
import ants.comm.*;

public class VoterModel extends Thing implements PropertyChangeListener {
  protected Vector listeners = new Vector();
  private VoterThing vT;

  public void init() {
    addPropertyChangeListener(this);
    System.err.println("[MOVE] - Voter model initialized.");
  }

  public String getTopic() {
    try {
      return getProperty ("voterThing");
    } catch (Exception x) {
      x.printStackTrace();
      return "Error getting voter thing!";
    }
  }

  public int getYes() {
    return vT.getYes();
  }

  public int getNo() {
    return vT.getNo();
  }

  public int getUnknown() {
    return vT.getUnknown();
  }

  public void setVoterThing (String thingKey) {
    try {
      setProperty ("voterThing", thingKey);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public VoterThing getVoterThing () {
    return vT;
  }

  public void loadVotation (String thingKey) {
    ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
    VoterThing vTH = new VoterThing();
    vTH.init(ctx, super.getThingGateway());

    vT = vTH;
  }

  public void addVote (String user) {
    try {
      vT.addTokenToProperty ("usersList", user);
    } catch (Exception pvex) {
      pvex.printStackTrace();
    }
  }

  public void voteYes (int votes) {
    Vector listeners = (Vector) this.listeners.clone ();
    for (int i = 0; i < listeners.size (); ++ i) {
      ((VoterListener) listeners.elementAt (i)).yes(votes, true);
    }
  }

  public void voteNo (int votes) {
    Vector listeners = (Vector) this.listeners.clone ();
    for (int i = 0; i < listeners.size (); ++ i) {
      ((VoterListener) listeners.elementAt (i)).no(votes, true);
    }
  }

  public void voteUnknown (int votes) {
    Vector listeners = (Vector) this.listeners.clone ();
    for (int i = 0; i < listeners.size (); ++ i) {
      ((VoterListener) listeners.elementAt (i)).unknown(votes, true);
    }
  }

  public void addVoterListener (VoterListener vList) throws SessionException {
    listeners.addElement(vList);
  }

  public void removeVoterListener (VoterListener vList) {
    listeners.remove(vList);
  }

  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();

    // Active topic changed
    if (propName.equals("voterThing")) {
      Vector listeners = (Vector) this.listeners.clone ();
      // Destroy the last thing (if initialized)
      if (vT != null) {
        vT.destroy();
      }
      loadVotation (evt.getPropValue());
      for (int i = 0; i < listeners.size (); ++ i) {
        ((VoterListener) listeners.elementAt (i)).setVoterThing (vT);
      }
    }
  }

  public String getType() {
    return "VOTER";
  }

  public void destroy() {
//    removePropertyChangeListener (this);
    if (vT != null) {
      vT.destroy();
    }
    super.destroy();
  }
}
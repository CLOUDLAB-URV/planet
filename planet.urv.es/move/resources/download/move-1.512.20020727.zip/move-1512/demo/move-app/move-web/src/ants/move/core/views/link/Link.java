// Package ants.move.core.views.link
// Link.java
// Implementation of Link
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.views.link;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

import ants.move.core.views.*;

// MOVECoreApplet applet import
import ants.move.core.MOVECoreApplet;

/** Implementation of Link.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.10 Build 2000
*/
public class Link implements VRMLEventListener {
  // VRML Zone
  private VRMLZone linkZone;
  // VRML Node
  private Node node;
  // Zone change EventOut
  private EventOutSFBool anchorSensor;
  // VRML Node name
  private String VRMLNodeName;
  // MUWorld applet reference
  private MOVECoreApplet mb;

  /** Sole constructor.
      @param z Zone name
      @param b Reference to VRML browser
      @param n VRML Node name
      @param w MUWorld applet reference
      @exception exceptions No exceptions thrown
  */
  public Link (String z, Browser b, String n, MOVECoreApplet mbr) {
    VRMLNodeName = n;
    mb = mbr;

    try {
      // Get VRML Node by name
      node = b.getNode(VRMLNodeName);
    } catch (Exception e) {
        System.out.println("NODE " + VRMLNodeName + " NOT FOUND!!!");
    }

    // Add VRMLEventListener to this DynamicObject
    linkZone = new VRMLZone();
    linkZone.addVRMLEventListener(this, VRMLNodeName);

    // Capture VRML Events produced by anchorSensor
    anchorSensor = (EventOutSFBool) b.getNode(VRMLNodeName + "TS").getEventOut("isActive");
    anchorSensor.advise(linkZone, VRMLNodeName);
  }

  /** Executed when a VRML Event is received.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventPerformed () {
    if (anchorSensor.getValue()) {
      System.err.println("Zone change detected. Going to " + VRMLNodeName);
      mb.zoneChange = true;
    }
  }
}

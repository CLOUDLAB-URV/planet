package ants.move.builder;

// java.awt Package imports
import java.awt.*;
import ants.move.builder.*;
import java.util.*;
import java.net.*;
import java.awt.event.*;
import java.rmi.*;

public class SelectWorldWindow extends Frame{
  private Button loadButton;
  private Choice worldsChoice;
  private Label nameLabel;
  private Item item;
  private MOVEBuilderRemote comp;
  private Vector worlds=null;


  public SelectWorldWindow(Item item,MOVEBuilderRemote comp){
    this.item=item;
    this.comp=comp;
    try {

       worlds= comp.getWorlds();
    } catch (Exception x) {
      System.err.println ("Error in getWorlds " + x);
    }
    loadButton= new Button(" OK ");
    loadButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loadButton_actionPerformed(e);
      }
    });
    worldsChoice= new Choice();
    for(Enumeration en=worlds.elements();en.hasMoreElements();){
          worldsChoice.addItem((String)en.nextElement());
    }

    nameLabel = new Label("Worlds:");
    nameLabel.setForeground(Color.blue);

    this.enableEvents(WindowEvent.WINDOW_EVENT_MASK);
    this.setLayout(new FlowLayout());
    Panel p = new Panel();
    p.add(nameLabel);
    p.add(worldsChoice);
    p.add(loadButton);
    p.setVisible(true);
    this.setSize(250,200);
    this.setLocation(700,250);
    this.setResizable(false);
    this.add(p);
    this.setTitle("Choose World");
    this.setVisible(true);
  }

  void loadButton_actionPerformed (ActionEvent e) {
    try{
      item.addProperty("world",worldsChoice.getSelectedItem());
    }catch(Exception ex){ex.printStackTrace();}
    SelectPlaceWindow spw= new SelectPlaceWindow(item,comp);
    this.dispose();
  }

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.dispose();
    }
  }
}
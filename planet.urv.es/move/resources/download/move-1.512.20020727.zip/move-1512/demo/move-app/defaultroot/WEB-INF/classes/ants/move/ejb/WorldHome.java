package ants.move.ejb;


import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.EJBHome;
import java.util.*;
/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the World Entity Bean Home interface
 */
public interface WorldHome extends EJBHome {

  public World create(String id) throws CreateException,RemoteException;
  public World findByPrimaryKey (String id) throws FinderException,RemoteException;
  public Collection findByAll() throws FinderException, RemoteException;

}


// Package ants.move.core.teacher
// DObjectContainer.java
// Contains all DynamicObjects
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.teacher;

// java.awt Package imports
//import java.awt.Label;
import java.awt.Checkbox;
import java.awt.Font;
import java.awt.ScrollPane;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.ItemEvent;

// java.util Package imports
import java.util.Enumeration;
import java.util.Vector;

/** Contains all DynamicObjects.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.2 Build 2000
*/
public class DObjectContainer {
  // Vector containing all DynamicObjects' User Interfaces
  private Vector objects;
  private ScrollPane pane;

  /** Sole constructor.
      @param objs Vector containing all DynamicObjects' User Interfaces
      @exception exceptions No exceptions thrown
  */
  public DObjectContainer (Vector objs, ScrollPane pan) {
    objects = objs;
    pane = pan;
    this.init();
  }

  /** Applet's entry point.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init() {
    Font lbl = new Font("Helvetica", Font.BOLD, 14);
    int aux = objects.size()-1;

    if (aux == 1) {
      aux++;
    }

    pane.setVisible(true);
    Panel p = new Panel();
    p.setLayout(null);
    p.setSize(195, (aux * 30) + 24);

    Enumeration e = objects.elements();
    for (int i = 0; i < objects.size(); i++) {
      TeacherInterface auxobj = (TeacherInterface)(e.nextElement());
      Checkbox auxCheckbox = new Checkbox ("Model: " + auxobj.getName(), false);
      auxCheckbox.setBounds(10, i * 30, 195, 24);

      auxCheckbox.addItemListener(new java.awt.event.ItemListener() {
        public void processItemEvent (ItemEvent e) {
        }
        public void itemStateChanged (ItemEvent e) {
          checkbox_itemStateChanged(e);
        }
      });

      p.add(auxCheckbox);
    }
    pane.add(p);
    pane.doLayout();
  }

  public void checkbox_itemStateChanged (ItemEvent e) {
    Checkbox auxCheckbox = (Checkbox)e.getSource();
    Rectangle r = auxCheckbox.getBounds();  // Get bounds of the button

    // Get button's index by simply calculating it using the Y position
    // of the button

    TeacherInterface dobj = (TeacherInterface) objects.elementAt((r.y) / 30);

    if (dobj.isVisible()) {
      dobj.hideWin();
    }
    else {
      dobj.showWin();
    }
  }
}

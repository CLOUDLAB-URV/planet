package ants.move.ejb;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;
import com.protomatter.syslog.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a Tool Manager
 */

public class ToolManagerBean implements SessionBean{

  ToolHome toolHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/ToolBean");
      toolHome =(ToolHome) PortableRemoteObject.narrow(objRef,ToolHome.class);
    }catch(Exception eC){
        Syslog.error (this, "Unable to create Manager");
    }
  }

  public Collection getTools(){
    Collection tools= new ArrayList();
    try{
      tools=toolHome.findByAll();
    }catch(Exception gwE){
        Syslog.debug (this, "getTools() : Contains 0 tools");
    }
    return tools;
  }

  public Tool getTool(String id){
    Tool tool=null;
    try{
      tool=toolHome.findByPrimaryKey(id);
    }catch(Exception gwE){
          Syslog.error (this, "getTool("+id+") : "+gwE);
    }
    return tool;
  }
  public Tool createTool(String id,String name,String type){
    Tool tool=null;
    try{
      tool= toolHome.create(id);
      tool.setName(name);
      tool.setType(type);

    }catch(Exception gwE){
        Syslog.error (this, "createTool("+id+","+name+","+type+") : "+gwE);
    }
    return tool;
  }
  public void removeTool(String id){
    Tool tool=null;
    try{
      tool=toolHome.findByPrimaryKey(id);
      tool.remove();
    }catch(Exception gwE){
        Syslog.error (this, "removeTool("+id+") : "+gwE);
    }
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
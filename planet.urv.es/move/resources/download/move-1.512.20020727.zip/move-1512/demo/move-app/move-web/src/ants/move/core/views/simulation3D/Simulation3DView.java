// Package ants.move.core.views.simulation3D
// Simulation3DView.java
// Implementation of DynamicObject Simulation3D
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.simulation3D;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.simulation3D.*;
import ants.move.core.teacher.simulation3D.*;

// java.io Package imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of DynamicObject Simulation3D.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.80 Build 2000
*/
public class Simulation3DView extends DynamicObject implements Simulation3DListener,
                                                               ViewInterface, VRMLEventListener {
  // VRML Node where 3D Simulations will be put
  private Node[] simul = null;
  // addChildren EventIn
  private EventInMFNode simulAddChildren;
  // removeChildren EventIn
  private EventInMFNode simulRemChildren;
  // Loaded simulation, added to simul
  private Node[] transSimul;
  // Simulation translation EventIn
  private EventInSFVec3f simulTranslation;
  // Simulation scale EventIn
  private EventInSFVec3f simulScale;
  // Simulation translation EventOut
  private EventOutSFVec3f simulTranslationOut;
  // Simulation scale EventOut
  private EventOutSFVec3f simulScaleOut;
  // DynamicObject used to dynamically add 3D Simulation to the scene
  private DynamicObject root;
  private Simulation3DModel sM;
  private Place conn;
  //Touchsensor
  private EventOutSFBool TS;
  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public Simulation3DView() {
  }

  /** Initializes necessary parameters to use this class. <BR>
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));
    root = (DynamicObject) ht.get("root");
    this.conn = (Place) ht.get("place");
    sM = (Simulation3DModel) conn.getModel (super.getName());
    if (sM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: S3D");
    }
    sM.addSimulation3DListener(this);

    try {
      String simulString = "Transform\n" +
                "{\n" +
                "rotation "+sM.getProperty("rotation")+"\n" +
		"translation "+sM.getTranslation()+"\n" +
		"scale "+sM.getScale()+"\n" +
  		"children [\n" +
                "       DEF TS1 TouchSensor{}\n" +
  		"]\n" +
	    	"}\n"+
                "DEF TS2 Script{\n" +
                "  eventIn SFBool active\n" +
                "  eventOut SFBool eOut\n" +
                "  url \"javascript: \n" +
                " function active(value)\n" +
                " { if (eOut == TRUE) eOut=FALSE;\n" +
                "     else eOut=TRUE;}\"" +
                "}\n" +
                "ROUTE TS1.isActive TO TS2.active\n" +
                "\n";

      simul = getBrowser().createVrmlFromString(simulString);
      TS = (EventOutSFBool)simul[1].getEventOut("eOut");
      VRMLZone zone= new VRMLZone();
      zone.addVRMLEventListener(this,this.getName());
      TS.advise(zone, this.getName());

      // Capture all simulation nodes
      root.setChNodes();
      root.setaddChValue(simul);
      // Capture all EventIns and EventOuts
      simulAddChildren = (EventInMFNode) simul[0].getEventIn("addChildren");
      simulRemChildren = (EventInMFNode) simul[0].getEventIn("removeChildren");
      simulTranslation = (EventInSFVec3f) simul[0].getEventIn("translation");
      simulScale = (EventInSFVec3f) simul[0].getEventIn("scale");
      simulTranslationOut = (EventOutSFVec3f) simul[0].getEventOut("translation_changed");
      simulScaleOut = (EventOutSFVec3f) simul[0].getEventOut("scale_changed");

    }
    catch (Exception e) {
      System.err.println("Exception capturing simulation: " + e);
    }

    // Load any S3D that was currently on that place

    if (!sM.getCurrent3DSlide().equalsIgnoreCase("")){
        moveSimulation (sM.getTranslation());
        scaleSimulation (sM.getScale());
        createSimulation (sM.getCurrent3DSlide());
    }else{
       String s = "Inline { url \"" +conn.getBaseURL()+"resources/things/s3d.v01.wrl" + " \" }";
       transSimul = getBrowser().createVrmlFromString(s);
       simulAddChildren.setValue(transSimul);
    }
    System.err.println ("[MOVE] - Simulation3D VRML view initialized.");
  }

  public void createSimulation (String url) {
    try {
      if (transSimul != null) {
        simulRemChildren.setValue(transSimul);
      }
     if(url!="----"){
       String s = "Inline { url \"" + url + " \" }";
       transSimul = getBrowser().createVrmlFromString(s);
       simulAddChildren.setValue(transSimul);
     }
    }
    catch (Exception e) {
      System.err.println("Exception creating simulation: " + e);
    }
  }

  public void removeSimulation () {
    if (simul!=null && transSimul!=null) {
      try {
        simulRemChildren.setValue(transSimul);
        String s = "Inline { url \"" +conn.getBaseURL()+"resources/things/s3d.v01.wrl" + " \" }";
        transSimul = getBrowser().createVrmlFromString(s);
        simulAddChildren.setValue(transSimul);
      }
    	catch (Exception e) {
    	  System.err.println("Exception removing simulation: " + e);
      }
    }
  }

  public void moveSimulation (String values) {

    float aux[] = new float[3];
    try {
      StringTokenizer tokens = new StringTokenizer (values);
      aux[0]=Float.valueOf(tokens.nextToken()).floatValue();
      aux[1]=Float.valueOf(tokens.nextToken()).floatValue();
      aux[2]=Float.valueOf(tokens.nextToken()).floatValue();
      simulTranslation.setValue(aux);
    }
    catch (Exception e) {
      System.err.println("Exception moving simulation: " + e);
    }
  }

  public void scaleSimulation (String values) {
    float aux[] = new float[3];
    try {
      StringTokenizer tokens = new StringTokenizer (values);
      aux[0]=Float.valueOf(tokens.nextToken()).floatValue();
      aux[1]=Float.valueOf(tokens.nextToken()).floatValue();
      aux[2]=Float.valueOf(tokens.nextToken()).floatValue();
      simulScale.setValue(aux);
    }
    catch (Exception e) {
      System.err.println("Exception moving simulation: "+e);
    }
  }

  public Simulation3DModel getModel() {
    return sM;
  }

  public void eventPerformed() {
    if (TS.getValue()) {
      if(conn.hasPermission("s3d.v01")){
       Hashtable params = new Hashtable();
       params.put("src",this.getName());
       params.put("place",conn);
       params.put("dispName","SIMULATION3D");

       Simulation3DWindow s3dw = new Simulation3DWindow();
       s3dw.init(params);
       s3dw.showWin();
      }
    }
  }
}

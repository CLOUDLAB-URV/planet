package ants.move.core.models.voter;

public interface VoterListener {

  // Methods
  public void yes (int votes, boolean updateOthers);
  public void no (int votes, boolean updateOthers);
  public void unknown (int votes, boolean updateOthers);
  public void setVoterThing (VoterThing vT);
}

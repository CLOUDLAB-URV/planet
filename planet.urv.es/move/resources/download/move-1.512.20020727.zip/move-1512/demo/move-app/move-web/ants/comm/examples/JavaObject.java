package ants.comm.examples;

public class JavaObject implements java.io.Serializable
{
			private String name;
			private Double data [][][];
			
			//= new String [3][3][3];

	public JavaObject(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
	
	
}
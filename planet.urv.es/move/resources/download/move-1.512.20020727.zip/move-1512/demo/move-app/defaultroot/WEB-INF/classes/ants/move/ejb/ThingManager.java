package ants.move.ejb;

import javax.ejb.EJBObject;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import javax.ejb.DuplicateKeyException;
import java.util.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 * This is the Remote Interface for Thing Manager Session Bean
 */

public interface ThingManager extends EJBObject {

  public Collection getThings(String placeId) throws RemoteException;
  public Collection getThingsByTool(String placeId, String toolId) throws RemoteException;
  public Thing getThing(String id) throws RemoteException;
  public Thing createThing(String id,String name, String placeId, String toolId) throws RemoteException;
  public void removeThing(String id) throws RemoteException;


}


// Package ants.move.core.models.avatar
// AvatarModel.java
// Implementation of Avatar Model
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.models.avatar;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.*;
import ants.move.core.teacher.chat.ChatWindow;
import ants.move.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.Hashtable;
import java.util.Vector;

/** Implementation of Avatar Model.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.47 Build 2001
*/
public class AvatarModel implements RemoteEventListener {
  private Place conn;
  private Vector listeners;
  private String username;
  // Avatar's current position
  private Float[] actualPosition;
  // Avatar's current orientation
  private Float[] actualOrientation;
  // Current avatar is a pilot avatar ?
  private Boolean isPilot = Boolean.FALSE;
  private String avatarRepresentation;
  private String clss;
  private String src;
  private Hashtable subscription = new Hashtable();
  private String codeBase;
  private ChatWindow chatWin;


  /** Sole & void constructor.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public AvatarModel (Place ch, Hashtable env) {
    clss = (String) env.get("CLASS");
    src = (String) env.get("SRC");
    conn = ch;
    chatWin = (ChatWindow) env.get("chatWin");
    username = (String) env.get("USER");
    isPilot = (Boolean) env.get("pilot");

    avatarRepresentation = (String) env.get("avtRep");
    listeners = new Vector();
    actualPosition = new Float[3];
    actualOrientation = new Float[4];

    subscription.put("CLASS", clss);
    subscription.put("SRC", src);
    subscription.put(ants.core.Context.WORLD, conn.getWorld());
    subscription.put(ants.core.Context.PLACE, conn.getPlaceId());

    // Subscribe to avatar's events in this place
    try {
      conn.addPlaceListener(this, subscription);
    }
    catch (SessionException ex) {
      Debug.error(ex);
    }

  }

  public void addAvatarListener (AvatarListener aList) {
    listeners.addElement(aList);
  }

  public void removeAvatarListener (AvatarListener aList) {
    listeners.removeElement(aList);
  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  public void newUser (Float[] pos, Float[] ori) {
    Hashtable evtp = new Hashtable();
    evtp.put("CLASS", "AvatarControl");
    evtp.put("SRC", src);
    evtp.put(ants.core.Context.WORLD, conn.getWorld());
    evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

    evtp.put("METHOD", "newUser");
    evtp.put("USER", username);
    evtp.put("AVTREP", avatarRepresentation);
    evtp.put("PX", pos[0].toString());
    evtp.put("PY", pos[1].toString());
    evtp.put("PZ", pos[2].toString());
    evtp.put("OX", ori[0].toString());
    evtp.put("OY", ori[1].toString());
    evtp.put("OZ", ori[2].toString());
    evtp.put("OA", ori[3].toString());

    // Send a 'newuser' event containing avatar's name, photo, position
    // and orientation, so as AvatarControl class can add it as a new
    // user
    try {
      conn.send(evtp);
    }
    catch (Exception ex) {
      chatWin.consoleMessage("Exception:Sending 'new user' :"+ex);
      System.err.println("Exception: Sending 'newUser' event: " + ex);
    }
  }

  public void moveAvatar (Float[] posNow, Float[] oriNow) {
    try {
      // positionResolurion=a*a+b*b
        float a=Math.abs(actualPosition[0].floatValue() - posNow[0].floatValue());
        float b=Math.abs(actualPosition[2].floatValue() - posNow[2].floatValue());
        float d= (a*a)+(b*b);
        if( d > Constants.getPositionResolution()
           || Math.abs(actualOrientation[3].floatValue() - oriNow[3].floatValue()) > Constants.getRotationResolution()) {

          Hashtable evtp = new Hashtable();
//          evtp.put("CLASS", "AvatarControl");
//          evtp.put("SRC", src);
          evtp.put("CLASS", "AVATAR");
          evtp.put("SRC", "MOVE");
          evtp.put(ants.core.Context.WORLD, conn.getWorld());
          evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

          evtp.put("METHOD", "move");
          evtp.put("USER", username);
          evtp.put("PX", posNow[0].toString());
          evtp.put("PY", posNow[1].toString());
          evtp.put("PZ", posNow[2].toString());

//          evtp.put("OX", oriNow[0].toString());
          evtp.put("OY", oriNow[1].toString());
//          evtp.put("OZ", oriNow[2].toString());
          evtp.put("OA", oriNow[3].toString());

          // Send avatar's position and/or orientation change
          conn.send(evtp);

          // Update position & orientation values
          actualPosition = posNow;
          actualOrientation = oriNow;
        }
      } catch (Exception e) {
          System.err.println("Exception when trying to send avatar's position or orientation: " + e);
      }
  }

  /** Moves non-pilot avatars, removes non-pilot avatars from the scene and answers the 'hello' event.
      This method is executed whenever an avatar remote event is received by the Elvin4 client.
      @param evt Context
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventArrived (Hashtable evt) {
    // Only non-pilot avatars have to move within the world
    if (!(isPilot.booleanValue())) {
      // Move
/*      if (((String)evt.get("METHOD")).equals("move") && ((String)evt.get("USER")).equals(username)) {
        Float[] p = new Float[3];
        p[0] = Float.valueOf((String) evt.get("PX"));
        p[1] = Float.valueOf((String) evt.get("PY"));
        p[2] = Float.valueOf((String) evt.get("PZ"));

        Float[] o = new Float[4];
        o[0] = Float.valueOf((String) evt.get("OX"));
        o[1] = Float.valueOf((String) evt.get("OY"));
        o[2] = Float.valueOf((String) evt.get("OZ"));
        o[3] = Float.valueOf((String) evt.get("OA"));

        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).moveAvatar (p, o);
        }
      }
      */
  /*    // Delete user
      if (((String)evt.get("METHOD")).equals("delUser") && ((String)evt.get("USER")).equals(username)) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).destroyAvatar();
        }
      }*/
      if (((String)evt.get("METHOD")).equals("greet") && ((String)evt.get("USER")).equals(username)) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).greetAvatar();
        }
      }
      else if (((String)evt.get("METHOD")).equals("dance") && ((String)evt.get("USER")).equals(username)) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).danceAvatar();
        }
      }
      else if (((String)evt.get("METHOD")).equals("GHOST_ON")) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).hideAvatar();
        }
      }
      else if (((String)evt.get("METHOD")).equals("GHOST_OFF")) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          ((AvatarListener) listeners.elementAt (i)).showAvatar();
        }
      }
    }
    // Only pilot avatars answer
    if (isPilot.booleanValue()) {


      // Ask event received: Let's Answer
      if (((String)evt.get("METHOD")).equals("ask")) {  // We are asked for our name
        if(!(((String)evt.get("USER")).equals(username))) {  // I don't answer if it's me
          Hashtable evtp = new Hashtable();
          evtp.put("CLASS","AvatarControl");
          evtp.put("SRC", src);
          evtp.put(ants.core.Context.WORLD, conn.getWorld());
          evtp.put(ants.core.Context.PLACE, conn.getPlaceId());

          // Information printed in Java console
//          System.err.println("User: " + username + " answering...");

          evtp.put("METHOD", "answer");
          evtp.put("USER", username);
          evtp.put("AVTREP", avatarRepresentation);

          evtp.put("PX", actualPosition[0].toString());
          evtp.put("PY", actualPosition[1].toString());
          evtp.put("PZ", actualPosition[2].toString());

          evtp.put("OX", actualOrientation[0].toString());
          evtp.put("OY", actualOrientation[1].toString());
          evtp.put("OZ", actualOrientation[2].toString());
          evtp.put("OA", actualOrientation[3].toString());

          // We answer sending our name, shape, position and orientation
          try {
            conn.send(evtp);
          }
          catch (Exception s) {
            System.err.println("Exception sending 'answer' event: " + s);
          }
        }
      }
    }
  }

  public float getActualPosition(int index) {
    return (actualPosition[index].floatValue());
  }

  public float getActualOrientation(int index) {
    return (actualOrientation[index].floatValue());
  }

/*  public void setActualPosition(float[] value) {
    actualPosition = value;
  } */

  public void setActualPosition(Float[] value) {
    actualPosition = value;
  }

/*  public void setActualOrientation(float[] value) {
    actualOrientation = value;
  } */

  public void setActualOrientation(Float[] value) {
    actualOrientation = value;
  }

  /** Leaves Notification Service's session.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void leaveSession() {
    try {
      // Remove Avatar Class subscription
      conn.removePlaceListener (subscription);
    }
    catch (Exception ex) {
      Debug.error(ex);
    }
  }


}
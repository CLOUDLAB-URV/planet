// Package ants.move.core.models.simulation3D
// Simulation3DModel.java
// Implementation of Simulation3D Model
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.models.simulation3D;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.util.Debug;

// java.io Package imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package imports
import java.util.*;

/** Implementation of Simulation3D Model.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2002
*/
public class Simulation3DModel extends Thing implements PropertyChangeListener {

  private Vector listeners = new Vector();
  // Vector containing all 3D Simulations
  private Vector simulations;
  // Enumeration of previous Vector
  private Enumeration simuls_enum;
  // Current 3D Simulation index
  private int index3dSimulation = -1;
  private int s3dNum =0;
  private boolean s3DLoaded = false;
  private Thing simulation3dThing;

  /** Sole & void constructor.
  */
  public Simulation3DModel() {
  }

/**
 * Initialize Model
 */
  public void init () {
    addPropertyChangeListener(this);
    try{
      String t3d=getProperty("s3DThing");
      if(!t3d.equalsIgnoreCase("----")){
        this.load3dSimulation(t3d);
        index3dSimulation=Integer.parseInt(getProperty("active"));
      }
      System.err.println("[MOVE] - Simulation3D model initialized.");
    }catch(Exception e){
      System.err.println("[MOVE] - Exception during Simulation3D model initialization.");
    }
  }
/**
 * Add new Simulation 3d listener
 * @param sList Class that implements Simulation3DListener interface
 */
  public void addSimulation3DListener (Simulation3DListener sList) {
    listeners.addElement(sList);
  }

  /**
   * Remove simulation3d listener
   * @param sList Class that implements Simulation3DListener interface
   */
  public void removeSimulation3DListener (Simulation3DListener sList) {
    listeners.removeElement(sList);
  }
/**
 * Set new Simulation3D set in tool
 * @param thingKey
 */
  public void setS3DThing (String thingKey) {
    try {
      setProperty ("s3DThing", thingKey);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
/**
 * Get simulation3D thing instance
 * @return Thing instance
 */
  public Thing getS3DThing () {
    return simulation3dThing;
  }

    // Loads new simulation3d set
  public void load3dSimulation (String thingKey) {
    try {
     if(!thingKey.equalsIgnoreCase("----")){
      ANTSContext ctx = new ANTSContext(super.getPlace(), thingKey);
      simulation3dThing = new Thing();
      simulation3dThing.init(ctx, super.getThingGateway());

      s3dNum = simulation3dThing.getIndexedPropertySize ("3Dslides");
      simulations = new Vector();
      for (int i = 1; i <= s3dNum; i++) {
        simulations.addElement(simulation3dThing.getIndexedProperty("3Dslides", i));
      }
      System.err.println("[MOVE] - New simulation3D set loaded.");
//      firstS3D();
     }
    } catch (Exception ex) {
      try{
        setProperty ("s3DThing", "----");
      }catch(Exception e){}
      System.err.println ("Exception getting IndexedProperties: ");
      ex.printStackTrace();
    }
  }



  /** Remotely remove 3D Simulation.
  */
  public void removeS3D() {
     try{
        index3dSimulation=-1;
        setProperty ("s3DThing","----");
     } catch (Exception ex) { ex.printStackTrace(); }
  }

  /**
   *  Remotely move 3D Simulation.
   * @param values translation "x y z" string
   */
  public void moveS3D (String values) {
    try {
      setProperty ("translation", values);
    } catch (Exception ex) { ex.printStackTrace(); }
  }

  /**
   * Remotely scale 3D Simulation.
   * @param values scale "x y z" string
  */
  public void scaleS3D (String values) {
    try {
      setProperty ("scale", values);
    } catch (Exception ex) { ex.printStackTrace(); }
  }

  /** Display first Simulation3D.
  */
  public void firstS3D() {
    try {
      index3dSimulation=0;
      super.setProperty("active",""+index3dSimulation);

    } catch (Exception ex) { ex.printStackTrace(); }
  }

  /** Display previous Simulation3D.
  */
  public void prevS3D() {
    try {
    if (index3dSimulation > 0) {
      index3dSimulation--;
      super.setProperty("active",""+index3dSimulation);
    }
    } catch (Exception ex) { ex.printStackTrace(); }
  }

  /** Display next Simulation3D.
  */
  public void nextS3D() {
    try {
    if (index3dSimulation < s3dNum-1) {
      index3dSimulation++;
      super.setProperty("active",""+index3dSimulation);
    }
    } catch (Exception ex) { ex.printStackTrace(); }
  }

  /** Display last Simulation3D.
  */
  public void lastS3D() {
    try {
     index3dSimulation=s3dNum-1;
     super.setProperty("active",""+index3dSimulation);
    } catch (Exception ex) { ex.printStackTrace(); }
  }

/**
 * Return Url of current Simulation3D
 * @return simulation3d source url
 */
  public String getCurrent3DSlide(){
   if(index3dSimulation== -1){
    return "";
   }else{
    return ((String)simulations.elementAt(index3dSimulation));
   }
  }

  public void propertyChange (PropertyChangeEvent evt) {
    String propName = evt.getPropName();
    if (propName.equals("active")) {
        Vector listeners = (Vector) this.listeners.clone ();
        for (int i = 0; i < listeners.size (); ++ i) {
          index3dSimulation=Integer.parseInt(evt.getPropValue());
          ((Simulation3DListener) listeners.elementAt (i)).createSimulation(getCurrent3DSlide());
        }
    }
    // Move 3D Simulation
    else if (propName.equals("translation")) {
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((Simulation3DListener) listeners.elementAt (i)).moveSimulation(evt.getPropValue());
      }
    }
    // Scale 3D Simulation
    else if (propName.equals("scale")) {
      Vector listeners = (Vector) this.listeners.clone ();
      for (int i = 0; i < listeners.size (); ++ i) {
        ((Simulation3DListener) listeners.elementAt (i)).scaleSimulation(evt.getPropValue());
      }
    }
    else if(propName.equals("s3DThing")){
       if(evt.getPropValue().equalsIgnoreCase("----")){
        // Remove 3D Simulation
        simulation3dThing=null;
        for (int i = 0; i < listeners.size (); ++ i) {
          ((Simulation3DListener) listeners.elementAt (i)).removeSimulation();
        }
      }else{
        this.load3dSimulation(evt.getPropValue());
      }
    }
  }


  /** Get 3D Simulation Translation factor by coordinate.
      @return  "x y z" String
  */

  public String getTranslation() {
    try {
      return getProperty ("translation");
    } catch (Exception x) {
      x.printStackTrace();
      return null;
    }
  }
/**
 * Get simulation3D scale factor by coordinate
 * @return "x y z" String
 */
  public String getScale() {
    try {
      return getProperty ("scale");
    } catch (Exception x) {
      x.printStackTrace();
      return null;
    }
  }
/**
 * Set new translation value
 * @param values String "x y z"
 */
  public void setTranslation (String values) {
    try {
      setProperty ("translation", values);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }
  /**
   * Set new scale value
   * @param values String "x y z"
   */
  public void setScale (String values) {
    try {
      setProperty ("scale", values);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

/**
 * Tool type
 * @return SIMULATION3D
 */
  public String getType() {
    return "SIMULATION3D";
  }
/**
 * Destroy method
 */
  public void destroy() {
//    removePropertyChangeListener (this);
    if (simulation3dThing != null) {
      simulation3dThing.destroy();
    }
    super.destroy();
  }
}

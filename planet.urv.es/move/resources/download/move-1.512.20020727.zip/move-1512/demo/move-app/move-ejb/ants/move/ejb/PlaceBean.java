package ants.move.ejb;


import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;
import com.protomatter.syslog.*;
import java.util.*;


/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Entity Bean for a Place
 *  It is a BMP (Bean Managed Persistence) EJB (Enterprise JavaBean)
 */
public class PlaceBean implements EntityBean {
  // Primary key
  private String          placeId;
  private String          worldId;
  private String          myName;
  private String          myType;
  private String          myDescription;
  protected EntityContext context;
  /**
   * This method gets a connection to the database
   */
  private Connection getConnection() throws SQLException {
    try {
      InitialContext jndiContext = new InitialContext();

      DataSource source = (DataSource) jndiContext.lookup (
                          "jdbc/DefaultPooledDS");
      return source.getConnection();
    } catch (Exception ex) {
      Syslog.fatal (this, "Exception getting database connection!");
      Syslog.fatal (this, ex);
      return null;
    }
  }

  /**
   * This method inserts a new register into the database
   */
  public String ejbCreate (String id) {
    placeId = id;
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("INSERT INTO place (id) VALUES ('"
                             + placeId + "')");
      return id;
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbPostCreate (String id) { }

  /**
   * This method removes a previously existent register from the database
   */
  public void ejbRemove () {
    String primaryKey = (String) context.getPrimaryKey();
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      sqlStmt.executeUpdate ("DELETE FROM place WHERE id = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM placeproperty WHERE subid = '" +
                             primaryKey+"'");
      sqlStmt.executeUpdate ("DELETE FROM placeindexproperty WHERE subid = '" +
                             primaryKey+"'");

    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the beginning of a transaction
   */
  public void ejbLoad() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                              "SELECT * FROM place WHERE id = '" +
                              primaryKey+"'");

      if (results.next()) {
        // Get the name information from the place table
        myName = new String (results.getString ("NAME"));
        // Get the type information from the place table
        myType = new String (results.getString ("TYPE"));
        // Get the description information from the place table
        myDescription = new String (results.getString ("DESCRIPTION"));
        // Get the worldId information from the place table
        worldId = new String (results.getString ("WORLDID"));
        // Get the placeId information from the thing table
        placeId = new String (results.getString ("ID"));


      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method is invoked at the end of the transaction, just before
   * the container sends all the changes to the database
   */
  public void ejbStore() {
    Connection conn = null;

    try {
      String primaryKey = (String) context.getPrimaryKey();
      conn = this.getConnection();
      PreparedStatement sqlPrep = conn.prepareStatement (
                                  "UPDATE place SET " +
                                  "name = ?, type = ?, description = ?, worldId = ? " +
                                  "WHERE id = ?");
      sqlPrep.setString (1, myName);
      sqlPrep.setString (2, myType);
      sqlPrep.setString (3, myDescription);
      sqlPrep.setString (4, worldId);
      sqlPrep.setString (5, placeId);
      sqlPrep.executeUpdate();
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method finds by primary key
   */
  public String ejbFindByPrimaryKey (String id)
                 throws ObjectNotFoundException {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT * FROM place WHERE id = '" +
                            id+"'");
      if (results.next()) {
        return id;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  /**
   * This method returns all primary keys
   */
  public Collection ejbFindByAll() throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT id FROM place");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }


  }

  /**
   * This method returns all places primary key in worldId
   */
  public Collection ejbFindByWorld(String worldId) throws ObjectNotFoundException
  {
    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT * FROM place WHERE worldid = '"+ worldId+"'");
      if (results.next()) {
       Collection keys = new ArrayList();
       keys.add(results.getString("id"));
       while (results.next()){
              keys.add(results.getString("id"));
       }
       return keys;
      }
      else {
        throw new ObjectNotFoundException();
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }
  }

  public void ejbActivate() {}
  public void ejbPassivate() {}



  public void setEntityContext (EntityContext cntx) {
    context = cntx;
  }

  public void unsetEntityContext() {
    context = null;
  }

  public String getName() {
    return myName;
  }

  public void setName (String name) {
    myName = name;
  }

  public String getType() {
    return myType;
  }

  public void setType (String type) {
    myType = type;
  }

  public String getDescription() {
    return myDescription;
  }

  public void setDescription (String description) {
    myDescription = description;
  }

  public String getId(){
  return placeId;
  }

  public String getWorldId() {
    return worldId;
  }

  public void setWorldId (String id) {
    worldId = id;
  }


  public String getProperty (String property) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM placeproperty " +
                            "WHERE subId ='"+placeId+"' and name='"+property+"'");
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setProperty (String property, String value)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE placeproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+placeId+"' and name='"+property+"'");
      if(results==0){
         //Property no exists --> add property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO placeproperty VALUES " +
                            "('"+placeId+"','"+property+"','"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public String getIndexedProperty (String property, int index) throws Exception
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      ResultSet results = sqlStmt.executeQuery (
                            "SELECT value FROM placeindexproperty " +
                            "WHERE subId ='"+placeId+"' and name='"+property+"' and index="+index);
      if (results.next()) {
       String value=results.getString("value");
       return value;
      }
      else {
        throw new Exception("Indexed property not found");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }

  public void setIndexedProperty (String property, String value, int index)
  {

    Connection conn = null;

    try {
      conn = this.getConnection();
      Statement sqlStmt = conn.createStatement();
      int results = sqlStmt.executeUpdate (
                            "UPDATE placeindexproperty SET value ='"+value+"' "+
                            "WHERE subId ='"+placeId+"' and name='"+property+"' ant index="+index);
      if(results==0){
         //Indexed property not exists --> add indexed property
          results = sqlStmt.executeUpdate (
                            "INSERT INTO placeindexproperty VALUES " +
                            "('"+placeId+"','"+property+"',"+index+",'"+value+"')");
      }
    } catch (SQLException sqle) {
      throw new EJBException (sqle);
    }
    finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException sqlex) {
          throw new EJBException (sqlex);
        }
      }
    }

  }


}
// Package ants.move.core.models.video
// VideoListener.java
// (C) 2000 Carles Pairot & Oriol Montal�
package ants.move.core.models.video;

/** VideoListener interface.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.0 Build 2000
*/
public interface VideoListener {
/**
 * Play video
 * @param url video source url
 */
  public void playVideo (String url);
  /**
   * Load new video but don't play it
   */
  public void loadVideo ();
  /**
   * Stop video
   */
  public void stopVideo ();
}

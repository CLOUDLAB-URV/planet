// Package ants.move.core.views.hook
// HookView.java
// Implementation of DynamicObject Hook
// (C) 2000-2001 Carles Pairot & Oriol Montal�
package ants.move.core.views.hook;

// ANTS imports
import ants.comm.*;
import ants.core.*;
import ants.move.core.models.*;
import ants.move.core.views.*;
import ants.move.core.models.hook.*;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of DynamicObject Hook.
    @author Carles Pairot (cpairot@tinet.org)
    @author Oriol Montal� (omontala@tinet.org)
    @version 1.10 Build 2000
*/
public class HookView extends DynamicObject implements ViewInterface,
                                                       HookListener {
  // DynamicObject used to dynamically add Hook to the scene
  private DynamicObject root;
  // Hook's VRML Node
  private Node[] auxNode;
  // NavigationInfo VRML Node
  private Node NavigationInfo;
  // VRML Scene's ProximitySensor
  private Node vrmlPS;
  // VRML Scene's Hook ProximitySensor
  private Node vrmlHPS;
  // VRML Scene's ProximitySensor EventIn
  private EventInSFBool AvatarPSEnabled;
  // VRML Scene's Hook ProximitySensor EventIn
  private EventInSFBool HookPSEnabled;
  // VRML Scene's NavigationInfo EventIn
  private EventInMFString NavigationType;
  // ProximitySensor's positionChanged EventOut
  private EventOutSFVec3f PSposition_changed;
  // ProximitySensor's orientationChanged EventOut
  private EventOutSFRotation PSorientation_changed;
  // Hook's ProximitySensor positionChanged EventOut
  private EventOutSFVec3f HookPSPos_changed;
  // Hook's ProximitySensor orientationChanged EventOut
  private EventOutSFRotation HookPSOri_changed;
  // EventIn hook's position (so it can be changed)
  private EventInSFVec3f hookPosition = null;
  // EventIn hook's orientation (so it can be changed)
  private EventInSFRotation hookRotation = null;
  private Place conn;
  private HookModel hM;
  private boolean captureHookMovements = false;
  private EventInSFBool jump = null;
  private Node entryViewpoint;

  /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public HookView() {
    super();
  }

  /** Initializes necessary parameters to use this class. <BR>
      This is the way to implement a dynamicObject through DObjectInterface interface.
      @param z Zone name
      @param b Reference to VRML browser
      @param n VRML Node name
      @param d Object name
      @param s Elvin4 session
      @param r Used to dynamically add VRML objects to the scene
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));

    root = (DynamicObject) ht.get("root");

    this.conn = (Place) ht.get("place");
    hM = (HookModel) conn.getModel(super.getName());
    if (hM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: HOOK");
    }
    hM.addHookListener(this);

    // Catch Scene's ProximitySensor
    vrmlPS = (super.getBrowser()).getNode("PS");
    vrmlHPS = (super.getBrowser()).getNode("HookPS");
    PSposition_changed = (EventOutSFVec3f)vrmlPS.getEventOut("position_changed");
    PSorientation_changed = (EventOutSFRotation)vrmlPS.getEventOut("orientation_changed");
    HookPSPos_changed = (EventOutSFVec3f)vrmlHPS.getEventOut("position_changed");
    HookPSOri_changed = (EventOutSFRotation)vrmlHPS.getEventOut("orientation_changed");

    VRMLZone vrmlZone = new VRMLZone();
    vrmlZone.addVRMLEventListener(this, "hook");

    PSposition_changed.advise(vrmlZone, "hook");
    PSorientation_changed.advise(vrmlZone, "hook");

    HookPSPos_changed.advise(vrmlZone, "hook");
    HookPSOri_changed.advise(vrmlZone, "hook");

    // True if hook movements have to be captured.
    captureHookMovements = false;

    hM.setHCamPos(PSposition_changed.getValue());
    hM.setHCamOri(PSorientation_changed.getValue());
    root.setChNodes();
    auxNode = (super.getBrowser()).createVrmlFromString("Viewpoint {\n"+
	                         	"description \"" + super.getName() + "\"\n"+
					"position " +
					hM.getHCamPos(0) + " " +
					hM.getHCamPos(1) + " " +
  				        hM.getHCamPos(2) + "\n" +
					"orientation " +
                                        hM.getHCamOri(0) + " " +
					hM.getHCamOri(1) + " " +
					hM.getHCamOri(2) + " " +
                                        hM.getHCamOri(3) + "\n" +
					"}\n");
    root.setaddChValue(auxNode);

    // Catch NavigationInfo Node
    NavigationInfo = (super.getBrowser()).getNode("NavInfo");
    AvatarPSEnabled = (EventInSFBool)vrmlPS.getEventIn("enabled");
    HookPSEnabled = (EventInSFBool)vrmlHPS.getEventIn("enabled");
    NavigationType = (EventInMFString)NavigationInfo.getEventIn("type");
    hookPosition = (EventInSFVec3f) auxNode[0].getEventIn("position");
    hookRotation = (EventInSFRotation) auxNode[0].getEventIn("orientation");
    jump = (EventInSFBool) auxNode[0].getEventIn("jump");
    entryViewpoint = (super.getBrowser()).getNode("View0");

    // Non-relative viewpoint changes
    jump.setValue(true);

    // Check whether I must be hooked or not
    try {
      if (hM.getProperty("hookBound").equals("true")) {
          ants.move.core.MOVECoreApplet mbr = (ants.move.core.MOVECoreApplet) ht.get("MOVECoreApplet");
          mbr.setNavigationAllowed(false);
//        hM.setBind(true);
          hook (hM.getProperty("translation"), hM.getProperty("orientation"));
          System.err.println("[MOVE] - User hooked.");
      }
    } catch (Exception x) {
      x.printStackTrace();
    }

    System.err.println ("[MOVE] - Hook VRML view initialized.");
  }

  /** Trims a float to an only decimal digit.
      @param n Number to trim
      @return Number trimmed
      @exception exceptions No exceptions thrown
  */
  public float to1d (float n) {
    return ((float)(int)(n*10))/10;
  }

  /** Executed when a VRML Event is received. <BR>
      Updates hook's position.
      @param params None
      @return No return value
      @exception exceptions No exceptions thrown
  */
  public void eventPerformed() {
    float[] posNow = new float[3];
    float[] oriNow = new float[4];
    if (captureHookMovements) {
      posNow = HookPSPos_changed.getValue();
      oriNow = HookPSOri_changed.getValue();
    }
    else {
      posNow = PSposition_changed.getValue();
      oriNow = PSorientation_changed.getValue();
    }
    posNow[0]=to1d(posNow[0]);
    posNow[1]=to1d(posNow[1]);
    posNow[2]=to1d(posNow[2]);

    oriNow[0]=to1d(oriNow[0]);
    oriNow[1]=to1d(oriNow[1]);
    oriNow[2]=to1d(oriNow[2]);
    oriNow[3]=to1d(oriNow[3]);

    if (captureHookMovements) {
      hM.movement(posNow, oriNow);
    }
    else {
      hM.setHCamPos(posNow);
      hM.setHCamOri(oriNow);
    }
  }

  public void hook (String pos, String ori) {
    AvatarPSEnabled.setValue(false);
    if (!hM.getHookBoolean()) {
      String[] NType = new String[1];
      // So pilot avatar can't move
      NType[0] = "NONE";
      NavigationType.setValue(NType);
    }
    else {
      HookPSEnabled.setValue(true);
    }

    float[] p = new float[3];
    StringTokenizer tokens = new StringTokenizer (pos);
    p[0] = Float.valueOf(tokens.nextToken()).floatValue();
    p[1] = Float.valueOf(tokens.nextToken()).floatValue();
    p[2] = Float.valueOf(tokens.nextToken()).floatValue();

    float[] o = new float[4];
    tokens = new StringTokenizer (ori);
    o[0] = Float.valueOf(tokens.nextToken()).floatValue();
    o[1] = Float.valueOf(tokens.nextToken()).floatValue();
    o[2] = Float.valueOf(tokens.nextToken()).floatValue();
    o[3] = Float.valueOf(tokens.nextToken()).floatValue();

    hookPosition.setValue(p);
    hookRotation.setValue(o);
    ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(true);
    captureHookMovements = true;
  }

  public void unHook() {
    try {
      String[] NType = new String[1];
      // Avatar will produce moves again
      NType[0] = "WALK";
      NavigationType.setValue(NType);
      HookPSEnabled.setValue(false);
      ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(false);
      AvatarPSEnabled.setValue(true);
      captureHookMovements = false;

      // Return to entry viewpoint
      ((EventInSFBool) entryViewpoint.getEventIn("set_bind")).setValue(true);
    } catch (Exception ex) {
      System.err.println("Exception occured while unhooking. Maybe user left place ?");
    }
  }

  public void hookPositionChanged (String value) {
    // If I produce hook movement events, these have to be ignored by me
    if (!hM.getHookBoolean()) {
      float[] p = new float[3];
      StringTokenizer tokens = new StringTokenizer(value);
      p[0] = Float.valueOf(tokens.nextToken()).floatValue();
      p[1] = Float.valueOf(tokens.nextToken()).floatValue();
      p[2] = Float.valueOf(tokens.nextToken()).floatValue();

      hookPosition.setValue(p);
      ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(true);
    }
  }

  public void hookOrientationChanged (String value) {
    // If I produce hook movement events, these have to be ignored by me
    if (!hM.getHookBoolean()) {
      float[] o = new float[4];
      StringTokenizer tokens = new StringTokenizer(value);
      o[0] = Float.valueOf(tokens.nextToken()).floatValue();
      o[1] = Float.valueOf(tokens.nextToken()).floatValue();
      o[2] = Float.valueOf(tokens.nextToken()).floatValue();
      o[3] = Float.valueOf(tokens.nextToken()).floatValue();

      hookRotation.setValue(o);
      ((EventInSFBool)auxNode[0].getEventIn("set_bind")).setValue(true);
    }
  }
}

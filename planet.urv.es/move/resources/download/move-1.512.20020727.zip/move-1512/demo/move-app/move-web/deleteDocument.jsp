<%@ page session="true" import = "java.io.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*" %>

<%
   try {
      String key_string = request.getParameter("thingId");
      String name = request.getParameter("name");
      String path_directory = application.getRealPath("") + File.separator +
                              "worlds" + File.separator + session.getAttribute("worldId") + File.separator +
                              session.getAttribute("placeId")+File.separator+ name;
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      FileDeleter fd = new FileDeleter (path_directory);
      fd.delete();
      Syslog.debug (this, "Doc file deleted from disk.");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      thm.removeThing(key_string);
      response.sendRedirect ("close.jsp");
   } catch (Exception e) {
      System.out.println(e);
   }
%>
<%@ page session="true" import = "ants.move.lang.*, java.text.*, java.util.*, javax.naming.*, javax.rmi.*, com.protomatter.syslog.*, ants.move.ejb.*, java.io.*" %>

<%! ResourceBundle labels, messages;
    LanguageUtilities lang; %>
    
<%  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");%>
  
<html>
<body>
<jsp:include page="header.jsp?string=/WORLDS/USERS&linked=false" flush="true"/>
<center>
<table width=90%>
<tr><td colspan="3" bgcolor="#00800F"><font color="white"><b><%=labels.getString("regList")%> : </b></font></td></tr>
<tr>
  <td colspan="2">
  </td>
  <td align="right">
    <FONT FACE="impact" SIZE=4 COLOR="green"><%=labels.getString("new")%>:</FONT>&nbsp;
    <a href="createUser.jsp"><FONT FACE="impact" SIZE=5 COLOR="blue"><%=labels.getString("user1")%></font></a><br><br>
  </td>
</tr></table>
  <table border="0" bgcolor="teal" width="90%">
     <tr>
        <th><font color="white"><%=labels.getString("loginTH")%></font></th>
        <th><font color="white"><%=labels.getString("passwordTH")%></font></th>
        <th><font color="white"><%=labels.getString("roleTH")%></font></th>
        <th><font color="white"><%=labels.getString("nameUserTH")%></font></th>
        <th><font color="white"><%=labels.getString("surnameTH")%></font></th>
        <th><font color="white"><%=labels.getString("emailTH")%></font></th>
        <th><font color="white"><%=labels.getString("date")%></font></th>
        
     </tr>
   <%
      try{
        InitialContext initial = new InitialContext();
        Object obj = initial.lookup("java:comp/env/UserManagerBean");
        UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow(obj,UserManagerHome.class);
        UserManager um = home5.create();

	Collection ul=um.getUsers();

        User user;
        for(Iterator it=ul.iterator();it.hasNext();){
           user=(User)it.next();
   %>
                      <tr bgcolor="#E6E4DD">
                        <td><a href="editUser.jsp?user=<%=user.getLogin()%>"><%=user.getLogin()%></a></td>
			<td><%=user.getPassword()%></td>
			<td><%=lang.translateText(user.getRole(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))%></td>
			<td><%=user.getProperty("name")%></td>
			<td><%=user.getProperty("surname")%></td>
   <%                 if(user.getProperty("email").equals("")){  %>
			<td><i><%=messages.getString("not")%></i></td>
   <%                 }else{				   %>
			<td><%=user.getProperty("email")%></td>
   <%                 }%>
   		        <td><%=lang.translateDateTime(new Date(user.getProperty("date")),DateFormat.FULL,DateFormat.FULL)%></td>
			<td bgcolor="white"><a href="removeUser.jsp?user=<%=user.getLogin()%>"><%=labels.getString("remove")%></a>
                      </tr>
   <%   }
      }catch(Exception e){
           Syslog.error(this,"Unable to get the users");
      }

   %>

  </table>
<br><br>
</center>

<jsp:include page="footer.jsp" flush="true"/>
</body>
<HTML>
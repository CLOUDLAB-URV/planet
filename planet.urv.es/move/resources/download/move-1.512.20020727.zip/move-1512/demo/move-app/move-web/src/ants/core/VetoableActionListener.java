package ants.core;


/**
*		Interface targeted for subscribing to VetoableActions. Coordination and policy 
*   managers will thus be notified for granting or rejecting a specified action. 
*
*/

public interface VetoableActionListener
{
	/**
	*	
	*  Method aimed for Coordination and policy managers controlling access to a soecified Action.
	* @return boolean Grant or denies an action
	* @throws ants.core.PropertyVetoException Exception containing information about a concrete veto.
	*/

	public boolean vetoableAction(VetoableActionEvent vE)
	throws PropertyVetoException;
	
}
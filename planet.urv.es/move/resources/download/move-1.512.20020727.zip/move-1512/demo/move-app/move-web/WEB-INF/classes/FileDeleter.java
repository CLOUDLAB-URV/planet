import java.io.*;
import com.protomatter.syslog.*;

/*
   Usage:

      FileDeleter fd=new FileDeleter(path);
      fd.delete();
      fd.setPath(path2);
      fd.delete();
 */

/**
 * This class deletes all the files and directories below a given path
 */
public class FileDeleter {

   private String path = "";

   private boolean recursiveDelete (File[] all_files) {
    File temporal;
    int i = 0;
    boolean ok = true;

    try {
      while ((i < all_files.length) && ok) {
        temporal = all_files[i];
        Syslog.debug (this, "   File -> " + temporal.getName());
        if (temporal.isDirectory()) {
          ok = recursiveDelete (temporal.listFiles());
          if (ok)
            ok = temporal.delete();
        }
        else
          ok = temporal.delete();
        i++;
      }
    } catch (Exception e) {
      Syslog.log(this, e);
    }
    return ok;
  }

  /**
  * Sets the path to be delteted.
  */
  public void setPath (String path) {
    this.path = path;
  }

  /**
  * Get the path to be deleted.
  */
  public String getPath () {
    return path;
  }

  /**
  * Function that deletes all the directory tree.
  */
  public boolean delete () {
    boolean ok = true;

    try {
      File file = new File (path);

      if (file.isDirectory()) {
        File[] all_files = file.listFiles();
        ok = recursiveDelete (all_files);
        if (ok)
          ok = file.delete ();
      } else
        ok = file.delete();
    } catch (Exception e) {
      Syslog.log (this, e);
    }
    return ok;
  }

  /**
  * Creates a new FileDeteter, prepared to delete the given path
  * @param path indicates the path that has to be deleted.
  */

  public FileDeleter(String path) {
    setPath (path);
  }
}
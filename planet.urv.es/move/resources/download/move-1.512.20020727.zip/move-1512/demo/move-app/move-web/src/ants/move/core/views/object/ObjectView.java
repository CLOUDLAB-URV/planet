package ants.move.core.views.object;
/**
* Package ants.move.core.views.object
* ObjectView.java
* Implementation of OBJECT Tool
* (C) 2002 Oriol Montal� & Carles Pairot
*/

// ANTS imports
import ants.move.core.views.*;
import ants.move.core.models.*;
import ants.move.core.models.object.*;
import ants.core.*;

// java.net Package imports
import java.net.URL;
import java.net.MalformedURLException;

// java.util Package import
import java.util.*;

// VRML Scene imports
import vrml.external.field.*;
import vrml.external.Node;
import vrml.external.Browser;

/** Implementation of Object Repository.
    @author Oriol Montal� (omontala@tinet.org)
    @author Carles Pairot (cpairot@tinet.org)
    @version 0.01 Build 2002
*/
public class ObjectView extends DynamicObject implements ViewInterface,ObjectListener {
  private Hashtable objectThingViews;
  private Place place;
  private ObjectModel oM;
  private DynamicObject root;
  private Node proximitySensor;
  // EventOut avatar position
  private EventOutSFVec3f positionChanged;
  // EventOut avatar orientation
  private EventOutSFRotation orientationChanged;


   /** Sole & void constructor. Used when newInstance() method is called.
      @param params None
      @exception exceptions No exceptions thrown
  */
  public ObjectView () {
  }

  public void init (Hashtable ht) {
    super.setBrowser((Browser) ht.get("browser"));
    super.setName((String) ht.get("src"));
    root=(DynamicObject)ht.get("root");
    place=(Place)ht.get("place");
    oM = (ObjectModel) place.getModel(super.getName());
    if (oM == null) {
      System.err.println("EXCEPTION CAPTURING MODEL: OBJECT");
    }
    oM.addObjectListener(this);
    objectThingViews= new Hashtable();
    Hashtable objectThings=oM.getObjectThings();
    String objectKey;
    for(Enumeration en=objectThings.keys();en.hasMoreElements();){
      objectKey=(String)en.nextElement();
      ht.put("objectThing",objectThings.get(objectKey));
      ObjectThingView oTV= new ObjectThingView (ht);
      objectThingViews.put(objectKey,oTV);
    }

    proximitySensor = getBrowser().getNode("PS");   // catch the scene's ProximitySensor

    System.err.println ("[MOVE] - Object OBJECT VRML view initialized.");
  }
  public void newThing(ObjectThing oT){
   try{
     if(oT.getProperty("owner").equalsIgnoreCase(oM.getPlace().getUser())){
        // Capture VRML position & orientation of avatar
        float[] t = new float[3];
        float[] r = new float[4];
        positionChanged=(EventOutSFVec3f)proximitySensor.getEventOut("position_changed");
        orientationChanged=(EventOutSFRotation)proximitySensor.getEventOut("orientation_changed");
        t = positionChanged.getValue();
        r = orientationChanged.getValue();
        oT.setProperty("translation",""+t[0]+" "+t[1]+" "+t[2]);
        oT.setProperty("rotation",""+r[0]+" "+r[1]+" "+r[2]+" "+r[3]);
     }
     Hashtable params = new Hashtable();
     params.put("objectThing",oT);
     params.put("browser",getBrowser());
     params.put("root",root);
     ObjectThingView oTV= new ObjectThingView (params);
     objectThingViews.put(oT.getThingId(),oTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Object Thing");ex.printStackTrace();}
  }

  public void loadThing(ObjectThing oT){
   try{
     Hashtable params = new Hashtable();
     params.put("objectThing",oT);
     params.put("browser",getBrowser());
     params.put("root",root);
     ObjectThingView oTV= new ObjectThingView (params);
     objectThingViews.put(oT.getThingId(),oTV);
   }catch(Exception ex){System.err.println("MOVE - Exception: Unable to add Object Thing");ex.printStackTrace();}
  }


  public void refreshThing(String objectThingId){
    ((ObjectThingView)objectThingViews.get(objectThingId)).show();
  }

  public void removeThing(String objectThingId){
    ObjectThingView oTv =(ObjectThingView)objectThingViews.get(objectThingId);
    objectThingViews.remove(objectThingId);
    oTv.destroy();
  }

  public void catchThing(String objectThingId){
    ((ObjectThingView)objectThingViews.get(objectThingId)).catchMe();
  }

  public void deployThing(String objectThingId){
    ((ObjectThingView)objectThingViews.get(objectThingId)).deploy();
  }


  }

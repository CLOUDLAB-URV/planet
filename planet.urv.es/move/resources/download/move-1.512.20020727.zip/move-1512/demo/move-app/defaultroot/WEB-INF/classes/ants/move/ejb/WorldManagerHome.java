package ants.move.ejb;


import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the World Manager Bean Home interface this is a session Bean
 */
public interface WorldManagerHome extends EJBHome {

  public WorldManager create() throws CreateException,RemoteException;

}
package ants.move.ejb;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.rmi.PortableRemoteObject;
import java.util.*;
import com.protomatter.syslog.*;

/**
 * Title:         Move! EJB
 * Description:   PFC Enginyeria Inform�tica
 * Copyright:     Copyright (c) 2001
 * Company:       --
 * @author        Oriol Montal�, Carles Pairot
 * @version 1.0
 */

/**
 *  This is the Session Bean for a Thing Manager
 */

public class ThingManagerBean implements SessionBean{

  ThingHome thingHome;

  public void ejbCreate(){
    try{
      InitialContext ctx= new InitialContext();
      Object objRef=ctx.lookup("java:comp/env/ThingBean");
      thingHome =(ThingHome) PortableRemoteObject.narrow(objRef,ThingHome.class);
    }catch(Exception eC){
        Syslog.error (this, "Unable to create Manager");
    }
  }

  public Collection getThings(String placeId){
    Collection things= new ArrayList();
    try{
      things=thingHome.findByPlace(placeId);
    }catch(Exception gwE){
        Syslog.debug (this, "getThings("+placeId+") : Contains 0 things");
    }
    return things;
  }

  public Collection getThingsByPlaceAndTool(String placeId, String toolId){
    Collection things= new ArrayList();
    try{
      things=thingHome.findByPlaceAndTool(placeId,toolId);
    }catch(Exception gwE){
        Syslog.debug (this, "getThingsByPlaceAndTool("+placeId+","+toolId+") : Contains 0 things");
    }
    return things;

  }

  public Collection getThingsByPlace(String placeId){
    Collection things= new ArrayList();
    try{
      things=thingHome.findByPlace(placeId);
    }catch(Exception gwE){
        Syslog.debug (this, "getThingsByPlace("+placeId+") : Contains 0 things");
    }
    return things;

  }


  public Thing getThing (String id){
    Thing thing=null;
    try{
      thing=thingHome.findByPrimaryKey(id);
    }catch(Exception gwE){
        Syslog.error (this, "getThing("+id+") : "+gwE);
    }
    return thing;
  }
  public Thing createThing(String id,String name,String placeId, String toolId){
    Thing thing=null;
    try{
      thing= thingHome.create(id);
      thing.setName(name);
      thing.setPlaceId(placeId);
      thing.setToolId(toolId);
    }catch(Exception gwE){
        Syslog.error (this, "createThing("+id+","+name+","+placeId+","+toolId+") : "+gwE);
    }
    return thing;
  }
  public void removeThing(String id){
    Thing thing=null;
    try{
      thing=thingHome.findByPrimaryKey(id);
      thing.remove();
    }catch(Exception gwE){
        Syslog.error (this, "removeThing("+id+") : "+gwE);
    }
  }


  public void setSessionContext(SessionContext contaxto) {}
  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void ejbLoad() {}
  public void ejbStore() {}

}
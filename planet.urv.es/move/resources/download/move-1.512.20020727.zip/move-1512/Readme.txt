Please visit http://www.orionserver.com or send an email to 
info@orionserver.com for information about this product.

This version is only for development use or for non-commercial
use. You need to purchase a license from http://www.orionserver.com
to be able to use this server commercially.

To install the server:
java -jar orion.jar -install
<follow the instructions>

To start the server:
java -jar orion.jar
or
java -jar orion.jar -config my/path/to/server.xml

Good luck!
The Orion team

This product uses Hypersonic SQL as an example database, more info about
Hypersonic SQL can be found at http://hsql.oron.ch/.

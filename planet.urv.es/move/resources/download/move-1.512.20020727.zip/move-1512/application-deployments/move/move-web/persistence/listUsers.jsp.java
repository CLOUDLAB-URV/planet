import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import java.io.*;

public class __jspPage0_listUsers_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_listUsers_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n    \r\n");
			
  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");


			out.write("\r\n  \r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/USERS&linked=false");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("regList")
			);

			out.write(" : </b></font></td></tr>\r\n<tr>\r\n  <td colspan=\"2\">\r\n  </td>\r\n  <td align=\"right\">\r\n    <FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write(":</FONT>&nbsp;\r\n    <a href=\"createUser.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">");
			out.print(
				labels.getString("user1")
			);

			out.write("</font></a><br><br>\r\n  </td>\r\n</tr></table>\r\n  <table border=\"0\" bgcolor=\"teal\" width=\"90%\">\r\n     <tr>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("loginTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("passwordTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("roleTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("nameUserTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("surnameTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("emailTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("date")
			);

			out.write("</font></th>\r\n        \r\n     </tr>\r\n   ");
			

      try{
        InitialContext initial = new InitialContext();
        Object obj = initial.lookup("java:comp/env/UserManagerBean");
        UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow(obj,UserManagerHome.class);
        UserManager um = home5.create();

	Collection ul=um.getUsers();

        User user;
        for(Iterator it=ul.iterator();it.hasNext();){
           user=(User)it.next();
   


			out.write("\r\n                      <tr bgcolor=\"#E6E4DD\">\r\n                        <td><a href=\"editUser.jsp?user=");
			out.print(
				user.getLogin()
			);

			out.write("\">");
			out.print(
				user.getLogin()
			);

			out.write("</a></td>\r\n\t\t\t<td>");
			out.print(
				user.getPassword()
			);

			out.write("</td>\r\n\t\t\t<td>");
			out.print(
				lang.translateText(user.getRole(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("</td>\r\n\t\t\t<td>");
			out.print(
				user.getProperty("name")
			);

			out.write("</td>\r\n\t\t\t<td>");
			out.print(
				user.getProperty("surname")
			);

			out.write("</td>\r\n   ");
			
                 if(user.getProperty("email").equals("")){  


			out.write("\r\n\t\t\t<td><i>");
			out.print(
				messages.getString("not")
			);

			out.write("</i></td>\r\n   ");
			
                 }else{				   


			out.write("\r\n\t\t\t<td>");
			out.print(
				user.getProperty("email")
			);

			out.write("</td>\r\n   ");
			
                 }


			out.write("\r\n   \t\t        <td>");
			out.print(
				lang.translateDateTime(new Date(user.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n\t\t\t<td bgcolor=\"white\"><a href=\"removeUser.jsp?user=");
			out.print(
				user.getLogin()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n                      </tr>\r\n   ");
			
   }
      }catch(Exception e){
           Syslog.error(this,"Unable to get the users");
      }

   


			out.write("\r\n\r\n  </table>\r\n<br><br>\r\n</center>\r\n\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</body>\r\n<HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
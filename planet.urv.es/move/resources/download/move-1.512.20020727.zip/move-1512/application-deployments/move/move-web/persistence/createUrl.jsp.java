import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import ants.move.core.*;

public class __jspPage1_createUrl_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_createUrl_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n  <html>\r\n<body>\r\n<center>\r\n<table width=90%>\r\n\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("addUrl")
			);

			out.write(" : </b></font></td></tr>\r\n   <form method=\"post\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("url")
			);

			out.write(" : </b> <br>\r\n      http://<input type=\"text\" size=\"40\" maxlength=\"500\" name=\"url\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("urlDescription")
			);

			out.write(" : </b><br>\r\n      <input type=\"text\" size=\"50\" maxlength=\"50\" name=\"desc\"><br><br>\r\n    </td>\r\n   </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <input type=\"checkbox\" name=\"copy\">\r\n    <b>");
			out.print(
				labels.getString("copy")
			);

			out.write("</b>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <input type=\"checkbox\" name=\"catch\">\r\n    <b>");
			out.print(
				labels.getString("catch")
			);

			out.write("</b>\r\n  </td>\r\n </tr>\r\n\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   </form>\r\n  </table>\r\n  </center>\r\n  </HTML>\r\n");
			

}else{
 try{
  String thingCopy="";
  String thingCatch="";
  try{
    if(request.getParameter("copy").equalsIgnoreCase("on")){
       thingCopy = new String("true");
    }else{
       thingCopy = new String("false");
    }
  }catch(Exception exc){}
  try{
    if(request.getParameter("catch").equalsIgnoreCase("on")){
       thingCatch = new String("true");
    }else{
       thingCatch = new String("false");
    }
  }catch(Exception exx){}
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  String url=new String("http://"+request.getParameter("url"));
  String thingKey = ""+System.currentTimeMillis();
  Thing thing=thm.createThing(thingKey,url,
                            (String)session.getAttribute("placeId"),"url.v01");
  thing.setDescription(request.getParameter("desc"));
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  thing.setProperty("translation","0 1 0");
  thing.setProperty("rotation","0 0 1 0");
  thing.setProperty("scale","1 1 1 ");
  thing.setProperty("copy",thingCopy);
  thing.setProperty("catch",thingCatch);


  //Add Thing to running Move Applet
  Hashtable env = new Hashtable();
  Constants.init(request.getRealPath(""));
  env.put(Constants.NSPORT, Constants.getNSPort());
  env.put(Constants.ANTSCLASS, Constants.getAntsClass());
  env.put(Constants.SERVER, Constants.getServer());
  ants.comm.Session commSession = ants.comm.SessionFactory.createSession (env);

  Hashtable evt2 = new Hashtable();
  evt2.put(Constants.WORLD, (String)session.getAttribute("worldId"));
  evt2.put(Constants.PLACE, (String)session.getAttribute("placeId"));
  evt2.put("CLASS","URL.V01");
  evt2.put("METHOD","NEWTHING");
  evt2.put("THINGKEY",thingKey);
  commSession.send(evt2);
  commSession.close();



			out.write("\r\n  <script> window.close(); </script>\r\n\r\n");
			
}catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}





			out.write("\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
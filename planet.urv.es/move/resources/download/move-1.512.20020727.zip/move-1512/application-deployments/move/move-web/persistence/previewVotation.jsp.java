import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage14_previewVotation_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage14_previewVotation_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			



LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

    // Add control for users who have voted!!!!!!

    String worldKey = null;
    String placeKey = null;
    String server = null;
    int port = 80;
    Thing objectInfo = null;
    String topic = null;
    int yes = 0;
    int no = 0;
    int unknown = 0;
    int total = 0;
    float yesPixel =0;
    float noPixel = 0;
    float unknownPixel = 0;
    float yesPC = 0;
    float noPC = 0;
    float unknownPC = 0;
    String userLogin = "Arohil";

    if (request.getMethod().equalsIgnoreCase("GET")) {

      server = request.getServerName();
      port = request.getServerPort();
      objectInfo =((ThingManager)session.getAttribute("thingManager")).getThing(request.getParameter("thingId"));
      topic = objectInfo.getDescription();
      String syes = objectInfo.getProperty("yes");

      // Parse 'yes' votes
      if (syes.equalsIgnoreCase ("----")) {
        yes = 0;
      }
      else {
        yes = Integer.parseInt (syes);
      }

      // Parse 'no' votes
      String sno = objectInfo.getProperty ("no");
      if (sno.equalsIgnoreCase ("----")) {
        no = 0;
      }
      else {
        no = Integer.parseInt (sno);
      }

      // Parse 'unknown' votes
      String sunknown = objectInfo.getProperty ("unknown");
      if (sunknown.equalsIgnoreCase ("----")) {
        unknown = 0;
      }
      else {
        unknown = Integer.parseInt (sunknown);
      }

      // Total number of votes
      total = yes + no + unknown;

      // Calculate % and bars sizes of votes
      if (total != 0) {
        if (yes != 0) {
          yesPC = ((float) yes / (float) total) * (float) 100.0;
          yesPixel= ((float) yes / (float) total) * (float) 470.0;
        }
        else {
	  yesPC = 0;
	  yesPixel = 1;
        }

        if (no != 0) {
 	  noPC = ((float) no / (float) total) * (float)100.0;
          noPixel = ((float) no / (float) total) * (float)470.0;
        } else {
	  noPC = 0;
	  noPixel = 1;
        }

        if(unknown != 0){
          unknownPC = ((float) unknown / (float) total) * (float) 100.0;
          unknownPixel = ((float) unknown / (float) total) * (float) 470.0;

        }
        else {
	  unknownPC = 0;
	  unknownPixel = 1;
        }

      }
      else {
        yesPixel = 1;
 	noPixel = 1;
 	unknownPixel = 1;

	yesPC = 0;
	noPC = 0;
	unknownPC = 0;
      }




			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("previewVot")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n <tr>\r\n  <td colspan=\"3\">\r\n  <center><h1>");
			out.print(
				labels.getString("topic")
			);

			out.write(":  ");
			out.print(
				topic
			);

			out.write("</h1></center>\r\n  <table width=\"500\" border=\"0\" align=\"center\">\r\n    <tr>\r\n    <td width=\"6%\">\r\n      <div align=\"right\"><b>");
			out.print(
				labels.getString("yes")
			);

			out.write("</b></div>\r\n    </td>\r\n    <td colspan=\"10\"><img src=\"resources/things/column.jpg\" width=\"");
			out.print(
				yesPixel
			);

			out.write("\" height=\"50\"</td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"6%\">\r\n      <div align=\"right\"><b>");
			out.print(
				labels.getString("no")
			);

			out.write("</b></div>\r\n    </td>\r\n    <td colspan=\"10\"><img src=\"resources/things/column.jpg\" width=\"");
			out.print(
				noPixel
			);

			out.write("\" height=\"50\"></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"6%\">\r\n      <div align=\"right\"><b>");
			out.print(
				labels.getString("unknown")
			);

			out.write("</b></div>\r\n    </td>\r\n    <td colspan=\"10\"><img src=\"resources/things/column.jpg\" width=\"");
			out.print(
				unknownPixel
			);

			out.write("\" height=\"50\"></td>\r\n  </tr>\r\n  <tr>\r\n  <tr>\r\n\r\n  </tr>\r\n</table>\r\n\r\n<table width=\"28%\" border=\"1\" align=\"center\" height=\"108\">\r\n  <tr>\r\n    <td width=\"29%\"><font color=\"#FF0000\"><b>");
			out.print(
				labels.getString("yes")
			);

			out.write("</b></font></td>\r\n    <td width=\"71%\"><b>:");
			out.print(
				yes
			);

			out.write(" ");
			out.print(
				labels.getString("votes")
			);

			out.write(" ");
			out.print(
				(int)yesPC
			);

			out.write("%</b></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"29%\"><font color=\"#FF0000\"><b>");
			out.print(
				labels.getString("no")
			);

			out.write("</b></font></td>\r\n    <td width=\"71%\"><b>:");
			out.print(
				no
			);

			out.write(" ");
			out.print(
				labels.getString("votes")
			);

			out.write(" ");
			out.print(
				(int)noPC
			);

			out.write("%</b></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"29%\"><font color=\"#FF0000\"><b>");
			out.print(
				labels.getString("unknown")
			);

			out.write("</b></font></td>\r\n    <td width=\"71%\"><b>:");
			out.print(
				unknown
			);

			out.write(" ");
			out.print(
				labels.getString("votes")
			);

			out.write(" ");
			out.print(
				(int)unknownPC
			);

			out.write("%</b></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"29%\"><font color=\"#FF0000\"><b>");
			out.print(
				labels.getString("total")
			);

			out.write("</b></font></td>\r\n    <td width=\"71%\"><b>:");
			out.print(
				total
			);

			out.write(" ");
			out.print(
				labels.getString("votes")
			);

			out.write("</b></td>\r\n  </tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n</body>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</html>\r\n\r\n");
			
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
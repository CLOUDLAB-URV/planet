import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import java.net.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage2_removeFromBag_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;


	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage2_removeFromBag_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {

 String thingId = request.getParameter("thingId");

 User user=(User)session.getAttribute("user");

 int size=Integer.parseInt(user.getProperty("BagSize"));
 String value;
 Vector items=new Vector();
 for(int i=0;i<size;i++){
   value=user.getIndexedProperty("Bag",i);
   items.addElement(value);
 }

 items.removeElement(thingId);

 user.setProperty("BagSize",""+items.size());
 for(int i=0;i<items.size();i++){
    user.setIndexedProperty("Bag",(String)items.elementAt(i),i);
 }

} catch (Exception e) {
    Syslog.log (this, e);
}

response.sendRedirect("bagList.jsp");


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
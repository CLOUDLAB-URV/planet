import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import ants.move.ejb.*;
import com.protomatter.syslog.*;
import ants.comm.*;
import ants.move.core.*;
import ants.core.rmi.*;
import java.util.*;
import java.net.*;
import java.rmi.*;

public class __jspPage1_goToMove_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels;
    LanguageUtilities lang;   
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_goToMove_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");

  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "UserGateway remote object not bound. Let's bind it now...");
     try {
      Properties env = new Properties();
      env.put("ants.comm.port", "2917");
      env.put("java.naming.provider.url", InetAddress.getLocalHost().getHostName());
      env.put("ants.comm.class", "ants.comm.elvin.Session");
      // Create session
      ants.comm.Session ses = SessionFactory.createSession (env);
      Hashtable evt = new Hashtable();
      UserGatewayImpl engine = new UserGatewayImpl(ses, evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway", engine);
      Syslog.debug(this, "RMI User Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/UserGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }
  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/PlaceGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "PlaceGateway remote object not bound. Let's bind it now...");
     try {
      Hashtable evt = new Hashtable();
      PlaceGatewayImpl engine = new ants.core.rmi.PlaceGatewayImpl(evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/PlaceGateway", engine);
      Syslog.debug(this, "RMI Place Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/PlaceGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }
  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/ThingGateway");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "ThingGateway remote object not bound. Let's bind it now...");
     try {
      Hashtable evt = new Hashtable();
      ThingGatewayImpl engine = new ThingGatewayImpl(evt);
      Naming.rebind("rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/core/ThingGateway", engine);
      Syslog.debug(this, "RMI Thing Gateway Engine bound OK on rmi://" + InetAddress.getLocalHost().getHostName() + "/core/ThingGateway");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }


  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  String userRole=((User)session.getAttribute("user")).getRole();
  String userLogin=((User)session.getAttribute("user")).getLogin();
  String userAvatar=((User)session.getAttribute("user")).getProperty("avatar");


  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  Thing thing=null;
  Tool tool;
  Place place=null;
  place=pm.getPlace(placeId);
  String placeType=place.getType();
  String jars= new String();
  jars= jars +"jars/ants-comm.jar,jars/je-4.jar,jars/move-core.jar";
  for (Iterator i=tm.getTools().iterator();i.hasNext();){
     tool=(Tool)i.next();
     if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
        if (!tool.getId().equalsIgnoreCase("netMeeting.v01"))
           jars=jars+",jars/move-"+tool.getId()+".jar";
     }
    }





			out.write("\r\n  <HTML><body>\r\n  <script>\r\n     function winOpen(param) {\r\n         window.open('',param,'width=500,height=350,resizable=0,scrollbars=0')\r\n\r\n\r\n     }\r\n     function winOpen2(param) {\r\n         window.open('',param,'width=640,height=480,resizable=0,scrollbars=1')\r\n\r\n\r\n     }\r\n     function openUsers() {\r\n         msgWindow=window.open('usersInPlace.jsp','users','scrollbars=yes,width=500,height=250,resizable=0')\r\n         if (msgWindow.opener == null) msgWindow.opener = self;\r\n     }\r\n   </script>\r\n\r\n  <center>\r\n\r\n  <table width=90%>\r\n   <tr><td colspan=\"2\" bgcolor=\"#00800F\"><font color=\"white\"><b>Multiuser Oriented Virtual Environments</b></font></td>\r\n   <td align=\"right\" bgcolor=\"#00800F\"><a href=\"leavePlace.jsp\"><FONT FACE=\"impact\" COLOR=\"white\">");
			out.print(
				labels.getString("exit")
			);

			out.write("</font></a></td></tr>\r\n   <tr>\r\n  <td valign=\"top\">\r\n\r\n\r\n    <table align=\"center\">\r\n      <th colspan=\"2\"><a href=\"listThings.jsp?placeId=");
			out.print(
				placeId
			);

			out.write("\"><img src=\"images/moveSmall.jpg\" border=\"0\"></th>\r\n      <tr>\r\n       <td><FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write(":</FONT>&nbsp;</td>\r\n       <td>\r\n\r\n       ");
			
if(place.getProperty("doc.v01").equalsIgnoreCase("active")){


			out.write("\r\n         <a href=\"createDocument.jsp?user=");
			out.print(
				userLogin
			);

			out.write("\" title=\"");
			out.print(
				labels.getString("uploadFile")
			);

			out.write("\" target=\"createDoc\" onClick=\"winOpen('createDoc');\"  ><img src=\"images/docSmall.gif\" border=\"0\"></a>\r\n       ");
			
}
         if(place.getProperty("url.v01").equalsIgnoreCase("active")){


			out.write("\r\n         <a href=\"createUrl.jsp?user=");
			out.print(
				userLogin
			);

			out.write("\" title=\"");
			out.print(
				labels.getString("createUrl")
			);

			out.write("\" target=\"createURL\" onClick=\"winOpen('createURL');\"  ><img src=\"images/urlSmall.gif\" border=\"0\"></a>\r\n       ");
			
}
         if(place.getProperty("object.v01").equalsIgnoreCase("active")){


			out.write("\r\n         <a href=\"createObject.jsp?user=");
			out.print(
				userLogin
			);

			out.write("\" title=\"");
			out.print(
				labels.getString("uploadObject")
			);

			out.write("\" target=\"createObject\" onClick=\"winOpen('createObject');\" ><img src=\"images/objectSmall.gif\" border=\"0\"></a>\r\n       ");
			
}

       


			out.write("\r\n         <a href=\"bagList.jsp?user=");
			out.print(
				userLogin
			);

			out.write("\" title=\"");
			out.print(
				labels.getString("bag")
			);

			out.write("\" target=\"bagList\" onClick=\"winOpen2('bagList');\"  ><img src=\"images/bag.gif\" border=\"0\"></a>\r\n       </td>\r\n      </tr>\r\n      <tr>\r\n       <td>\r\n       </td>\r\n      </tr>\r\n   ");
			
 if(place.getProperty("netMeeting.v01").equalsIgnoreCase("active")){ 


			out.write("\r\n     <tr>\r\n       <td colspan=\"2\">\r\n        <object ID=\"NetMeeting\" CLASSID=\"CLSID:3E9BAF2D-7A79-11d2-9334-0000F875AE17\">\r\n        <PARAM NAME = \"MODE\" VALUE = \"RemoteOnly\"></object>\r\n        <object ID=\"NetMeetingPreview\" CLASSID=\"CLSID:3E9BAF2D-7A79-11d2-9334-0000F875AE17\">\r\n        <PARAM NAME = \"MODE\" VALUE = \"PreviewOnly\"></object>\r\n        <input type=button value =\"");
			out.print(
				labels.getString("hangUp")
			);

			out.write("\" id=HangUpBtn onclick=NetMeeting.LeaveConference()>\r\n        <input type=button value =\"");
			out.print(
				labels.getString("usersBtn")
			);

			out.write("\" id=UsersBtn onclick=\"openUsers();\">\r\n       </td>\r\n      </tr>\r\n\r\n   ");
			
 }  


			out.write("\r\n\r\n    </table>\r\n  </td>\r\n\r\n    <td colspan=\"2\" align=\"center\">\r\n     <EMBED SRC=\"worlds/");
			out.print(
				worldId
			);

			out.write("/");
			out.print(
				placeId
			);

			out.write("/");
			out.print(
				placeId
			);

			out.write(".wrl\" HEIGHT=\"300\" WIDTH=\"560\">\r\n\r\n     <APPLET CODE=\"ants.move.core.MOVECoreApplet.class\" mayscript WIDTH=\"560\" HEIGHT=\"150\"\r\n          ALIGN=\"ABSCENTER\"\r\n          ARCHIVE=\"");
			out.print(
				jars
			);

			out.write("\">\r\n            <PARAM name=worldKey value=\"");
			out.print(
				worldId
			);

			out.write("\">\r\n\t    <PARAM name=placeKey value=\"");
			out.print(
				placeId
			);

			out.write("\">\r\n            <PARAM name=userRole value=\"");
			out.print(
				userRole
			);

			out.write("\">\r\n            <PARAM name=userLogin value=\"");
			out.print(
				userLogin
			);

			out.write("\">\r\n            <PARAM name=placeType value=\"");
			out.print(
				placeType
			);

			out.write("\">\r\n            <PARAM name=avatar value=\"");
			out.print(
				userAvatar
			);

			out.write("\">\r\n    </APPLET>\r\n    <br>\r\n  </td>\r\n  </td>\r\n </tr>\r\n </table>\r\n\r\n</center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n</HTML>\r\n\r\n\r\n\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
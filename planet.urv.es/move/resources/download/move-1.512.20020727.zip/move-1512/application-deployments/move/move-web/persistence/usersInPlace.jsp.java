import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import ants.move.ejb.*;
import com.protomatter.syslog.*;
import ants.comm.*;
import ants.move.core.*;
import ants.core.rmi.*;
import java.util.*;
import java.net.*;
import java.rmi.*;

public class __jspPage0_usersInPlace_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels,messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_usersInPlace_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");

  UserManager um = (UserManager)session.getAttribute("userManager");
    
  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  UserGateway ug=(UserGateway)Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/core/UserGateway");
  
  
  Vector v=ug.getUsers(worldId,placeId);
 
  Enumeration e=v.elements();
  




			out.write("\r\n<html>\r\n<body>\r\n<center>\r\n<h3>");
			out.print(
				messages.getString("users")
			);

			out.write(":</h3> <br>\r\n<table width=\"90%\" border=\"0\" bgcolor=\"teal\">\r\n     <tr>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("userTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("nameUserTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("surnameTH")
			);

			out.write("</font></th>\r\n        <th><font color=\"white\">");
			out.print(
				labels.getString("ipTH")
			);

			out.write("</font></th>\r\n     </tr>\r\n ");
			

  while (e.hasMoreElements()){
    String userName=(String) e.nextElement();

 


			out.write("\r\n  <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n    <td>");
			out.print(
				userName
			);

			out.write("</td>\r\n    <td>");
			out.print(
				((User)um.getUser(userName)).getProperty("name")
			);

			out.write("</td>\r\n    <td>");
			out.print(
				((User)um.getUser(userName)).getProperty("surname")
			);

			out.write("</td>\r\n    <td>");
			out.print(
				ug.getUserIP(worldId,placeId,userName)
			);

			out.write("</td>\r\n    <td><INPUT TYPE=\"HIDDEN\" name=\"ip\" VALUE=\"");
			out.print(
				ug.getUserIP(worldId,placeId,userName)
			);

			out.write("\">\r\n        <input type=button value=\"");
			out.print(
				labels.getString("call")
			);

			out.write("\" name=\"CallBtn\" onClick=top.opener.window.document.NetMeeting.CallTo(\"");
			out.print(
				ug.getUserIP(worldId,placeId,userName)
			);

			out.write("\")>\r\n  </tr>\r\n ");
			

  }



			out.write("\r\n</table> \r\n<br><br>\r\n   <input type=button value=\"");
			out.print(
				labels.getString("update")
			);

			out.write("\" name=\"refreshBtn\" onClick=location.reload()>\r\n\r\n\r\n</center>\r\n</body>\r\n</html>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
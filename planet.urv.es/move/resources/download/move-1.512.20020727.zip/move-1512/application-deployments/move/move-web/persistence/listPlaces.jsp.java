import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage5_listPlaces_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage5_listPlaces_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			
  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES&linked=false");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("choosePlace")
			);

			out.write(" : </b></font></td></tr>\r\n<tr>\r\n  <td align=\"right\">\r\n    <FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write(":</FONT>&nbsp;\r\n    <a href=\"createPlace.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">Place</font></a>\r\n    ");
			
if(((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
    


			out.write("\r\n      &nbsp;&nbsp;&nbsp;&nbsp;<a href=\"configurePermissions.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("?role=teacher\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">");
			out.print(
				labels.getString("permission")
			);

			out.write("</font></a>\r\n    ");
			
}


			out.write("\r\n    <br><br>\r\n  </td>\r\n</tr>\r\n</table>\r\n\r\n\r\n  ");
			

   try {
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");
      ToolManager tm = (ToolManager)session.getAttribute("toolManager");
      if(request.getParameter("worldId")!=null){
        session.setAttribute("worldId",request.getParameter("worldId"));
      }
      String worldId=(String)session.getAttribute("worldId");
      
      int thingsNum;
      Place place=null;

      if((pm.getPlaces(worldId).size())!=0){
         
   


			out.write("\r\n\r\n      <table border=\"0\" bgcolor=\"teal\" width=\"90%\">\r\n         <TR>\r\n\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("nameTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("typeTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("descriptionTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">Things</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("creationTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("createdTH")
			);

			out.write("</TH>\r\n\r\n         </TR>\r\n     ");
			

      for (Iterator i=pm.getPlaces((String)session.getAttribute("worldId")).iterator();i.hasNext();){
        place=(Place)i.next();
        thingsNum=thm.getThingsByPlaceAndTool(place.getId(),"video.v01").size() +
       		   thm.getThingsByPlaceAndTool(place.getId(),"votation.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"slides.v05").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"s3d.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"url.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"doc.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"audio.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"banner.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"info.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"object.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"videoStream.v01").size() +
                   thm.getThingsByPlaceAndTool(place.getId(),"videoStream.v02").size();

        


			out.write("\r\n         <TR ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <TD align=\"left\"><a href=\"listThings.jsp?placeId=");
			out.print(
				place.getId()
			);

			out.write("\"><B>");
			out.print(
				place.getName()
			);

			out.write("</B></A></TD><TD>");
			out.print(
				(place.getType()).substring(0,(place.getType()).lastIndexOf("_"))
			);

			out.write("</TD><TD>");
			out.print(
				place.getDescription()
			);

			out.write("</TD>\r\n          <td>");
			out.print(
				thingsNum
			);

			out.write("<TD>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</TD><TD>");
			out.print(
				place.getProperty("owner")
			);

			out.write("</TD>\r\n          <TD bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(place.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n           <a href=\"removePlace.jsp?placeId=");
			out.print(
				place.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n\t </TD>\r\n         </TR>\r\n\r\n\r\n        ");
			

      }
    }

   } catch (Exception e) {
      Syslog.log (this, e);
   }
  


			out.write("        </table>\r\n\r\n<br><br>\r\n\r\n\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
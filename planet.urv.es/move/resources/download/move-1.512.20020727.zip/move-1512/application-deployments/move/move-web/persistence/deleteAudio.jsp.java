import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage6_deleteAudio_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage6_deleteAudio_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			


 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");

  
   try {

      String key_string = request.getParameter("thingId");
      ThingManager thm = (ThingManager)session.getAttribute("thingManager");

      Thing th = thm.getThing(key_string);

      String path_directory=pageContext.getServletContext().getRealPath
                            ("/worlds/"+worldKey+"/"+placeKey+"/")+th.getProperty("fileName");
      FileDeleter fd = new FileDeleter(path_directory);
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      
      fd.delete();
      Syslog.debug (this, "Track deleted from disk.");
      
      thm.removeThing(key_string);
      response.sendRedirect("listThings.jsp");

   } catch (Exception e) {
      System.out.println(e);
   }


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
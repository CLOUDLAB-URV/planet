import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import java.net.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import ants.move.core.*;
import java.util.zip.*;
import java.io.*;

public class __jspPage5_deployObject_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;


	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage5_deployObject_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
 Thing thingBase=null;
 String thingId=request.getParameter("thingId");
 User user=(User)session.getAttribute("user");
 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");

 int size=Integer.parseInt(user.getProperty("BagSize"));
 String value;
 Vector items=new Vector();
 for(int i=0;i<size;i++){
   value=user.getIndexedProperty("Bag",i);
   items.addElement(value);
 }
 items.removeElement(thingId);
 user.setProperty("BagSize",""+items.size());
 for(int i=0;i<items.size();i++){
   user.setIndexedProperty("Bag",(String)items.elementAt(i),i);
 }

 thingBase=thm.getThing(thingId);
 String thingKey = "Copy_"+System.currentTimeMillis();

 String placeBase=thingBase.getPlaceId();
 String worldBase=pm.getPlace(placeBase).getWorldId();
 
 File f = new File (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey);
                             
 f.mkdir ();

 FileInputStream fin = new FileInputStream(pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingBase.getProperty("fileName")+"/bak.zip");


 FileOutputStream fout = new FileOutputStream
        		          (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey+"/bak.zip");

 int s=fin.available();
 byte b[] = new byte[s];
 fin.read(b);
 fout.write(b);

 fout.flush();
 fout.close();
 fin.close();

 ZipFile zip = new ZipFile (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey+"/bak.zip");
 File f2 = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+thingKey);
 f2.mkdir ();
 for (Enumeration originFiles = zip.entries(); originFiles.hasMoreElements(); ) {
        ZipEntry ze = (ZipEntry) originFiles.nextElement();
        if(ze.isDirectory()){
           (new File(pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/") + thingKey + "/" +ze.getName())).mkdir();
           continue;
         } 
        FileOutputStream destinyFile = new FileOutputStream
                                             (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")
                                              + thingKey +"/" + ze.getName());
        InputStream inzip = zip.getInputStream (ze);
        BufferedOutputStream outzip=new BufferedOutputStream(destinyFile);
        byte[] buffer = new byte[1024];
        int len;
        while((len = inzip.read(buffer)) >= 0)
           outzip.write(buffer, 0, len);

        inzip.close();
        outzip.close();
         

  }
  zip.close();


 ants.move.ejb.Thing thing=thm.createThing(thingKey,"(Copy) "+thingBase.getName(),thingBase.getPlaceId(),"object.v01");
 thing.setDescription(thingBase.getDescription());
 thing.setProperty("date",thingBase.getProperty("date"));
 thing.setProperty("owner",user.getLogin());
 thing.setProperty("fileName",thingKey);
 thing.setProperty("translation","0 1 0");
 thing.setProperty("rotation","0 0 1 0");
 thing.setProperty("scale","1 1 1 ");
 thing.setProperty("copy",thingBase.getProperty("copy"));
 thing.setProperty("catch",thingBase.getProperty("catch"));

   //Add Thing to running Move Applet
    Hashtable env = new Hashtable();
    Constants.init(request.getRealPath(""));
    env.put(Constants.NSPORT, Constants.getNSPort());
    env.put(Constants.ANTSCLASS, Constants.getAntsClass());
    env.put(Constants.SERVER, Constants.getServer());
    ants.comm.Session commSession = ants.comm.SessionFactory.createSession (env);

    Hashtable evt2 = new Hashtable();
    evt2.put(Constants.WORLD, worldKey);
    evt2.put(Constants.PLACE, placeKey);
    evt2.put("CLASS","OBJECT.V01");
    evt2.put("METHOD","NEWTHING");
    evt2.put("THINGKEY",thingKey);
    commSession.send(evt2);
    commSession.close();

} catch (Exception e) {
    Syslog.log (this, e);
}

response.sendRedirect("bagList.jsp");
  


			out.write("\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
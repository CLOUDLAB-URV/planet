import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage3_header_jsp extends com.orionserver.http.OrionHttpJspPage
{
 LanguageUtilities lang; 
    ResourceBundle labels; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage3_header_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n<center>\r\n<table width=90%>\r\n<tr>\r\n  <td><img src=\"images/moveSmall.jpg\"></td>\r\n  <td align=\"left\"><h2>   \r\n");
			
  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    
    String link=request.getParameter("linked");
    StringTokenizer str=new StringTokenizer(request.getParameter("string"),"/");
    while(str.hasMoreTokens()){
	String s=str.nextToken();
	if (s.equals("WORLDS")){
             if (str.hasMoreTokens()){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listWorlds.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/WORLDS</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("true")){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listWorlds.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/WORLDS</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("false")){ 


			out.write("\r\n                 <font color=\"green\">/WORLDS</font>\r\n");
			
           }
       }else if (s.equals("PLACES")){
             if (str.hasMoreTokens()){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listPlaces.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/PLACES</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("true")){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listPlaces.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/PLACES</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("false")){ 


			out.write("\r\n                 <font color=\"green\">/PLACES</font>\r\n");
			
           }
       }else if (s.equals("USERS")){
             if (str.hasMoreTokens()){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listUsers.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/");
			out.print(
				labels.getString("users")
			);

			out.write("</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("true")){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listUsers.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/");
			out.print(
				labels.getString("users")
			);

			out.write("</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("false")){ 


			out.write("\r\n                 <font color=\"green\">/");
			out.print(
				labels.getString("users")
			);

			out.write("</font>\r\n\r\n");
			
           } 
       }else if (s.equals("THINGS")){
             if (str.hasMoreTokens()){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listThings.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/THINGS</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("true")){ 


			out.write("\r\n                 <a target=\"_parent\" href=\"listThings.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><font color=\"green\">/THINGS</font></a>\r\n");
			
           }else if(!str.hasMoreTokens() && link.equals("false")){ 


			out.write("\r\n                 <font color=\"green\">/THINGS</font>\r\n");
			
           } 

       }
    }



			out.write("\r\n  </h2></td>\r\n\r\n  <td align=\"left\" width=\"25%\">\r\n    <font color =\"#00800F\"><b>");
			out.print(
				labels.getString("user2")
			);

			out.write(" :</b></font><a href=\"editUser.jsp?");
			out.print(
				((User)session.getAttribute("user")).getLogin()
			);

			out.write("\"> ");
			out.print(
				((User)session.getAttribute("user")).getLogin()
			);

			out.write("</a><br>\r\n    <font color=\"#00800F\"><b>");
			out.print(
				labels.getString("roleOL")
			);

			out.write(" :</b></font><a href=\"editUser.jsp?");
			out.print(
				((User)session.getAttribute("user")).getLogin()
			);

			out.write("\"> ");
			out.print(
				lang.translateText(((User)session.getAttribute("user")).getRole(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("</a>\r\n  </td>\r\n</tr>\r\n</table>\r\n</center>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
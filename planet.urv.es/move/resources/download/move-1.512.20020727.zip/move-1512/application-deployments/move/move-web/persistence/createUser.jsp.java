import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.util.*;
import java.io.*;

public class __jspPage1_createUser_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_createUser_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			
 
        Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"resources/avatars/avatars.properties");
          props.load(fis);
        }catch(IOException e){System.out.println(e);}        



			out.write("\r\n<HTML>\r\n<FRAMESET cols=\"70%, 30%\" name=\"root\">\r\n     <frameset  >\r\n        <FRAME NORESIZE SRC=\"newUser.jsp\" name=\"jsp\">\r\n        <FRAME NORESIZE SRC=\"resources/avatars/uncompressed/avatarPreview.wrl\" name=\"vrml\">\r\n     </frameset>\r\n     \r\n     \r\n</FRAMESET>\r\n      \r\n</HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import java.net.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage3_listThings_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;


	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage3_listThings_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ToolManager tm=(ToolManager)session.getAttribute("toolManager");
 PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 Thing thing=null;
 Tool tool=null;
 Place place=null;

 if(request.getParameter("placeId")!=null){
   session.setAttribute("placeId",request.getParameter("placeId"));
 }
 String placeId=(String)session.getAttribute("placeId");

 place=pm.getPlace(placeId);




			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=false");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("thingsList")
			);

			out.write(" : </b></font></td></tr>\r\n<tr>\r\n  <td colspan=\"2\">\r\n  </td>\r\n  <td align=\"right\">\r\n\r\n  <table border=\"0\">\r\n  <tr>\r\n  <td>\r\n        <FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write(":</FONT>&nbsp;\r\n  </td>\r\n  ");
			


  for (Iterator i=tm.getTools().iterator();i.hasNext();){
   tool=(Tool)i.next();

   if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
    if(tool.getId().equalsIgnoreCase("slides.v05")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createSlides.jsp\" title=\"");
			out.print(
				labels.getString("uploadSlides")
			);

			out.write("\"><img src=\"images/slides.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("s3d.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"create3DSlides.jsp\" title=\"");
			out.print(
				labels.getString("upload3DSlides")
			);

			out.write("\"><img src=\"images/s3d.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("video.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createVideo.jsp\" title=\"");
			out.print(
				labels.getString("uploadVideo")
			);

			out.write("\"><img src=\"images/video.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			


    }else if (tool.getId().equalsIgnoreCase("votation.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createVotation.jsp\" title=\"");
			out.print(
				labels.getString("createVotation")
			);

			out.write("\"><img src=\"images/votation.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("audio.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createAudio.jsp\" title=\"");
			out.print(
				labels.getString("uploadAudio")
			);

			out.write("\"><img src=\"images/audio.v01.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("banner.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createBanner.jsp\" title=\"");
			out.print(
				labels.getString("uploadBanner")
			);

			out.write("\"><img src=\"images/banner.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("videoStream.v02")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createVideoStream2.jsp\" title=\"");
			out.print(
				labels.getString("createVideoStream2")
			);

			out.write("\"><img src=\"images/videoStream.v02.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("videoStream.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createVideoStream.jsp\" title=\"");
			out.print(
				labels.getString("createVideoStream")
			);

			out.write("\"><img src=\"images/videoStream.v01.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			

    }else if (tool.getId().equalsIgnoreCase("info.v01")){
      


			out.write("\r\n      <td>\r\n       <a href=\"createInfo.jsp\" title=\"");
			out.print(
				labels.getString("uploadInfo")
			);

			out.write("\"><img src=\"images/info.gif\" border=\"0\"></a>\r\n      </td>\r\n      ");
			


    }
   }
 }



			out.write("\r\n    <td>\r\n     <a title=\"Configure Tools\" href=\"configureTools.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><img src=\"images/tools2.gif\" border=\"0\"></a>\r\n    </td>\r\n  </tr>\r\n  </table>\r\n </td>\r\n</tr>\r\n</table><br>\r\n  ");
			

    if((thm.getThingsByPlaceAndTool(placeId,"video.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"votation.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"slides.v05").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"s3d.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"url.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"doc.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"audio.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"banner.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"info.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"object.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"videoStream.v01").size()!=0) ||
       (thm.getThingsByPlaceAndTool(placeId,"videoStream.v02").size()!=0)){

  


			out.write("\r\n      <table border=\"0\" bgcolor=\"teal\" width=\"90%\">\r\n         <TR>\r\n              <TH><font color=\"white\">Thing</font></TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("nameTH")
			);

			out.write("</font></TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("descriptionTH")
			);

			out.write("</font></TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("creationTH")
			);

			out.write("</font></TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("createdTH")
			);

			out.write("</font></TH>\r\n\r\n         </TR>\r\n  ");
			



      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"video.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"previewVideo.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n              <img src=\"images/videoSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteVideo.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }
      //Votation
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"votation.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"previewVotation.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n              <img src=\"images/votationSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteThing.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }
      //Slides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"slides.v05").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"previewSlides.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n            <img src=\"images/slidesSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteSlides.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }
      //3DSlides
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"s3d.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><img src=\"images/s3dSmall.gif\" align=\"middle\" border=\"0\"></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"delete3DSlides.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }

      //URL
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"url.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				thing.getName()
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/urlSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n\r\n        </tr>");
			

      }

      //DOC
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"doc.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        String worldId=(String)session.getAttribute("worldId");

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				"worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/docSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n\r\n        </tr>");
			

      }
      //Audio
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"audio.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"listenAudio.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n              <img src=\"images/audioSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteAudio.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }

      //banner
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"banner.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"previewBanner.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n              <img src=\"images/bannerSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteBanner.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }
      //Information
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"info.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();

        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"previewInfo.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">\r\n              <img src=\"images/infoSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n         ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteInfo.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n         </td>\r\n        </tr>");
			

      }
      //Object
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"object.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();
        String worldId=(String)session.getAttribute("worldId");
        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				"worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")+"/main.wrl"
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/objectSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          \r\n          \r\n        </tr>");
			

      }
      
       //Videostreaming
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v01").iterator();i.hasNext();){
        thing=(Thing)i.next();


        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				thing.getProperty("url")
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/videoStreamSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteThing.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>        \r\n       ");
			

       }          

      //Videostreaming2
      for (Iterator i=thm.getThingsByPlaceAndTool((String)session.getAttribute("placeId"),"videoStream.v02").iterator();i.hasNext();){
        thing=(Thing)i.next();


        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				thing.getProperty("url")
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/videoStream2Small.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(place.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(thing.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n          <a href=\"deleteThing.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </td>\r\n        </tr>");
			

      }



    


			out.write("\r\n    </table>\r\n\r\n  ");
			

     }
   } catch (Exception e) {
      Syslog.log (this, e);
   }
  


			out.write("\r\n\r\n\r\n<br><br>\r\n<a href=\"goToMove.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">");
			out.print(
				labels.getString("go")
			);

			out.write("</font></a><br><br>\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
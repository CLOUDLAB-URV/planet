import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage3_editUser_jsp extends com.orionserver.http.OrionHttpJspPage
{
 User user;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage3_editUser_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

      try{
        UserManager um = (UserManager)session.getAttribute("userManager");

        String u=request.getParameter("user");
        if (u==null){
          user=(User)session.getAttribute("user");
        }else{
          user=um.getUser(u);
        }

      }catch(Exception e){
         Syslog.error(this,"Unable to get the user");
      }



			out.write("\r\n\r\n<HTML>\r\n<FRAMESET cols=\"70%, 30%\" name=\"root\">\r\n     <frameset  >\r\n        <FRAME NORESIZE SRC=\"editUserProps.jsp?user=");
			out.print(
				user.getLogin()
			);

			out.write("\" name=\"jsp\">\r\n        <FRAME NORESIZE SRC=\"resources/avatars/uncompressed/avatarPreview.wrl\" name=\"vrml\">\r\n     </frameset>\r\n\r\n\r\n</FRAMESET>\r\n\r\n</HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
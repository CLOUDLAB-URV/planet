import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage3_previewBanner_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage3_previewBanner_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			

String worldKey=(String)session.getAttribute("worldId");
String placeKey=(String)session.getAttribute("placeId");
String thingId = request.getParameter("thingId");
String server = request.getServerName ();
int port = request.getServerPort ();
Tool tool=null;
Thing thing=null;
int index=1;


LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

try{
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  tool=tm.getTool("banner.v01");
  thing=thm.getThing(thingId);
  


} catch (Exception e) {
    Syslog.log (this, e);
}




			out.write("\r\n<html>\r\n<head>\r\n<SCRIPT LANGUAGE=\"JavaScript\">\r\n  var g = ");
			out.print(
				tool.getProperty("delay")
			);

			out.write(";\r\n  var images = new Array();\r\n  var j = 0;\r\n  \r\n  function animateBanner(){\r\n    \r\n    document.currentImage.src = images[j].src \r\n   \r\n    j++;\r\n    if (j == images.length )\r\n\tj = 0;\r\n    setTimeout('animateBanner()',g);\r\n   \r\n  }\r\n\r\n  \r\n</script>\r\n</head>\r\n");
			

String path = application.getRealPath("/worlds/"+worldKey+"/"+placeKey+"/") + thingId;
  File f = new File(path);

  File files[]=f.listFiles();

  for( int i=0 ; i<files.length ; i++){
      f=files[i];
      
 


			out.write("\r\n      <script>\r\n\r\n         index = ");
			out.print(
				i
			);

			out.write(";\r\n                 \r\n         images[index] = new Image();\r\n         images[index].src = \"worlds/");
			out.print(
				worldKey
			);

			out.write("/");
			out.print(
				placeKey
			);

			out.write("/");
			out.print(
				thingId
			);

			out.write("/");
			out.print(
				f.getName()
			);

			out.write("\";    \r\n      </script>\r\n");
			
     
    }



			out.write("\r\n\r\n<body onLoad=\"animateBanner()\">\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("previewBanner")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<br>\r\n<br>\r\n<table width=\"500\" height=\"200\" border=\"3\" fgcolor=\"black\">\r\n  <tr><td><img name=\"currentImage\" width=\"500\" height=\"200\" src=\"worlds/");
			out.print(
				worldKey
			);

			out.write("/");
			out.print(
				placeKey
			);

			out.write("/");
			out.print(
				thingId
			);

			out.write("/");
			out.print(
				files[0].getName()
			);

			out.write("\"></td></tr>\r\n</table>\r\n<br><br>\r\n\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</BODY>\r\n</HTML>\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
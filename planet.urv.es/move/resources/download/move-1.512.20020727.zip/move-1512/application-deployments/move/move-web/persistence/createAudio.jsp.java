import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import com.evermind.io.*;
import java.io.*;
import ants.move.ejb.*;

public class __jspPage1_createAudio_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_createAudio_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 String userLogin = ((User)session.getAttribute("user")).getLogin();
 String toolKey = "audio.v01";
 int port = 80;
 if (request.getMethod().equalsIgnoreCase("GET")) {
    String server=request.getServerName();
    port=request.getServerPort();
    

    lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("uploadAudio")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n <form enctype=\"multipart/form-data\" method=\"POST\">\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <br>");
			out.print(
				messages.getString("uploadAudio")
			);

			out.write("\r\n     <br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n  <b>");
			out.print(
				labels.getString("audioName")
			);

			out.write(" :</b> <input type=\"text\" name=\"name\" size=\"20\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("audioDescription")
			);

			out.write(" :</b>\r\n    <input type=\"text\" name=\"desc\"  size=\"50\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("chooseAudio")
			);

			out.write(" :</b><input type=\"file\" name=\"file\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <center><input type=submit name=action value=\"");
			out.print(
				labels.getString("upload")
			);

			out.write("\"> <input TYPE=\"reset\" VALUE=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n    </center>\r\n  </td>\r\n </tr>\r\n</form>\r\n</table>\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</BODY>\r\n</HTML>\r\n  ");
			

}else{

   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String fileName="";

    Enumeration enumeration = new FilePostParser(request.getInputStream(), 
                                                 request.getContentLength()); 
    while( enumeration.hasMoreElements() ) { 
         Object element = enumeration.nextElement(); 
         if( element instanceof Map.Entry ) { 
              Map.Entry entry = (Map.Entry)element; 

              if ((entry.getKey()).equals("name")){
	     	     thingName = (String)entry.getValue();
                     
	      }
	      if ((entry.getKey()).equals("desc")){
	             thingDesc = (String)entry.getValue();
	      }

                             
         } 
         else if( element instanceof PostFileInputStream ) { 
              PostFileInputStream in = (PostFileInputStream)element;
              String s=in.getFileName();
              int index=s.lastIndexOf("\\");
              if(index == -1){
                 //Unix platform
                 index=s.lastIndexOf("/");
              }
               
               
               
              fileName=thingKey+"_"+s.substring(index+1); 
			   
              FileOutputStream fout = new FileOutputStream
        		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);

              int bite;
              while((bite=in.read()) != -1)
                   fout.write(bite);

              in.close();
              fout.close();
         }

    }

     ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
     Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
     thing.setDescription(thingDesc);
     thing.setProperty("date",(new Date()).toGMTString());
     thing.setProperty("owner",userLogin);
     thing.setProperty ("fileName", fileName);

     Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
     response.sendRedirect("listThings.jsp");
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
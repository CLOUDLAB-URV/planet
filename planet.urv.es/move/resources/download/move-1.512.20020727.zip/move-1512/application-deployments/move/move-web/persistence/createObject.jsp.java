import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import com.evermind.io.FilePostParser;
import com.evermind.io.PostFileInputStream;
import ants.move.ejb.*;
import java.io.*;
import java.util.zip.*;
import ants.move.core.*;

public class __jspPage2_createObject_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage2_createObject_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

  String toolKey = "object.v01";
  String worldKey=(String)session.getAttribute("worldId");
  String placeKey=(String)session.getAttribute("placeId");
  String userLogin = ((User)session.getAttribute("user")).getLogin();
  String userRole = ((User)session.getAttribute("user")).getRole();

 if (request.getMethod().equalsIgnoreCase("GET")) {

    lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");

 


			out.write("\r\n<html>\r\n\r\n<body >\r\n<center>\r\n<table width=90%>\r\n\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("uploadObject")
			);

			out.write(" : </b></font></td></tr>\r\n\r\n <form enctype=\"multipart/form-data\" method=\"POST\">\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <br>\r\n  </td>\r\n </tr>\r\n\r\n <tr>\r\n  <td colspan=\"3\">\r\n  <b>");
			out.print(
				labels.getString("objectName")
			);

			out.write(" :</b> <br>\r\n     <input type=\"text\" name=\"Name\" size=\"20\">\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("objectDescription")
			);

			out.write(" :</b><br>\r\n    <input type=\"text\" name=\"Desc\"  size=\"50\">\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <input type=\"checkbox\" name=\"copy\">\r\n    <b>");
			out.print(
				labels.getString("copy")
			);

			out.write("</b>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <input type=\"checkbox\" name=\"catch\">\r\n    <b>");
			out.print(
				labels.getString("catch")
			);

			out.write("</b>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("chooseZipFile")
			);

			out.write(" :</b><br>\r\n     <input type=\"file\" name=\"file\">\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <br>\r\n    <center><input type=submit name=action value=\"");
			out.print(
				labels.getString("upload")
			);

			out.write("\"> <input TYPE=\"reset\" VALUE=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n    </center>\r\n  </td>\r\n </tr>\r\n</form>\r\n</table>\r\n</center>\r\n\r\n</BODY>\r\n</HTML>\r\n  ");
			

}else{
  try{
   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String thingCopy="";
   String thingCatch="";
   String fileName="";

    Enumeration enumeration = new FilePostParser(request.getInputStream(),
                                                 request.getContentLength());
    while( enumeration.hasMoreElements() ) {
         Object element = enumeration.nextElement();
         if( element instanceof Map.Entry ) {
              Map.Entry entry = (Map.Entry)element;

              if ((entry.getKey()).equals("Name")){
	     	     thingName = (String)entry.getValue();

	      }
	      if ((entry.getKey()).equals("Desc")){
	             thingDesc = (String)entry.getValue();
	      }
              if ((entry.getKey()).equals("copy")){
	             if(((String)entry.getValue()).equalsIgnoreCase("on")){
                       thingCopy = new String("true");
                     }else{
                       thingCopy = new String("false");
                     }

	      }
	      if ((entry.getKey()).equals("catch")){
	             if(((String)entry.getValue()).equalsIgnoreCase("on")){
                       thingCatch = new String("true");
                     }else{
                       thingCatch = new String("false");
                     }
	      }


         }
         else if( element instanceof PostFileInputStream ) {
              PostFileInputStream in = (PostFileInputStream)element;
              String s=in.getFileName();
              int index=s.lastIndexOf("\\");
              if(index == -1){
                 //Unix platform
                 index=s.lastIndexOf("/");
              }



              fileName=thingKey+"_"+s.substring(index+1);
              File f = new File (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey);
                             
              f.mkdir ();
              FileOutputStream fout = new FileOutputStream
        		          (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey+"/bak.zip");

              int bite;
              while((bite=in.read()) != -1)
                   fout.write(bite);

              in.close();
              fout.close();
         }

    }

    ZipFile zip = new ZipFile (pageContext.getServletContext().getRealPath("/resources/things/objbak/")+thingKey+"/bak.zip");
    File f = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+thingKey);
    f.mkdir ();
    for (Enumeration originFiles = zip.entries(); originFiles.hasMoreElements(); ) {
           ZipEntry ze = (ZipEntry) originFiles.nextElement();
           if(ze.isDirectory()){
              (new File(pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/") + thingKey + "/" +ze.getName())).mkdir();
              continue;

           } 
           FileOutputStream destinyFile = new FileOutputStream
                                                (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")
                                                 + thingKey +"/" + ze.getName());
           InputStream inzip = zip.getInputStream (ze);
           BufferedOutputStream outzip=new BufferedOutputStream(destinyFile);
           byte[] buffer = new byte[1024];
           int len;

           while((len = inzip.read(buffer)) >= 0)
              outzip.write(buffer, 0, len);

           inzip.close();
           outzip.close();

           

     }
     zip.close();

    ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
    ants.move.ejb.Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
    thing.setDescription(thingDesc);
    thing.setProperty("date",(new Date()).toGMTString());
    thing.setProperty("owner",userLogin);
    thing.setProperty("fileName",thingKey);
    thing.setProperty("translation","0 1 0");
    thing.setProperty("rotation","0 0 1 0");
    thing.setProperty("scale","1 1 1 ");
    thing.setProperty("copy",thingCopy);
    thing.setProperty("catch",thingCatch);


   //Add Thing to running Move Applet
    Hashtable env = new Hashtable();
    Constants.init(request.getRealPath(""));
    env.put(Constants.NSPORT, Constants.getNSPort());
    env.put(Constants.ANTSCLASS, Constants.getAntsClass());
    env.put(Constants.SERVER, Constants.getServer());
    ants.comm.Session commSession = ants.comm.SessionFactory.createSession (env);

    Hashtable evt2 = new Hashtable();
    evt2.put(Constants.WORLD, worldKey);
    evt2.put(Constants.PLACE, placeKey);
    evt2.put("CLASS","OBJECT.V01");
    evt2.put("METHOD","NEWTHING");
    evt2.put("THINGKEY",thingKey);
    commSession.send(evt2);
    commSession.close();

    Syslog.debug (this, "Uploaded thing of tool = " +toolKey );



			out.write("\r\n  <script> window.close(); </script>\r\n\r\n");
			
}catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }

}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
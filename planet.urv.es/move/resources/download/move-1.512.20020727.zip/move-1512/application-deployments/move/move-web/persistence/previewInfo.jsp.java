import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage5_previewInfo_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage5_previewInfo_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			

String thingId = request.getParameter("thingId");
String worldKey=(String)session.getAttribute("worldId");
String placeKey=(String)session.getAttribute("placeId");
Thing thing=null;

LanguageUtilities lang = (LanguageUtilities)session.getAttribute("language");
ResourceBundle labels=lang.getResource("ants.move.lang.LabelsBundle");

try{
  ThingManager thm = (ThingManager)session.getAttribute("thingManager");
  thing=thm.getThing(thingId);

} catch (Exception e) {
    Syslog.log (this, e);
}





			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("previewInfo")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n <tr>\r\n  <td colspan=\"3\">\r\n  <table bgcolor=\"teal\" align=\"center\" width=\"80%\">\r\n   <td align=\"center\">\r\n      <img  height=\"200\" src=\"");
			out.print(
				request.getContextPath()
			);

			out.write("/worlds/");
			out.print(
				worldKey
			);

			out.write("/");
			out.print(
				placeKey
			);

			out.write("/");
			out.print(
				thing.getProperty("fileName")
			);

			out.write("\">\r\n   </td>\r\n   </table>\r\n  </td>\r\n </tr>\r\n</form>\r\n</table>\r\n\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</BODY>\r\n</HTML>\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
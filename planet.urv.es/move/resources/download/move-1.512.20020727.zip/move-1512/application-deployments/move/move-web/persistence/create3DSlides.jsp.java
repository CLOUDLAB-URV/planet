import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import java.io.*;
import com.evermind.io.*;
import java.util.zip.*;

public class __jspPage0_create3DSlides_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_create3DSlides_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

 String worldKey=(String)session.getAttribute("worldId");
 String placeKey=(String)session.getAttribute("placeId");
 String userLogin = ((User)session.getAttribute("user")).getLogin();
 String toolKey = "s3d.v01";

 if (request.getMethod().equalsIgnoreCase("GET")) {
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");
 


			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("upload3DSlides")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n\r\n <form enctype=\"multipart/form-data\" method=\"POST\">\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <br>");
			out.print(
				messages.getString("uploadSlides3D")
			);

			out.write("\r\n     <br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n  <b>");
			out.print(
				labels.getString("presentationName")
			);

			out.write(" :</b> <input type=\"text\" name=\"Name\" size=\"20\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("presentationDescription")
			);

			out.write(" :</b>\r\n    <input type=\"text\" name=\"Desc\"  size=\"50\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <b>");
			out.print(
				labels.getString("chooseZipFile")
			);

			out.write(" :</b><input type=\"file\" name=\"file\"><br><br>\r\n  </td>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"3\">\r\n    <center><input type=submit name=action value=\"");
			out.print(
				labels.getString("upload")
			);

			out.write("\"> <input TYPE=\"reset\" VALUE=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n    </center>\r\n  </td>\r\n </tr>\r\n</form>\r\n</table>\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</BODY>\r\n</HTML>\r\n  ");
			

}else{

   String thingKey=""+System.currentTimeMillis();
   String thingName="";
   String thingDesc="";
   String fileName="";
   Vector thingFiles=new Vector();

   Enumeration enumeration = new FilePostParser(request.getInputStream(),
                                                request.getContentLength());
   while( enumeration.hasMoreElements() ) {
          Object element = enumeration.nextElement();
          if( element instanceof Map.Entry ) {
               Map.Entry entry = (Map.Entry)element;

               if ((entry.getKey()).equals("Name"))
		   thingName = (String)entry.getValue();
               if ((entry.getKey()).equals("Desc"))
		   thingDesc = (String)entry.getValue();



           }
           else if( element instanceof PostFileInputStream ) {
               PostFileInputStream in = (PostFileInputStream)element;
               File file=new File(in.getFileName());

               fileName=file.getName();
               FileOutputStream fout = new FileOutputStream
       		          (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
               int bite;
               while((bite=in.read()) != -1)
                   fout.write(bite);

               in.close();
               fout.close();

           }
    }

    ZipFile zip = new ZipFile (pageContext.getServletContext().getRealPath("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
    byte[] buffer = new byte [1024];
    for (Enumeration images = zip.entries(); images.hasMoreElements(); ) {
           ZipEntry ze = (ZipEntry) images.nextElement();
           File f = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+thingKey);
           f.mkdir ();
           FileOutputStream slide = new FileOutputStream
                                                (pageContext.getServletContext().getRealPath("/worlds/"
                                                 + worldKey+"/"+placeKey+"/")+thingKey + "/"
                                                 + ze.getName());
           InputStream inzip = zip.getInputStream (ze);
           int ix;
           while ((ix = inzip.read (buffer, 0, 1024)) != -1) {
              if (ix != 1024) {
                  byte[] buf2 = new byte [ix];
                  for (int k = 0; k < ix; k++) {
                      buf2[k] = buffer[k];
                  }
                  slide.write (buf2);
                } else {
                    slide.write (buffer);
                }
           }
           if (ze.getName().endsWith(".wrl") || ze.getName().endsWith(".wrz")) {
              thingFiles.addElement("../../../worlds/"+worldKey+"/"+placeKey+"/" + thingKey + "/" + ze.getName());
           }

     }
     zip.close();
     File f = new File (pageContext.getServletContext().getRealPath
                             ("/worlds/"+worldKey+"/"+placeKey+"/")+fileName);
     f.delete();
     ThingManager thingManager = (ThingManager)session.getAttribute("thingManager");
     Thing thing=thingManager.createThing(thingKey,thingName,placeKey,toolKey);
     thing.setDescription(thingDesc);
     thing.setProperty("date",(new Date()).toGMTString());
     thing.setProperty("owner",userLogin);
     thing.setProperty ("3DslidesSize", ""+thingFiles.size());
     Enumeration e = thingFiles.elements();
     int idx = 1;
     while (e.hasMoreElements()) {
       thing.setIndexedProperty ("3Dslides", (String) e.nextElement(), idx);
       idx++;
     }
     Syslog.debug (this, "Uploaded thing of tool = " +toolKey );
     response.sendRedirect("listThings.jsp");
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
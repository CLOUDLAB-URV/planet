import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage4_index_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage4_index_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

if(request.getMethod().equalsIgnoreCase("get")){

   if((request.getParameter("lang")==null) && (request.getParameter("retry")==null)){
     //load the default LanguageUtilities
     Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"move.properties");
          props.load(fis);
        }catch(IOException e){System.out.println(e);}
     lang=new LanguageUtilities(props.getProperty("language"),props.getProperty("country"));
   try{
     labels=ResourceBundle.getBundle("ants.move.lang.LabelsBundle",lang.getLocale());
     messages=ResourceBundle.getBundle("ants.move.lang.MessagesBundle",lang.getLocale());
     lang.addResource(labels,"ants.move.lang.LabelsBundle");
     lang.addResource(messages,"ants.move.lang.MessagesBundle");


   }catch(Exception e){Syslog.error(this,"Resource not found");}

   }else if(request.getParameter("lang")!=null){

      //load LanguageUtilities
      if((request.getParameter("lang")).equals("CAT"))
        lang=new LanguageUtilities("ca","ES");
      else if((request.getParameter("lang")).equals("ESP"))
        lang=new LanguageUtilities("es","ES");
      else if((request.getParameter("lang")).equals("ENG"))
        lang=new LanguageUtilities("en","UK");

      try{
        labels=ResourceBundle.getBundle("ants.move.lang.LabelsBundle",lang.getLocale());
        messages=ResourceBundle.getBundle("ants.move.lang.MessagesBundle",lang.getLocale());
        lang.addResource(labels,"ants.move.lang.LabelsBundle");
        lang.addResource(messages,"ants.move.lang.MessagesBundle");


   }catch(Exception e){Syslog.error(this,"Resource not found");}
  }





			out.write("\r\n\r\n<html>\r\n\t<head>\r\n\t\t<title>MOVE! Multiuser Oriented Virtual Environment</title>\r\n\t</head>\r\n<body ");
			
if(request.getParameter("retry")!=null){
  


			out.write("onLoad=\"alert(document.alertString.logFailed.value);\"");
			
}


			out.write(">\r\n<br><br>\r\n<center>\r\n<table width=20%>\r\n  <tr>\r\n      <td><br><br><br><img src=\"images/move.jpg\"></td><br><br>\r\n  </tr>\r\n  <tr>\r\n  <td valign=top bgcolor=\"#E6E4DD\">\r\n   <form method=\"post\">\r\n      <font size=2 color=\"red\" face=\"courier\">\r\n        <br>");
			out.print(
				labels.getString("user1")
			);

			out.write(":<br>\r\n        <b>Login:</b><input type=\"text\" name=\"login\" size=\"10\"><br>\r\n        <b>Passw:</b><input type=\"password\" name=\"pass\" size=\"10\"><br>\r\n        <center><br>\r\n        <input type=\"submit\" size=10 type=BUTTON value=\"");
			out.print(
				labels.getString("join")
			);

			out.write("\">\r\n        </center><br>\r\n      </font>\r\n   </form>\r\n  </td>\r\n  </tr>\r\n</table><br><br>\r\n<table width=20%>\r\n  <tr>\r\n  <tr>\r\n   <td><a href=\"index.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("?lang=CAT\"><img src=\"images/cat.gif\" border=\"0\" width=\"50\" height=\"50\"></a>\r\n   <td><a href=\"index.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("?lang=ESP\"><img src=\"images/esp.gif\" border=\"0\" width=\"50\" height=\"50\"></a>\r\n   <td><a href=\"index.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("?lang=ENG\"><img src=\"images/uk.gif\" border=\"0\" width=\"50\" height=\"50\"></a>\r\n  </tr>\r\n  <tr align=center>\r\n   <td valign=top><font size=2>catal\u00e0</font></td>\r\n   <td><font size=2>castellano</font></td>\r\n   <td><font size=2>english</font></td>\r\n  </tr>\r\n</table>\r\n </center>\r\n <!-- this form contains the alert string value that we obtain from current Language ResourceBundle-->\r\n <form name=\"alertString\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"logFailed\" VALUE=\"");
			out.print(
				messages.getString("alertLogging")
			);

			out.write("\">\r\n </form>\r\n</body>\r\n</html>\r\n\r\n");
			

}else{
      //load userManager
      Syslog.setLogMask("ERROR");
      Context initial = new InitialContext();
      Object obj = initial.lookup("java:comp/env/UserManagerBean");
      UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow (obj, UserManagerHome.class);
      UserManager um = home5.create();
      session.setAttribute("userManager",um);

      User user=um.getUser(request.getParameter("login"));
      if(user!=null){
        if(user.getPassword().equalsIgnoreCase(request.getParameter("pass"))){
          session.setAttribute("user",user);
          session.setAttribute("language",lang);
          response.sendRedirect("loadContext.jsp");
        }else{
          response.sendRedirect("index.jsp?retry=true");
        }
      }
      else{
          response.sendRedirect("index.jsp?retry=true");
      }
}



			out.write("\r\n\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
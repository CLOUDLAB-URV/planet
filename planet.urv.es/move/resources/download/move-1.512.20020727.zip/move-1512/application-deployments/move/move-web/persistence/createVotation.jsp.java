import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage13_createVotation_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage13_createVotation_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n  <html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("createVot")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n    <b>");
			out.print(
				messages.getString("createVotation")
			);

			out.write("</b>\r\n    </td>\r\n   </tr>\r\n   <form method=\"post\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("topic")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"50\" name=\"topic\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   </form>\r\n  </table>\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n </HTML>\r\n");
			

}else{
 try{
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  Thing thing=thm.createThing(""+System.currentTimeMillis(),"Votation",
                            (String)session.getAttribute("placeId"),"votation.v01");
  thing.setDescription(request.getParameter("topic"));
  thing.setProperty("yes","----");
  thing.setProperty("no","----");
  thing.setProperty("unknown","----");
  thing.setProperty("usersList","----");
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
//
//	Users list cal que sigui un indexedProperty. Actualmetnt mti no ho suporta per\u00f2
//	ho far\u00e0 en la propera versi\u00f3
//
//

  response.sendRedirect("listThings.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}



			out.write("\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
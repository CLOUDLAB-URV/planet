import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import java.io.*;

public class __jspPage11_createPlace_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels,messages;
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage11_createPlace_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");

  Properties props = new Properties();
  FileInputStream fis = new FileInputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
  props.load(fis);



			out.write("\r\n <html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("createPlace")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n\r\n<table width=90%>\r\n   <form method=\"post\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("placeName")
			);

			out.write(" : </b><input type=\"text\" size=\"30\" maxlength=\"30\" name=\"name\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("placeDescription")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"50\" name=\"description\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("placeType")
			);

			out.write(" : </b>\r\n      <select name=\"type\">\r\n      ");
			

        String key;
        String value;
        for(Enumeration e=props.keys();e.hasMoreElements();){
          key=(String)e.nextElement();
          value=(String)props.get(key);

          


			out.write("\r\n          <option value=\"");
			out.print(
				value
			);

			out.write("\"> ");
			out.print(
				value.substring(0,value.lastIndexOf("_"))
			);

			out.write("\r\n          ");
			

        }
      


			out.write("\r\n      </select>\r\n      <a href=\"newPlace.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write("</FONT></a>\r\n\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n      <br> <hr>\r\n    </td>\r\n   </tr>\r\n  </form>\r\n  <tr>\r\n   <td><H3>-");
			out.print(
				messages.getString("previewPlace")
			);

			out.write(":</h3></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n     ");
			

        for(Enumeration e=props.keys();e.hasMoreElements();){
          key=(String)e.nextElement();
          value=(String)props.get(key);
          


			out.write("\r\n           <a href=\"resources/things/places/");
			out.print(
				props.get(key)
			);

			out.write("/main.wrl\" target=\"_blank\"><b>[");
			out.print(
				value.substring(0,value.lastIndexOf("_"))
			);

			out.write("]</b></a>&nbsp;&nbsp;\r\n          ");
			

        }
      


			out.write("\r\n   </td>\r\n  </tr>\r\n </table>\r\n </center>\r\n      <br><br>\r\n\r\n\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n </HTML>\r\n");
			

}else{
 try{
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  String worldId=(String)session.getAttribute("worldId");
  int num=pm.getPlaces(worldId).size();
  if(num!=0){
    Place p;
    for(Iterator i=pm.getPlaces(worldId).iterator();i.hasNext();){
      p=(Place)i.next();
      if(p.getProperty("lastCreated").equalsIgnoreCase("true")){
        num=Integer.parseInt(p.getId().substring(p.getId().lastIndexOf("P")+1));
        num++;
        p.setProperty("lastCreated","false");
      }
    }
  }

  String placeId=worldId+"_P"+num;
  Place place=pm.createPlace(placeId,request.getParameter("name"),
                            request.getParameter("type"),worldId);
  place.setDescription(request.getParameter("description"));
  place.setProperty("date",(new Date()).toGMTString());
  place.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  place.setProperty("lastCreated","true");
  Tool tool=null;
  for (Iterator i=tm.getTools().iterator();i.hasNext();){
    tool=(Tool)i.next();
    place.setProperty(tool.getId(),"inactive");
  }
  response.sendRedirect("createWrl.jsp?placeId="+placeId+"&placeType="+request.getParameter("type"));
 }catch(Exception e){
  Syslog.error(this,"Unable to create Place :"+ e);
 }
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
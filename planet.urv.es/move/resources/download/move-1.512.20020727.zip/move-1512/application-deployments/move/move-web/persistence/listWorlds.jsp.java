import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage2_listWorlds_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage2_listWorlds_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			
  lang = (LanguageUtilities)session.getAttribute("language");
    labels=lang.getResource("ants.move.lang.LabelsBundle");
    messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS&linked=false");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("chooseWorld")
			);

			out.write(" : </b></font></td></tr>\r\n<tr>\r\n  <td align=\"right\" >\r\n    <FONT FACE=\"impact\" SIZE=4 COLOR=\"green\">");
			out.print(
				labels.getString("new")
			);

			out.write(":</FONT>&nbsp;\r\n\r\n    <a href=\"createWorld.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">World</font></a>&nbsp;&nbsp;&nbsp;&nbsp;\r\n    ");
			

    if(((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
    


			out.write("\r\n      <a href=\"listUsers.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">");
			out.print(
				labels.getString("user1")
			);

			out.write("</font></a>\r\n    ");
			
}


			out.write("<br><br>\r\n  </td>\r\n</tr>\r\n</table>\r\n\r\n\r\n  ");
			


   try {
      WorldManager wm = (WorldManager)session.getAttribute("worldManager");
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");

     if((wm.getWorlds().size())!=0){ 


			out.write("\r\n       <table border=\"0\" bgcolor=\"teal\" width=\"90%\">\r\n         <TR>\r\n\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("nameTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("typeTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("descriptionTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">Places</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("creationTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("createdTH")
			);

			out.write("</TH>\r\n\r\n         </TR>\r\n      ");
			

       Collection worlds=wm.getWorlds();

       int placeNum;
       World world=null;
       for (Iterator i=worlds.iterator();i.hasNext();){
         world=(World)i.next();
         if(pm.getPlaces(world.getId())!=null){
           placeNum=pm.getPlaces(world.getId()).size();
         }else{
           placeNum=0;
         }
         


			out.write("\r\n         <TR ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <TD align=\"left\"><A href=\"listPlaces.jsp?worldId=");
			out.print(
				world.getId()
			);

			out.write("\"><B>");
			out.print(
				world.getName()
			);

			out.write("</B></A></TD><TD>");
			out.print(
				world.getType()
			);

			out.write("</TD><TD>");
			out.print(
				world.getDescription()
			);

			out.write("</TD>\r\n          <TD>");
			out.print(
				placeNum
			);

			out.write("</TD><TD>");
			out.print(
				lang.translateDateTime(new Date(world.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</TD><TD>");
			out.print(
				world.getProperty("owner")
			);

			out.write("</TD>\r\n          <TD bgcolor=\"white\">\r\n          ");
			

          if(((User)session.getAttribute("user")).getLogin().equalsIgnoreCase(world.getProperty("owner"))
            ||((User)session.getAttribute("user")).getRole().equalsIgnoreCase("root")){
          


			out.write("\r\n            <a href=\"removeWorld.jsp?worldId=");
			out.print(
				world.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a>\r\n          ");
			

          }
          


			out.write("\r\n          </TD>\r\n         </TR>\r\n\r\n\r\n\r\n        ");
			

      }
     }
   } catch (Exception e) {
      Syslog.log (this, e);
   }
  


			out.write("        </table>\r\n\r\n<br><br>\r\n\r\n\r\n</center>\r\n");
			pageContext.include("footer.jsp");

			out.write("\r\n</body>\r\n<HTML>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
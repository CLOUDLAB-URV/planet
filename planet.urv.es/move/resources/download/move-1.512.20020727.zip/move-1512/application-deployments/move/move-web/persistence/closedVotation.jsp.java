import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage8_closedVotation_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage8_closedVotation_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			

Thing thing =((ThingManager)session.getAttribute("thingManager")).getThing(request.getParameter("thingId"));
if(request.getParameter("vote").equalsIgnoreCase("yes")){
  String syes = thing.getProperty ("yes");
  int yes;
  if (syes.equalsIgnoreCase ("----")) {
     yes = 0;
  }
  else {
   yes = Integer.parseInt (syes);
  }
  yes++;
  thing.setProperty("yes",""+yes);
}else if (request.getParameter("vote").equalsIgnoreCase("no")){
  String sno = thing.getProperty ("no");
  int no;
  if (sno.equalsIgnoreCase ("----")) {
     no = 0;
  }
  else {
   no = Integer.parseInt (sno);
  }
  no++;
  thing.setProperty("no",""+no);
}else if(request.getParameter("vote").equalsIgnoreCase("unknown")){
  String sunknown = thing.getProperty ("unknown");
  int unknown;
  if (sunknown.equalsIgnoreCase ("----")) {
     unknown = 0;
  }
  else {
   unknown = Integer.parseInt (sunknown);
  }
  unknown++;
  thing.setProperty("unknown",""+unknown);
}
response.sendRedirect("previewVotation.jsp?thingId="+request.getParameter("thingId"));



			out.write("\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
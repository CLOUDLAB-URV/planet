import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import net.yagga.util.Unzip;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import com.evermind.io.FilePostParser;
import com.evermind.io.PostFileInputStream;
import ants.move.ejb.*;
import java.io.*;
import java.util.zip.*;

public class __jspPage6_newPlace_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels,messages;
    LanguageUtilities lang;
  String placeType=null;
  String placeName=null;

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage6_newPlace_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
  messages=lang.getResource("ants.move.lang.MessagesBundle");
   



			out.write("\r\n <html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("newPlace")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n\r\n<table width=90%>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n    <br>");
			out.print(
				messages.getString("uploadPlace")
			);

			out.write("<br><br>\r\n    </td>\r\n   </tr>\r\n   <form enctype=\"multipart/form-data\" method=\"POST\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("placeType")
			);

			out.write(" : </b><input type=\"text\" size=\"10\" maxlength=\"12\" name=\"type\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("chooseFile")
			);

			out.write(" :</b><input type=\"file\" name=\"file\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   </form>\r\n  </table>\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n</body>\r\n</HTML>\r\n");
			

}else{
   String fileName="";
   
   Properties props = new Properties();
   FileInputStream fis = new FileInputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
   
   props.load(fis);
   
   fis.close();

   Enumeration enumeration = new FilePostParser(request.getInputStream(), 
                                                request.getContentLength()); 
       while( enumeration.hasMoreElements() ) { 
          Object element = enumeration.nextElement(); 
          if( element instanceof Map.Entry ) { 
               Map.Entry entry = (Map.Entry)element; 
       
               if ((entry.getKey()).equals("type"))
		   placeType = (String)entry.getValue();

               
               
           } 
           else if( element instanceof PostFileInputStream ) { 
               PostFileInputStream in = (PostFileInputStream)element;
               File file=new File(in.getFileName());

               fileName=file.getName();
              

               FileOutputStream fout = new FileOutputStream
       		          (pageContext.getServletContext().getRealPath("/resources/things/")+fileName);
               int bite;
               while((bite=in.read()) != -1)
                   fout.write(bite);
          
               in.close();
               fout.close();

              
              
            
           }
       }
    
    placeName=placeType+"_"+System.currentTimeMillis();             
    File f = new File (pageContext.getServletContext().getRealPath
                             ("/resources/things/places/"+placeName));
    f.mkdir ();
    
    

    props.setProperty("place"+(props.size()+1),placeName);

    Unzip u=new Unzip(pageContext.getServletContext().getRealPath("/resources/things/")+fileName,pageContext.getServletContext().getRealPath("/resources/things/places/")+placeName);
    u.uncompress(false); 
    

     File f2 = new File (pageContext.getServletContext().getRealPath("/resources/things/")+fileName);
     f2.delete();

   
   
   FileOutputStream fos = new FileOutputStream((pageContext.getServletContext()).getRealPath("")+File.separator+"places.properties");
   props.store(fos,"Base places");
   fos.close();
   
   response.sendRedirect("createPlace.jsp");
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;
import java.io.*;

public class __jspPage4_editUserProps_jsp extends com.orionserver.http.OrionHttpJspPage
{
 User user;
    UserManager um;
    ResourceBundle labels,messages;
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage4_editUserProps_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n\r\n\r\n");

			out.write("\r\n");
			


try{
  um = (UserManager)session.getAttribute("userManager");
}catch(Exception e){
  Syslog.error(this,"Unable to create UserManager");
}

if(request.getMethod().equalsIgnoreCase("GET")){
          lang = (LanguageUtilities)session.getAttribute("language");
          labels=lang.getResource("ants.move.lang.LabelsBundle");
          messages=lang.getResource("ants.move.lang.MessagesBundle");
	  user=um.getUser(request.getParameter("user"));



			out.write("\r\n<html>\r\n  <head>\r\n  <script>\r\n    <!--\r\n\r\n    function changeAvatar(){\r\n      var avatarString=document.user.avatar.options[document.user.avatar.selectedIndex].text\r\n      var vrmlString=\"NavigationInfo{\\n\"+\"type \\\"NONE\\\"\\n\"+\"}\\n\"+\r\n                     \"DEF PreviewViewpoint Viewpoint{\\n\"+\"position 0 -0.8 2\\n\"+\"}\\n\"+\r\n                     \"SpotLight{\\n\"+\"location 0 -0.8 2\\n\"+\"intensity 2.0\\n\"+\"color 1.0 1.0 1.0\\n\"+\"}\\n\"+\r\n                     \"DEF Movment TimeSensor{\\n\"+\"cycleInterval 5\\n\"+\"loop TRUE\\n\"+\"startTime  1\\n\"+\"}\\n\"+\r\n\t\t     \"DEF AvatarMovment OrientationInterpolator{\\n\"+\"key [ 0 0.5 1 ]\\n\"+\"keyValue [0 1 0 0, 0 1 0 3.14, 0 1 0 6.28 ]\\n\"+\"}\\n\"+\r\n                     \"DEF Avatar Transform{\\n\"+\"children[\\n\"+\"DEF source Inline{\\n\"+\"url [\"+avatarString+\"]\\n\"+\"}\\n\"+\"]\\n\"+\"}\\n\"+\r\n                     \"ROUTE Movment.fraction_changed TO AvatarMovment.set_fraction\\n\"+\r\n                     \"ROUTE AvatarMovment.value_changed TO Avatar.set_rotation\\n\"\r\n\r\n      var browser=parent.frames[1].document.embeds[0]\r\n      browser.replaceWorld(browser.createVrmlFromString(vrmlString))\r\n\r\n    }\r\n\r\n    function testObligatoryField(field){\r\n\tif(field.value.length==0) return false\r\n\treturn true\r\n    }\r\n\r\n    function testPasswordFields(field1,field2){\r\n\tif(field1.value!=field2.value) return false\r\n        return true\r\n    }\r\n\r\n    function testOK(form){\r\n       var ok=false\r\n       if(testObligatoryField(form.name)){\r\n\t  if(testObligatoryField(form.surname)){\r\n \t     if(testObligatoryField(form.password)){\r\n\t        if(testObligatoryField(form.password2)){\r\n\t           if(testPasswordFields(form.password,form.password2))\r\n\t\t      ok=true\r\n                   else alert(document.alertStrings.twoPass.value)\r\n\t        }else alert(document.alertStrings.password2.value)\r\n             }else alert(document.alertStrings.password1.value)\r\n          }else alert(document.alertStrings.surname.value)\r\n       }else alert(document.alertStrings.name.value)\r\n\r\n       return ok\r\n\r\n    }\r\n    \r\n     // -->\r\n  </script>\r\n  </head>\r\n  <body onLoad=\"changeAvatar();\">\r\n");
			

   if ((user.getRole()).equalsIgnoreCase("root")){



			out.write("\r\n");
			pageContext.include("header.jsp?string=/WORLDS/USERS&linked=true");

			out.write("\r\n");
			
 }else{ 


			out.write("\r\n");
			pageContext.include("header.jsp?string=/WORLDS&linked=true");

			out.write("\r\n");
			
 } 


			out.write("\r\n<center>\r\n<table width=90%>\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("editUser")
			);

			out.write(" :</b></font></td></tr>\r\n   <tr>\r\n    <td colspan=\"3\"><br>\r\n    </td>\r\n   <tr>\r\n    <td colspan=\"3\"><b>");
			out.print(
				(labels.getString("loginIT")).toUpperCase()
			);

			out.write(": </b><big><i>");
			out.print(
				request.getParameter("user")
			);

			out.write("</i></big></td>\r\n   </tr>\r\n  </table>\r\n  <hr noshade width=90%>\r\n  <form name=\"user\" onSubmit=\"return testOK(user)\" method=\"post\">\r\n\r\n   <table  width=90%>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("nameUserIT")
			);

			out.write(" : </b><input type=\"text\" size=\"20\" maxlength=\"20\" name=\"name\" value=\"");
			out.print(
				user.getProperty("name")
			);

			out.write("\">\r\n    </td>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("surnameIT")
			);

			out.write(" : </b><input type=\"text\" size=\"40\" maxlength=\"40\" name=\"surname\" value=\"");
			out.print(
				user.getProperty("surname")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("emailIT")
			);

			out.write(" : </b><input type=\"text\" size=\"30\" maxlength=\"30\" name=\"email\" value=\"");
			out.print(
				user.getProperty("email")
			);

			out.write("\">*\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("passwordIT")
			);

			out.write(" : </b><input type=\"password\" size=\"20\" maxlength=\"20\" name=\"password\" value=\"");
			out.print(
				user.getPassword()
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("passwordConfirmation")
			);

			out.write(" : </b><input type=\"password\" size=\"20\" maxlength=\"20\" name=\"password2\" value=\"");
			out.print(
				user.getPassword()
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   ");
			
 if((((User)session.getAttribute("user")).getRole()).equalsIgnoreCase("root")){  


			out.write("\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("roleTH")
			);

			out.write(" : </b><select name=\"role\">\r\n              ");
			
      if(user.getRole().equals("root")){


			out.write("\r\n                                <option value=\"root\">");
			out.print(
				lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option value=\"teacher\">");
			out.print(
				lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option value=\"student\">");
			out.print(
				lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n\t      ");
			
      }else if(user.getRole().equals("teacher")){


			out.write("\r\n                                <option value=\"root\">");
			out.print(
				lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option selected value=\"teacher\">");
			out.print(
				lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option value=\"student\">");
			out.print(
				lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n\t      ");
			
      }else if(user.getRole().equals("student")){


			out.write("\r\n      \t\t\t        <option value=\"root\">");
			out.print(
				lang.translateText("root","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option value=\"teacher\">");
			out.print(
				lang.translateText("teacher","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n      \t\t\t        <option selected value=\"student\">");
			out.print(
				lang.translateText("student","ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("\r\n              ");
			
      } 


			out.write("\r\n\r\n      \t\t    </select>\r\n\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("world")
			);

			out.write(" : </b><select name=\"world\">\r\n      ");
			

      try{
        WorldManager wm=(WorldManager)session.getAttribute("worldManager");
        Collection wl=wm.getWorlds();
        World world;
        for(Iterator it=wl.iterator();it.hasNext();){
           world=(World)it.next();
           if(!world.getName().equals(user.getProperty("world"))){

      


			out.write("\r\n                        <option>");
			out.print(
				world.getName()
			);

			out.write("\r\n      ");
			
   }else{


			out.write("\r\n                        <option selected>");
			out.print(
				world.getName()
			);

			out.write("\r\n      ");
			
   }
        }
      } catch (Exception e) {
         Syslog.log (this,e);
      }
      


			out.write("\r\n      \t\t     </select>\r\n\r\n    </td>\r\n   </tr>\r\n   ");
			
 } 


			out.write("\r\n   <tr>\r\n    <td>\r\n      <b>");
			out.print(
				labels.getString("avatar")
			);

			out.write(" : </b><select name=\"avatar\" onChange=\"changeAvatar()\">\r\n      ");
			

        Properties props=null;
	try{
          props=new Properties();
	  FileInputStream fis=new FileInputStream(request.getRealPath("/")+"resources/avatars/avatars.properties");
          props.load(fis);
        }catch(IOException e){
           Syslog.error(this,"Unable to read the \"avatars.properties file\"");
        }
        try{
          for(int i=1;i<=Integer.parseInt(props.getProperty("avatarsNum"));i++){
             if(!props.getProperty("avatar"+Integer.toString(i)).equals(user.getProperty("avatar"))){

      


			out.write("\r\n                        <option>");
			out.print(
				props.getProperty("avatar"+Integer.toString(i))
			);

			out.write("\r\n      ");
			
     }else{


			out.write("\r\n                        <option selected>");
			out.print(
				props.getProperty("avatar"+Integer.toString(i))
			);

			out.write("\r\n\r\n       ");
			
    }
          }
        }catch(Exception e){
           Syslog.error(this,"Incorrect file format: \"avatars.properties\"");
        }
       


			out.write("\r\n\t              </select>\r\n\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n     <td colspan=\"3\"><font size=\"-1\"><i>(*) ");
			out.print(
				labels.getString("optional")
			);

			out.write("</i></font></td>\r\n   </tr>\r\n   <tr>\r\n    <td align=\"center\"><input type=\"submit\" value=\"");
			out.print(
				labels.getString("update")
			);

			out.write("\" ></td>\r\n   </tr>\r\n  </table>\r\n  </form>\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n\r\n  <!-- this form contains the alert string values that we obtain from current Language ResourceBundle-->\r\n  <form name=\"alertStrings\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"name\" VALUE=\"");
			out.print(
				messages.getString("alertName")
			);

			out.write("\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"surname\" VALUE=\"");
			out.print(
				messages.getString("alertSurname")
			);

			out.write("\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"login\" VALUE=\"");
			out.print(
				messages.getString("alertLogin")
			);

			out.write("\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"password1\" VALUE=\"");
			out.print(
				messages.getString("alertPass1")
			);

			out.write("\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"password2\" VALUE=\"");
			out.print(
				messages.getString("alertPass2")
			);

			out.write("\">\r\n    <INPUT TYPE=\"HIDDEN\" name=\"twoPass\" VALUE=\"");
			out.print(
				messages.getString("alertTwoPass")
			);

			out.write("\">\r\n  </form>\r\n </body>\r\n</html>\r\n");
			

}else{


        user.setPassword(request.getParameter("password"));
//        user.setRole(request.getParameter("role"));


        user.setProperty("name",request.getParameter("name"));
        user.setProperty("surname",request.getParameter("surname"));
        user.setProperty("email",request.getParameter("email"));
//        user.setProperty("world",request.getParameter("world"));
        user.setProperty("avatar",request.getParameter("avatar"));




			out.write("\r\n        <script>\r\n          <!--\r\n             parent.location=\"listUsers.jsp\"\r\n          // -->\r\n        </script>\r\n\r\n\r\n");
			

}



			out.write("\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
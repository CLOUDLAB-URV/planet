import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.ejb.*;
import ants.move.builder.*;
import java.net.*;
import java.util.*;
import com.protomatter.syslog.*;
import java.rmi.*;

public class __jspPage12_createWrl_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage12_createWrl_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			

try {
 try{
  Syslog.debug (this, "Capturing MOVE! Builder object...");
  MOVEBuilderRemote comp = (MOVEBuilderRemote) Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  Syslog.debug (this, "creating WRL...");
  String create = comp.create3DPlace ((String)session.getAttribute("worldId"),request.getParameter("placeId"),
                  "role","login",request.getParameter("placeType"));
  Syslog.debug (this, "WRL created successfully...");
 }catch(Exception ex){
  //Object not bound --> Bound object
  Hashtable env= new Hashtable();
  env.put ("PATH", (pageContext.getServletContext()).getRealPath(""));
  Syslog.debug (this, "Initializing MOVE! Builder object...");
  MOVEBuilderRemoteEngine engine = new MOVEBuilderRemoteEngine (env);
  Syslog.debug (this, "MOVE! Builder remote object initialized.");
  Syslog.debug (this, "//" + InetAddress.getLocalHost().getHostName() + ":1152/MoveBuilder");
  Naming.rebind ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder", engine);
  Syslog.debug(this, "MOVE! Builder remote object bound on rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  MOVEBuilderRemote comp = (MOVEBuilderRemote) Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  String create = comp.create3DPlace ((String)session.getAttribute("worldId"),request.getParameter("placeId"),
                  "role","login",request.getParameter("placeType"));
 }
} catch (Exception x) {
 Syslog.log (this, x);
}
response.sendRedirect("listPlaces.jsp");



			out.write("\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import java.net.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage0_bagList_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang;


	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_bagList_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");
messages=lang.getResource("ants.move.lang.MessagesBundle");

try {
 ThingManager thm = (ThingManager)session.getAttribute("thingManager");
 PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
 Thing thing=null;
 User user=(User)session.getAttribute("user");




			out.write("\r\n<html>\r\n<body>\r\n<center>\r\n<h3>");
			out.print(
				messages.getString("things")
			);

			out.write(":</h3> <br>\r\n\r\n      <table border=\"0\" bgcolor=\"teal\" width=\"90%\">\r\n         <TR>\r\n              <TH><font color=\"white\">Thing</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("nameTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("descriptionTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("creationTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("createdTH")
			);

			out.write("</TH>\r\n              <TH><font color=\"white\">");
			out.print(
				labels.getString("deploy")
			);

			out.write("</TH>\r\n\r\n         </TR>\r\n  ");
			



    int size=Integer.parseInt(user.getProperty("BagSize"));
    String value;
    Vector items=new Vector();
    for(int i=0;i<size;i++){
      value=user.getIndexedProperty("Bag",i);
      items.addElement(value);
    }

    for(Enumeration e=items.elements(); e.hasMoreElements();){
      value=(String)e.nextElement();
      try{
        thing=thm.getThing(value);


      if(thing.getToolId().equalsIgnoreCase("url.v01")){
        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				thing.getName()
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/urlSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td><a href=\"deployURL.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("deploy")
			);

			out.write("</a></td>\r\n          <td><a href=\"removeFromBag.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a></td>\r\n        </tr>");
			

      }else if(thing.getToolId().equalsIgnoreCase("doc.v01")){

         String placeId=thing.getPlaceId();
         String worldId=pm.getPlace(placeId).getWorldId();
        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				"worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/docSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td><a href=\"deployDoc.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("deploy")
			);

			out.write("</a></td>\r\n          <td><a href=\"removeFromBag.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a></td>\r\n\r\n        </tr>");
			


      }else if(thing.getToolId().equalsIgnoreCase("object.v01")){

         String placeId=thing.getPlaceId();
         String worldId=pm.getPlace(placeId).getWorldId();
        


			out.write("\r\n        <tr ALIGN=CENTER bgcolor=\"#E6E4DD\">\r\n          <td><a href=\"");
			out.print(
				"worlds/"+worldId+"/"+placeId+"/"+thing.getProperty("fileName")+"/main.wrl"
			);

			out.write("\" target=\"_blank\">\r\n              <img src=\"images/objectSmall.gif\" align=\"middle\" border=\"0\"></a></td>\r\n          <td>");
			out.print(
				thing.getName()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getDescription()
			);

			out.write("</td>\r\n          <td>");
			out.print(
				lang.translateDateTime(new Date(thing.getProperty("date")),DateFormat.FULL,DateFormat.FULL)
			);

			out.write("</td>\r\n          <td>");
			out.print(
				thing.getProperty("owner")
			);

			out.write("</td>\r\n          <td><a href=\"deployObject.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("deploy")
			);

			out.write("</a></td>\r\n          <td><a href=\"removeFromBag.jsp?thingId=");
			out.print(
				thing.getId()
			);

			out.write("\">");
			out.print(
				labels.getString("remove")
			);

			out.write("</a></td>\r\n\r\n        </tr>");
			


        }
      }catch(Exception ex){
        items.removeElement(value);
      }
     }
    user.setProperty("BagSize",""+items.size());
    for(int i=0;i<items.size();i++){
      user.setIndexedProperty("Bag",(String)items.elementAt(i),i);
    }


    


			out.write("\r\n    </table>\r\n  ");
			


   } catch (Exception e) {
      Syslog.log (this, e);
   }
  


			out.write("\r\n\r\n\r\n</center>\r\n</body>\r\n</html>");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
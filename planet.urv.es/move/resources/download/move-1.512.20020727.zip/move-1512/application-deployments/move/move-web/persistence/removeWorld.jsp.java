import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage0_removeWorld_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_removeWorld_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");
			

try {
   ThingManager thm = (ThingManager)session.getAttribute("thingManager");
   PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
   WorldManager wm = (WorldManager)session.getAttribute("worldManager");
   World world=wm.getWorld(request.getParameter("worldId"));
   Place place=null;
   String placeId;
   Thing thing=null;
   String path_directory=null;
   for(Iterator j = pm.getPlaces(world.getId()).iterator();j.hasNext();){
     place=(Place)j.next();
     placeId=place.getId();
      for( Iterator i=thm.getThingsByPlace(placeId).iterator();i.hasNext();){
        thing=(Thing)i.next();

        if(thing.getToolId().equalsIgnoreCase("s3d.v06")){
           //delete 3DSlides
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "3dslides" + File.separator +
                              thing.getId();
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
        }else if(thing.getToolId().equalsIgnoreCase("slides.v05")){
           //delete slides
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "slides" + File.separator +
                              thing.getId();
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
           Syslog.debug (this, "Slides files deleted from disk.");
        }else if(thing.getToolId().equalsIgnoreCase("video.v01")){
           //delete video
           path_directory = application.getRealPath("") + File.separator +
                              "resources" + File.separator + "videos" + File.separator +
                              thing.getId() + ".avi";
           Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
           FileDeleter fd = new FileDeleter (path_directory);
           fd.delete();
           Syslog.debug (this, "Video file deleted from disk.");
        }
        thing.remove();
      }
      //delete place directory: .wrl ...
      path_directory = application.getRealPath("") + File.separator +
                              "worlds" + File.separator + place.getWorldId() + File.separator +
                              place.getId();
      Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
      FileDeleter fd = new FileDeleter (path_directory);
      fd.delete();
      //Delete EJB
      place.remove();
   }
   //delete world directory:
   path_directory = application.getRealPath("") + File.separator +
                              "worlds" + File.separator + world.getId();
   Syslog.debug (this, "Let's delete ->" + path_directory +"<-");
   File f = new File(path_directory);
   if(f.exists()){
    f.delete();
   }
   //Delete EJB
   world.remove();

   response.sendRedirect("listWorlds.jsp");
} catch (Exception e) {
   Syslog.error(this,"Unable to remove world"+e);
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
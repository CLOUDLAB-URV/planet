import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage4_footer_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage4_footer_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n<center>\r\n<table width=90% bgcolor=\"#00800F\">\r\n<tr>\r\n  <td><br>\r\n  </td>\r\n</tr>\r\n</table>\r\n<font size=\"-2\">Developers: <i>\r\n<a href=\"mailto:omontala@tinet.org\">Oriol Montal\u00e0</a>,\r\n<a href=\"mailto:cpairot@tinet.org\"> Carles Pairot</a>,\r\n<a href=\"mailto:fpd@tinet.org\"> Francesc Pi\u00f1as</a>\r\n  2000 - 2002<br>\r\nDepartament d'Enginyeria Inform\u00e0tica i Matem\u00e0tiques<br>\r\nEscola T\u00e8cnica Superior d'Enginyeria<br>\r\nUniversitat Rovira i Virgili</i></font>\r\n</center>\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import ants.move.ejb.*;
import com.protomatter.syslog.*;
import ants.move.core.*;
import ants.move.builder.*;
import java.util.*;
import java.net.*;
import java.rmi.*;

public class __jspPage0_goToBuilder_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels; 
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_goToBuilder_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

lang = (LanguageUtilities)session.getAttribute("language");
labels=lang.getResource("ants.move.lang.LabelsBundle");

  try {
    Naming.lookup ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
  } catch (java.rmi.NotBoundException nbe) {
     Syslog.debug (this, "MOVE! Builder remote object not bound. Let's bind it now...");
     try {
       Hashtable env = new Hashtable();
       env.put ("PATH", (pageContext.getServletContext()).getRealPath(""));
       Syslog.debug (this, "Initializing MOVE! Builder remote object...");
       MOVEBuilderRemoteEngine engine = new MOVEBuilderRemoteEngine (env);
       Syslog.debug (this, "MOVE! Builder remote object initialized.");
       Naming.rebind ("//" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder", engine);
       Syslog.debug (this, "MOVE! Builder remote object bound on rmi://" + InetAddress.getLocalHost().getHostName() + ":1152/move/MoveBuilder");
     } catch (Exception x) {
        x.printStackTrace();
     }
  }



  String worldId=(String)session.getAttribute("worldId");
  String placeId=(String)session.getAttribute("placeId");
  String userRole=((User)session.getAttribute("user")).getRole();
  String userLogin=((User)session.getAttribute("user")).getLogin();
  String placeType=null;
  try {
      PlaceManager pm = (PlaceManager)session.getAttribute("placeManager");
      placeType=(pm.getPlace(placeId)).getType();
      
  } catch (Exception e) {
      Syslog.log (this, e);
  }



			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>Move builder: </b></font></td></tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n     <EMBED SRC=\"resources/util/new3d.wrl\" HEIGHT=\"350\" WIDTH=\"450\">\r\n     <APPLET CODE=\"ants.move.builder.MOVEBuilderApplet.class\" mayscript WIDTH=\"100\" HEIGHT=\"350\"\r\n          ALIGN=\"ABSCENTER\"\r\n          ARCHIVE=\"jars/move-builder.jar,jars/move-core.jar\">\r\n            <PARAM name=worldKey value=\"");
			out.print(
				worldId
			);

			out.write("\">\r\n\t    <PARAM name=placeKey value=\"");
			out.print(
				placeId
			);

			out.write("\">\r\n            <PARAM name=userRole value=\"");
			out.print(
				userRole
			);

			out.write("\">\r\n            <PARAM name=userLogin value=\"");
			out.print(
				userLogin
			);

			out.write("\">\r\n            <PARAM name=placeType value=\"");
			out.print(
				placeType
			);

			out.write("\">\r\n    </APPLET>\r\n    <br>\r\n  </td>\r\n </tr>\r\n </table>\r\n</center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n</HTML>\r\n\r\n\r\n\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
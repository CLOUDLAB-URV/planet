import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage1_loadContext_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_loadContext_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n");
			


//load to session all SessionBean
   try {
      Context initial = new InitialContext();
      //load worldManager
      Object obj = initial.lookup("java:comp/env/WorldManagerBean");
      WorldManagerHome home1 = (WorldManagerHome) PortableRemoteObject.narrow (obj, WorldManagerHome.class);
      WorldManager wm = home1.create();
      session.setAttribute("worldManager",wm);

      //load placeManager
      obj = initial.lookup("java:comp/env/PlaceManagerBean");
      PlaceManagerHome home2 = (PlaceManagerHome) PortableRemoteObject.narrow (obj, PlaceManagerHome.class);
      PlaceManager pm = home2.create();
      session.setAttribute("placeManager",pm);


      //load toolManager
      obj = initial.lookup("java:comp/env/ToolManagerBean");
      ToolManagerHome home3 = (ToolManagerHome) PortableRemoteObject.narrow (obj, ToolManagerHome.class);
      ToolManager tm = home3.create();
      session.setAttribute("toolManager",tm);


      //load thingManager
      obj = initial.lookup("java:comp/env/ThingManagerBean");
      ThingManagerHome home4 = (ThingManagerHome) PortableRemoteObject.narrow (obj, ThingManagerHome.class);
      ThingManager thm = home4.create();
      session.setAttribute("thingManager",thm);

      //load userManager
      obj = initial.lookup("java:comp/env/UserManagerBean");
      UserManagerHome home5 = (UserManagerHome) PortableRemoteObject.narrow (obj, UserManagerHome.class);
      UserManager um = home5.create();
      session.setAttribute("userManager",um);

      response.sendRedirect("listWorlds.jsp");
   } catch (Exception e) {
      Syslog.log (this, e);
   }


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
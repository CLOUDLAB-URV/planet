import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage0_configureTools_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_configureTools_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  Place place=pm.getPlace((String)session.getAttribute("placeId"));
  World world=wm.getWorld((String)session.getAttribute("worldId"));
  Vector per = new Vector();
  int size=Integer.parseInt(world.getProperty(((User)session.getAttribute("user")).getRole()+"size"));
  for(int i=0;i<size;i++){
    per.addElement(world.getIndexedProperty(((User)session.getAttribute("user")).getRole(),i));
  }




			out.write("\r\n <html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("configTools")
			);

			out.write(": </b></font></td></tr>\r\n\r\n      ");
			
if(per.contains("builder.v01")){
       


			out.write("\r\n       <tr>\r\n        <td align=\"right\"><a href=\"goToBuilder.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\"><FONT FACE=\"impact\" SIZE=5 COLOR=\"blue\">Builder</font></a><br><br></td>\r\n       </tr>\r\n       ");
			

      }


			out.write("\r\n\r\n</table>\r\n\r\n   <table width=\"80%\" border=\"0\" bgcolor=\"teal\">\r\n\r\n   <th><font color=\"white\">");
			out.print(
				labels.getString("nameThingTH")
			);

			out.write("</font></th>\r\n   <th><font color=\"white\">");
			out.print(
				labels.getString("descriptionTH")
			);

			out.write("</font></th>\r\n   <th><font color=\"white\">");
			out.print(
				labels.getString("thingType")
			);

			out.write("</font></th>\r\n   <th><font color=\"white\">");
			out.print(
				labels.getString("status")
			);

			out.write("</font></th>\r\n   <th><font color=\"white\">");
			out.print(
				labels.getString("action")
			);

			out.write("</font></th>\r\n\r\n   ");
			

   Tool tool=null;
   for(Iterator i=tm.getTools().iterator();i.hasNext();){
    tool=(Tool)i.next();
    if(per.contains(tool.getId())){
    if(!tool.getId().equalsIgnoreCase("builder.v01")){
    


			out.write("\r\n\r\n    <tr bgcolor=\"#E6E4DD\">\r\n      <form method=\"post\" action=\"configureTools.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\">\r\n      <td>");
			out.print(
				tool.getName()
			);

			out.write("</td>\r\n      <td>");
			out.print(
				lang.translateText(tool.getDescription(),"ants.move.lang.MessagesBundle",new Locale("en","UK"))
			);

			out.write("</td>\r\n      <td>");
			out.print(
				tool.getType()
			);

			out.write("</td>\r\n      ");
			

      if(place.getProperty(tool.getId()).equalsIgnoreCase("active")){
       


			out.write("<td>");
			out.print(
				messages.getString("active")
			);

			out.write("</td>\r\n         <input type=\"hidden\" name=\"toolId\" value=\"");
			out.print(
				tool.getId()
			);

			out.write("\">\r\n         <td align=\"center\"><input type=\"submit\" value=\"");
			out.print(
				labels.getString("deactivate")
			);

			out.write("\"></td></form>\r\n       ");
			

      }else{
       


			out.write("<td>");
			out.print(
				messages.getString("inactive")
			);

			out.write("</td>\r\n         <input type=\"hidden\" name=\"toolId\" value=\"");
			out.print(
				tool.getId()
			);

			out.write("\">\r\n         <td align=\"center\"><input type=\"submit\" value=\"");
			out.print(
				labels.getString("activate")
			);

			out.write("\"></td></form>\r\n       ");
			

      }
      


			out.write("\r\n    </tr>\r\n    ");
			

    }
    }
   }

   


			out.write("\r\n   </table>\r\n   <br><br>\r\n\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n </HTML>\r\n");
			

}else{

  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  PlaceManager pm=(PlaceManager)session.getAttribute("placeManager");
  Place place=pm.getPlace((String)session.getAttribute("placeId"));
  String toolId=(String)request.getParameter("toolId");
  if(place.getProperty(toolId).equalsIgnoreCase("Active")){
    place.setProperty(toolId,"deactive");
  }else{
    place.setProperty(toolId,"active");
  }
  response.sendRedirect("configureTools.jsp?");
}



			out.write("\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage1_createWorld_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels;
    LanguageUtilities lang;
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage1_createWorld_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
  lang = (LanguageUtilities)session.getAttribute("language");
  labels=lang.getResource("ants.move.lang.LabelsBundle");



			out.write("\r\n<html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n<tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("createWorld")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n\r\n<table width=90%>\r\n<form method=\"post\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("worldName")
			);

			out.write(" : </b><input type=\"text\" size=\"30\" maxlength=\"30\" name=\"name\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("worldDescription")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"50\" name=\"description\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("worldType")
			);

			out.write(" : </b><input type=\"text\" size=\"20\" maxlength=\"20\" name=\"type\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   </form>\r\n  </table>\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n </HTML>\r\n");
			

}else{
 try{
  WorldManager wm=(WorldManager)session.getAttribute("worldManager");
  int num=wm.getWorlds().size();
  if(num!=0){
    World w;
    for(Iterator i=wm.getWorlds().iterator();i.hasNext();){
      w=(World)i.next();
      if(w.getProperty("lastCreated").equalsIgnoreCase("true")){
        num=Integer.parseInt(w.getId().substring(1));
	num++;
        w.setProperty("lastCreated","false");
      }
    }
  }
  World world=wm.createWorld("W"+num,request.getParameter("name"),request.getParameter("type"));
  world.setDescription(request.getParameter("description"));
  world.setProperty("date",(new Date()).toGMTString());
  world.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  ToolManager tm=(ToolManager)session.getAttribute("toolManager");
  Collection tools=tm.getTools();
  world.setProperty("teachersize",""+tools.size());
  world.setProperty("rootsize",""+tools.size());
  world.setProperty("studentsize",""+tools.size());
  world.setProperty("lastCreated","true");
  Tool tool;
  int count=0;
  for(Iterator i=tools.iterator();i.hasNext();){
    tool=(Tool)i.next();
    world.setIndexedProperty("teacher",tool.getId(),count);
    world.setIndexedProperty("student",tool.getId(),count);
    world.setIndexedProperty("root",tool.getId(),count);
    count++;
  }
  response.sendRedirect("listWorlds.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create World");
 }
}


		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
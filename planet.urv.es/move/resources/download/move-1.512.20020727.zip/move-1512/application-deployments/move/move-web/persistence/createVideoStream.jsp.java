import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import ants.move.lang.*;
import java.text.*;
import java.util.*;
import javax.naming.*;
import javax.rmi.*;
import com.protomatter.syslog.*;
import ants.move.ejb.*;

public class __jspPage0_createVideoStream_jsp extends com.orionserver.http.OrionHttpJspPage
{
 ResourceBundle labels, messages;
    LanguageUtilities lang; 
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		Object __tempVar;
		response.setContentType("text/html");
		HttpSession session;
		__jspPage0_createVideoStream_jsp page = this;
		session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("\r\n\r\n");

			out.write("\r\n\r\n");
			

if(request.getMethod().equalsIgnoreCase("GET")){
   lang = (LanguageUtilities)session.getAttribute("language");
   labels=lang.getResource("ants.move.lang.LabelsBundle");
   messages=lang.getResource("ants.move.lang.MessagesBundle");



			out.write("\r\n  <html>\r\n<body>\r\n");
			pageContext.include("header.jsp?string=/WORLDS/PLACES/THINGS&linked=true");

			out.write("\r\n<center>\r\n<table width=90%>\r\n   <tr><td colspan=\"3\" bgcolor=\"#00800F\"><font color=\"white\"><b>");
			out.print(
				labels.getString("createVideoStream")
			);

			out.write(" : </b></font></td></tr>\r\n</table>\r\n<table width=90%>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n    <b>");
			out.print(
				messages.getString("createVideoStream")
			);

			out.write("</b>\r\n    </td>\r\n   </tr>\r\n   <form method=\"post\">\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("videoStreamName")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"50\" name=\"name\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("videoStreamDescription")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"200\" name=\"desc\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\">\r\n      <b>");
			out.print(
				labels.getString("videoStreamSource")
			);

			out.write(" : </b><input type=\"text\" size=\"50\" maxlength=\"400\" name=\"url\"><br><br>\r\n    </td>\r\n   </tr>\r\n   <tr>\r\n    <td colspan=\"3\" align=\"center\">\r\n      <input type=\"submit\" value=\"");
			out.print(
				labels.getString("create")
			);

			out.write("\"> <input type=\"reset\" value=\"");
			out.print(
				labels.getString("reset")
			);

			out.write("\">\r\n    </td>\r\n   </tr>\r\n   </form>\r\n  </table>\r\n  </center>\r\n  ");
			pageContext.include("footer.jsp");

			out.write("\r\n </HTML>\r\n");
			

}else{
 try{
  ThingManager thm=(ThingManager)session.getAttribute("thingManager");
  Thing thing=thm.createThing(""+System.currentTimeMillis(),request.getParameter("name"),
                            (String)session.getAttribute("placeId"),"videoStream.v01");
  thing.setDescription(request.getParameter("desc"));
  thing.setProperty("url",request.getParameter("url"));
  thing.setProperty("date",(new Date()).toGMTString());
  thing.setProperty("owner",((User)session.getAttribute("user")).getLogin());
  response.sendRedirect("listThings.jsp");
 }catch(Exception e){
  Syslog.error(this,"Unable to create Thing");
 }
}



			out.write("\r\n\r\n");
		}
		catch(Exception __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}
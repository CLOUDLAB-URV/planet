/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package org.planet.p2pcm;

import java.io.*;
import java.util.*;
import java.lang.reflect.InvocationTargetException;

import dermi.*;
import dermi.util.*;
import dermi.registry.*;
import dermi.exception.*;
import dermi.listener.*;

/**
 * This class models the component's factory.
 * It provides the necessary methods for instantiating new component instances
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public abstract class ComponentFactory implements RemoteEventListener {
  // Component's URL
  private String componentURL = "";
  // Component's properties
  private Properties generalProps = new Properties();
  // Component's metadata
  private Properties metadata = new Properties();
  private Hashtable results = new Hashtable();

  /**
   * Void constructor
   */
  public ComponentFactory() {
  }

  /**
   * Default factory constructor: Component's URL in DOLR must be known
   * @param componentURL String Component's URL
   */
  public ComponentFactory (String componentURL) throws RemoteException {
    this.componentURL = componentURL;

    FileInputStream fis = null;

    if (!Registry.isConnected()) {
      try {
        fis = new FileInputStream (Context.CONFIG_FILE);
        generalProps.loadFromXML (fis);
      } catch (Exception e) {
        throw new RemoteException ("Unable to establish connection. Properties file is missing.");
      }

      // Load registry
      Registry.loadRegistry (Context.CONFIG_FILE);
    }
    else {
      generalProps = Registry.getConnectionProperties();
      metadata = (Properties) Registry.lookupSer (componentURL);
    }
  }

  public ComponentFactory (Properties props, String configFile) throws RemoteException {
    metadata = (Properties) props.clone();
    FileInputStream fis = null;

    if (!Registry.isConnected()) {
      try {
        fis = new FileInputStream (configFile);
        generalProps.loadFromXML (fis);
      } catch (Exception e) {
        throw new RemoteException ("Unable to establish connection. Properties file is missing.");
      }

      // Load registry
      Registry.loadRegistry (configFile);
    }
    else {
      generalProps = Registry.getConnectionProperties();
    }
  }

  /**
   * Creates a component's instance. The component's constructor has no arguments.
   * @param interf String Component's interface to be returned (component's desired view)
   * @param instance String Component's instance identifier
   * @return ComponentInterface An implementation of the ComponentInterface interface
   * @throws InterfaceNotFoundException If the specified interface cannot be found
   * @throws RemoteException If something else goes wrong ;-)
   */
  public ComponentInterface createInstance (String interf, String instance) throws InterfaceNotFoundException, RemoteException {
    return this.createInstance (false, interf, instance, (Object[]) null);
  }

  public ComponentInterface createInstance (String interf, String instance, Object...args) throws InterfaceNotFoundException, RemoteException {
    return this.createInstance (false, interf, instance, args);
  }

  /**
   * Creates a component's instance. The component's constructor has arguments.
   * @param interf String Component's interface to be returned (component's desired view)
   * @param instance String Component's instance identifier
   * @param args Object[] Component's constructor arguments
   * @return ComponentInterface An implementation of the ComponentInterface interface
   * @throws InterfaceNotFoundException If the specified interface cannot be found
   * @throws RemoteException If something else goes wrong ;-)
   */
  public ComponentInterface createInstance (boolean replicated, String interf, String inst, Object...args) throws InterfaceNotFoundException, RemoteException {
    String instance = this.getClass().getName() + "$" + inst;

    ComponentInterface stub = null;
    if (!replicated) {
      stub = (ComponentInterface) getComponentStub (interf, instance);
    }

    if (stub != null) {
      // Returning stub to remote component instance
      return stub.queryInterface (interf);
    }
    else {
      // Component needs to be instantiated (locally)
      try {
        Component comp = (Component) this.instantiateComponent (instance, args);
        // Life cycle management
        int activationThreshold = Context.ACTV_THRESHOLD;
        int passivationThreshold = Context.PASV_THRESHOLD;
        ComponentControl cc = new ComponentControl ((ComponentInterface) comp, passivationThreshold, activationThreshold);
        comp.setLifeCycleManager (cc);

        // Returning stub to local component instance
        return ((ComponentInterface) comp).queryInterface (interf);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    throw new InterfaceNotFoundException ("Unexpected exception!");
  }

  /**
   * This method returns the component's URL
   * @return String Component's URL
   */
  public String getComponentURL() {
    return componentURL;
  }

  /**
   * This method returns the component's metadata
   * @return Properties Component's metadata
   */
  public Properties getComponentMetadata() {
    return metadata;
  }

  // Method used for getting the component's stub
  private ERemote getComponentStub (String interf, String instance) throws InterfaceNotFoundException, RemoteException {
    Properties p = new Properties();
    if (metadata == null) {
      // Lookup component metadata in the decentralized registry
      p = (Properties) Registry.lookupSer (componentURL);
      metadata = (Properties) p.clone();
    }
    else {
      p = (Properties) metadata.clone();
    }

    p.put (Context.CLASS_ID, instance);

    // Get component instance iff an active instance of this component already exists
    boolean instanceLoaded = checkAlreadyActiveInstance (p);

    if (instanceLoaded) {
      // System.out.println ("Component instance already found running...");
      // Obtain stub
      p.put (Context.CLASS_NAME, p.get (Context.IMPLEMENTATION_NAME));
      p.put (Context.PROVIDER_CLASS, generalProps.get (Context.PROVIDER_CLASS));
      p.put (Context.PROVIDER_HOST, generalProps.get (Context.PROVIDER_HOST));
      p.put (Context.PROVIDER_PORT, generalProps.get (Context.PROVIDER_PORT));
      p.put (Context.PROTOCOL, generalProps.get (Context.PROTOCOL));

      // Stub reference found, return it
      return FileRegistry.loadERef (p);
    }
    else {
      // System.out.println ("Component instance NOT found running...");
      return null;
    }
  }

  // Auxiliary method used for calling the component's constructor with no arguments
  private ERemote instantiateComponent (String instance) throws ComponentInitializationException {
    return instantiateComponent (instance, (Object[]) null);
  }

  // Auxiliary method used for calling the component's constructor with arguments
  private ERemote instantiateComponent (String instance, Object ... params) throws ComponentInitializationException {
    try {
      Properties p = new Properties();
      if (metadata == null) {
        // Lookup component metadata in the decentralized registry
        p = (Properties) Registry.lookupSer (componentURL);
        metadata = (Properties) p.clone();
      }
      else {
        p = (Properties) metadata.clone();
      }

      Class[] cl; Object[] objs;

      // Get arguments
      if (params != null) {
        cl = new Class [params.length + 1];
        objs = new Object [params.length + 1];
        objs[0] = generalProps;
        cl[0] = Properties.class;

        for (int i = 0; i < params.length; i++) {
          cl[i+1] = params[i].getClass();
          objs[i+1] = params[i];
        }
      }
      else {
        cl = new Class[1]; cl[0] = Properties.class;
        objs = new Object[1]; objs[0] = generalProps;
      }

      generalProps.put (Context.CLASS_NAME, p.getProperty (Context.IMPLEMENTATION_NAME));
      generalProps.put (Context.CLASS_ID, instance);

      // Load default classloader (to avoid ClassNotFoundException matters ;-))
      dermi.util.BusClassLoader loader = new dermi.util.BusClassLoader (generalProps);
      loader.close();

      Class theClass = loader.loadClass (p.getProperty (Context.IMPLEMENTATION_NAME));

      // Create new component's instance
      return (ERemote) theClass.getConstructor(cl).newInstance (objs);
    } catch (Exception e) {
      if (e instanceof InvocationTargetException) {
        ((InvocationTargetException) e).getTargetException().printStackTrace();
      }
      else {
        e.printStackTrace();
      }
      throw new ComponentInitializationException (e.getMessage());
    }
  }

  /**
   * Callback method executed when an event regarding the factory is received
   * @param evt Hashtable Event data
   */
  public void eventArrived (Hashtable evt) {
    results.put (((String) evt.get (Context.OBJECTID)) + ((String) evt.get (Context.TIMESTAMP)), evt.get (Context.OBJECTCONTENT));

/*    if (((String) evt.get (Context.TYPE)).equals (Context.EXCEPTION))  {
      exception = true;
    }
    else {
      if (evt.get (Context.OBJECTCONTENT) != null) {
        isAlreadyActive = ((Boolean) evt.get (Context.OBJECTCONTENT)).booleanValue();
        resultReceived = true;
      }
    }
*/
  }

  // Utility method
  private synchronized boolean contains (Hashtable results, String tstamp) {
    Iterator i = results.keySet().iterator();
    while (i.hasNext()) {
      Object ob = i.next();
      if (results.get (tstamp) != null) {
        return true;
      }
    }
    return false;
  }

  /**
   * Callback method executed when an anycall event is received [IT IS CURRENTLY UNUSED]
   * @param evt Hashtable Event data
   * @return Hashtable Transformed event data
   * @throws UnmatchedAnycallMethodException Thrown whenever the specified method was not an anycall
   */
  public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
    throw new UnmatchedAnycallMethodException ((String) evt.get (Context.METHOD));
  }

  // Method used for checking whether there exists any other component's instance in the network
  private boolean checkAlreadyActiveInstance (Properties p) {
    int retries = dermi.util.Context.RETRANSMISSIONS;
    if (metadata.get (Context.RETRIES) != null) {
      retries = (Integer) metadata.get (Context.RETRIES);
    }

    String method = "getRemoteObjectState";

    // Wait a certain time for joining to be complete
    try {
      Thread.sleep (1000);
    } catch (Exception e) {}

    try {
      Session s = SessionFactory.createSession (Context.CONFIG_FILE);

      Hashtable evt = new Hashtable();
      evt.put (Context.OBJECTID, p.getProperty (Context.CLASS_ID) + Context.APPEND_RESULT);
      s.subscribe (this, evt);

      // Set timestamp for this event and its possible retransmissions
      String tstamp = "" + System.currentTimeMillis();

      evt.put (Context.TYPE, Context.DISPATCH);
      evt.put (Context.METHOD, method);
      evt.put (Context.GET_COMPONENT_INSTANCE, new Boolean (true));
      evt.put (Context.SOURCE_NODEHANDLE, s.getLocalNodeHandle ());
      evt.put (Context.OBJECTCONTENT, new Vector ());
      evt.put (Context.TIMESTAMP, tstamp);
      evt.put (Context.OBJECTID, p.getProperty (Context.CLASS_ID));

      int timeout = 0;

      for (int retransmission = 0; retransmission < retries; retransmission++) {
        if (retransmission == 1) {
          System.out.print ("[ComponentFactory] - Component location retransmissions... ");
        }
        if (retransmission != 0) {
          System.out.print (retransmission + " ");
        }
        s.anycall (evt);
        timeout = 0;
        while (!contains (results, p.getProperty (Context.CLASS_ID) + Context.APPEND_RESULT + tstamp) && timeout < Context.TIMEOUT) {
          try {
            Thread.currentThread().sleep (Context.DELAY);
          } catch (InterruptedException ex) {
            ex.printStackTrace();
          }
          timeout++;
        }
        if (timeout == Context.TIMEOUT) {
          continue;
        } else if (results.get (p.getProperty (Context.CLASS_ID) + Context.APPEND_RESULT + tstamp) instanceof Exception) {
          continue;
        }
        break;
      }
      if (timeout == Context.TIMEOUT) {
        return false;
      }
      if (results.get (p.getProperty (Context.CLASS_ID) + Context.APPEND_RESULT + tstamp) instanceof Exception) {
        return false;
      }
      return (Boolean) results.remove (p.getProperty (Context.CLASS_ID) + Context.APPEND_RESULT + tstamp);
    } catch (SessionException ex) {
      return false;
    }

/*      String tstamp = "" + System.currentTimeMillis ();

      evt.put (Context.TIMESTAMP, tstamp);

      for (int retransmission = 0; retransmission < retries; retransmission++) {
        s.anycall (evt);

        timeout = 0;
        exception = false;
        resultReceived = false;

        while (exception == false && resultReceived == false && timeout < Context.TIMEOUT) {
          try {
            Thread.currentThread().sleep (Context.DELAY);
          } catch (InterruptedException ex) {
            ex.printStackTrace();
          }
          timeout++;
        }

        if (exception) {
          retries--;
          try {
            Thread.currentThread().sleep (Context.DELAY * 100);
          } catch (InterruptedException ex) {
            ex.printStackTrace();
          }
          break;
        }
        else if (timeout == Context.TIMEOUT) {
          retransmission++;
          continue;
        }

        if (resultReceived) {
          return isAlreadyActive;
        }
        break;
      }

      if (timeout == Context.TIMEOUT) {
        return false;
      }

      if (exception) return false;
      else return isAlreadyActive;

    } catch (SessionException ex) {
      return false;
    } */
  }
}

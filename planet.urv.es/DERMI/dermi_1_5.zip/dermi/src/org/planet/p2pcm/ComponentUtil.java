/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package org.planet.p2pcm;

import dermi.*;
import dermi.util.*;
import dermi.exception.*;
import org.planet.p2pcm.*;
import dermi.annotation.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import java.lang.reflect.*;
import java.lang.annotation.*;

/**
 * This class provides static methods for deploying / undeploying components in the network
 *
 * @author Rub�n Mond�jar  <ruben.mondejar@estudiants.urv.es>
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ComponentUtil {

  public static void deployComponent (String componentResource) throws ComponentDeploymentException, ComponentMetadataIncompleteException {
    System.out.println ("Deploying component file... " + componentResource);
    try {
      deployComponent (new FileInputStream (componentResource));
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      throw new ComponentDeploymentException ("Unable to locate component's file.");
    }
  }

  /**
   * Method for deploying a component on the structured peer-to-peer overlay network
   * @param componentResource URL Component's URL
   * @throws ComponentDeploymentException
   * @throws ComponentMetadataIncompleteException
   */
  public static void deployComponent (URL componentResource) throws ComponentDeploymentException, ComponentMetadataIncompleteException {
    try {
      System.out.println ("Deploying component file... " + componentResource.toString());
      deployComponent (componentResource.openStream());
    } catch (IOException e) {
      e.printStackTrace();
      throw new ComponentDeploymentException ("Unable to load component's file.");
    }
  }

  public static void deployComponent (InputStream is) throws ComponentDeploymentException, ComponentMetadataIncompleteException {
    Properties componentProperties = new Properties();

    String implementationName = null;
    String factoryName = null;
    Vector<String> interfaceName = new Vector<String>();

    byte[] implementationClass = null;
    byte[] factoryClass = null;
    Vector<byte[]> interfaceClass = new Vector<byte[]>();

    try {
      // Read component's jar file
      ZipInputStream bis = new ZipInputStream (is);
      ZipEntry z = bis.getNextEntry();

      // Process all jar file entries
      while (z != null) {
        String name = z.getName();
        name = name.replaceAll("/", ".");
        // System.out.println("load :"+name);
        if (name.toLowerCase().endsWith (".class")) {
            // Load class
            int size = (int) z.getSize();
            byte[] bytes = new byte[size];

            // Read in the bytes
            int offset = 0;
            int numRead = 0;
            while (offset < bytes.length
                   && (numRead = bis.read (bytes, offset, bytes.length - offset)) >= 0) {
              offset += numRead;
            }

            // Ensure all the bytes have been read in
            if (offset < bytes.length) {
              throw new ComponentDeploymentException ("Could not completely read file " + name);
            }

            ByteClassLoader loader = new ByteClassLoader (bytes, Thread.currentThread().getContextClassLoader());

            Class theClass = loader.loadClass (name.substring (0, name.length() - 6));

            // Get all available annotations
            Annotation[] annots = theClass.getAnnotations();

            if (annots!=null) {
              // Process annotations
              for (int i=0; i < annots.length; i++) {
                // Process DCMFactory annotations
                if (annots[i] instanceof DCMFactory) {
                  // Get all required properties
                  DCMFactory ann = (DCMFactory) annots[i];
                  componentProperties.put (Context.COMPONENT_URL, ann.url());
                  componentProperties.put (Context.COMPONENT_ID, ann.id());
                  componentProperties.put (Context.STATEFUL, new Boolean(ann.stateful()));
                  componentProperties.put (Context.PERSISTENT, ann.persistent());
                  componentProperties.put (Context.REPLICATED, new Boolean(ann.replicated()));
                  componentProperties.put (Context.RETRIES, new Integer(ann.retries()));

                  factoryName = name.substring (0, name.length() - 6);
                  // System.out.println("Factory: " + name);

//                  System.out.println ("Processing " + factoryName + " {" + z.getName() + "} [" + z.getSize() + " bytes]");
                  factoryClass = new byte[(int) z.getSize()];
                  int bytesRead;

                  while (-1 != (bytesRead = bis.read (factoryClass, 0, factoryClass.length)));
                }
                // Process DCMImplementation annotations
                else if (annots[i] instanceof DCMImplementation) {
                  implementationName = name.substring (0, name.length() - 6);
                  // System.out.println("Impl: "+name);
//                  System.out.println ("Processing " + interfaceName + " {" + z.getName() + "} [" + z.getSize() + " bytes]");
                  implementationClass = new byte[(int) z.getSize()];
                  int bytesRead;
                  while (-1 != (bytesRead = bis.read (implementationClass, 0, implementationClass.length)));
                }
                // Process DermiRemoteInterface annotations
                else if (annots[i] instanceof DermiRemoteInterface) {
                  interfaceName.add(name.substring (0, name.length() - 6));
                  // System.out.println("Interface: "+name);
//                  System.out.println ("Processing " + name + " {" + z.getName() + "} [" + z.getSize() + " bytes]");
                  byte[] temp = new byte[(int) z.getSize()];
                  int bytesRead;

                  while (-1 != (bytesRead = bis.read (temp, 0, temp.length)));
                  interfaceClass.add(bytes);
                }
              }
            }
          }
          z = bis.getNextEntry();
        }
    } catch (Exception e) {
      e.printStackTrace();
      throw new ComponentDeploymentException ("Unable to deploy component due to an unexpected exception.");
    }

    if (componentProperties.getProperty (Context.COMPONENT_URL) == null || implementationName == null || componentProperties.getProperty (Context.COMPONENT_ID) == null) {
      if (componentProperties.getProperty (Context.COMPONENT_URL) == null) {
        throw new ComponentMetadataIncompleteException ("Component's metadata field missing: COMPONENT_URL");
      }
      if (implementationName == null) {
        throw new ComponentMetadataIncompleteException ("Component's metadata field missing: IMPLEMENTATION_NAME");
      }
      if (componentProperties.getProperty (Context.COMPONENT_ID) == null) {
        throw new ComponentMetadataIncompleteException ("Component's metadata field missing: COMPONENT_ID");
      }
    }

    componentProperties.put (Context.IMPLEMENTATION_NAME, implementationName);
    componentProperties.put (Context.INTERFACE_NAME, interfaceName);
    componentProperties.put (Context.FACTORY_NAME, factoryName);

    componentProperties.put (Context.IMPLEMENTATION_CLASS, implementationClass);
    componentProperties.put (Context.INTERFACE_CLASS, interfaceClass);
    componentProperties.put (Context.FACTORY_CLASS, factoryClass);

    // Now proceed with the component's registration on the DOLR tree
    // Load registry first
    try {
      if (!Registry.isConnected()) {
        Registry.loadRegistry ("dermi-config.xml");
      }

      // Look up object in registry
      Registry.bind (componentProperties.getProperty (Context.COMPONENT_URL), componentProperties);
    } catch (RemoteException ex) {
      throw new ComponentDeploymentException ("Unable to deploy component: failed to insert into the decentralized registry.");
    }
  }

  /**
   * Method for undeploying a Dermi component
   * @param componentID String Component's identifier
   * @throws ComponentDeploymentException If component cannot be unregistered correctly
   */
  public static void unDeployComponent (String componentID) throws ComponentDeploymentException {
    System.out.println ("UnDeploying component ... " + componentID);
    // Load registry first
    try {
      if (!Registry.isConnected()) {
        Registry.loadRegistry ("dermi-config.xml");
      }

      // Unbind component from registry
      Registry.unbind (componentID);
    } catch (RemoteException ex) {
      throw new ComponentDeploymentException ("Unable to undeploy component: exception occured when accessing the decentralized registry.");
    }
  }

  /**
   * Method for getting any component's factory instance
   * @param componentLocation String URL-like component locator
   * @return ComponentFactory The component's factory class
   * @throws ComponentNotRegisteredException Thrown if the component was not previously deployed on the overlay network
   * @throws ComponentInitializationException Thrown if it is impossible to initialize the component's factory
   */
  public static ComponentFactory getComponentFactory (String componentLocation) throws ComponentNotRegisteredException, ComponentInitializationException {
    // Load registry first (if not loaded yet)
    try {
      if (!Registry.isConnected ()) {
        Registry.loadRegistry ("dermi-config.xml");
      }
    } catch (RemoteException re) {
      throw new ComponentInitializationException (re.getMessage());
    }

    // Look up component's metadata
    Properties componentProperties = null;
    try {
      componentProperties = (Properties) Registry.lookupSer (componentLocation);
    } catch (RemoteException ex) {
      throw new ComponentNotRegisteredException(ex.getMessage());
    }

    ComponentFactory factory = null;
    try {
      // Load component interfaces
      Vector<String> interfaceName = interfaceName = (Vector<String>) componentProperties.get(Context.INTERFACE_NAME);
      Vector<byte[]> interfaceClass = interfaceClass = (Vector<byte[]>) componentProperties.get(Context.INTERFACE_CLASS);

      for (int i = 0; i < interfaceName.size(); i++) {
        String name = interfaceName.get (i);
        byte[] bytes = interfaceClass.get (i);

        ByteClassLoader loader = new ByteClassLoader (bytes, Thread.currentThread().getContextClassLoader());
        loader.loadClass (name, true);
      }

      // Load Component's factory class and return an instance
      String name = (String) componentProperties.get (Context.FACTORY_NAME);

      byte[] bytes = (byte[]) componentProperties.get (Context.FACTORY_CLASS);
      ByteClassLoader loader = new ByteClassLoader (bytes, Thread.currentThread().getContextClassLoader());

      name = name.replaceAll ("/", ".");
      Class theClass = loader.loadClass (name);
      Constructor theConstructor = theClass.getConstructor (componentLocation.getClass());
      factory = (ComponentFactory) theConstructor.newInstance (componentLocation);
      return factory;
    } catch (Exception ex) {
      if (ex instanceof InvocationTargetException) {
        ((InvocationTargetException) ex).getTargetException ().printStackTrace ();
      }
      else {
        ex.printStackTrace ();
      }
      throw new ComponentInitializationException (ex.getMessage());
    }
  }

  /**
   * Factory method used for creating an inner object within a component
   * Useful for components which may delegate some view implementations to other classes / objects
   * @param implClass String Implementation class name
   * @param instance String Instance name
   * @param params Object[] Object creation arguments
   * @return ComponentInterface A component's interface implementation
   * @throws ComponentInitializationException If component (inner object) cannot be initialized
   */
  public static ComponentInterface createInnerObject (String implClass, String instance, Object ... params) throws ComponentInitializationException {
    try {
      Properties p = new Properties();
      p.loadFromXML (new java.io.FileInputStream (Context.CONFIG_FILE));
      p.put (Context.CLASS_ID, instance);
      p.put (Context.CLASS_NAME, implClass);

      Class[] cl; Object[] objs;

      if (params != null) {
        cl = new Class [params.length + 1];
        objs = new Object [params.length + 1];
        objs[0] = p;
        cl[0] = Properties.class;

        for (int i = 0; i < params.length; i++) {
          cl[i+1] = params[i].getClass();
          objs[i+1] = params[i];
        }
      }
      else {
        cl = new Class[1]; cl[0] = Properties.class;
        objs = new Object[1]; objs[0] = p;
      }
      return (ComponentInterface) Class.forName (implClass).getConstructor (cl).newInstance (objs);
    } catch (Exception e) {
      throw new ComponentInitializationException (e.getMessage());
    }
  }

  public static Properties getComponentProperties (Class componentFactory, Class componentInterface, Class componentImplementation) throws ComponentMetadataIncompleteException {
    Properties componentProperties = new Properties();

    // Get all available annotations
    Annotation[] annots = componentFactory.getAnnotations();

    if (annots != null) {
      // Process annotations
      for (int i = 0; i < annots.length; i++) {
        // Process DCMFactory annotations
        if (annots[i] instanceof DCMFactory) {
          // Get all required properties
          DCMFactory ann = (DCMFactory) annots[i];
          componentProperties.put (Context.COMPONENT_URL, ann.url());
          componentProperties.put (Context.COMPONENT_ID, ann.id());
          componentProperties.put (Context.STATEFUL, ann.stateful());
          componentProperties.put (Context.PERSISTENT, ann.persistent());
          componentProperties.put (Context.REPLICATED, ann.replicated());
          componentProperties.put (Context.RETRIES, ann.retries());
        }
      }

      if (componentProperties.getProperty (Context.COMPONENT_URL) == null || componentProperties.getProperty (Context.COMPONENT_ID) == null) {
        if (componentProperties.getProperty (Context.COMPONENT_URL) == null) {
          throw new ComponentMetadataIncompleteException ("Component's metadata field missing: COMPONENT_URL");
        }
        if (componentProperties.getProperty (Context.COMPONENT_ID) == null) {
          throw new ComponentMetadataIncompleteException ("Component's metadata field missing: COMPONENT_ID");
        }
      }

      componentProperties.put (Context.IMPLEMENTATION_NAME, componentImplementation.getName());
      componentProperties.put (Context.INTERFACE_NAME, componentInterface.getName());
      componentProperties.put (Context.FACTORY_NAME, componentFactory.getName());
      return componentProperties;
    }
    else {
      throw new ComponentMetadataIncompleteException ("No annotations found in component's factory class!");
    }
  }
}

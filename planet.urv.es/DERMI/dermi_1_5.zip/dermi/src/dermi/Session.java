/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.util.*;
import dermi.listener.*;
import dermi.exception.*;

import java.util.*;
import java.io.Serializable;

/**
 * The Session class establishes a simple contract to access publish/subscribe
 * middleware. It mimics the delegation event model to smooth the transition
 * from local to remote events for Java programmers
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public interface Session {

  /**
   * The open method is mainly used by the facility class SessionFactory, so normally
   * should not be used by programmers.
   * @param evt Hashtable key/value pairs representing connection parameters
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void open (Hashtable evt) throws SessionException;

  /**
   * The close method safely frees resources and closes the connection.
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void close() throws SessionException;

  /**
   * This method creates a listener of remote events that matches the subscription specified in the subscription parameter.
   * @param listener RemoteEventListener The listener of remote events. It will handle incoming events matching the subscription.
   * @param subs String The subscription is represented using a String in the specified constraint filter language of the used notification service.
   * @see RemoteEventListener
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void subscribe (RemoteEventListener listener, String subs) throws SessionException;

  /**
   * This method creates a listener of remote events that matches the subscription specified in the subscription parameter.
   * @param listener RemoteEventListener The listener of remote events. It will handle incoming events matching the subscription.
   * @param subs Hashtable The subscription is represented using a Hashtable.
   * @see RemoteEventListener
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void subscribe (RemoteEventListener listener, Hashtable subs) throws SessionException;

  /**
   * This method removes the subscription specified in subscription parameters.
   * @param listener RemoteEventListener The listener of remote events
   * @param subs String The subscription to be removed (using specific constraint filter language)
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void unsubscribe (RemoteEventListener listener, String subs) throws SessionException;

  /**
   * This method removes the subscription specified in subscription parameters.
   * @param listener RemoteEventListener The listener of remote events
   * @param subs Hashtable The subscription to be removed
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void unsubscribe (RemoteEventListener listener, Hashtable subs) throws SessionException;

  /**
   * The publish method produces notifications in a simple and straightforward style.
   * @param event Hashtable The well-known java.util.Hashtable class is used for creating key/value pair notifications
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void publish (Hashtable event) throws SessionException;

  /**
   * Publisher method that accepts a Serializable object as a parameter. It will be received by the client with the key
   * Context.OBJECTCONTENT in the hashtable event parameter.
   * @param event Hashtable The well-known java.util.Hashtable class is used for creating key/value pair notifications
   * @param obj Serializable Java serializable object
   * @throws SessionException It throws the wrapper SessionException encapsulating all possible problems in the connection phase.
   */
  public void publish (Hashtable event, Serializable obj) throws SessionException;

  /**
   * Publishes an event directly to a peer (without routing it through the rendezvous point)
   * @param event Hashtable Event data
   * @throws SessionException If something goes wrong ;-)
   */
  public void publishDirect (Hashtable event) throws SessionException;

  /**
   * Publishes an event directly to a peer (without routing it through the rendezvous point)
   * @param event Hashtable Event data
   * @param obj Serializable Object to publish
   * @throws SessionException If something goes wrong ;-)
   */
  public void publishDirect (Hashtable event, java.io.Serializable obj) throws SessionException;

  /**
   * Adds an interceptor to the specified multicast group
   * @param listener RemoteInterceptorListener The interceptor to add
   * @param evt Hashtable Subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void addInterceptor (RemoteInterceptorListener listener, Hashtable evt) throws SessionException;

  /**
   * Removes an interceptor from the specified multicast group
   * @param evt Hashtable Subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void removeInterceptor (Hashtable evt) throws SessionException;

  /**
   * Continues distributed interception process
   * @param evt Hashtable Event data
   * @param interceptors ArrayList List of remaining interceptors
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors);

  /**
   * Adds an anycall listener
   * @param sel RemoteAnycallEventListener The listener
   * @param subscription Hashtable Subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void addRemoteAnycallEventListener (RemoteEventListener sel, Hashtable subscription) throws SessionException;

  /**
   * Removes an anycall listener
   * @param sel RemoteAnycallEventListener The listener
   * @param subscription Hashtable Subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void removeRemoteAnycallEventListener (RemoteEventListener sel, Hashtable subscription) throws SessionException;

  /**
   * Makes an anycall
   * @param evt Hashtable Subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void anycall (Hashtable evt) throws SessionException;

//  public int getMembers (Hashtable evt) throws SessionException;

  /**
   * Returns a set of suitable replica nodes for such Id
   * @param id Id Which id to replicate
   * @param maxRank int Maximum number of replicas
   * @return Collection Set of replicas
   */
  public Collection getReplicaSet (dermi.core.Id id, int maxRank);

  /**
   * Method used to obtain the local node handle for this node
   * @return NodeHandle Local node handle
   */
  public dermi.core.NodeHandle getLocalNodeHandle();

  /**
   * Method used to obtain the local node instance
   * @return Node Local node instance
   */
  public dermi.core.Node getLocalNode();

  /**
   * Method used to obtain the local node id
   * @return Node Local node id
   */
  public dermi.core.Id getLocalNodeId();

  public dermi.activation.ActivatorClient getActivator();

  public void addActiveObject (String uid, ERemote ref);
  public void removeActiveObject (String uid);
  public boolean containsActiveObject (String uid);
  public Collection listActiveObjects();
  public PriorityList getComponentHops (String uid);
}

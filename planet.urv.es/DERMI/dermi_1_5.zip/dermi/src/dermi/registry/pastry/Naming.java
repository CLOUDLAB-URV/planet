/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry.pastry;

import java.io.*;
import java.net.*;
import java.util.*;

import bunshin.*;
import bunshin.util.*;

import dermi.*;
import dermi.core.*;
import dermi.util.*;
import dermi.exception.*;
import dermi.registry.*;
import dermi.util.*;
import dermi.util.pastry.*;

/**
 * The Naming class provides methods for storing and obtaining references to remote objects
 * in the remote object registry.<br><br>
 * The dermi.Naming API (unlike Java RMI) does not use URLs, but properties objects or files
 * containing connection parameters. It is then mandatory to call the <i>loadRegistry</i> method
 * before using the functionality of the registry.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar
 * @version 1.2
 */
public class Naming implements dermi.registry.Naming {
  // Singleton
  private static Naming instance;

  private static Registry registry = null;
  private static DermiConnection connection = null;
  private static String bunshinProperties = null; //path to the bunshin.properties file
  private final String field = "DERMI";

  // Singleton design pattern
  private Naming() {
  }

  // Singleton design pattern
  public static Naming getInstance() {
    if (instance == null) {
      return new Naming ();
    }
    else {
      return instance;
    }
  }

  /**
   * It connects to the decentralized registry
   * @param conn DermiConnection The Dermi node where the registry will run on
   * @throws RemoteException If registry cannot be created
   */
  public void loadRegistry (DermiConnection conn, Properties props) throws RemoteException {
    if (registry == null) {
      registry = new Registry ((rice.p2p.commonapi.Node) conn.getLocalNode(), props);
      connection = conn;
      connection.loadActivator();
    }
  }

  /**
   * Gets the real path to the bunshin properties file.
   * @param dolrConfigPath Paht to the DOLR config path.
   * @return Path to the bunshi.properties file, using the real path that
   * appears in 'dolrConfigPath'.
   */
  private static String getBunshinPropertiesPath (String dolrConfigPath) {
    int last = dolrConfigPath.lastIndexOf (File.separator);
    if (last == -1) //doesn't exist
      return "bunshin.properties";
    else
      return dolrConfigPath.substring (0, last + 1) + "bunshin.properties";
  }


  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public void loadRegistry (String ref) throws RemoteException {
    if (registry == null) {
      try {
        FileInputStream fis = new FileInputStream (ref);
        Properties env = new Properties();
        env.loadFromXML (fis);
        String hostName = env.getProperty (dermi.util.Context.PROVIDER_HOST);
        int port = (new Integer (env.getProperty (dermi.util.Context.PROVIDER_PORT))).intValue();

        Class[] cl = {Object[].class};
        Object[] objs1 = {hostName, port, null, new Integer (env.getProperty (dermi.util.Context.PROTOCOL)), ref};
        Object[] objs = {objs1};
        String className = "dermi.core." + env.getProperty (dermi.util.Context.UNDERLYING_DHT) + ".DermiConnection";
        connection = (DermiConnection) Class.forName (className).getConstructor (cl).newInstance (objs);
        // Necessary time to allow correct initialization
//        Thread.currentThread().sleep (5000);
      } catch (Exception e) {
        e.printStackTrace();
        throw new RemoteException (e.getMessage ());
      }
    }
  }

  public void setInfoContext(String context, String path, String url, URL[] URLsList) throws RemoteException {
    registry.setInfoContext(context,path,url, URLsList);
  }

  /**
   * It closes the connection and kills the node
   * @throws RemoteException If the connection with the event service fails.
   */
  public void leave() throws RemoteException {

  	registry.leave();

  	//waiting while the registry executes the leave method
  	try {
  	  Thread.sleep (2000);
  	}
    catch (InterruptedException ex) {}

  	//connection.close();
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (name);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name, String communityId, String className) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (connection, name, communityId, className);
  }

  /**
   * Returns a serializable object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Serializable Object's reference
   */
  public Serializable lookupSer (String context, Id id) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (context,(dermi.core.Id) id);
  }

  public Serializable lookupSer (String context, Id id, String field) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (context,(dermi.core.Id) id, field);
  }

  public URL lookupURL (String context, Id id, String field) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookupURL (context,(dermi.core.Id) id, field);
  }


  public Serializable lookupSer (String context, String componentURL) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (context,HashGenerator.generateHash (componentURL));
  }

  public Serializable lookupSer (String componentURL) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (HashGenerator.generateHash (componentURL));
  }


  public void removeSer (String context, Id id, String field) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.remove (context,(dermi.core.Id) id, field);
  }
  
 public void removeSer (Id id) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.removeSer ((dermi.core.Id) id);
  }


  public void removeSer (String key) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.removeSer(key);
  }


  /**
   * Method used to know if the registry is already connected to a Pastry node
   * @return boolean true if it is connected
   */
  public boolean isConnected () {
    return (connection != null);
  }

  /**
   * Method used to get the connection to the Pastry node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public DermiConnection getConnection() {
    return connection;
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, ERemote ref) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.bind (name, ref.getERef());
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties env) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.bind (name, env);
  }

  public boolean bindSer (dermi.core.Id id, Serializable object) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    return registry.insert (id, object, field);
  }

  public boolean bindSer (String context, dermi.core.Id id, Serializable object) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    return registry.insert (context, id, object, field);
  }

  public boolean bindSer (String context, String name, Serializable object) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    return registry.insert (context, HashGenerator.generateHash (name), object, field);
  }

  public boolean bindSer (String name, Serializable object) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    return registry.insert (HashGenerator.generateHash (name), object, field);
  }

  /**
   * Unbinds the specified  name from a remote object.
   * @param name Id of the remote object
   * @throws dermi.NotBoundException - if the Registry does not contains this Id.
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
     public void unbind (String name) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.unbind (name);
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bindRoot() throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    // System.out.println ("[DERMI REGISTRY] - Looking for base root...");
    try {
      Properties p = (Properties) registry.lookup (HashGenerator.generateHash ("p2p://"));

    } catch (NotBoundException ne) {
      System.out.println ("[DERMI REGISTRY] - Base root not bound... Binding 'p2p://'");
      Properties p = new Properties();
      p.setProperty (dermi.util.Context.DERMI_DOLR_UNIQUE_URI, "p2p://");
      p.put (dermi.util.Context.DERMI_DOLR_CHILDREN, new ArrayList<Properties>());
      registry.insert (HashGenerator.generateHash ("p2p://"), p, field);
    }
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void rebind (String name, ERemote ref) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.rebind (name, ref.getERef());
  }
  
  
  public Hashtable getStorageInfo() throws RemoteException {
  	if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
      
  	return registry.getStorageInfo();
  }
  
  public Hashtable getReplicaInfo() throws RemoteException {
  	if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
      
  	return registry.getReplicaInfo();
  }


  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public Collection list (String root) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.list(root);
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand implements rice.Continuation {
    boolean received;
    Properties eref;

    public NamingCommand (boolean received, Properties eref) {
      this.received = received;
      this.eref = eref;
    }

    public void receiveResult (Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}

    public void receiveException(Exception e) {
      e.printStackTrace();
      System.out.println ("receiveException on NamingCommand");
    }
  }

  /* SECURE */

  public boolean bindSecure (String context, dermi.core.Id id, Serializable object, String pass) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    return registry.insertSecure (context, id, object, field, pass);
  }
  
  public boolean bindSecure (String context, dermi.core.Id id, Serializable object, String pass, boolean getcheck) throws RemoteException {
	    if (registry == null) {
	      throw new RegistryNotLoadedException ("Registry not loaded");
	    }
	    return registry.insertSecure (context, id, object, field, pass, getcheck);
	  }

  public Serializable lookupSecure (String context, Id id, String pass) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookupSecure (context,(dermi.core.Id) id, field, pass);
  }


  /* DERMI EXTRA METHODS */

  public void insertURL (String context, Id id, java.net.URL url, String field) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    registry.insertURL (context, id, url, field);
   }

   public void modify (String context, Id id, Object value, String field, boolean add) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

      registry.modify(context, id,value,field,add);
    }

   public void modify (String context, Id id, Collection values, String field, boolean add) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

     registry.modify(context, id,values,field,add);
   }

   public void setRemoteListener (String context, Id id, RemoteListener listener, String field) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

     registry.setRemoteListener(context, id,listener,field);
   }

   public void removeRemoteListener (String context, Id id, String field) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

     registry.removeRemoteListener(context, id,field);
   }

   public Collection getIncomingLinks (String context, Id id) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

     return registry.getIncomingLinks(context, id);
   }

   public Collection getOutgoingLinks(String context, Id id) throws RemoteException {
     if (registry == null)
       throw new RegistryNotLoadedException ("Registry not loaded");

     return registry.getOutgoingLinks(context, id);
   }


  /* DERMI SEARCH METHODS */

  public void insert(String context, String keywords, String key, Serializable value)  throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    registry.insert (context, keywords,key,value);
  }

  public ResultSortedQueue query (String context,String keywords)  throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    return registry.query (context, keywords);
  }

  public void remove(String context, String keywords, String key) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.remove(context, keywords,key);
  }
}


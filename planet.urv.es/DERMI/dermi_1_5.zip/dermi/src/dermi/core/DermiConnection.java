/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.core;

import dermi.*;
import dermi.util.*;
import dermi.session.*;
import dermi.exception.*;
import dermi.activation.*;

import java.util.*;
import java.util.logging.*;
import java.io.*;
import java.net.*;

/**
 * This class wraps a connection to any DHT substrate and is used by Dermi as its main
 * routing substrate.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public abstract class DermiConnection {
  // the instance name to use
  public static String INSTANCE_NAME = "Dermi";

  protected transient Logger logger = Logger.getLogger (this.getClass().getName());

  // the host to boot the first node off of
  public static String BOOTSTRAP_HOST = "localhost";

  protected String configurationFile = "";

  // ----- ATTEMPT TO LOAD LOCAL HOSTNAME -----
  static {
    try {
      BOOTSTRAP_HOST = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      Logger.getLogger (DermiConnection.class.getName()).severe ("Error determining local host: " + e);
    }
  }

  protected ActivatorClient activatorClient;
  protected ActivatorImpl activatorImpl;

  private static Hashtable<String, ERemote> activeObjects = new Hashtable();

  // This constructor must be implemented by all subclasses
  protected DermiConnection (Object ... args) throws ConnectionException { }

  /**
   * This method loads all activator objects for this Dermi instance,
   * one for each community it is member of
   */
  public void loadActivator() {
    // Initialize Activator object(s), which will be responsible of the communities
    // this Dermi node belongs to
    try {
      Properties env = Registry.getEnvironment (configurationFile);
      env.setProperty (Context.CLASS_ID, Context.ACTIVATOR_ID);
      env.setProperty (Context.CLASS_NAME, (ActivatorImpl.class).getName());
      // Start activator object itself
      activatorImpl = new ActivatorImpl (env);

      // Start activator object stub
      activatorClient = new ActivatorClient (env);
    } catch (RemoteException e) {
      logger.severe ("Unable to instantiate activator object.");
      e.printStackTrace();
    }
  }

  /**
   * This method returns the activator client responsible for the community
   * @param communityId String The community id
   * @return ActivatorClient The activator client responsible for that community
   */
  public ActivatorClient getActivator() {
    return activatorClient;
  }

  /**
   * Method for subscribing an application to a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to subscribe
   */
  public abstract void subscribe (Topic topic, Client subscriber);

  /**
   * Checks whether this topic is already subscribed on this node
   * @param topic Topic The group's identifier
   * @return boolean True if the topic is already subscribed
   */
//  public abstract boolean isSubscribed (Topic topic);

  /**
   * Method for unsubscribing an application from a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to unsubscribe
   */
  public abstract void unsubscribe (Topic topic, Client subscriber);

  /**
   * Method for publishing data
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public abstract void publish (Topic topic, Serializable data);

  /**
   * Method for publishing data directly to a node
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public abstract void publishDirect (Topic topic, Serializable data);

  /**
   * Method for anycalling to a group of objects
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public abstract void anycall (Topic topic, Serializable data);

  /**
   * Utility method for obtaining the local node handle
   * @return NodeHandle Local node handle
   */
  public abstract dermi.core.NodeHandle getLocalNodeHandle();

  /**
   * Utility method for obtaining the local node
   * @return Node Local node
   */
  public abstract dermi.core.Node getLocalNode();

  public abstract dermi.core.Id getLocalNodeId();

  /**
   * Method for adding an interceptor to an object group
   * @param npar NotificationParser Interceptor application
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public abstract void addInterceptor (DermiApplicationListener npar, Id subsKey, String interceptorId);

  /**
   * Method for removing an interceptor from an object group
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public abstract void removeInterceptor (Id subsKey, String interceptorId);

  /**
   * Method for resuming the interception process. Automatically called
   * by interceptor skeletons
   * @param evt Hashtable
   * @param interceptors ArrayList
   */
  public abstract void continueInterception (Hashtable evt, ArrayList interceptors);

//  public abstract int getMembers (Topic topic);

  /**
   * Returns a set of suitable replica nodes for such Id
   * @param id Id Which id to replicate
   * @param maxRank int Maximum number of replicas
   * @return Collection Set of replicas
   */
  public abstract Collection getReplicaSet (dermi.core.Id id, int maxRank);

  /**
   * Method for closing a connection, thus killing the node
   */
  public abstract void close();

  public void addActiveObject (String uid, ERemote ref) {
    if (!uid.equals (Context.ACTIVATOR_ID)) {
      activeObjects.put (uid, ref);
    }
  }

  public void removeActiveObject (String uid) {
    if (!uid.equals (Context.ACTIVATOR_ID)) {
      activeObjects.remove (uid);
    }
  }

  public Collection listActiveObjects() {
    return (Collection) activeObjects.clone();
  }

  public boolean containsActiveObject (String uid) {
    return activeObjects.contains (uid);
  }

  public abstract PriorityList getComponentHops (String uid);
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.core.pastry;

import java.util.*;
import java.util.logging.*;

import dermi.*;
import dermi.util.*;
import dermi.util.pastry.*;
import dermi.session.pastry.*;
import dermi.messaging.pastry.*;
import dermi.exception.*;

import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;
import rice.p2p.commonapi.*;

/**
 * This class implements the kernel of Dermi based on Scribe. It extends the Scribe event
 * service to provide all the features and services
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar
 * @version 1.2
 */
public class DermiKernel extends ScribeImpl {
  private transient Logger logger = Logger.getLogger (this.getClass().getName());
  private static Hashtable<String, PriorityList<dermi.core.NodeHandle>> lastComponentHops = new Hashtable<String, PriorityList<dermi.core.NodeHandle>>();
  private transient DermiConnection upperDermi = null;

  /**
   * The kernel constructor
   * @param instance String Instance name
   * @param conn DermiConnection The connection node
   */
  public DermiKernel (String instance, DermiConnection conn) {
    super ((rice.p2p.commonapi.Node) conn.getLocalNode(), instance);
    upperDermi = conn;
  }

  /**
   * Method for adding an interceptor object to an object group
   * @param client ScribeClient Interceptor application
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  public void addInterceptor (dermi.session.DermiApplicationListener client, dermi.core.Topic topic, String intId) {
    logger.fine ("Adding interceptor...");
    TopicManager manager = (TopicManager) topics.get (topic);

    if (manager == null) {
    	logger.finer ("Creating topic manager on this node...");
      manager = new TopicManager ((rice.p2p.scribe.Topic) topic,(rice.p2p.scribe.ScribeClient) client);
      topics.put (topic, manager);
    }

    // Send a message to the group's root so as the new interceptor is added.
    // If root is local node, the message is not sent remotely
    manager.addInterceptor (intId, (rice.p2p.scribe.ScribeClient) client, this.getLocalNodeHandle());
    sendInterceptorSubscribeMsg ((rice.p2p.commonapi.NodeHandle) handle, (rice.p2p.scribe.Topic) topic, intId);
  }

  /**
   * For sending an interceptor subscribe message
   * @param handle NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  private void sendInterceptorSubscribeMsg (rice.p2p.commonapi.NodeHandle handle, rice.p2p.scribe.Topic topic, String intId) {
    endpoint.route (topic.getId(), new InterceptorSubscribeMessage (handle, topic, handle, intId), null);
  }

  /**
   * For sending an interceptor unsubscribe message
   * @param handle NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  private void sendInterceptorUnsubscribeMsg (rice.p2p.commonapi.NodeHandle handle, rice.p2p.scribe.Topic topic, String intId) {
    endpoint.route (topic.getId(), new InterceptorUnsubscribeMessage (handle, topic, intId), null);
  }

  /**
   * Method for removing an interceptor from an object group
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  public void removeInterceptor (rice.p2p.scribe.Topic topic, String intId) {
    logger.fine ("Removing interceptor...");
    TopicManager manager = (TopicManager) topics.get (topic);

    if (manager == null) {
      logger.warning ("Nothing to remove here...");
    }

    // Send a message to the group's root so as the new interceptor is removed.
    // If root is local node, the message is not sent remotely
    manager.removeInterceptor (intId);
    sendInterceptorUnsubscribeMsg ((rice.p2p.commonapi.NodeHandle) handle, topic, intId);
  }

  /**
   * Returns the local node handle
   * @return NodeHandle Returned node handle
   */
  public rice.p2p.commonapi.NodeHandle getLocalNodeHandle() {
    return handle;
  }

  public void publish (dermi.core.Topic topic, dermi.core.pastry.DermiContent cnt) {
    super.publish ((rice.p2p.scribe.Topic) topic, cnt);
  }

  public void anycast (dermi.core.Topic topic, dermi.core.pastry.DermiContent cnt) {
    super.anycast ((rice.p2p.scribe.Topic) topic, cnt);
  }

  /**
   * Returns a set of suitable replica nodes for such Id
   * @param id Id Which id to replicate
   * @param maxRank int Maximum number of replicas
   * @return Collection Set of replicas
   */
  public Collection getReplicaSet (dermi.core.Id id, int maxRank) {
    NodeHandleSet nhs = endpoint.replicaSet ((rice.p2p.commonapi.Id) id, maxRank);
    ArrayList a = new ArrayList();
    for (int i = 0; i < nhs.size(); i++) {
      a.add (nhs.getHandle (i));
    }
    return a;
  }

  /**
   * Publishes a direct message to the topic. (This means sending it not via
   * the rendezvous point, but directly to the destination peer)
   *
   * @param topic The topic to publish to
   * @param content The content to publish
   */
  public void publishDirect (dermi.core.Topic topic, dermi.core.pastry.DermiContent content) {
    rice.p2p.commonapi.NodeHandle nh = null;
    if (((Hashtable) content.getData()).get (Context.DESTINATION_NODEHANDLE) != null) {
      nh = (rice.p2p.commonapi.NodeHandle) ((Hashtable) content.getData()).get (Context.DESTINATION_NODEHANDLE);
    }
    else {
      nh = (rice.p2p.commonapi.NodeHandle) ( (Hashtable) content.getData()).get (Context.SOURCE_NODEHANDLE);
    }
    if (((Hashtable) content.getData()).get (Context.HOPPED) != null) {
      endpoint.route ((rice.p2p.commonapi.Id) nh.getId(), new DirectMessage (handle, (rice.p2p.scribe.Topic) topic, content), null);
    }
    else {
      endpoint.route ((rice.p2p.commonapi.Id) nh.getId(), new DirectMessage (handle, (rice.p2p.scribe.Topic) topic, content), nh);
    }
  }

  /**
   * This method is invoked to inform the application that the given node has either joined or left
   * the neighbor set of the local node, as the set would be returned by the neighborSet call.
   *
   * @param handle The handle that has joined/left
   * @param joined Whether the node has joined or left
   */
  public void update (NodeHandle handle, boolean joined) {
    Set set = topics.keySet();
    Iterator e = set.iterator();
    TopicManager manager;
    Topic topic;

    while (e.hasNext()){
      topic = (Topic)e.next();
      manager = (TopicManager) topics.get (topic);

      if (joined) {
        // check if new guy is root, we were old root, then subscribe
        if (manager.getParent() == null){
          // send subscribe message
          super.subscribe (topic, null, null);
          // send interceptor data
          if (manager.containsInterceptors()) {
            sendInterceptorData (topic, manager);
          }
        }
      } else {
        if (isRoot (topic) && (manager.getParent() != null)) {
          endpoint.route (null, new UnsubscribeMessage (handle, topic), manager.getParent());
          manager.setParent (null);
        }
      }
    }
  }

  /**
   * Method for sending interceptor data
   * @param topic Topic Group's identifier
   * @param manager TopicManager The group's manager
   */
  private void sendInterceptorData (Topic topic, TopicManager manager) {
    endpoint.route (topic.getId(), new InterceptorDataMessage (getLocalNodeHandle(), topic, manager.getInterceptors()), null);
  }

  public PriorityList getComponentHops (String componentId) {
    return lastComponentHops.get (componentId);
  }

  /**
   * The Common API forward method has been changed to first pass the RouteMessage to Dermi's notification
   * parser, so as to be able to route new messages with content changes (useful in manycalls)
   *
   * @param message RouteMessage Received message
   * @return boolean true if message has to be routed further
   */
  public boolean forward (final RouteMessage message) {
	  logger.finest(endpoint.getId() + ": Forward called with " + message.getMessage());
    // Store previous hop handle with information about the overwhelming object

    if (message.getMessage() instanceof DirectMessage) {
      DirectMessage dm = (DirectMessage) message.getMessage();
      DermiContent dc = (DermiContent) dm.getContent();
      Hashtable ht = (Hashtable) dc.getData();

      // Only count client requests. Do not count server responses.
      if (ht.get (Context.OBJECTID) != null) {

        PriorityList<dermi.core.NodeHandle> list = lastComponentHops.get (ht.get (Context.OBJECTID));

        if (list == null) {
          list = new PriorityList<dermi.core.NodeHandle>();
        }

        rice.p2p.commonapi.NodeHandle nh = ((ScribeMessage) message.getMessage ()).getPreviousHop();
        list.update ((dermi.core.NodeHandle) nh);
        lastComponentHops.put ((String) ht.get (Context.OBJECTID), list);

        // Check if the invocation should be intercepted by a "nearby" object instance instead of
        // the original one
        if (ht.get (Context.DYNAMIC_HOPPED_CALL) != null) {
          // The current node contains this object. We must intercept this call.
          if (upperDermi.containsActiveObject ((String) ht.get (Context.OBJECTID)) &&
              !message.getDestinationId().equals (this.getLocalNodeHandle().getId())) {
            System.out.println ("Capturing hopped call - not addressed to this node, but processing it...: " + ht.get(Context.OBJECTID));
            this.deliver (message.getDestinationId(), message.getMessage());
            return false;
          }
        }
      }
    }

    if (message.getMessage() instanceof AnycastMessage) {
      AnycastMessage aMessage = (AnycastMessage) message.getMessage();

      // get the topic manager associated with this topic
      TopicManager manager = (TopicManager) topics.get (aMessage.getTopic());

      // if it's a subscribe message, we must handle it differently
      if (message.getMessage() instanceof SubscribeMessage) {
        SubscribeMessage sMessage = (SubscribeMessage) message.getMessage();

        // if this is our own subscribe message, ignore it
        if (sMessage.getSource().getId().equals(endpoint.getId())) {
          sMessage.setPreviousHop (this.getLocalNodeHandle());
          return true;
        }

        if (manager != null) {
          // first, we have to make sure that we don't create a loop, which would occur
          // if the subcribing node's previous parent is on our path to the root
          rice.p2p.commonapi.Id previousParent = sMessage.getPreviousParent();
          List path = Arrays.asList(manager.getPathToRoot());

          if (path.contains(previousParent)) {
        	  logger.info(endpoint.getId() + ": Rejecting subscribe message from " +
                      sMessage.getSubscriber() + " for topic " + sMessage.getTopic() +
                      " because we are on the subscriber's path to the root.");
             sMessage.setPreviousHop (this.getLocalNodeHandle());
             return true;
           }
         }

        rice.p2p.scribe.ScribeClient[] clients = new ScribeClient[0];
        rice.p2p.commonapi.NodeHandle[] handles = new NodeHandle[0];

        if (manager != null) {
          clients = manager.getClients();
          handles = manager.getChildren();
        }

        // check if child is already there
        if (Arrays.asList(handles).contains (sMessage.getSubscriber())){
          sMessage.setPreviousHop (this.getLocalNodeHandle());
          return false;
        }

        // see if the policy will allow us to take on this child
        if (policy.allowSubscribe(sMessage, clients, handles)) {
        	logger.finer(endpoint.getId() + ": Hijacking subscribe message from " +
            sMessage.getSubscriber() + " for topic " + sMessage.getTopic());

          // if so, add the child
          addChild(sMessage.getTopic(), sMessage.getSubscriber());
          sMessage.setPreviousHop (this.getLocalNodeHandle());
          return false;
        }

        // otherwise, we are effectively rejecting the child
        logger.finer(endpoint.getId() + ": Rejecting subscribe message from " +
          sMessage.getSubscriber() + " for topic " + sMessage.getTopic());

        // if we are not associated with this topic at all, we simply let the subscribe go
        // closer to the root
        if (manager == null) {
          sMessage.setPreviousHop (this.getLocalNodeHandle());
          return true;
        }
      } else {
        // if we are not associated with this topic at all, let the
        // anycast continue
        if (manager == null) {
          // Check if message contains a Context.GET_COMPONENT_INSTANCE field.
          // In such case, we should return something to indicate that no instance is bound
          if (checkComponentInstance (aMessage)) {
            // Tell the originator that there are no alive instances of the component
            // Any/Many call unsatisfied by any of the group members
            DermiContent dc = (DermiContent) aMessage.getContent();
            Hashtable ht = (Hashtable) dc.getData();

            Hashtable<String, Object> send = new Hashtable<String, Object>();
            send.put (Context.OBJECTID, ht.get (Context.OBJECTID) + Context.APPEND_RESULT);
            send.put (Context.TYPE, Context.EXCEPTION);
            send.put (Context.METHOD, ht.get (Context.METHOD));
            send.put (Context.TIMESTAMP, ht.get (Context.TIMESTAMP));
            send.put (Context.OBJECTCONTENT, new dermi.exception.NotSatisfiedException ());

            rice.p2p.commonapi.NodeHandle nh = (rice.p2p.commonapi.NodeHandle) (ht.get (Context.SOURCE_NODEHANDLE));
            DermiContent content = new DermiContent (send);

            // Message returned directly
            endpoint.route ((rice.p2p.commonapi.Id) nh.getId(), new DirectMessage (nh, new dermi.core.pastry.Topic (HashGenerator.generateSessionHash (send)), content), nh);
          }
          aMessage.setPreviousHop (this.getLocalNodeHandle());
          return true;
        }

        rice.p2p.scribe.ScribeClient[] clients = manager.getClients();

        // see if one of our clients will accept the anycast
        for (int i = 0; i < clients.length; i++) {
          if (clients[i] instanceof dermi.session.DermiApplicationListener) {
            aMessage.setContent ((ScribeContent) ((dermi.session.DermiApplicationListener) clients[i]).interceptAnycast ((Topic) aMessage.getTopic(), (DermiContent) aMessage.getContent()));
          }
          if (clients[i].anycast (aMessage.getTopic(), aMessage.getContent())) {
        	  logger.finer(endpoint.getId() + ": Accepting anycast message from " + aMessage.getSource() + " for topic " + aMessage.getTopic());
            aMessage.setPreviousHop (this.getLocalNodeHandle());
            return false;
          }
        }

        // if we are the orginator for this anycast and it already has a destination,
        // we let it go ahead
        if (aMessage.getSource().getId().equals(endpoint.getId()) &&
            ( message.getNextHopHandle() != null) &&
            (! handle.equals(message.getNextHopHandle()))) {
          aMessage.setPreviousHop (this.getLocalNodeHandle());
          return true;
        }

        logger.finer(endpoint.getId() + ": Rejecting anycast message from " +
          aMessage.getSource() + " for topic " + aMessage.getTopic());
      }

      // add the local node to the visited list
      aMessage.addVisited (endpoint.getLocalNodeHandle());

      // allow the policy to select the order in which the nodes are visited
      policy.directAnycast (aMessage, manager.getParent(), manager.getChildren());

      // reset the source of the message to be us
      aMessage.setSource (endpoint.getLocalNodeHandle());

      // get the next hop
      rice.p2p.commonapi.NodeHandle handle = aMessage.getNext();

      // make sure that the next node is alive
      while ((handle != null) && (!handle.isAlive())) {
        handle = aMessage.getNext();
      }

      logger.finer(endpoint.getId() + ": Forwarding anycast message for topic " + aMessage.getTopic() + "on to " + handle);

      if (handle == null) {
        logger.finer (endpoint.getId() + ": Anycast " + aMessage + " failed.");

        // Any/Many call unsatisfied by any of the group members
        DermiContent dc = (DermiContent) aMessage.getContent();
        Hashtable ht = (Hashtable) dc.getData();

        Hashtable<String, Object> send = new Hashtable<String, Object>();

        if (ht.get (Context.REPLICA) != null) {
          send.put (Context.OBJECTID, ht.get (Context.OBJECTID));
        }
        else {
          if (ht.get (Context.OBJECTID) != null) {
            send.put (Context.OBJ, ht.get (Context.OBJECTID) + Context.APPEND_RESULT);
          }
          else {
            send.put (Context.OBJ, ht.get (Context.OBJ));
          }
        }

        send.put (Context.TYPE, Context.EXCEPTION);
        send.put (Context.METHOD, ht.get (Context.METHOD));
        send.put (Context.TIMESTAMP, ht.get (Context.TIMESTAMP));
        send.put (Context.OBJECTCONTENT, new dermi.exception.NotSatisfiedException ());

        rice.p2p.commonapi.NodeHandle nh = (rice.p2p.commonapi.NodeHandle) (ht.get (Context.SOURCE_NODEHANDLE));
        DermiContent content = new DermiContent (send);

        // Message returned directly
        endpoint.route ((rice.p2p.commonapi.Id) nh.getId(), new DirectMessage (nh, new dermi.core.pastry.Topic (HashGenerator.generateSessionHash (send)), content), nh);

        // if it's a subscribe message, send a subscribe failed message back
        // as a courtesy
        if (aMessage instanceof SubscribeMessage) {
          SubscribeMessage sMessage = (SubscribeMessage) aMessage;
          logger.finer(endpoint.getId() + ": Sending SubscribeFailedMessage to " + sMessage.getSubscriber());

          endpoint.route(sMessage.getSubscriber().getId(),
                         new SubscribeFailedMessage(handle, sMessage.getTopic(), sMessage.getId()),
                         sMessage.getSubscriber());
        }
      } else {
        endpoint.route (handle.getId(), aMessage, handle);
      }
      aMessage.setPreviousHop (this.getLocalNodeHandle());
      return false;
    }

    ((ScribeMessage) message.getMessage()).setPreviousHop (this.getLocalNodeHandle());
    return true;
  }

  /**
   * This method is called on the application at the destination node for the given id.
   *
   * @param id The destination id of the message
   * @param message The message being sent
   */
  public void deliver (rice.p2p.commonapi.Id id, Message message) {
    if (message instanceof InterceptorSubscribeMessage) {
      InterceptorSubscribeMessage iMessage = (InterceptorSubscribeMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        logger.fine ("The root has no manager for this topic!!!");
      }
      else {
        // Add interceptor application. The root will know it is a remote interceptor, because
        // null client is specified
    	  logger.finer ("Added new interceptor to the root.");
        manager.addInterceptor (iMessage.getInterceptorId(), null, iMessage.getInterceptorHandle());
      }
      return;
    }

    if (message instanceof InterceptorUnsubscribeMessage) {
      InterceptorUnsubscribeMessage iMessage = (InterceptorUnsubscribeMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        logger.fine ("The root has no manager for this topic!!!");
      }
      else {
        // Remove interceptor application.
        logger.finer ("Removed interceptor from the root.");
        manager.removeInterceptor (iMessage.getInterceptorId());
      }
      return;
    }

    if (message instanceof InterceptorDataMessage) {
      InterceptorDataMessage iMessage = (InterceptorDataMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        logger.fine ("The root has no manager for this topic!!!");
      }
      else {
        logger.finer ("Received interceptor data from old root...");
        Iterator it = iMessage.getInterceptors().iterator();

        while (it.hasNext()) {
          logger.finer ("Interceptor clients received by the message: " + iMessage.getInterceptors());
          logger.finest ("Interceptor clients in the topic manager: " + manager.getInterceptors() + "\n");
          InterceptorApp intApp = (InterceptorApp) it.next();
          if (!manager.existsInterceptor (intApp.getInterceptorId())) {
            logger.fine ("Adding new interceptor.");
            manager.addInterceptor (intApp.getInterceptorId(), intApp.getApplication(), intApp.getApplicationNodeHandle());
          }
        }
      }

      return;
    }

    if (message instanceof DirectMessage) {
      DirectMessage dMessage = (DirectMessage) message;
      TopicManager manager = (TopicManager) topics.get (dMessage.getTopic());
      if (manager != null) {
        rice.p2p.scribe.ScribeClient[] clients = manager.getClients();

        for (int i = 0; i < clients.length; i++) {
          clients[i].deliver (dMessage.getTopic(), dMessage.getContent());
        }
      }
      return;
    }

    if (message instanceof PublishRequestMessage) {
      PublishRequestMessage prMessage = (PublishRequestMessage) message;
      TopicManager manager = (TopicManager) topics.get(prMessage.getTopic());

      logger.finer(endpoint.getId() + ": Received publish request message with data " +
                prMessage.getContent() + " for topic " + prMessage.getTopic());

      // if message is for a non-existant topic, drop it on the floor (we are the root, after all)
      // otherwise, turn it into a publish message, and forward it on
      if (manager == null) {
        logger.fine (endpoint.getId() + ": Received publish request message for non-existent topic " +
                 prMessage.getTopic() + " - dropping on floor.");
      } else {

        // if the root has interceptors, we must forward the message to the first one, before forwarding it to the members
        // of the group
        while (manager.containsInterceptors()) {
          logger.finer ("Entering interception phase...");
          ArrayList interceptors = manager.getInterceptors();
          InterceptorApp app = (InterceptorApp) interceptors.get (0);
          logger.finest ("The next interceptor is alive? " + app.getApplicationNodeHandle().isAlive());
          if (app.getApplicationNodeHandle().isAlive()) {
            endpoint.route (app.getApplicationNodeHandle().getId(), new InterceptorMessage (getLocalNodeHandle(), prMessage.getSource(), prMessage.getTopic(), prMessage.getContent(), interceptors), app.getApplicationNodeHandle());
            return;
          }
        }
        logger.fine ("Publishing without interception.");
        deliver (prMessage.getTopic().getId(), new PublishMessage (prMessage.getSource(), prMessage.getTopic(), prMessage.getContent()));
        return;
      }
    }

    if (message instanceof InterceptorMessage) {
      logger.finer ("Interception message received.");
      InterceptorMessage iMessage = (InterceptorMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        logger.finer (endpoint.getId() + ": Received interceptor message for non-existent topic " +
                 iMessage.getTopic() + " - dropping on floor.");
      }
      else {
        // Check if already intercepted message has reached the root
        if (isRoot (iMessage.getTopic()) && iMessage.isInterceptionFinished()) {
          logger.fine ("Publishing normally after interception...");
          deliver (iMessage.getTopic().getId(), new PublishMessage (getLocalNodeHandle(), iMessage.getTopic(), iMessage.getContent()));
        }

        else {
          logger.finer ("Intercepting...");
          ArrayList interceptors = iMessage.getInterceptors();
          try {
            InterceptorApp app = (InterceptorApp) interceptors.get (0);
            interceptors.remove (0);
            String intKey = app.getInterceptorId();

            // Look for this key in the topic manager's interceptor clients and
            // execute the callback
            NotificationParser np = (NotificationParser) manager.getInterceptorClient (intKey);
            Hashtable content = (Hashtable) ((DermiContent) iMessage.getContent()).getData();
            np.receiveInterceptorMessage (content, interceptors);
          } catch (IndexOutOfBoundsException abe) {
            // Interceptor unavailable (maybe interceptor data has not reached the root yet)
            logger.warning ("Distributed interception failure!!! - Sending message to group members without being intercepted.");
            endpoint.route (iMessage.getTopic().getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), iMessage.getTopic(), iMessage.getContent(), interceptors, true), null);
          }
        }
      }
      return;
    }

/*
    if (message instanceof MembershipMessage) {
      MembershipMessage msm = (MembershipMessage) message;
      memberMessageReceived (msm.getTopic(), msm.isJoin());

      if (!isRoot (msm.getTopic())) {
        sendMembershipMessage (msm);
      }
      return;
    }

    if (message instanceof SubscribeAckMessage) {
      SubscribeAckMessage saMessage = (SubscribeAckMessage) message;
      TopicManager manager = (TopicManager) topics.get (saMessage.getTopic());

      if (!isRoot (saMessage.getTopic())) {
        if (manager != null) {
          while (manager.getNotify()>0) {
            sendMembershipMessage(new MembershipMessage(handle,saMessage.getTopic(),true));
            manager.decNotify();
          }
        }
      }
    }
 */
    // To deal with other kinds of standard Scribe messages
    super.deliver (id, message);
  }

  /**
   * Method invoked by interceptor skeletons to resume the interception process
   * @param evt Hashtable Event data
   * @param interceptors ArrayList Remaining interceptors to be traversed
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors) {
    rice.p2p.scribe.Topic topic = new dermi.core.pastry.Topic (HashGenerator.generateSessionHash (evt));

    // Check whether it is the last interceptor on the queue
    while (interceptors.size() != 0) {
      InterceptorApp iApp = (InterceptorApp) interceptors.get (0);
      rice.p2p.commonapi.NodeHandle interceptorHandle = iApp.getApplicationNodeHandle();
      logger.finest ("Resuming interception process... - to interceptor " + iApp.getInterceptorId());
      if (interceptorHandle.isAlive()) {
        endpoint.route (interceptorHandle.getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), topic, new DermiContent (evt), interceptors), interceptorHandle);
        return;
      }
      logger.finer ("Interceptor dead... Proceeding to next one...");
      interceptors.remove (0);
    }
    // Should be routed directly to root ?
    logger.finer ("Sending message back to multicast group root...");
    endpoint.route (topic.getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), topic, new DermiContent (evt), interceptors, true), null);
  }

  /**
   * Sends a membership message
   * @param msm MembershipMessage MembershipMessage to be send
   */
/*  private void sendMembershipMessage (MembershipMessage msm) {
    rice.p2p.scribe.Topic topic = msm.getTopic();
    if (topics.get (topic) != null) {
      TopicManager manager = (TopicManager) topics.get (topic);
      rice.p2p.commonapi.NodeHandle parent = manager.getParent();
      msm.setSource(endpoint.getLocalNodeHandle());
      if (parent != null) {
        endpoint.route (endpoint.getId(), msm, parent);
      }
      else {
        manager.incNotify();
      }
    }
  }
*/

  /**
   * Internal method which processes an ack message
   *
   * @param message The ackMessage
   */
/*  public void ackMessageReceived (SubscribeAckMessage message) {
    super.ackMessageReceived (message);

    rice.p2p.scribe.Topic topic = message.getTopic();
    TopicManager manager = (TopicManager) topics.get (topic);

    if (!manager.isAck_subscribe()) {
      rice.p2p.commonapi.NodeHandle parent = manager.getParent();
      rice.p2p.commonapi.Id[] path = message.getPathToRoot();
      if (parent != null) {
        endpoint.route (endpoint.getId(), new MembershipMessage (handle, topic, true), parent);
        manager.setAck_subscribe (true);
      }
      else {
        manager.incNotify();
        manager.setAck_subscribe (true);
      }
    }
  }
*/

  /**
   * Unsubscribes the given client from the provided topic.
   *
   * @param topic The topic to unsubscribe from
   * @param client The client to unsubscribe
   */
  public void unsubscribe (dermi.core.Topic topic, dermi.core.Client client) {
	  logger.finer (endpoint.getId() + ": Unsubscribing client " + client + " from topic " + topic);

    if (topics.get (topic) != null) {
      TopicManager manager = (TopicManager) topics.get (topic);

      //MEMBERSHIP NEW MESSAGE
      rice.p2p.commonapi.NodeHandle parent = manager.getParent();
/*      if (parent != null) {
        endpoint.route (parent.getId(), new MembershipMessage (handle, (rice.p2p.scribe.Topic) topic, false), parent);
      }
*/

      // if this is the last client and there are no children,
      // then we unsubscribe from the topic
      if (manager.removeClient ((ScribeClient) client)) {

        topics.remove (topic);
        // NodeHandle parent = manager.getParent();

        if (parent != null) {
          endpoint.route (null, new UnsubscribeMessage (handle, (rice.p2p.scribe.Topic) topic), parent);
        }
      }
    } else {
    	logger.warning (endpoint.getId() + ": Attempt to unsubscribe client " + client + " from unknown topic " + topic);
    }
  }


  public void subscribe (dermi.core.Topic topic, dermi.core.Client client) {
    super.subscribe ((rice.p2p.scribe.Topic) topic, (ScribeClient) client);
  }

/*  public boolean isSubscribed (dermi.core.Topic topic) {
    System.out.println ("Checking whether topic " + topic + " is already subscribed...");

    if (topics.get (topic) != null) System.out.println ("SUBSCRIBED"); else System.out.println ("NOT SUBSCRIBED");

    return (topics.get (topic) != null);
  }
*/
  /**
   * Returns the number of members for this topic
   *
   * @param topic The topic to remove the child from
   * @return number of members
   */
/*  public int getMembers (dermi.core.Topic topic) {
    if (topics.get (topic) != null) {
      return ((TopicManager) topics.get (topic)).getMembers();
    }
    return 0;
  }
*/

/*  private void memberMessageReceived (rice.p2p.scribe.Topic topic, boolean join) {
    if (topics.get(topic) != null) {
      TopicManager tman = (TopicManager) topics.get(topic);
      //sendMembershipMessage(source,new MembershipMessage(handle,topic,true));
      if (join) {
        tman.incMembers();
      }
      else tman.decMembers();
    }
  }
*/

  private boolean checkComponentInstance (AnycastMessage aMessage) {
    try {
      DermiContent dc = (DermiContent) aMessage.getContent();
      Hashtable ht = (Hashtable) dc.getData();
      return (ht.get (Context.GET_COMPONENT_INSTANCE) != null);
    } catch (Exception e) {
      return false;
    }
  }
}


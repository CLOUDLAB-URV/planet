/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dolr;

import dermi.*;
import dermi.exception.*;
import dermi.listener.*;


import java.io.*;
import java.util.*;


public class DOLRChannelImpl extends DermiRemoteObject implements DOLRChannel, StatefulReplica {

  String data;

  // Dermi constructor: REQUIRED
  public DOLRChannelImpl() {
  }

  // Dermi constructor: REQUIRED
  public DOLRChannelImpl (Properties env) throws RemoteException {
    super (env);

    // Load replica state
    super.loadReplicaState();

  }

  public void notify (DOLREvent evt) throws RemoteException {
   // Iterator it =listeners.iterator();

    triggerEvent (evt);
   // while(it.hasNext()) {
   //   BasicListener ls = (BasicListener) it.next();
   //     ls.onEvent(evt);
   // }
  }

  public void addListener(BasicListener dl) throws RemoteException {
//    listeners.add(dl);
    super.addListener (DOLREvent.class, dl);
  }

  public void removeListener(BasicListener dl) throws RemoteException {
  //	listeners.remove(dl);
  	super.removeListener (DOLREvent.class, dl);
  }

  /**
   * Method for loading state into this object
   * @param data SpriteValues Object state
   */
  public void loadRemoteObjectState() throws RemoteException {
    data = "";
  }

  /**
   * Method for obtaining this object's state
   * @return SpriteData
   */
  public Serializable getRemoteObjectState() {
    return data;
  }

}

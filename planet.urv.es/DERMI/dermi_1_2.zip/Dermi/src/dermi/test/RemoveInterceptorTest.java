/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import dermi.samples.simple.*;
import dermi.samples.interception.LogInterceptorImpl;
import dermi.registry.*;
import dermi.exception.RemoteException;
import dermi.*;

/**
 * Interception removal testcase
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class RemoveInterceptorTest extends TestCase {
  SimpleImpl server;
  LogInterceptorImpl interceptor;

  public RemoveInterceptorTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[InterceptionRemovalTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try	{
      Properties p = Registry.getEnvironment ("dermi-config.xml");
      server = new SimpleImpl (p);
      server.writeERef ("dermi-config.xml");

      p = Registry.getEnvironment ("dermi-config.xml");
      interceptor = (LogInterceptorImpl) FileRegistry.loadInterceptor (p, "dermi.samples.interception.LogInterceptorImpl");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[InterceptionRemovalTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
      interceptor.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (RemoveInterceptorTest.class);
  }

  public void testRemoveInterceptor() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("dermi-config.xml");
    client.setAge ("30");
    String s = client.getAge();
    assertEquals ("32", s);

    interceptor.removeInterceptor();

    client.setAge ("30");
    s = client.getAge();
    assertEquals ("30", s);

    client.close();
  }
}

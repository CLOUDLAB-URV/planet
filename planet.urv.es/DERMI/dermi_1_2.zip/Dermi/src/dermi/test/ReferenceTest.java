/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.reference.*;

import java.util.*;

/**
 * This is the pass-by-reference testcase
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class ReferenceTest extends TestCase {
  PlaceImpl place;
  UserImpl user1, user2;

  public ReferenceTest (String name) {
    super (name);
  }

  protected void setUp() {
    try {
      System.out.println ("[ReferenceTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
      Properties env = Registry.getEnvironment ("dermi-config.xml");

      place = new PlaceImpl ("chat", env);
      place.writeERef ("dermi-config.xml");
      user1 = new UserImpl ("gojiita", env);
      user2 = new UserImpl ("cpairot", env);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[ReferenceTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      place.close();
      Thread.sleep (1000);
      user1.close();
      Thread.sleep (1000);
      user2.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (ReferenceTest.class);
  }


  public void testReferenceJoin() throws Exception {
    Place thePlace = (Place) FileRegistry.loadERef ("dermi-config.xml");
    thePlace.join (user1);

    Vector list = thePlace.getUsers();
    int size = list.size();

    assertEquals (size, 1);

    thePlace.leave (user1);

    Vector list2 = thePlace.getUsers();
    int size2 = list2.size();

    assertEquals (size2, 0);
    thePlace.close();
  }

  public void testReferenceUsers() throws Exception {
    Place thePlace = (Place) FileRegistry.loadERef ("dermi-config.xml");
    thePlace.join (user1);

    Vector list = thePlace.getUsers();
    int size = list.size();

    assertEquals (size, 1);

    Place thePlace2 = (Place) FileRegistry.loadERef ("dermi-config.xml");
    thePlace2.join (user2);

    Vector list2 = thePlace.getUsers();
    int size2 = list2.size();
    Vector list3 = thePlace2.getUsers();
    int size3 = list3.size();

    assertEquals (size2, 2);
    assertEquals (size3, 2);

    thePlace2.leave (user2);

    Vector list4 = thePlace.getUsers();
    int size4 = list4.size();
    assertEquals (size4, 1);

    thePlace.close();
    thePlace2.close();
  }

  public void testReferenceUser() throws Exception {
    Place thePlace = (Place) FileRegistry.loadERef ("dermi-config.xml");
    thePlace.join (user1);

    Vector list = thePlace.getUsers();
    Iterator it = list.iterator();
    User user = (User) it.next();
    user.init();   // Required here
    String name = user.getName();
    assertEquals (name, "gojiita");

    thePlace.close();
  }
}

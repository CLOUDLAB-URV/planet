/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.messaging.pastry;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;

/**
 * This class wraps a message addressed to a unique application in a node
 * It is sent via a publishDirect() invocation
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class DirectMessage extends ScribeMessage {

  // the content of this message
  protected ScribeContent content;

  /**
   * Constructor
   * @param source NodeHandle Source nodehandle
   * @param topic Topic Group's identifier
   * @param content ScribeContent The message content
   */
  public DirectMessage (NodeHandle source, Topic topic, ScribeContent content) {
    super (source, topic);
    this.content = content;
  }

  /**
   * Returns the content
   * @return The content
   */
  public ScribeContent getContent() {
    return content;
  }

  public String toString() {
    return "DirectMessage" + topic + ":" + content;
  }

}

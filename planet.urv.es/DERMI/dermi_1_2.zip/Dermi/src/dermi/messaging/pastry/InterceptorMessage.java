/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.messaging.pastry;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;
import java.util.*;

/**
 * This class wraps an interceptor message. Used by the
 * distributed interception facility
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class InterceptorMessage extends ScribeMessage {

  // The content of this message
  protected ScribeContent content;

  // Root's handle
  protected NodeHandle rootHandle;

  // Remaining interceptors yet to be traversed
  protected ArrayList interceptors;

  // Is interception process finished?
  protected boolean interceptionProcessFinished = false;

  /**
   * Constructor
   * @param rootHandle NodeHandle Root's node handle
   * @param source NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param content ScribeContent The content of the message
   * @param interceptors ArrayList Remaining interceptors to be traversed
   */
  public InterceptorMessage (NodeHandle rootHandle, NodeHandle source, Topic topic, ScribeContent content, ArrayList interceptors) {
    super (source, topic);

    this.content = content;
    this.rootHandle = rootHandle;
    this.interceptors = interceptors;
  }

  /**
   *
   * Constructor
   * @param rootHandle NodeHandle Root's node handle
   * @param source NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param content ScribeContent The content of the message
   * @param interceptors ArrayList Remaining interceptors to be traversed
   * @param isFinished boolean Is interception finished?
   */
  public InterceptorMessage (NodeHandle rootHandle, NodeHandle source, Topic topic, ScribeContent content, ArrayList interceptors, boolean isFinished) {
    super (source, topic);

    this.content = content;
    this.rootHandle = rootHandle;
    this.interceptors = interceptors;
    this.interceptionProcessFinished = isFinished;
  }

  /**
   * Returns the content
   * @return The content
   */
  public ScribeContent getContent() {
    return content;
  }

  /**
   * Returns the remaining interceptors
   * @return ArrayList
   */
  public ArrayList getInterceptors() {
    return interceptors;
  }

  /**
   * Returns whether the interception process is finished
   * @return boolean true if it is finished
   */
  public boolean isInterceptionFinished() {
    return interceptionProcessFinished;
  }

  public String toString() {
    return "InterceptorMessage " + topic + ":" + content + " " + interceptors;
  }
}

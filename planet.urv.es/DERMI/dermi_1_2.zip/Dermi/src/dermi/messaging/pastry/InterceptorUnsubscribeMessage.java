/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.messaging.pastry;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;

/**
 * Message used when willing to unsubscribe an interceptor application from an object group
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class InterceptorUnsubscribeMessage extends ScribeMessage {
  // the interceptor identifier
  protected String intId;

  /**
   * Constructor
   * @param source NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  public InterceptorUnsubscribeMessage (NodeHandle source, Topic topic, String intId) {
  super (source, topic);
    this.intId = intId;
  }

  /**
   * Returns the interceptor's identifier
   * @return String Interceptor's identifier
   */
  public String getInterceptorId() {
    return intId;
  }

  public String toString() {
    return "InterceptorUnsubscribeMessage" + topic + ":" + intId;
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.listener;

import dermi.exception.RemoteException;

import java.util.Hashtable;
import java.util.ArrayList;

/**
 * Interface for subscribing to interception events
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar
 * @version 1.2
 */
public interface RemoteInterceptorListener {

  /**
   * This method is the standard callback provided for distributed interception events.
   * @param evt Hashtable Event data
   * @param interceptors ArrayList interceptors yet to be traversed
   * @throws RemoteException If the method to be intercepted is not recognized
   */
  public void interceptorEventArrived (Hashtable evt, ArrayList interceptors) throws RemoteException;
}

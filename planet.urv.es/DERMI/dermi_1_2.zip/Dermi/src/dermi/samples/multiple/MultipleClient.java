/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.multiple;

import dermi.*;
import dermi.exception.*;
import dermi.registry.*;


/**
 * This class encapsulates a client willing to access the Simple object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class MultipleClient {

  public static void main (String[] args) throws RemoteException {

    Simple client = null;
    Other client2 = null;
    try {

      ERemote ref = FileRegistry.loadERef ("dermi-config.xml");
      client = (Simple) ref;
      client2 = (Other) ref;

    } catch (RemoteException ex) {
      ex.printStackTrace();
      System.err.println ("ERROR: Impossible to load object reference.");
      System.exit (-1);
    }

    try {

      client2.setName("Dermi");
      client.setAge ("30");

      String s = client.getAge();
      System.out.println ("age :"+s);
      String n = client2.getName();
      System.out.println ("name : "+n);
      client.setAge ("99");
      String res = client.merge (new Integer (3), "543", new Integer (33));
      System.out.println ("merge : "+res);
    } catch (RemoteException re) {
      re.printStackTrace();
    }
    client.close();
    System.exit(0);
  }
}

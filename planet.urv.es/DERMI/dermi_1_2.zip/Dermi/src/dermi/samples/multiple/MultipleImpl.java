/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.multiple;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * Implementation of object's methods
 * Note that this implementation does not care about remote state propagation
 * This will be taken into account by the object's skeleton
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class MultipleImpl extends DermiRemoteObject implements Simple, Other {

  String age = "12";
  String name = "Dr. Zoiberg";

  // Dermi constructor: REQUIRED
  public MultipleImpl() {
  }

  // Dermi constructor: REQUIRED
  public MultipleImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Multiple] object created.");
  }

  public void setAge (String age) throws RemoteException {
    System.out.println ("[setAge] called.");
    this.age = age;
  }

  public String getAge() throws RemoteException {
    System.out.println ("[getAge] called.");
    return age;
  }

  public void setName (String name) throws RemoteException {
    System.out.println ("[setName] called.");
    this.name = name;
  }

  public String getName() throws RemoteException {
    System.out.println ("[getName] called.");
    return name;
  }

  public String merge (Integer x, String y, Integer z) throws RemoteException {
    System.out.println ("[merge] called.");
    return age + " + " + y + " + " + x + " + " + z;
  }
}

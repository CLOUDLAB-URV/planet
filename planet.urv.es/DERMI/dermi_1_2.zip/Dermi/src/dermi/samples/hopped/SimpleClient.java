/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.hopped;

import dermi.*;
import dermi.exception.*;
import dermi.registry.*;

/**
 * This class encapsulates a client willing to access the Simple object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class SimpleClient /* implements javax.management.NotificationListener */ {
/*  public void handleNotification(javax.management.Notification notification, Object handback)  {
        String notifType = notification.getType();
        if (notifType.equals(java.lang.management.MemoryNotificationInfo.MEMORY_THRESHOLD_EXCEEDED)) {
            // potential low memory, notify another thread
            // to redistribute outstanding tasks to other VMs
            // and stop receiving new tasks.
            System.out.println ("LO MEM");
        }
    }
*/

  public static void main (String[] args) throws RemoteException {

// CHECK!

      // Register MyListener with MemoryMXBean
/*      java.lang.management.MemoryMXBean mbean = java.lang.management.ManagementFactory.getMemoryMXBean();
      javax.management.NotificationEmitter emitter = (javax.management.NotificationEmitter) mbean;
      SimpleClient tut = new SimpleClient();
      emitter.addNotificationListener(tut, null, null);
System.out.println ("MEM HEAP USED = " + mbean.getHeapMemoryUsage().getUsed());
System.out.println ("MEM NON-HEAP USED = " + mbean.getNonHeapMemoryUsage().getUsed());


    java.util.List<java.lang.management.MemoryPoolMXBean> pools = java.lang.management.ManagementFactory.getMemoryPoolMXBeans();
    for (java.lang.management.MemoryPoolMXBean p : pools) {
      System.out.println("Memory type="+p.getType()+" Memory usage="+p.getUsage());
    }

    java.util.ArrayList a = new java.util.ArrayList();
    for(;;) {
      a.add (new Integer (100000));
      if (mbean.getHeapMemoryUsage().getUsed() > 156100000) {
        System.out.println ("MEM HEAP USED = " + mbean.getHeapMemoryUsage().getUsed());
        System.out.println ("MEM HEAP MAX = " + mbean.getHeapMemoryUsage().getMax());
      }
    }
*/

    Simple client = null;
    // Load the registry first
    Registry.loadRegistry ("registry-config.xml");

    // Look up an object in the registry
    try {
      client = (Simple) Registry.lookup ("p2p://hopped.deim.etse.urv.es");
    } catch (RemoteException ex) {
      ex.printStackTrace();
      System.err.println ("ERROR: Impossible to load object reference.");
      System.exit (-1);
    }

    try {
      client.setAge ("30");
      String s = client.getAge();
      System.out.println (s);
      client.setAge ("99");
      String res = client.merge (new Integer (3), "543", new Integer (33));
      System.out.println (res);
    } catch (RemoteException re) {
      re.printStackTrace();
    }
    client.close();
    System.exit(0);
  }
}

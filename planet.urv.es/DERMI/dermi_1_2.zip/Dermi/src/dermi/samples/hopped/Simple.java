/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.hopped;

import dermi.*;
import dermi.exception.*;
import dermi.annotation.*;

/**
 * Interface to object's methods
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */

// This tag specifies that this object will automatically be replicated among the neighbour nodes
// This remains in stark contrast with the implementation of the StatefulReplica interface,
// where the user can instantiate objects in wherever nodes it desires, and all of them will
// maintain a replicated state.
//
// In this case, the original object is instantiated, and spread through the neighbour nodes.
// Subsequent setter methods will automatically be transformed into MULTICALLs (so as all of
// the replicas are aware of such state change), and getter methods will use the HOPPED CALL
// algorithm.
@HoppedFaultTolerant (replicas = 2)
@DermiRemoteInterface
public interface Simple extends ERemote {
  @RemoteMethod (granularity = Granularity.HOPPEDCALL, type = SynchronyType.SYNCHRONOUS)
  public void setAge (String age) throws RemoteException;

  @RemoteMethod (granularity = Granularity.HOPPEDCALL, type = SynchronyType.SYNCHRONOUS)
  public String getAge() throws RemoteException;

  @RemoteMethod (granularity = Granularity.HOPPEDCALL, type = SynchronyType.SYNCHRONOUS)
  public String merge (Integer x, String y, Integer z) throws RemoteException;
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.inheritance;

import dermi.*;

/**
 * This class demonstrates the inheritance and polymorphic properties of Dermi.
 * The object's behaviour is the same as in classic local object inheritance in Java.
 * Several animals are looked up (we must have previously started an instance of the
 * AnimalServer class), and their talk() method is invoked.
 * Note that the talk() method called is the right one.
 *
 * Finally, a polymorphic assignment is done, and when we make the animal talk,
 * the invoked method is the one belonging to the dynamic type.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class AnimalClient {
  public static void main (String[] args) throws Exception {
    // Load the registry first
    Registry.loadRegistry ("dermi-config.xml");

    Animal animal = (Animal) Registry.lookup ("p2p://animal.deim.etse.urv.es");
    Dog d = (Dog) Registry.lookup ("p2p://milu.deim.etse.urv.es");
    Cat g = (Cat) Registry.lookup ("p2p://felix.deim.etse.urv.es");
    Parrot l = (Parrot) Registry.lookup ("p2p://couille.deim.etse.urv.es");
    MutantParrot lM = (MutantParrot) Registry.lookup ("p2p://coui_couille.deim.etse.urv.es");

    // Execute the talk() method on each of the animals
    System.out.println ("\nLet the animals talk...");
    System.out.println ("----------------------------------------------------------");

    System.out.println ("Animal talks: " + animal.talk());
    System.out.println ("Dog talks: " + d.talk());
    System.out.println ("Cat talks: " + g.talk());
    System.out.println ("Parrot talks: " + l.talk());
    System.out.println ("Mutant parrot talks: " + lM.talk());

    System.out.println ("\nPolymorphism demo: Assign a Cat to an Animal");
    System.out.println ("----------------------------------------------------------");

    // Assignment polymorphism: the animal is now a dog
    animal = g;
    System.out.println ("Let the animal talk now: " + animal.talk());

    System.out.println ("\nPolymorphism demo: Assign a Mutant Parrot to an Animal");
    System.out.println ("----------------------------------------------------------");

    // Assignment polymorphism: the animal is now a mutant parrot
    animal = lM;
    System.out.println ("Let the animal talk now: " + animal.talk() + "\n");

    animal.close();
    d.close();
    g.close();
    l.close();
    lM.close();
    System.exit(0);
  }
}

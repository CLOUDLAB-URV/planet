/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.inheritance;

import dermi.*;

/**
 * This class demonstrates the inheritance and polymorphic properties of Dermi.
 * The object's behaviour is the same as in classic local object inheritance in Java.
 * Several animals are looked up (we must have previously started an instance of the
 * AnimalServer class), and stored into an array. Their talk() method is invoked right away.
 * Note that the talk() method called is the right one depending on the object's dynamic type.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class AnimalFarm {
  public static void main (String[] args) throws Exception {
    // Load the registry first
    Registry.loadRegistry ("dermi-config.xml");

    // Look up all animals
    Animal animal = (Animal) Registry.lookup ("p2p://animal.deim.etse.urv.es");
    Dog d = (Dog) Registry.lookup ("p2p://milu.deim.etse.urv.es");
    Cat g = (Cat) Registry.lookup ("p2p://felix.deim.etse.urv.es");
    Parrot l = (Parrot) Registry.lookup ("p2p://couille.deim.etse.urv.es");
    MutantParrot lM = (MutantParrot) Registry.lookup ("p2p://coui_couille.deim.etse.urv.es");

    System.out.println ("\nLet's store all animals in an Animal array and let'em talk...");
    System.out.println ("--------------------------------------------------------------------------");

    // Store all animals into an Animal array
    Animal farm[] = new Animal[5];
    farm[0] = animal; farm[1] = d; farm[2] = g; farm[3] = l; farm[4] = lM;

    // Invoke the talk() method on each of them
    for (Animal a : farm) {
      System.out.println ("I am a " + a + " and I am talking: " + a.talk());
    }

    System.out.println ("\nLet's store all animals in a Truck and let'em talk...");
    System.out.println ("--------------------------------------------------------------------------");

    // Store all animals into an Object array
    Object truck[] = new Object[5];
    truck[0] = animal; truck[1] = d; truck[2] = g; truck[3] = l; truck[4] = lM;

    // Invoke the talk() method on each of them
    for (Object o : truck) {
      System.out.println ("I am a " + o + " and I am talking: " + ((Animal) o).talk());
    }

    System.out.println ("\n");

    // Close all stub objects
    for (Animal a : farm) {
      a.close();
    }

    System.exit(0);
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.inheritance;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * The MutantParrot implementation: note that it extends ParrotImpl and implements the MutantParrot interface
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class MutantParrotImpl extends ParrotImpl implements MutantParrot {
    // Dermi constructor: REQUIRED
    public MutantParrotImpl() {
      super();
    }

    // Dermi constructor: REQUIRED
    public MutantParrotImpl (String name, int legs, int eyes, Properties env) throws RemoteException {
      super (name, legs, eyes, env);
      System.out.println ("[MutantParrot - " + name + "] created.");
    }

    public String talk() throws RemoteException {
      System.out.println ("MutantParrot - " + name + " talking...: cabron cabron bleaghhh.");
      return "cabron cabron bleaghhh";
    }

    public void fly() throws RemoteException {
      System.out.println ("MutantParrot - " + name + " flying... and falling!");
    }
}

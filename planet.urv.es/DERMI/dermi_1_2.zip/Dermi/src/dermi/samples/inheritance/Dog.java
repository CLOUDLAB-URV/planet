/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.inheritance;

import dermi.*;
import dermi.exception.*;
import dermi.annotation.*;

/**
 * The Dog interface, extends the Animal remote interface
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DermiRemoteInterface
public interface Dog extends Animal {
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public String talk() throws RemoteException;

  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public void sniff() throws RemoteException;
}

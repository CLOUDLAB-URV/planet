/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.inheritance;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * The Animal implementation: note that it extends DermiRemoteObject and implements the Animal interface
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class AnimalImpl extends DermiRemoteObject implements Animal {

  protected String name = "";
  private int legs = 0;
  private int eyes = 0;

  // Dermi constructor: REQUIRED
  public AnimalImpl() {
  }

  // Dermi constructor: REQUIRED
  public AnimalImpl (String name, int legs, int eyes, Properties env) throws RemoteException {
    super (env);
    this.name = name;
    this.legs = legs;
    this.eyes = eyes;
//    System.out.println ("[Animal - " + name + "] created.");
  }

  public String talk() throws RemoteException {
    System.out.println ("Animal - " + name + " talking...: brbrbrbrbrrrr");
    return "blah";
  }

  public void walk() throws RemoteException {
    System.out.println ("Animal - " + name + " walking...");
  }

  public void setLegs (int legs) throws RemoteException {
    this.legs = legs;
  }

  public int getLegs() throws RemoteException {
    return legs;
  }

  public void setEyes (int eyes) throws RemoteException {
    this.eyes = eyes;
  }

  public int getEyes() throws RemoteException {
    return eyes;
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.anycall;

import dermi.*;
import dermi.exception.*;
import dermi.annotation.*;

/**
 * This is the interface for the Seti anycall demo object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DermiRemoteInterface
public interface Seti extends ERemote {

  // Method signature for the anycall method pair must be the same, except for the return result,
  // which needs to be boolean for the condition method

  /**
   * This method returns a data unit from one of the client's nearest server
   * @param System String Example parameter
   * @throws RemoteException If something goes wrong ;-)
   * @return String Data unit returned
   */
  @RemoteMethod (granularity = Granularity.ANYCALL)
  public String getDataUnit (String System) throws RemoteException;

  /**
   * This method is automatically called by the skeleton to check whether the condition
   * can be satisfied for each server
   * @param System String Example parameter
   * @throws RemoteException If something goes wrong ;-)
   * @return boolean true if condition satisfied (the server has available data units)
   */
  @RemoteMethod (granularity = Granularity.ANYCALL_CONDITION)
  public boolean getDataUnitCondition (String System) throws RemoteException;
}

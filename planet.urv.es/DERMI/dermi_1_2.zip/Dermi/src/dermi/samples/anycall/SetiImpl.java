/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.anycall;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * This class contains the implementation of the set of Seti servers
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class SetiImpl extends DermiRemoteObject implements Seti {
  public int unitsRemaining = 5;

  // Dermi constructor: REQUIRED
  public SetiImpl() {
  }

  // Dermi constructor: REQUIRED
  public SetiImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Seti] object created.");
  }

  public String getDataUnit (String sys) {
    System.out.println ("[getDataUnit] called.");
    unitsRemaining--;
    if (sys.equals ("United Devices")) {
      return "63666737873_UD";
    }
    else {
      return "46672872982_SaH";
    }
  }

  public boolean getDataUnitCondition (String sys) {
    if (unitsRemaining > 0) {
      return true;
    }
    return false;
  }
}

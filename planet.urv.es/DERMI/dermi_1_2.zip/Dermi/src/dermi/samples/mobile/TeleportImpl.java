/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.mobile;

import dermi.*;
import dermi.exception.*;
import dermi.samples.simple.*;

import java.io.Serializable;
import java.util.Properties;

/**
 * This class contains a trivial implementation for the Teleport object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class TeleportImpl extends DermiRemoteObject implements Teleport {
  // Dermi constructor: REQUIRED
  public TeleportImpl() {
  }

  // Dermi constructor: REQUIRED
  public TeleportImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Teleport] object created.");
  }

  public void send (Serializable ref) throws RemoteException {
    System.out.println ("[send] called.");
    ERemote server = (ERemote) ref;
    server.init();
  }
}

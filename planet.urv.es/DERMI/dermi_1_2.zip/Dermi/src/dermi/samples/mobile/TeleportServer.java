/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.mobile;

import dermi.*;
import dermi.registry.*;

import java.util.Properties;

/**
 * This class implements the Teleport server
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class TeleportServer {
  public static void main (String[] args) {
    try	{
      Properties env = Registry.getEnvironment ("dermi-config.xml");

      TeleportImpl server = new TeleportImpl (env);

      // If you want to use the File registry, uncomment the next line and comment
      // the next
      server.writeERef ("teleport-config.xml");

      Registry.bind ("p2p://teleport", server);

      System.in.read();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

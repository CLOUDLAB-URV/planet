/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.naming;

import dermi.*;
import dermi.registry.*;
import dermi.samples.simple.*;

import java.util.*;
import java.io.*;

/**
 * This class encapsulates the Simpleconn.getNaming() server object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class SimpleNamingServer {
  public static void main (String[] args) {
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      SimpleImpl server = new SimpleImpl (env);

      // Bind the same object into different names
      Registry.bind ("p2p://simple1", server);
      Registry.bind ("p2p://simple2", server);
      Registry.bind ("p2p://simple3", server);
      Registry.bind ("p2p://simple4", server);
      Registry.bind ("p2p://simple1/simpler1", server);
      Registry.bind ("p2p://simple1/simpler1/thesimplest", server);

      System.in.read();
      System.exit(0);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.manycall;

import dermi.*;
import dermi.registry.*;
import dermi.exception.*;

import java.io.*;

/**
 * This class implements a simple Voting client
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class VotingClient {
  public static void main(String[] args) throws Exception {
    // If you want to use the File registry, uncomment the next line and comment
    // the next two
    Voting client = (Voting) FileRegistry.loadERef ("dermi-config.xml");

    // Load the registry first
    // Registry.loadRegistry ("registry-config.xml");

    // Voting client = (Voting) Registry.lookup ("p2p://voting");

    BufferedReader dis = new BufferedReader (new InputStreamReader (System.in));
    String input = "";
    System.out.println ("Client loaded. Enter 'quit' to exit it, or <RETURN> to start ballot...");
    while (!(input = dis.readLine()).equals ("quit")) {
      if (input.equals("")) {
        System.out.println ("Initiating ballot... We need at least 20 positive votes.");
        try {
          Integer s = client.vote (new Integer (0), new Integer (20), "Party time!");
          System.out.println ("Ballot result positive. Obtained " + s + " votes.");
        } catch (NotSatisfiedException ne) {
          System.out.println ("Ballot result negative.");
        }
      }
    }
    client.close();
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.manycall;

import java.util.*;

import dermi.*;
import dermi.exception.RemoteException;

/**
 * This is the implementation of the Voting object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class VotingImpl extends DermiRemoteObject implements Voting {
  // Dermi constructor: REQUIRED
  public VotingImpl() {
  }

  // Dermi constructor: REQUIRED
  public VotingImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Voting] object created.");
  }

  public Integer vote (Integer currentVotes, Integer maxVotes, String party) {
    System.out.println ("[vote] called.");
    int votes = currentVotes.intValue();
    return new Integer (votes += 15);
  }

  public boolean voteCondition (Integer currentVotes, Integer maxVotes, String party) {
    if (party.equals ("Party time!"))
      return true;
    return false;
  }

  public boolean voteGlobalCondition (Integer currentVotes, Integer maxVotes, String party) {
    if (currentVotes.intValue() >= maxVotes.intValue()) {
      return true;
    }
    return false;
  }
}

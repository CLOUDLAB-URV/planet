/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import bunshin.util.*;
import dermi.util.*;
import dermi.exception.*;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * This class provides Decentralized Registry's static and generic methods
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class Registry {
  private static dermi.registry.Naming naming;

  /**
   * Returns the object's environment properties
   *
   * @param filename String Object properties filename
   * @throws RemoteException If something goes wrong ;-)
   * @return Properties Object properties
   */
  public static Properties getEnvironment (String filename) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (filename);
      Properties p = new Properties();
      p.loadFromXML (fis);

      return p;
    } catch (Exception e) {
      throw new RemoteException ("Impossible to get object properties.");
    }
  }

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void loadRegistry (String ref) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (ref);
      Properties env = new Properties();
      env.loadFromXML (fis);
      String hostName = env.getProperty (Context.PROVIDER_HOST);
      int port = (new Integer (env.getProperty (Context.PROVIDER_PORT))).intValue();

      Class[] cl = {};
      Object[] objs = {};
      String className = "dermi.registry." + env.getProperty (Context.UNDERLYING_DHT) + ".Naming";
      Class cls = Class.forName (className);
      Method meth = cls.getMethod ("getInstance", cl);
      naming = (dermi.registry.Naming) meth.invoke (null, objs);
      naming.loadRegistry (ref);
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e.getMessage ());
    }
  }

   /**
   * It closes the connection and kills the node
   * @throws RemoteException If the disconnection with the event service fails.
   */
  public static void leave() throws RemoteException {
    naming.leave();
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name) throws RemoteException {
    return naming.lookup (name);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name, String communityId, String className) throws RemoteException {
    return naming.lookup (name, communityId, className);
  }

  /**
   * Returns a serialized object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (dermi.core.Id id) throws RemoteException {
    return naming.lookupSer (id);
  }

  /**
   * Returns a serialized object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (String url) throws RemoteException {
    return naming.lookupSer (url);
  }

  /**
   * Method used to know if the registry is already connected to a node
   * @return boolean true if it is connected
   */
  public static boolean isConnected () {
    if (naming == null) {
      return false;
    }
    else {
      return naming.isConnected ();
    }
  }

  /**
   * Method used to get the connection to the node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public static dermi.core.DermiConnection getConnection() {
    return naming.getConnection();
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, ERemote ref) throws RemoteException {
    naming.bind (name, ref);
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, Properties env) throws RemoteException {
    naming.bind (name, env);
  }

  /**
   * Unbinds the specified name from a remote object.
   * @param name Id of the remote object
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void unbind (String name) throws RemoteException {
    naming.unbind (name);
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bindRoot() throws RemoteException {
    naming.bindRoot();
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void rebind (String name, ERemote ref) throws RemoteException {
    naming.rebind (name, ref);
  }

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public static Collection list (String root) throws RemoteException {
    return naming.list (root);
  }

  public static void setInstance (dermi.registry.Naming reg) {
    naming = reg;
  }

  public static void bindSer (dermi.core.Id id, Serializable object) throws RemoteException {
    naming.bindSer (id, object);
  }

  /* DERMI SEARCH METHODS */

  public static void insert(String keywords, String key, Serializable value)  throws RemoteException {
    naming.insert (keywords, key, value);
  }

  public static ResultSortedQueue query(String keywords)  throws RemoteException {
    return naming.query (keywords);
  }

  public static void remove(String keywords, String key) throws RemoteException {
    naming.remove (keywords, key);
  }
}

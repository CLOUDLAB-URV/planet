/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.util;

import java.io.*;
import org.doomdark.uuid.*;

/**
 * Utility class for unique ID generation
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class UID {
  public static String getUID() {
    UUIDGenerator gen = UUIDGenerator.getInstance();
    UUID id = gen.generateRandomBasedUUID();
    return id.toString();
  }

  public static void writeUID (String fileName, String uid) {
    try	{
      FileOutputStream fos = new FileOutputStream (fileName);
      PrintStream pos = new PrintStream (fos);
      pos.println (uid);
      pos.close();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public static String readUID() {
    try {
      BufferedReader pos = new BufferedReader (new InputStreamReader (System.in));
      String res =  pos.readLine();
      pos.close();
      return res;
    } catch (IOException ex) {
      ex.printStackTrace();
    }
    return "";
  }
}

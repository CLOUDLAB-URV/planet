package dermi.util;

import java.util.*;

/**
 * @(#) PriorityList.java
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 * @author Carles Pairot <carles.pairot@urv.net> -- Java 5 Generics translation
 */

public class PriorityList<E> {
  private ArrayList<E> list = new ArrayList<E>();
  private ArrayList priorities = new ArrayList();

  //max properties
  private int indexMax = 0;
  private int max = 0;

  public void insert (E elem, int priority) {
    list.add(elem);
    int index = list.indexOf (elem);
    priorities.add (index, new Integer(priority));

    if (priority>max) {
      indexMax = index;
      max = priority;
    }
  }

  public void update (E elem) {
    int index = list.indexOf(elem);
    int priority = 0;
    if (index<0) {
      list.add(elem);
      index = list.indexOf(elem);
      priorities.add (index, new Integer (priority));
    }
    else {
      priority = ((Integer) priorities.get (index)).intValue () + 1;
      priorities.set (index, new Integer (priority));
    }

    if (priority>max) {
      indexMax = index;
      max = priority;
    }
  }

  public E peak() {
    return list.get (indexMax);
  }

  public void clear() {
    indexMax = 0;
    max = 0;

    priorities.clear();
    list.clear();
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.*;
import dermi.util.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.annotation.*;
import dermi.dcm.Component;
import dermi.core.NodeHandle;
import dermi.registry.FileRegistry;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.lang.annotation.*;
import java.util.logging.*;
import dermi.dcm.ActivationException;

/**
 * This class implements the generic skeleton class for any Dermi object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public abstract class DermiRemoteObject extends EventServer implements RemoteEventListener {
  private Hashtable subs = new Hashtable();
  private transient Hashtable receivedEvents = new Hashtable();
  private boolean exception = false;

  // This attribute marks if this is a replicated object
  private boolean isStatefulReplica = false;

  // This attribute marks the replica's state as up to date or not
  private boolean isReplicaReady = false;

  // Primitive types and their wrappers
  private String[] basicTypes = {"int", "char", "double", "float", "long", "boolean", "byte", "short"};
  private String[] wrappers = {"java.lang.Integer", "java.lang.Character", "java.lang.Double", "java.lang.Float", "java.lang.Long", "java.lang.Boolean", "java.lang.Byte", "java.lang.Short"};

  protected transient Logger logger = Logger.getLogger (this.getClass().getName());

  /**
   * Local constructor: Entry point to the skeleton class
   */
  public DermiRemoteObject() { }

  /**
   * Constructor: Entry point to the skeleton class
   * @param env Properties Environment properties
   * @throws RemoteException When something goes wrong ;-)
   */
  public DermiRemoteObject (Properties env) throws RemoteException {
    super (env);
    className = this.getClass().getName();
    uid = dermi.util.UID.getUID();

    // If this is a replica, the UID will come from the environment properties
    if (env.getProperty (Context.CLASS_NAME).equals (className)) {

      if (env.getProperty (Context.CLASS_ID) != null) {
        uid = env.getProperty (Context.CLASS_ID);
      }
    }
    subs.put (Context.OBJECTID, uid);

    try {
      conn.subscribe (this, subs);

      // storeNodeHandle();
    } catch (Exception e) {
      throw new ConnectionException (e.getMessage());
    }

    // Add current NodeHandle and NodeId properties to this remote object
    eref.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());

    // If this is a HoppedFaultTolerant object, we must automatically activate and
    // replicate it among the neighbours
    Class[] interfaces = this.getClass().getInterfaces();

    for (Class interf : interfaces) {
      HoppedFaultTolerant annot = (HoppedFaultTolerant) interf.getAnnotation (HoppedFaultTolerant.class);
      if (annot != null) {
        System.out.println ("Hopped fault tolerant object: Creating " + annot.replicas() + " transparent object replicas.");
        // Activate object in the number of neighbours specified in the HoppedFaultTolerant annotation
        // Wait for node joining to be complete
        try {
          Thread.sleep (2000);
        }
        catch (InterruptedException ex) {
        }
        Collection c = conn.getReplicaSet (conn.getLocalNodeId(), annot.replicas() + 1);

        if (c.size() < annot.replicas() + 1) {
          throw new RemoteException ("Unable to activate new object: unable to find enough nodes to replicate in!");
        }

        try {
            // Activate this object and its K neighbours as well
            // Append the NodeId + uid to store it in this node
            Registry.bindSer (conn.getLocalNodeId(), this);

// CAUTION: Now only ONE object per NODE can be bound -> (INSERTION PER NODEID HAS BEEN FORCED) !!! To permit more of them,
// we need to insert NON-EXCLUSIVELY (so as not to overwrite previous objects on that node). Change registry functions!

//                localActivator.activate (nh, this);
              } catch (RemoteException e) {
                e.printStackTrace();
                throw new RemoteException ("Unable to activate new object: activation exception!");
              }
//            }
//            else {
//              throw new RemoteException ("Unable to activate new object: all surrounding nodes have already an active object");
//            }
  //        }
//        }
      }
    }

    // Add this object as currently active on this node
    if (conn != null) {
      conn.addActiveObject (uid, (ERemote) this);
    }
  }

  /**
   * This method starts load replica state mechanism
   * @throws RemoteException If replica state cannot be loaded
   */
  protected void loadReplicaState() throws RemoteException {
    // Check whether this object is to be replicated (statefully)
    Class[] interfaces = this.getClass().getInterfaces();
    for (int i = 0; i < interfaces.length; i++) {
      if ((interfaces[i].getName()).contains ("StatefulReplica")) {
        isStatefulReplica = true;
        // Get state from any of the replicas (if none, default value)
        getReplicaState();
      }
    }
  }

  /**
   * Stores server's NodeHandle on disk (used by the FileRegistry)
   * @throws RemoteException
   */
/*  private void storeNodeHandle() throws RemoteException {
    try {
      FileOutputStream fos = new FileOutputStream ("nodehandle.data");
      ObjectOutputStream bo = new ObjectOutputStream (fos);
      logger.fine ("Server NodeHandle = " + conn.getLocalNodeHandle());
      bo.writeObject (conn.getLocalNodeHandle());
    }
    catch (Exception e) {
    	e.printStackTrace();
      throw new RemoteException ("Impossible to store node handle in the File Registry.");
    }
  }
*/

  /**
   * Method for obtaining the object's state from any of the available replicas
   */
  public void getReplicaState() throws RemoteException {
    // Wait a certain time for joining to be complete
    try {
      Thread.sleep (1000);
    } catch (Exception e) {}
    // If replica, we must update our status
    try {
      Method m = this.getClass().getMethod ("loadRemoteObjectState");
      m.invoke (this, (Object[]) null);
    } catch (Exception e) {
      if (e instanceof InvocationTargetException)
       if (((InvocationTargetException) e).getTargetException() instanceof NotSatisfiedException) {
        // Unable to load replica state: assume it is the first replica
        isReplicaReady = true;
      }
      else {
        e.printStackTrace();
        throw new RemoteException (e.getMessage ());
      }
    }
  }

  /**
   * Method invoked each time the skeleton receives an event
   * @param evt Hashtable Information about the received event
   */
  public synchronized void eventArrived (Hashtable evt) {
    String method = (String) evt.get (Context.METHOD);

    // Account for another invocation if this object is a component
    if (this instanceof dermi.dcm.Component) {
      if (((Component) this).getLifeCycleManager() != null) {
        if (!method.equals ("getBytes") && !method.equals ("getRemoteObjectState")) {
          ((Component) this).getLifeCycleManager ().incInvocationNum ();
        }
      }
    }

    // Dynamic class loading method
    if (method.equals ("getBytes")) {
      try {
      String fileClass = classStore + className;
      byte data[] = getBytes (fileClass);
      Hashtable msg = new Hashtable();
      msg.put (Context.OBJ, uid + Context.APPEND_RESULT_DYNAMIC);
      msg.put (Context.TYPE, Context.DISPATCH);
      msg.put (Context.METHOD, "getBytes");
      msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
      dispatchEvent (msg, data);
    }
    catch (IOException ex1) {
      Hashtable msg = new Hashtable();
      msg.put (Context.OBJ, uid + Context.APPEND_RESULT_DYNAMIC);
      msg.put (Context.TYPE, Context.EXCEPTION);
      msg.put (Context.METHOD, "getBytes");
      msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
      try {
        dispatchEvent (msg, ex1);
      }
      catch (RemoteException e2) {
        e2.printStackTrace ();
      }
    }
    catch (RemoteException ex2) {
      ex2.printStackTrace ();
    }
  }
    else {
      try {
        if (!isStatefulReplica || method.equals ("getRemoteObjectState") || (isStatefulReplica && isReplicaReady)) {
          if (method.equals ("getRemoteObjectState")) {
            receivedEvents.put ("loadState" + evt.get (Context.TIMESTAMP), evt.get (Context.OBJECTCONTENT));
            if (((String) evt.get (Context.TYPE)).equals (Context.EXCEPTION)) {
              exception = true;
            }
            return;
          }

          Vector args = (Vector) evt.get (Context.OBJECTCONTENT);

          if (args == null) {
            args = new Vector ();
          }
          Method m = loadMethod (method, args);

          Object[] objs = new Object[args.size ()];

          // Load object arguments array
          for (int i = 0; i < args.size (); i++) {
            objs[i] = args.elementAt (i);
          }

          // Check whether this method returns any value
          boolean hasReturnValue = (m.getReturnType () != void.class);
          Object res = null;

          if (hasReturnValue) {
            if (receivedEvents.get (method + evt.get (Context.TIMESTAMP)) != null) {
              res = receivedEvents.get (method + evt.get (Context.TIMESTAMP));
            }
            else {
              // Method is invoked
              res = m.invoke (this, objs);
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), res);
            }
          }
          else {
            if (receivedEvents.get (method + evt.get (Context.TIMESTAMP)) == null) {
              m.invoke (this, objs);
              receivedEvents.put (method + (evt.get (Context.TIMESTAMP)), new Integer ( -1));
            }
          }

          Hashtable msg = new Hashtable ();
          msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
          msg.put (Context.TYPE, Context.DISPATCH);
          msg.put (Context.METHOD, method);
          msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
          if (hasReturnValue) {
            msg.put (Context.OBJECTCONTENT, res);
          }
          try {
            // Event is dispatched using the event service (response is sent to MANY objects)
            if (evt.get (Context.SOURCE_NODEHANDLE) == null) {
              dispatchEvent (msg);
            }
            else {
              // Event is dispatched routing a direct message to stub source (response is sent to ONE object)
              msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              dispatchDirectEvent (msg);
            }
          }
          catch (RemoteException e2) {
            e2.printStackTrace ();
          }
        }
      } catch (Exception eex) {
        Exception ex = null;
        if (eex instanceof InvocationTargetException) {
          ex = (Exception) ((InvocationTargetException) eex).getTargetException ();
        }
        else {
          ex = eex;
        }
        Hashtable msg = new Hashtable ();
        msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
        msg.put (Context.TYPE, Context.EXCEPTION);
        msg.put (Context.METHOD, method);
        msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
        receivedEvents.put (method + evt.get (Context.TIMESTAMP), ex);
        try {
          // Event is dispatched using the event service (response is sent to MANY objects)
          if (evt.get (Context.SOURCE_NODEHANDLE) == null) {
            dispatchEvent (msg, ex);
          }
          else {
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            // Event is dispatched routing a direct message to stub source (response is sent to ONE object)
            dispatchDirectEvent (msg, ex);
          }
        } catch (RemoteException e2) {
          e2.printStackTrace ();
        }
      }
      }
  }

  /**
   * Method invoked each time the skeleton receives an anycall event
   * @param evt Hashtable Information about the received event
   */
  public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
    String method = (String) evt.get (Context.METHOD);
    Vector args = (Vector) evt.get (Context.OBJECTCONTENT);

    // Account for another invocation if this object is a component
    if (this instanceof dermi.dcm.Component) {
      if (((Component) this).getLifeCycleManager() != null) {
        if (!method.equals ("getRemoteObjectState")) {
          ((Component) this).getLifeCycleManager().incInvocationNum();
        }
      }
    }

    try {
      if (method.equals ("getRemoteObjectState")) {
        Serializable res = null;
        Hashtable oldEvent = (Hashtable) receivedEvents.get (method + evt.get (Context.TIMESTAMP));
        if (oldEvent != null) {
          return oldEvent;
        }
        else {
          // Get component instance call
          if (evt.get (Context.GET_COMPONENT_INSTANCE) != null) {
            // Answer (OBJECTCONTENT -> TRUE, just to indicate that the instance is active)
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJECTID, uid + Context.APPEND_RESULT);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.ANYCALL_RESULT, new Boolean (false));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            msg.put (Context.OBJECTCONTENT, new Boolean (true));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            return msg;
          }

          // Replica's state must not be stale
          if (isReplicaReady) {
            Method m = loadMethod (method, args);
            res = (Serializable) m.invoke (this, (Object[]) null);
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJECTID, uid);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.OBJECTCONTENT, res);
            msg.put (Context.REPLICA, new Boolean (true));
            msg.put (Context.ANYCALL_RESULT, new Boolean (false));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            return msg;
          }
          else {
            // Replica's state is stale, message is routed to another member of the replica group
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJECTID, uid);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.OBJECTCONTENT, evt.get (Context.OBJECTCONTENT));
            msg.put (Context.REPLICA, new Boolean (true));
            msg.put (Context.RESULT, Context.VOID);
            msg.put (Context.ANYCALL_RESULT, new Boolean (true));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            return msg;
          }
        }
      }
      else {
      Method m = loadMethod (method, args);
      Method conditionMethod = loadMethod (method + "Condition", args);
      Method globalConditionMethod = null;
      try {
        globalConditionMethod = loadMethod (method + "GlobalCondition", args);
      } catch (Exception e) {
        // Method unavailable: anycall. If available we are dealing with a manycall.
      }

      Object[] objs = new Object[args.size ()];

      // Load object arguments array
      for (int i = 0; i < args.size (); i++) {
        objs[i] = args.elementAt (i);
      }

      // Check whether this method returns any value
      boolean hasReturnValue = (m.getReturnType () != void.class);

      Object res = null;

      Hashtable oldEvent = (Hashtable) receivedEvents.get (method + evt.get (Context.TIMESTAMP));
      if (oldEvent != null) {
        return oldEvent;
      }
      else {
        // Check for local condition
        if (((Boolean) conditionMethod.invoke (this, objs)).booleanValue()) {
          if (globalConditionMethod != null) {
            // Manycall
            res = m.invoke (this, objs);
            Object[] tempArgs = (Object[]) objs.clone();
            objs[0] = res;
            if (((Boolean) globalConditionMethod.invoke (this, objs)).booleanValue()) {
              // Global condition met, returning results
              Hashtable msg = new Hashtable();
              msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
              msg.put (Context.TYPE, Context.DISPATCH);
              msg.put (Context.METHOD, method);
              msg.put (Context.ANYCALL_RESULT, new Boolean (false));
              msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
              msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
              if (hasReturnValue) {
                msg.put (Context.OBJECTCONTENT, res);
              }
              return msg;
            }
            else {
              // Global condition not met, message will be routed to another member of the group
              Hashtable evt2 = (Hashtable) evt.clone();
              Vector args2 = new Vector();
              args2.add (res);

              // Add parameters (if any)
              if (args != null) {
                for (int i = 1; i < args.size(); i++) {
                  args2.add (args.elementAt (i));
                }
              }
              evt2.put (Context.STATUS, Context.MANYCALL);
              evt2.put (Context.ANYCALL_RESULT, new Boolean (true));
              evt2.put (Context.OBJECTCONTENT, args2);
              evt2.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
              evt2.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), evt2);
              return evt2;
            }
          }
          else {
            // Anycall (local condition met)
            res = m.invoke (this, objs);
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.ANYCALL_RESULT, new Boolean (false));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            if (hasReturnValue) {
              msg.put (Context.OBJECTCONTENT, res);
            }
            return msg;
          }
        }
        else {
          // Local condition not met, message will be routed to another member of the group
          Hashtable msg = new Hashtable();
          msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
          msg.put (Context.TYPE, Context.DISPATCH);
          msg.put (Context.METHOD, method);
          if (globalConditionMethod != null) {
            msg.put (Context.OBJECTCONTENT, args);
          }
          else {
            msg.put (Context.OBJECTCONTENT, evt.get (Context.OBJECTCONTENT));
          }
          msg.put (Context.RESULT, Context.VOID);
          msg.put (Context.ANYCALL_RESULT, new Boolean (true));
          msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
          msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
          receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
          return msg;
        }
      }
      }
    } catch (Exception eex) {
      Exception ex = null;
      if (eex instanceof InvocationTargetException) {
        ex = (Exception) ((InvocationTargetException) eex).getTargetException ();
      }
      else if (eex instanceof NoSuchMethodException) {
        ex = new UnmatchedAnycallMethodException (method);
      }
      else {
        ex = eex;
      }
      Hashtable msg = new Hashtable();
      msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
      msg.put (Context.TYPE, Context.EXCEPTION);
      msg.put (Context.METHOD, method);
      msg.put (Context.OBJECTCONTENT, ex);
      msg.put (Context.ANYCALL_RESULT, new Boolean (false));
      msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
      msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
      receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
      return msg;
    }
  }

  /**
   * This method triggers an event (used in listeners)
   * @param res Serializable The event to trigger
   * @throws RemoteException If something goes wrong ;-)
   */
  public void triggerEvent (Serializable res) throws RemoteException {
    Hashtable msg = new Hashtable();
    msg.put (Context.OBJ, uid + ":RESULT:" + res.getClass().getName());
    msg.put (Context.TYPE, Context.DISPATCH);

    try {

      dispatchEvent (msg, res);
    } catch (RemoteException e2) {
      e2.printStackTrace();
    }
  }

  /**
   * This method is used for a not updated replica in order to obtain
   * the object's state
   */
  public Serializable loadState() throws RemoteException {
    int timeout = 0;
    // Set timestamp for this event and its possible retransmissions
    String tstamp = "" + System.currentTimeMillis();
    String method2 = "getRemoteObjectState";
    String method = "loadState";

    for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
      Hashtable evt = new Hashtable();
      evt.put (Context.OBJECTID, uid);
      evt.put (Context.TYPE, Context.DISPATCH);
      evt.put (Context.METHOD, method2);
      evt.put (Context.TIMESTAMP, tstamp);
      evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
      evt.put (Context.OBJECTCONTENT, new Vector());
      try {
        conn.anycall (evt);
      }
      catch (SessionException ex1) {
        throw new RemoteException (ex1.getMessage());
      }
      timeout = 0;
      while (!contains (receivedEvents, method + tstamp) && timeout < Context.TIMEOUT) {
        try {
          Thread.currentThread().sleep (Context.DELAY);
        } catch (InterruptedException ex) {
          ex.printStackTrace();
        }
        timeout++;
      }
      if (exception) {
        exception = false;
        Exception ex = (Exception) receivedEvents.get (method + tstamp);

        if (ex instanceof RemoteException) {
          throw (RemoteException) ex;
        }

        throw new RemoteException (ex.getMessage());
      } else if (timeout == Context.TIMEOUT) {
        retransmission++;
        continue;
      }
      break;
    }
    if (timeout == Context.TIMEOUT) {
      throw new TimeoutException ("Object seems to be down.");
    }
    else {
      // Replica's state now up to date
      isReplicaReady = true;
      logger.info ("Object's state restored from replica.");

      return (Serializable) receivedEvents.get (method + tstamp);
    }
  }

  /**
   * Closes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void close() throws RemoteException {
    try {
      if (conn != null) {
        conn.unsubscribe (this, subs);
        dermi.util.Bus.close ();
        conn.removeActiveObject (uid);
      }
    } catch (SessionException e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * Initializes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void init() throws RemoteException {
    if (uid != null) {
      System.out.println ("Dynamic activation of object: " + uid + ", " + this);
      conn = dermi.util.Bus.getBus (eref);
      logger = Logger.getLogger (this.getClass().getName());
      receivedEvents = new Hashtable();
      try {
        conn.subscribe (this, subs);
      } catch (SessionException e) {
        throw new ConnectionException (e.getMessage());
      }
      eref.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
      conn.addActiveObject (uid, (ERemote) this);
    }
  }

  /**
   * Writes the current object to a stream
   * @param out ObjectOutputStream Data stream
   * @throws IOException  If something goes wrong ;-)
   */
  private void writeObject (ObjectOutputStream out) throws IOException {
    out.defaultWriteObject();
  }

  /**
   * Reads an object from a stream
   * @param in ObjectInputStream Data stream
   * @throws IOException  If something goes wrong ;-)
   * @throws ClassNotFoundException  If something goes wrong ;-)
   */
  private void readObject (ObjectInputStream in) throws IOException, ClassNotFoundException {
    try {
      in.defaultReadObject();
      init();
    } catch (RemoteException e) {
      e.printStackTrace();
    }
  }

  /**
   * Returns a stub copy of this class
   * @throws RemoteException If something goes wrong ;-)
   * @return ERemote The returned stub
   */
  public ERemote copy() throws RemoteException {
    ERemote ref = FileRegistry.loadStub (super.getERef());
    ref.init();
    return (ERemote) ref;
  }

  private Method loadMethod (String methodName, Vector args) throws Exception {
    // Get class reference
    Class thisClass = this.getClass ();
    Class[] c = new Class[args.size()];

    // Load class arguments array
    for (int i = 0; i < args.size(); i++) {
      c[i] = args.elementAt(i).getClass();
    }

    Method m = null;

    // Find method to invoke
    try {
      if (c.length > 0 && c[0].getName().equals ("rice.pastry.wire.WireNodeHandle")) {
        c[0] = dermi.core.NodeHandle.class;
      }
      m = thisClass.getMethod (methodName, c);
    }
    catch (NoSuchMethodException nse) {
      // try the same method using primitive types
      Method[] ms = thisClass.getMethods ();

      boolean found = false;
      for (Method mm : ms) {
        // Find method name
        if (mm.getName ().equals (methodName)) {
          // Equal number of input parameters?
          if (mm.getParameterTypes ().length == args.size ()) {
            // Check method signature
            Class[] cs = mm.getParameterTypes ();

            boolean argsOK = true;
            for (int i = 0; i < args.size (); i++) {
              try {
                if (!(basicTypes[findType (args.elementAt (i).getClass ().getName ())].equals (cs[i].getName ()))) {
                  argsOK = false;
                }
              }
              catch (TypeNotFoundException tnf) {
                continue;
              }
            }
            // Method signature OK: it is the same method with primitive types
            if (argsOK) {
              m = mm;
              found = true;
              break;
            }
          }
        }
      }
      if (!found) {
        throw nse;
      }
    }
    return m;
  }

  private int findType (String type) throws TypeNotFoundException {
    for (int i = 0; i < wrappers.length; i++) {
      if (wrappers[i].equals (type)) {
        return i;
      }
    }
    throw new TypeNotFoundException ("Primitive type " + type + " is unknown.");
  }

  // Utility method
  private boolean contains (Hashtable results, String tstamp) {
    Iterator i = results.keySet().iterator();
    while (i.hasNext()) {
      Object ob = i.next();
      if (results.get (tstamp) != null) {
        return true;
      }
    }
    return false;
  }

  int listenerCount = 0;
  Vector listeners = new Vector();

  // Special case: stub local call (without using dynamic proxy)
  public void addListener (Class eventClass, BasicListener sL) throws RemoteException {
    if (listenerCount == 0) {
      Hashtable lsubs = new Hashtable();
      lsubs.put (Context.OBJ, uid + ":RESULT:" + eventClass.getName());

      try {
        conn.subscribe (new RemoteEventListener() {
          public void eventArrived (Hashtable evt) {
            Serializable result = (Serializable) evt.get (Context.OBJECTCONTENT);
            Vector clisteners = (Vector) listeners.clone();
            Iterator it = clisteners.iterator();
            while (it.hasNext()) {
              BasicListener aListener = (BasicListener) it.next();
              aListener.onEvent (result);
            }
          }
          public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
            return null;
          }
        }, lsubs);
      } catch (SessionException ex) {
        throw new ConnectionException ("Problem subscribing listener.");
      }
    }
    listeners.add (sL);
    listenerCount++;
  }

  public void removeListener (Class eventClass, BasicListener sL) throws RemoteException {
    listeners.remove (sL);
    listenerCount--;
    if (listenerCount == 0) {
      Hashtable lsubs = new Hashtable();
      lsubs.put (Context.OBJ, uid + ":RESULT:" + (eventClass).getName());
      try {
        conn.unsubscribe (this, lsubs);
      } catch (SessionException ex) {
        throw new ConnectionException ("Problem unsubscribing listener.");
      }
    }
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dcm;

import java.util.*;

import dermi.*;
import dermi.exception.*;
import dermi.util.PriorityList;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * This class is the base class for a Dermi Component. It is in fact a special
 * kind of Dermi Remote Object which provides the component's standard methods
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class Component extends DermiRemoteObject {
  // Life cycle manager attribute
  private transient ComponentControl lc = null;

  /**
   * Default void Dermi Remote Object constructor
   */
  public Component() {
  }

  /**
   * Default Dermi Remote Object constructor
   * @param env Properties Object properties
   * @throws RemoteException If something goes wrong ;-)
   */
  public Component (Properties env) throws RemoteException {
    super (env);
  }

  /**
   * Life cycle manager setter method
   * @param cc ComponentControl A previously initialized life cycle manager
   */
  public void setLifeCycleManager (ComponentControl cc) {
    this.lc = cc;
  }

  /**
   * Life cycle manager getter method
   * @return ComponentControl The component's life cycle manager
   */
  public ComponentControl getLifeCycleManager() {
    return lc;
  }

  /**
   * This method implements the default activation policy for components
   * It thus follows this algorithm:
   *   - Obtain first the node's 5 most suitable replicas
   *   - If replica number is less than 2, it is impossible to activate new components (node is isolated)
   *   - Identify which node is overwhelming this component, and activate new object replica there, unless there is an
   *     already active instance within that node.
   *
   * @throws ActivationException If impossible to activate new object replica for any reason (see below)
   */
  public void activate() throws ActivationException {
    System.out.println ("Activating new instance for component " + this.uid);
    // Check if it is possible to activate a new replica
    Collection c = conn.getReplicaSet (conn.getLocalNodeId(), 5);
    if (c.size() < 2) {
      throw new ActivationException ("Unable to activate new object: unable to find enough nodes to replicate in!");
    }

    // Get node which is overwhelming us: the new component instance will dynamically be activated there
    PriorityList pl = conn.getComponentHops (uid);
    dermi.core.NodeHandle nh = (dermi.core.NodeHandle) pl.peak();

    // Activate instance in the overwhelming node
    if (nh != null && !nh.equals (conn.getLocalNodeHandle())) {
      dermi.activation.ActivatorClient localActivator = conn.getActivator();
      // Check if there is an active instance in that node
      if (!localActivator.isAlreadyActive (nh, uid)) {
          // Activate new object replica
          try {
            System.out.println ("Activating new object replica...");
            localActivator.activate (nh, this);
          } catch (RemoteException e) {
            e.printStackTrace();
            throw new ActivationException ("Unable to activate new object: activation exception!");
          }
        }
        else {
          throw new ActivationException ("Unable to activate new object: all surrounding nodes have already an active object");
        }
      }
  }

  /**
   * This method implements the default passivation policy for components
   * It now unloads the component from memory. Should take care of possible state persistence, which
   * will be implemented in a near future ;-)
   *
   * @throws PassivationException If the component cannot be passivated.
   */
  public void passivate() throws PassivationException {
    System.out.println ("Passivating component instance " + this.uid);
    // TODO: Check whether it is the last available instance, and if so, insert on DOLR
    try {
      this.close ();
    }
    catch (RemoteException ex) {
      throw new PassivationException ("Unable to passivate object: passivation exception!");
    }
  }

  /**
   * Executed when a component is de-serialized and read from a stream
   * @param in ObjectInputStream Data stream
   * @throws IOException  If something goes wrong ;-)
   * @throws ClassNotFoundException  If something goes wrong ;-)
   */
  private void readObject (ObjectInputStream in) throws IOException, ClassNotFoundException {
    try {
      in.defaultReadObject();
      init();
      lc = new ComponentControl ((ComponentInterface) this, Integer.MAX_VALUE, Integer.MAX_VALUE);
    } catch (RemoteException e) {
      e.printStackTrace();
    }
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dcm;

import dermi.util.*;
import java.util.*;

/**
 * This class models any component's life cycle manager.
 * It provides the necessary callbacks for component activation and passivation
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ComponentControl {
  // Timeout to component passivation when no invocations are received
  private long timeToPassivate;
  // Current per interval number of invocations
  private int invocationNum = 0;
  // Invocation threshold: if exceeded new component instance activation will be performed
  private int maxInvocations;

  // Activation timer task
  private Timer activationTimer;
  // Passivation timer task
  private Timer passivationTimer;

  // Component's callback reference
  private ComponentInterface cmpInt;

  /**
   * Constructor
   * @param cmpInt ComponentInterface Component's callback reference
   * @param timeToPassivate long Time for component's passivation if no invocations occur
   * @param maxInvocations int Per interval maximum number of invocations for component's new activation to occur
   */
  public ComponentControl (ComponentInterface cmpInt, long timeToPassivate, int maxInvocations) {
    this.cmpInt = cmpInt;
    this.timeToPassivate = timeToPassivate;
    this.maxInvocations = maxInvocations;

    activationTimer = new Timer();
    passivationTimer = new Timer();
    // Check number of invocations and available memory every 1000 milliseconds
    activationTimer.scheduleAtFixedRate (new ActivationControlTask(), 0, 1000);
    // If no invocations are received, component will passivate in timeToPassivate milliseconds
    passivationTimer.scheduleAtFixedRate (new PassivationControlTask(), timeToPassivate, timeToPassivate);
  }

  // Method called when a new component's instance must be activated
  private void activation() {
    try {
      // Component callback for activation
      cmpInt.activate ();
    } catch (ActivationException e) {
      e.printStackTrace();
    }
  }

  // Method called when the component's instance must be passivated
  private void passivation() {
    try {
      // Component callback for passivation
      cmpInt.passivate ();
      // Cancel all timers
      activationTimer.cancel();
      passivationTimer.cancel();
    } catch (PassivationException e) {
      e.printStackTrace();
    }
  }

  // Method called whenever any method on the component is called
  public synchronized void incInvocationNum() {
    invocationNum++;
    // Cancel passivation timer
    passivationTimer.cancel();
    passivationTimer = new Timer();
    // Reschedule passivation timer
    passivationTimer.scheduleAtFixedRate (new PassivationControlTask(), timeToPassivate, timeToPassivate);
    // If number of invocations is too high (per second), activate new instances on surrounding nodes
    if (invocationNum > maxInvocations) {
      activation();
      invocationNum = 0;
    }
  }

  // The ActivationControl task
  private class ActivationControlTask extends TimerTask {
     /**
      * Executed every 1000 milliseconds
      */
     public void run() {
       invocationNum = 0;
       // If available memory is low, passivate component
       if (Runtime.getRuntime().freeMemory() < Context.FREEMEM_THRESHOLD) {
         passivation();
       }
     }
  }

  // The PassivationControl task
  private class PassivationControlTask extends TimerTask {
     /**
      * Executed every timeToPassivate milliseconds
      */
     public void run() {
       // Component passivated if not called (unused) for timeToPassivate milliseconds
       passivation();
     }
  }
}

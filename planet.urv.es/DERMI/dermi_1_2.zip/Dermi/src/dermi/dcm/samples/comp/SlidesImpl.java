/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dcm.samples.comp;

import dermi.dcm.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * This is the component's base class. In this case, it implements all the component's interfaces.
 * It is in fact a special Dermi Remote Object that must extend the Component class, and be
 * labelled with @DCMImplementation annotation tag.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DCMImplementation
public class SlidesImpl extends Component implements Slides /* , StatefulReplica */ {
  private String currentImageSet = "";
  private int currentSlide = 0;

  // Dermi stub constructor: REQUIRED
  public SlidesImpl() {
  }

  // Dermi skel constructor: REQUIRED
  public SlidesImpl (Properties env) throws RemoteException {
    super (env);
  }

  // Constructor with arguments
  public SlidesImpl (Properties env, String imageSet) throws RemoteException {
    this (env);
    currentImageSet = imageSet;
    System.out.println ("[Slides] - component created. Image set loaded: \"" + currentImageSet + "\"");
  }

  public void first() throws RemoteException {
    if (currentImageSet.equals ("")) {
      System.out.println ("Image set not loaded!");
    }
    else {
      System.out.println ("[first] - called.");
    }
  }

  public void last() throws RemoteException {
    currentSlide = 10;
  }

  public void loadImageSet (String imageSet) throws RemoteException {
    currentImageSet = imageSet;
    System.out.println ("[loadImageSet] - loaded.");
  }

  public String getCurrentImageSet() throws RemoteException {
    return currentImageSet;
  }

  public void next() throws RemoteException {
    currentSlide++;
  }

  public void previous() throws RemoteException {
    currentSlide--;
  }

  /**
   * The queryInterface method must return a suitable component implementation
   * for the specified interface
   * @param interf String The desired interface implementation
   * @return ComponentInterface The desired implementation instance
   * @throws InterfaceNotFoundException If the component does not provide an implementation for such specified interface
   */
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException {
    try {
      if (interf.equals ("dermi.dcm.ComponentInterface") || interf.equals ("dermi.dcm.samples.comp.Slides")) {
        System.out.println ("Returning slides stub...");
        // Stub will either be local or remote, depending on the case
        return (ComponentInterface) this.copy();
      }
    } catch (RemoteException re) {
      throw new InterfaceNotFoundException ("Unable to query for interface " + interf + ": " + re.getMessage());
    }
    throw new InterfaceNotFoundException ("Interface " + interf + " not implemented.");
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dcm.samples.innerobj;

import dermi.dcm.*;
import dermi.exception.*;

import java.util.*;

/**
 * This is the component's base class. In this case, it implements all the component's interfaces.
 * It is in fact a special Dermi Remote Object that must extend the Component class, and be
 * labelled with @DCMImplementation annotation tag.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ScreenImpl extends Component implements Screen {

  // Dermi constructor: REQUIRED
  public ScreenImpl() {
  }

  // Dermi constructor: REQUIRED
  public ScreenImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Screen] - Inner component created.");
  }

  public void resize (int percent) throws RemoteException {
    System.out.println ("[Screen] - resize called.");
  }

  /**
   * The queryInterface method must return a suitable component implementation
   * for the specified interface
   * @param interf String The desired interface implementation
   * @return ComponentInterface The desired implementation instance
   * @throws InterfaceNotFoundException If the component does not provide an implementation for such specified interface
   */
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException {
    try {
      if (interf.equals ("dermi.dcm.ComponentInterface") || interf.equals ("dermi.dcm.samples.innerobj.Screen")) {
        return (ComponentInterface) this.copy();
      }
    } catch (RemoteException re) {
      throw new InterfaceNotFoundException ("Unable to query for interface " + interf + ": " + re.getMessage());
    }
    throw new InterfaceNotFoundException ("Interface " + interf + " not implemented.");
  }
}

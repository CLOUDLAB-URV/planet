/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.dcm.samples.stateful;

import dermi.*;
import dermi.dcm.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * This is the component's base class. In this case, it implements all the component's interfaces.
 * It is in fact a special Dermi Remote Object that must extend the Component class, and be
 * labelled with @DCMImplementation annotation tag.
 *
 * Note that we want this component to be <b>stateful</b>, and as such, we must make it implement
 * the <b>StatefulReplica</b> interface
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DCMImplementation
public class PlaceImpl extends Component implements Place, StatefulReplica {
  private ArrayList<Slides> things = new ArrayList<Slides>();

  // Dermi stub constructor: REQUIRED
  public PlaceImpl() {
  }

  // Dermi skel constructor: REQUIRED
  public PlaceImpl (Properties env) throws RemoteException {
    super (env);

    // Load replica state: as in any other stateful Dermi remote object
    super.loadReplicaState();
    System.out.println ("[Place] - component created.");
  }

  public void addThing (Slides t) throws RemoteException {
    System.out.println ("[Place] - Thing " + t.getCurrentImageSet() + " added.");
    things.add (t);
  }

  public void removeThing (Slides t) throws RemoteException {
    System.out.println ("[Place] - Thing " + t.getCurrentImageSet() + " removed.");
    things.remove (t);
  }

  public Collection getThings() throws RemoteException {
    System.out.println ("[Place] - Returning things vector...");
    return things;
  }

  int i = 1;
  public String getName() throws RemoteException {
    System.out.println ("[Place] - getName... " + i);
    i++;
    return "hola";
  }

  /**
   * The queryInterface method must return a suitable component implementation
   * for the specified interface
   * @param interf String The desired interface implementation
   * @return ComponentInterface The desired implementation instance
   * @throws InterfaceNotFoundException If the component does not provide an implementation for such specified interface
   */
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException {
    try {
      if (interf.equals ("dermi.dcm.ComponentInterface") || interf.equals ("dermi.dcm.samples.stateful.Place")) {
        System.out.println ("Returning place stub...");
        // Stub will either be local or remote, depending on the case
        return (ComponentInterface) this.copy();
      }
    } catch (RemoteException re) {
      throw new InterfaceNotFoundException ("Unable to query for interface " + interf + ": " + re.getMessage());
    }
    throw new InterfaceNotFoundException ("Interface " + interf + " not implemented.");
  }

  /**
   * Method for loading state into this object
   * @param data SpriteValues Object state
   */
  public void loadRemoteObjectState() throws RemoteException {
    this.things = (ArrayList<Slides>) super.loadState ();
    System.out.println ("[loadRemoteObjectState] - new state loaded: " + things);
  }

  /**
   * Method for obtaining this object's state
   * @return SpriteData
   */
  public java.io.Serializable getRemoteObjectState() {
    return (java.io.Serializable) things.clone();
  }

  /**
   * The activate() method can be overwritten to implement another activation
   * policy. Here we simply call the default (superclass) activation policy.
   * @throws ActivationException If impossible to activate a new component instance
   */
  public void activate() throws ActivationException {
    System.out.println ("Activating new Place instance...");
    // Default activation policy
    super.activate();
  }

  /**
   * The passivate() method can be overwritten to implement another passivation
   * policy. Here we simply call the default (superclass) passivation policy.
   * @throws PassivationException If impossible to passivate the component instance
   */
  public void passivate() throws PassivationException {
    System.out.println ("Place component passivated.");
    // Default passivation policy
    super.passivate();
  }
}

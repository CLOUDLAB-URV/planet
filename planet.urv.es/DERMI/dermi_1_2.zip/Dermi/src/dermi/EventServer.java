/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import java.io.*;
import java.util.*;
import java.util.logging.*;

import dermi.util.*;
import dermi.exception.*;

/**
 * This is an utility class for skeletons and stubs (both inherit from EventServer).
 * It handles event service connections, disconnections, event dispatching, exception wrapping, and
 * stub class requests. It is internally used by Dermi, so <b>IT IS NOT AIMED FOR END USERS</B>.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class EventServer implements Serializable {
  static final long serialVersionUID = 10L;

  protected String uid;
  protected String classStore = "";
  protected String className;
  protected Properties eref = new Properties();

  protected transient Session conn;
  private transient Logger logger = Logger.getLogger (this.getClass().getName());

  public EventServer() {
  }

  /**
   * EventServer constructor
   * @param env Properties Environment properties
   * @throws RemoteException If something goes wrong ;-)
   */
  public EventServer (Properties env) throws RemoteException {
    this.start (env);
  }

  protected void start (Properties env) throws RemoteException {
    eref = (Properties) env.clone();
    String store = env.getProperty (Context.CLASS_STORE);
    if (store != null) {
      this.classStore = store;
    }
    conn = Bus.getBus (env);
  }

  /**
   * Dispatches an event whose main content is a byte array
   * @param evt Hashtable Event data
   * @param data byte[] Byte array
   * @throws RemoteException If something goes wrong ;-)
   */
  public void dispatchEvent (Hashtable evt, byte data[]) throws RemoteException	{
    try	{
      ByteWrapper bw = new ByteWrapper (data);
      conn.publish (evt, bw);

    } catch (SessionException e) {
      throw new ConnectionException (e);
    }
  }

  /**
   * Dispatches an event whose main content is a serializable object
   * @param evt Hashtable Event data
   * @param data Serializable Object
   * @throws RemoteException If something goes wrong ;-)
   */
  public void dispatchEvent (Hashtable evt, Serializable data) throws RemoteException	{
    try {
      conn.publish (evt, data);
    } catch (SessionException e) {
      throw new ConnectionException (e);
    }
  }

  /**
   * Dispatches an event whose main content is embedded on a hash table
   * @param evt Hashtable Event data
   * @throws RemoteException If something goes wrong ;-)
   */
  public void dispatchEvent (Hashtable evt) throws RemoteException {
    try	{
      conn.publish (evt);
    } catch (SessionException e) {
      throw new ConnectionException (e);
    }
  }

  /**
   * Dispatches an event directly without using the event service
   * @param evt Hashtable Event data
   * @param params Serializable Object
   * @throws RemoteException If something goes wrong ;-)
   */
  public void dispatchDirectEvent (Hashtable evt, Serializable params) throws RemoteException {
    try {
      conn.publishDirect (evt, params);
    } catch (SessionException e) {
      throw new ConnectionException (e);
    }
  }

  /**
   * Dispatches an event directly without using the event service
   * @param evt Hashtable Event data
   * @throws RemoteException If something goes wrong ;-)
   */
  public void dispatchDirectEvent (Hashtable evt) throws RemoteException {
    try {
      conn.publishDirect (evt);
    } catch (SessionException e) {
      throw new ConnectionException (e);
    }
  }

  /**
   * Return object's unique identifier
   * @return String UID
   */
  public String getUID() {
    return uid;
  }

  /**
   * Writes this object's reference to a properties file
   * @param fileName String Properties file name
   */
  public void writeERef (String fileName) {
    try	{
      eref.setProperty (Context.CLASS_ID, uid);
      eref.setProperty (Context.CLASS_NAME, className);

      Properties propsToWrite = (Properties) eref.clone();
      propsToWrite.remove (Context.SOURCE_NODEHANDLE);

      FileOutputStream fos = new FileOutputStream (fileName);
      String title = "\nEnvironment properties\n" +
          "\n\tdermi.host\t\t\t\t\t-\tBootstrap host (enter 'auto' for localhost autodetection)\n" +
          "\tdermi.port\t\t\t\t\t-\tBootstrap port\n" +
          "\tdermi.protocol\t\t\t-\tProtocol to be used: -138 - DIRECT / 0 - RMI / 1 - WIRE\n" +
          "\tdermi.classID\t\t\t\t-\tLast bound object's ID\n" +
          "\tdermi.className\t\t\t-\tLast bound object's fully qualified class name\n" +
          "\tdermi.sessionClass\t-\tDermi's session class\n" +
          "\tdermi.classStore\t\t-\tLocation of the class store for remote classes\n" +
          "\tdermi.underlyingDHT\t-\tUndelying DHT to be used\n\n";

      fos = new FileOutputStream (fileName);
      propsToWrite.storeToXML (fos, title);
      fos.close();

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Returns the object's reference
   * @return Properties Object's properties
   */
  public Properties getERef() {
    if (className != null) {
      eref.setProperty (Context.CLASS_NAME, className);
    }
    eref.setProperty (Context.CLASS_ID, uid);
    return eref;
  }

  /**
   * Gets an array of bytes from a file
   * @param filename String File name
   * @throws IOException If something goes wrong ;-)
   * @return byte[] Byte array representing the file
   */
  public byte[] getBytes (String filename) throws IOException {
    String fName = filename.replace ('.', '/') + ".class";
    logger.fine (fName);
    // Determine file length
    File file = new File (fName);
    long len = file.length();
    // Create an array just the right size for the file's contents
    byte raw[] = new byte[(int)len];
    // Open file
    FileInputStream fin = new FileInputStream (file);
    // Read all of it into the array; if we don't get all, then it's an error.
    int r = fin.read (raw);
    if (r != len) {
      throw new IOException ("Can't read all, " + r + " != " + len);
    }
    // Don't forget to close the file!
    fin.close();
    // And finally return the file contents as an array
    return raw;
  }

  /**
   * This method returns the class store
   * @return String
   */
  public String getClassStore() {
    return classStore;
  }
}

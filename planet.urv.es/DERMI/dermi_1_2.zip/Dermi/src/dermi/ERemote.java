/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.exception.*;

import java.util.Properties;

/**
 * The Remote Interface is used to identify interfaces whose methods may be invoked from
 * a non-local virtual machine. Any remote object must directly or indirectly implement
 * this interface. Only those methods specified in a remote interface are available remotely.
 * <br>
 * The current implementation of Dermi does not support inheritance from other remote interfaces.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public interface ERemote {
 /**
  * This method returns a property object containing the required information to connect to this remote object.
  * The information contained in this file includes the event service location, event service factory class,
  * and Object's unique ID for remote subscriptions.
  * @return Properties Reference information for a remote object (connection and subscription information).
  */
 public Properties getERef();

 /**
  * It removes all subscriptions for this object and releases the event service connection.<br>
  * It is highly recommended to call this method on object references that will no longer be used.
  *
  * @throws RemoteException If the connection with the event service fails.
  */
 public void close() throws RemoteException;

 /**
  * It connects to the event service and creates all subscriptions for this object.
  *
  * @throws RemoteException If the connection with the event service fails.
  */
 public void init() throws RemoteException;

 /**
  * This method returns a reference to a new stub instance of this remote object. This is mainly used
  * in the pass by reference calls to remote objects. This stub is later initialized (init) when
  * it is deserialized in the demanding endpoint.<br><br>
  * It is mandatory to call this method when a remote server returns an object by reference.
  *
  * @throws RemoteException If the stub cannot be instantiated for any reason (explained in the RemoteException message).
  */
 public ERemote copy() throws RemoteException;

}

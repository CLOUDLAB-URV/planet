package dermi;

import dermi.*;
import dermi.listener.*;
import dermi.exception.*;

import java.util.*;
import java.io.*;
import dermi.dolr.*;


public class GenericDOLR {

   private DOLRChannel channel;

   public GenericDOLR() throws RemoteException {

   	 Registry.loadRegistry ("dolr-config.xml");



       Properties env = Registry.getEnvironment ("dolr-config.xml");
   	   channel = new DOLRChannelImpl (env);

   }

   public GenericDOLR(String path) throws RemoteException {
   	 Registry.loadRegistry (path);

   	 Properties env = Registry.getEnvironment (path);
     channel = new DOLRChannelImpl (env);
   }

   public void insert(String location, Properties prop)  throws RemoteException {
   	  Registry.bind ("p2p://"+location, prop);
   	  channel.notify(new DOLREvent("insert",location));
   }

   public void insertSer(String location, Serializable ser)  throws RemoteException {
   	  Properties prop = new Properties();
   	  prop.put("GENERIC_DOLR_OBJECT",ser);
   	  Registry.bind ("p2p://"+location, prop);
   	  channel.notify(new DOLREvent("insert",location));
   }

   public Serializable lookupSer(String location)  throws RemoteException {
   	 Properties prop = (Properties) Registry.lookupSer ("p2p://"+location);
   	 return (Serializable) prop.get("GENERIC_DOLR_OBJECT");
   }

   public Properties lookup(String location)  throws RemoteException {
   	 return (Properties) Registry.lookupSer ("p2p://"+location);
   }

   public void addDOLRListener(BasicListener bl) throws RemoteException {
   	 channel.addListener(bl);
   }

   public void removeDOLRListener(BasicListener bl) throws RemoteException {
   	 channel.removeListener(bl);
   }

   public void remove(String location) throws RemoteException {
   	 Registry.unbind("p2p://"+location);
   	 channel.notify(new DOLREvent("remove",location));
   }


   public String[] list(String location)  throws RemoteException {
     Collection records = Registry.list ("p2p://"+location);
     if (records.size() != 0) {
       String[] locations = new String[records.size()];
       Iterator it = records.iterator();
       int i=0;
       while (it.hasNext()) {
         dermi.registry.RegistryRecord r = (dermi.registry.RegistryRecord) it.next();
         locations[i]=r.getObjectName().substring(6); // cut by "p2p://"
         i++;
      }
      return locations;
     }
   	 return null;
   }

   public void leave() throws dermi.exception.RemoteException {
     channel.close();
     Registry.leave();
   }


   static class DOLRListener implements BasicListener{
   	     public void onEvent (Serializable eL) {
           DOLREvent evt = (DOLREvent) eL;
           System.out.println ("Listener : "+evt.getType()+" --> "+evt.getLocation());
         }

      }

   public static void main(String args[]) {
   	try{
   	  GenericDOLR dolr = new GenericDOLR();
   	  dolr = new GenericDOLR();
   	  BasicListener listerner = new DOLRListener();
   	  dolr.addDOLRListener(listerner);

   	  //TEST
   	  int whatToDo = (Integer.valueOf(args[0])).intValue();

   	  if (whatToDo==0) {

   	    // insert data
   	    dolr.insertSer("home",new Date());
   	    dolr.insertSer("home/today",new Date());
   	    dolr.insertSer("home/yesterday",new Date());
   	    dolr.insertSer("home/tomorrow",new Date());

   	    dolr.insertSer("metadata","META-DATA");

   	    // retreive data
   	    Date home = (Date) dolr.lookupSer("home/tomorrow");
   	    System.out.println("Recuperades dades: " + home);

   	  }
   	  else   {
   	    dolr.remove("home/tomorrow");

   	    String[] list = dolr.list ("home");
   	    for(int i=0;i<list.length;i++)
   	      System.out.println(list[i]);

      }

      System.in.read();

      System.out.println("Prem <RETURN> per finalitzar...");
      System.in.read();

      dolr.removeDOLRListener(listerner);
      dolr.leave();

   	} catch (Exception ex) {
   	  ex.printStackTrace();
   	}
   }
}

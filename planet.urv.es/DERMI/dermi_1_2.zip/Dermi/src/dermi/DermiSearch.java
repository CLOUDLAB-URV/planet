package dermi;

import dermi.*;
import dermi.core.Id;
import dermi.exception.*;

import bunshin.util.*;

import java.util.*;
import java.io.*;


public class DermiSearch {

   public DermiSearch() throws RemoteException {

   	 Registry.loadRegistry ("search-config.xml");     
     Properties env = Registry.getEnvironment ("search-config.xml");
     
   }

   public DermiSearch(String path) throws RemoteException {
   	 Registry.loadRegistry (path);
   	 Properties env = Registry.getEnvironment (path);     
   }

   public void insert(String keywords, String key, Serializable value)  throws RemoteException {
   	  Registry.insert (keywords,key,value);   	  
   }
   
   public ResultSortedQueue query(String keywords)  throws RemoteException {
   	 return Registry.query (keywords);   	 
   }

   public Serializable retreive(String key)  throws RemoteException {
   	 return Registry.lookupSer(key);
   }

   public Serializable retreive(Id key)  throws RemoteException {
   	 return Registry.lookupSer(key);
   }
      
   public void remove(String keywords, String key) throws RemoteException {
   	 Registry.remove(keywords,key);
   }

   public void leave() throws dermi.exception.RemoteException {     
     Registry.leave();
   } 
 
}

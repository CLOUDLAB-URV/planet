/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.activation;

import dermi.*;
import dermi.dcm.*;
import dermi.util.*;
import dermi.exception.RemoteException;

import java.util.*;
import java.io.Serializable;
import dermi.util.pastry.HashGenerator;

/**
 * Implementation of object's methods
 * Note that this implementation does not care about remote state propagation
 * This will be taken into account by the object's skeleton
 * @author Carles Pairot   <carles.pairot@urv.net>
 */
public class ActivatorImpl extends DermiRemoteObject implements Activator {

  // Dermi constructor: REQUIRED
  public ActivatorImpl() {
  }

  // Dermi constructor: REQUIRED
  public ActivatorImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("Dermi Dynamic Activation algorithms online.");
  }

  public boolean isAlreadyActive (dermi.core.NodeHandle nh, String objectId) throws RemoteException {
    if (conn.containsActiveObject (objectId)) {
      System.out.println ("CONTE LA CLAU: " + objectId);
      return true;
    }
    else {
      System.out.println ("NO CONTE LA CLAU: " + objectId);
      return false;
    }
  }

  public void activate (dermi.core.NodeHandle nh, Serializable objectData) throws RemoteException {
    if (objectData instanceof Component) {
      Component com = (Component) objectData;
      com.init();
      conn.addActiveObject (com.getUID(), (ERemote) com);
      System.out.println ("Component instance " + com.getUID() + " dynamically activated.");
    }
    else {
      ERemote obj = (ERemote) objectData;
      obj.init();
      conn.addActiveObject (((EventServer) obj).getUID(), obj);
      System.out.println ("Object " + ((EventServer) obj).getUID() + " dynamically activated.");
    }
  }
}

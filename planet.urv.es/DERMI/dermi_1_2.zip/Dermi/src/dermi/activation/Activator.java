/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.activation;

import dermi.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.io.Serializable;

/**
 * Interface to object's methods
 * @author Carles Pairot   <carles.pairot@urv.net>
 */
@DermiRemoteInterface
public interface Activator extends ERemote {
  // When doing a direct call, the object's destination NodeHandle must be passed.
  // IT MUST ALWAYS BE the FIRST PARAMETER in the direct call so as it works.
  @RemoteMethod (granularity = Granularity.DIRECTCALL, type = SynchronyType.SYNCHRONOUS)
  public boolean isAlreadyActive (dermi.core.NodeHandle nh, String objectId) throws RemoteException;

  // When doing a direct call, the object's destination NodeHandle must be passed.
  // IT MUST ALWAYS BE the FIRST PARAMETER in the direct call so as it works.
  @RemoteMethod (granularity = Granularity.DIRECTCALL, type = SynchronyType.SYNCHRONOUS)
  public void activate (dermi.core.NodeHandle nh, Serializable objectData) throws RemoteException;

/*  public void addClass (String className, byte[] skelClass, byte[] implClass, byte[] stubClass) throws RemoteException;

  public Properties activateObject (String componentUrl, String instance) throws RemoteException;

  public Properties activateMultipleObjects (Properties env) throws RemoteException;
  public boolean isBound (String componentUrl, String instance) throws RemoteException;
*/
}

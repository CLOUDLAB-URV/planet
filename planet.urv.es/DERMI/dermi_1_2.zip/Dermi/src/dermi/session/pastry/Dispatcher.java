/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session.pastry;

import java.util.Hashtable;

import dermi.listener.*;

/**
 * Class used to dispatch received events to the different objects
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class Dispatcher extends Thread {
  // Client to be notified
  private RemoteEventListener caller;

  // Event to dispatch
  private Hashtable event;

  /**
   * Constructor
   * @param caller RemoteEventListener Client to be notified
   * @param event Hashtable Event to dispatch
   */
  public Dispatcher (RemoteEventListener caller, Hashtable event) {
    this.caller = caller;
    this.event = (Hashtable) event.clone();
  }

  public void run() {
    caller.eventArrived ((Hashtable) event.clone());
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session.pastry;

import dermi.*;
import dermi.core.*;
import dermi.util.*;
import dermi.session.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.util.pastry.*;

import java.util.*;
import java.io.*;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;

/**
 * The Session class establishes a simple contract to access publish/subscribe
 * middleware. It mimics the delegation event model to smooth the transition
 * from local to remote events for Java programmers
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @author Ruben Mondejar
 * @version 1.2
 */
public class Session implements dermi.Session {
  public DermiConnection conn;
  private Hashtable env;

  private Hashtable subscriptions;
  private Hashtable connections;

  private Hashtable athreads;

  /**
   * Opens a new session.
   *
   * @param env environment connection properties
   *
   * @throws SessionException if any exception occurs
   */
  public void open (Hashtable env) throws SessionException {
    try {
      this.env = env;

      String host = (String) env.get (Context.PROVIDER_HOST);
      int port = Integer.parseInt ((String) env.get (Context.PROVIDER_PORT));

      // Reuse open connection to the Pastry node (if any)
      if (Registry.isConnected()) {
       conn = Registry.getConnection();
      }
      else {
        conn = new dermi.core.pastry.DermiConnection (host, port, null, Integer.parseInt ((String) env.get (Context.PROTOCOL)));
      }

      subscriptions = new Hashtable();
      connections = new Hashtable();
      athreads = new Hashtable();

    } catch (Exception ex) {
      throw new SessionException(ex);
    }
  }

  /**
   * Closes the current session.
   *
   * @throws SessionException
   */
  public void close() throws SessionException {
    try {
      Iterator it = athreads.keySet().iterator();
      while (it.hasNext()) {
        String subject = (String) it.next();
        Hashtable alert = new Hashtable();
        alert.put ("connection_event", "close");
        alert.put ("subject",subject);
        publish (alert);

        AliveThread at = (AliveThread) athreads.get(subject);
        at.die();
      }
      conn.close();
    }
    catch (Exception ex) {
      throw new SessionException (ex);
    }
  }

  /**
   * Send event to multicast group.
   *
   * @param evt group subscription
   *
   * @throws SessionException
   */
  public void publish (Hashtable evt) throws SessionException {
    try {
      dermi.core.Id subsKey = HashGenerator.generateSessionHash (evt);
      Hashtable ht = (Hashtable) evt.clone();

      conn.publish (new dermi.core.pastry.Topic (subsKey), ht);

      if (!athreads.isEmpty()) {
      	if (ht.containsKey ("subject")) {
          String subject = (String) ht.get ("subject");
          if (athreads.containsKey (subject)) {
            AliveThread at = (AliveThread) athreads.get(subject);
            at.time();
            athreads.put(subject,at);
          }
        }
      }

    } catch (Exception ex){
      throw new SessionException (ex);
    }
  }

  /**
   * Send object event to multicast group.
   *
   * @param event group subscription
   * @param obj object to be sent
   *
   * @throws SessionException
   */
  public void publish (Hashtable event, java.io.Serializable obj) throws SessionException {
    try {
      dermi.core.Id subsKey = HashGenerator.generateSessionHash (event);
      Hashtable ht = (Hashtable) event.clone();

      ht.put (Context.OBJECTCONTENT, obj);
      conn.publish (new dermi.core.pastry.Topic (subsKey), ht);

      if (!athreads.isEmpty()) {
      	if (ht.containsKey ("subject")) {
          String subject = (String) ht.get ("subject");
          if (athreads.containsKey (subject)) {
            AliveThread at = (AliveThread) athreads.get (subject);
            at.time();
            athreads.put (subject,at);
          }
        }
      }
    } catch (Exception ex){
      throw new SessionException(ex);
    }
  }

  /**
   * Send event directly.
   *
   * @param evt group subscription
   *
   * @throws SessionException
   */
  public void publishDirect (Hashtable evt) throws SessionException {
    try {
      dermi.core.Id subsKey = HashGenerator.generateSessionHash (evt);
      Hashtable ht = (Hashtable) evt.clone();

      conn.publishDirect (new dermi.core.pastry.Topic (subsKey), ht);

      if (!athreads.isEmpty()) {
        if (ht.containsKey("subject")) {
          String subject = (String) ht.get ("subject");
          if (athreads.containsKey (subject)) {
            AliveThread at = (AliveThread) athreads.get(subject);
            at.time();
            athreads.put (subject,at);
          }
        }
      }

    } catch (Exception ex){
      throw new SessionException (ex);
    }
  }

  /**
   * Send object directly.
   *
   * @param event group subscription
   * @param obj object to be sent
   *
   * @throws SessionException
   */
  public void publishDirect (Hashtable event, Serializable obj) throws SessionException {
    try {
      dermi.core.Id subsKey = HashGenerator.generateSessionHash(event);
      Hashtable ht = (Hashtable) event.clone();

      ht.put (Context.OBJECTCONTENT, obj);
      conn.publishDirect (new dermi.core.pastry.Topic (subsKey), ht);

      if (!athreads.isEmpty()) {
        if (ht.containsKey("subject")) {
          String subject = (String) ht.get ("subject");
          if (athreads.containsKey (subject)) {
            AliveThread at = (AliveThread) athreads.get (subject);
            at.time();
            athreads.put (subject,at);
          }
        }
      }

    } catch (Exception ex){
      throw new SessionException(ex);
    }
  }

  /**
   * Add interceptor application to specified multicast group.
   *
   * @param sel the filter application to be called
   * @param evt group subscription
   *
   * @throws SessionException
   */
  public void addInterceptor (RemoteInterceptorListener sel, Hashtable evt) throws SessionException {
    String interceptorId = HashGenerator.generateKeyId (evt);
    dermi.core.pastry.Id subsKey = (dermi.core.pastry.Id) HashGenerator.generateHash (interceptorId);
    NotificationParser npar = new NotificationParser (sel);
    conn.addInterceptor ((dermi.session.DermiApplicationListener) npar, (dermi.core.Id) subsKey, interceptorId);
  }

  /**
   * Remove interceptor application from specified multicast group.
   *
   * @param evt group subscription
   *
   * @throws SessionException
   */
  public void removeInterceptor (Hashtable evt) throws SessionException {
    String interceptorId = HashGenerator.generateKeyId (evt);
    dermi.core.Id subsKey = HashGenerator.generateHash (interceptorId);
    conn.removeInterceptor ((dermi.core.Id) subsKey, interceptorId);
  }

  /**
   * Make a method call to any of the group members. Only one object will
   * execute the method (which one does so depends on arbitrary criteria)
   *
   * @param evt hashtable containing group id, method to be invoked, params, ...
   * @throws SessionException If something goes wrong ;-)
   */
  public void anycall (Hashtable evt) throws SessionException {
    dermi.core.Id subsKey = HashGenerator.generateSessionHash (evt);
    try {
      String key = HashGenerator.generateKeyId (evt) + System.currentTimeMillis();
      conn.anycall (new dermi.core.pastry.Topic (subsKey), evt);
    }
    catch (Exception ex) {
      throw new SessionException (ex);
    }
  }

  /**
   * Add remote anycast event listener to specified multicast group. The listener will be
   * called every time an event is received in this group.
   *
   * @param sel the remote anycast event listener application to be called
   * @param event group subscription
   * @throws SessionException
   */
  public void addRemoteAnycallEventListener (RemoteEventListener sel, Hashtable event) throws SessionException {
    subscribe (sel, event);
  }

  /**
   * Add remote event listener to specified multicast group. The listener will be
   * called every time an event is received in this group.
   *
   * @param sel the remote event listener application to be called
   * @param event group subscription
   *
   * @throws SessionException
   */
  public void subscribe (RemoteEventListener sel, Hashtable event) throws SessionException {
    try	{
      dermi.core.Id subsKey = HashGenerator.generateSessionHash (event);

      NotificationParser npar = new NotificationParser (sel);
      npar.setConnection (conn);
      conn.subscribe (new dermi.core.pastry.Topic (subsKey), npar);

      Vector npars;

      if (!subscriptions.containsKey (subsKey)) {
        npars = new Vector();
// UNCOMMENT WHEN CBUS IS REWRITTEN!
//        addSubscriber (subsKey,event);
      }
      else {
        npars = (Vector) subscriptions.get (subsKey);
      }

      npars.add (npar);
      subscriptions.put (subsKey, npars);
    } catch (Exception ex) {
      throw new SessionException(ex);
    }
  }

  /**
   * Add remote event listener to specified multicast group. The listener will be
   * called every time an event is received in this group
   *
   * @param listener the remote event listener application to be called
   * @param subs group subscription
   *
   * @throws SessionException
   */
  public void subscribe (RemoteEventListener listener, String subs) throws SessionException {
    Hashtable evt = new Hashtable();
    evt.put ("subject", subs);
    try {
      subscribe (listener, evt);
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new SessionException(ex);
    }
  }

  public int getMembers (Hashtable event) {
    dermi.core.Id subsKey = HashGenerator.generateSessionHash (event);

    return conn.getMembers (new dermi.core.pastry.Topic (subsKey));
  }

  /**
   * Returns a set of suitable replica nodes for such Id
   * @param id Id Which id to replicate
   * @param maxRank int Maximum number of replicas
   * @return Collection Set of replicas
   */
  public Collection getReplicaSet (dermi.core.Id id, int maxRank) {
    return conn.getReplicaSet (id, maxRank);
  }

  /**
   * Remove remote event listener from the specified multicast group.
   *
   * @param event group subscription
   *
   * @throws SessionException
   */
  public void unsubscribe (RemoteEventListener sel, Hashtable event) throws SessionException {
    try {
      dermi.core.Id subsKey = HashGenerator.generateSessionHash (event);
      NotificationParser npar = new NotificationParser (sel);

      DermiApplicationListener app = (DermiApplicationListener) npar;
      conn.unsubscribe (new dermi.core.pastry.Topic (subsKey), app);

      Vector npars = (Vector) subscriptions.get (subsKey);

      npars.remove (sel);

      if (npars.isEmpty()) {
        subscriptions.remove (subsKey);
// UNCOMMENT WHEN CBUS IS REWRITTEN!
//        remSubscriber (subsKey);
      }

    } catch (Exception ex) {
      ex.printStackTrace();
      throw new SessionException(ex);
    }
  }

  /**
   * Remove remote event listener from the specified multicast group.
   *
   * @param listener listener to unsubscribe
   * @param subs group subscription
   *
   * @throws SessionException
   */
  public void unsubscribe (RemoteEventListener listener, String subs) throws SessionException {
    Hashtable evt = new Hashtable();
    evt.put ("subject", subs);
    try {
      unsubscribe (listener,evt);
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new SessionException(ex);
    }
  }

  /**
   * Removes an anycall event listener
   * @param sel RemoteAnycallEventListener The listener
   * @param event Hashtable Event subscription data
   * @throws SessionException If something goes wrong ;-)
   */
  public void removeRemoteAnycallEventListener (RemoteEventListener sel, Hashtable event) throws SessionException {
    this.unsubscribe (sel, event);
  }

  /**
   * Gets an instance to the current local node handle
   * @return NodeHandle The local node handle
   */
  public dermi.core.NodeHandle getLocalNodeHandle() {
    return (dermi.core.NodeHandle) conn.getLocalNodeHandle();
  }

  /**
   * Gets an instance to the current local node
   * @return Node The local node
   */
  public dermi.core.Node getLocalNode() {
    return (dermi.core.Node) conn.getLocalNode();
  }

  /**
   * Gets an instance to the current local node id
   * @return Node The local node id
   */
  public dermi.core.Id getLocalNodeId() {
    return (dermi.core.Id) conn.getLocalNodeId();
  }

  /**
   * Invoked by interceptor skeleton to force the resuming of the interception process
   *
   * @param evt Hashtable Event data
   * @param interceptors ArrayList Remaining interceptors
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors) {
    conn.continueInterception (evt, interceptors);
  }

  public dermi.activation.ActivatorClient getActivator() {
    return conn.getActivator();
  }

  public void addActiveObject (String uid, ERemote ref) {
    conn.addActiveObject (uid, ref);
  }

  public void removeActiveObject (String uid) {
    conn.removeActiveObject (uid);
  }

  public Collection listActiveObjects() {
    return conn.listActiveObjects();
  }

  public boolean containsActiveObject (String uid) {
    return conn.containsActiveObject (uid);
  }

  public PriorityList getComponentHops (String uid) {
    return conn.getComponentHops (uid);
  }
}

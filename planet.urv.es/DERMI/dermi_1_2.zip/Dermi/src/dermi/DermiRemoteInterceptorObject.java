/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.*;
import dermi.util.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.core.NodeHandle;
import dermi.registry.FileRegistry;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.logging.*;

/**
 * This class implements the generic skeleton class for any interceptor object
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public abstract class DermiRemoteInterceptorObject extends EventServer implements RemoteInterceptorListener {
  private Hashtable msg = new Hashtable();
  private Hashtable subs = new Hashtable();
  private Hashtable receivedEvents = new Hashtable();

  // Primitive types and their wrappers
  private String[] basicTypes = {"int", "char", "double", "float", "long", "boolean", "byte", "short"};
  private String[] wrappers = {"java.lang.Integer", "java.lang.Character", "java.lang.Double", "java.lang.Float", "java.lang.Long", "java.lang.Boolean", "java.lang.Byte", "java.lang.Short"};

  protected transient Logger logger = Logger.getLogger (this.getClass().getName());

  /**
   * Local constructor: Entry point to the skeleton class
   */
  public DermiRemoteInterceptorObject() { }

  /**
   * Constructor: Entry point to the skeleton class
   * @param env Properties Environment properties
   * @throws RemoteException When something goes wrong ;-)
   */
  public DermiRemoteInterceptorObject (Properties env) throws RemoteException {
    super (env);

    uid = env.getProperty (Context.CLASS_ID);
    className = this.getClass().getName();
    this.addInterceptor();
  }

  /**
   * Method executed every time an interception event is received
   * @param evt Hashtable Event data (it may be transformed)
   * @param interceptors ArrayList Remaining interceptors
   * @throws RemoteException If something goes wrong ;-)
   */
  public void interceptorEventArrived (Hashtable evt, ArrayList interceptors) throws RemoteException {
    String method = (String) evt.get (Context.METHOD);
    Vector args = (Vector) evt.get (Context.OBJECTCONTENT);

    if (args == null) {
      args = new Vector ();
    }

    try {
      Method m = loadMethod (method, args);

      Object[] objs = new Object[args.size ()];

      // Load object arguments array
      for (int i = 0; i < args.size (); i++) {
        objs[i] = args.elementAt (i);
      }

      // Check whether this method returns any value
      boolean hasReturnValue = (m.getReturnType () != void.class);

      if (evt.get (Context.OBJECTCONTENT) != null) {
        if (hasReturnValue) {
          args = (Vector) m.invoke (this, objs);
          resumeInterception (evt, args, interceptors);
        }
      }
      else {
        m.invoke (this, objs);
        resumeInterception (evt, null, interceptors);
      }
    } catch (Exception ex) {
      Hashtable msg = new Hashtable();
      msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
      msg.put (Context.TYPE, Context.EXCEPTION);
      msg.put (Context.METHOD, method);
      msg.put (Context.SOURCE_NODEHANDLE, (NodeHandle) evt.get (Context.SOURCE_NODEHANDLE));
      msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
      try {
        // Event is dispatched using the event service (response is sent to MANY objects)
        if (evt.get (Context.SOURCE_NODEHANDLE) == null) {
          dispatchEvent (msg, ex);
        }
        else {
          // Event is dispatched routing a direct message to stub source (response is sent to ONE object)
          dispatchDirectEvent (msg, ex);
        }
        dispatchEvent (msg, ex);
      } catch (RemoteException e2) {
        e2.printStackTrace();
      }
    }
  }

  /**
   * This method resumes the interception process throughout the server object
   * @param data Hashtable Event data
   * @param arguments Vector Method arguments
   * @param interceptors ArrayList Remaining interceptors list
   * @throws RemoteException If something goes wrong ;-)
   */
  public void resumeInterception (Hashtable data, Vector arguments, ArrayList interceptors) throws RemoteException {
    Hashtable evt = new Hashtable();
    evt.put (Context.OBJECTID, uid);
    evt.put (Context.TYPE, Context.DISPATCH);
    evt.put (Context.METHOD, data.get (Context.METHOD));
    evt.put (Context.SOURCE_NODEHANDLE, (NodeHandle) data.get (Context.SOURCE_NODEHANDLE));
    evt.put (Context.TIMESTAMP, (String) data.get (Context.TIMESTAMP));
    Vector args = new Vector();

    if (arguments != null) {
      // Add parameters (if any)
      for (Object obj : arguments) {
        args.add (obj);
      }
      evt.put (Context.OBJECTCONTENT, args);
    }
    conn.continueInterception (evt, interceptors);
  }

  /**
   * This method adds this instance as interceptor to the UID object
   * @throws RemoteException If something goes wrong ;-)
   */
  public void addInterceptor() throws RemoteException {
    try {
      Hashtable subs = new Hashtable();
      subs.put (Context.OBJECTID, uid);
      conn.addInterceptor (this, subs);
    } catch (SessionException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * This method removes this instance as interceptor from the UID object
   * @throws RemoteException If something goes wrong ;-)
   */
  public void removeInterceptor() throws RemoteException {
    try {
      Hashtable subs = new Hashtable();
      subs.put (Context.OBJECTID, uid);
      conn.removeInterceptor (subs);
    } catch (SessionException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Closes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void close() throws RemoteException {
    dermi.util.Bus.close();
  }

  /**
   * Initializes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void init() throws RemoteException {
    conn = dermi.util.Bus.getBus (eref);
  }

  /**
   * Returns a stub copy of this class
   * @throws RemoteException If something goes wrong ;-)
   * @return ERemote The returned stub
   */
  public ERemote copy() throws RemoteException {
    ERemote ref = dermi.registry.FileRegistry.loadStub(getERef());
    return (ERemote) ref;
  }

  private Method loadMethod (String methodName, Vector args) throws Exception {
    // Get class reference
    Class thisClass = this.getClass ();
    Class[] c = new Class[args.size ()];

    // Load class arguments array
    for (int i = 0; i < args.size(); i++) {
      c[i] = args.elementAt (i).getClass ();
    }

    Method m = null;

    // Find method to invoke
    try {
      m = thisClass.getMethod (methodName, c);
    }
    catch (NoSuchMethodException nse) {
      // try the same method using primitive types
      Method[] ms = thisClass.getMethods ();

      boolean found = false;
      for (Method mm : ms) {
        // Find method name
        if (mm.getName ().equals (methodName)) {
          // Equal number of input parameters?
          if (mm.getParameterTypes ().length == args.size ()) {
            // Check method signature
            Class[] cs = mm.getParameterTypes ();

            boolean argsOK = true;
            for (int i = 0; i < args.size (); i++) {
              try {
                if (!(basicTypes[findType (args.elementAt (i).getClass ().getName ())].equals (cs[i].getName ()))) {
                  argsOK = false;
                }
              }
              catch (TypeNotFoundException tnf) {
                continue;
              }
            }
            // Method signature OK: it is the same method with primitive types
            if (argsOK) {
              m = mm;
              found = true;
              break;
            }
          }
        }
      }
      if (!found) {
        throw nse;
      }
    }
    return m;
  }

  private int findType (String type) throws TypeNotFoundException {
    for (int i = 0; i < wrappers.length; i++) {
      if (wrappers[i].equals (type)) {
        return i;
      }
    }
    throw new TypeNotFoundException ("Primitive type " + type + " is unknown.");
  }
}

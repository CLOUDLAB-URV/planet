/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry;

import dermi.*;
import dermi.util.*;
import dermi.exception.*;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * Utility class for stub and interceptor loading (they are loaded from a file)
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class FileRegistry {

  /**
   * Returns a reference (stub) for the remote object associated with the specified file location.
   * @param fileName String Name of the properties file containing the object's location
   * @throws RemoteException If the connection with the event service fails
   * @return ERemote Reference to the remote object
   */
  public static ERemote loadERef (String fileName) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (fileName);
      Properties env = new Properties();
      env.loadFromXML (fis);
      String className = env.getProperty (Context.CLASS_NAME);
      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (className);

      Constructor theConstructor = theClass.getConstructor();
      ERemote ref = (ERemote) DermiProxy.newInstance (theConstructor.newInstance(), env);

      loader.close();
      return ref;
    } catch (FileNotFoundException e) {
      throw new RemoteException (e.getMessage());
    } catch (IOException e2) {
      throw new RemoteException (e2.getMessage());
    } catch (ClassNotFoundException e3) {
      throw new RemoteException (e3.getMessage());
    } catch (NoSuchMethodException e4) {
      throw new RemoteException (e4.getMessage());
    } catch (InstantiationException e5) {
      throw new RemoteException (e5.getMessage());
    } catch (IllegalAccessException e6) {
      throw new RemoteException (e6.getMessage());
    } catch (InvocationTargetException e7) {
      throw new RemoteException (e7.getMessage());
    }
  }

// AMB STUBS I SKELS ANAVA AQUEST
/*  public static ERemote loadERef (String fileName) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (fileName);
      Properties env = new Properties();
      env.load (fis);
      String className = env.getProperty (Context.CLASS_NAME);

      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (className);
      loader.close();

      Class params[] = new Class[1];
      params[0] = env.getClass();
      Constructor theConstructor = theClass.getConstructor (params);
      Object args[] = new Object[1];
      args[0] = env;
      ERemote ref = (ERemote) theConstructor.newInstance (args);
      return ref;
    } catch (FileNotFoundException e) {
      throw new RemoteException (e.getMessage());
    } catch (IOException e2) {
      throw new RemoteException (e2.getMessage());
    } catch (ClassNotFoundException e3) {
      throw new RemoteException (e3.getMessage());
    } catch (NoSuchMethodException e4) {
      throw new RemoteException (e4.getMessage());
    } catch (InstantiationException e5) {
      throw new RemoteException (e5.getMessage());
    } catch (IllegalAccessException e6) {
      throw new RemoteException (e6.getMessage());
    } catch (InvocationTargetException e7) {
      throw new RemoteException (e7.getMessage());
    }
  }
*/
  /**
   * Returns a reference (stub) for the remote object associated with the specified information in the properties Object.
   * @param env Properties Containing object location
   * @throws RemoteException If the connection with the event service fails
   * @return ERemote Reference to the remote object
   */
  public static ERemote loadERef (Properties env) throws RemoteException {
    try {
      String className = env.getProperty (Context.CLASS_NAME);
      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (className);
      loader.close();

      Constructor theConstructor = theClass.getConstructor();
      ERemote ref = (ERemote) DermiProxy.newInstance (theConstructor.newInstance(), env);
      return ref;
    } catch (ClassNotFoundException e3) {
      throw new RemoteException (e3.getMessage());
    } catch (NoSuchMethodException e4) {
      throw new RemoteException (e4.getMessage());
    } catch (InstantiationException e5) {
      throw new RemoteException (e5.getMessage());
    } catch (IllegalAccessException e6) {
      throw new RemoteException (e6.getMessage());
    } catch (InvocationTargetException e7) {
      throw new RemoteException (e7.getMessage());
    }
  }


// AMB STUBS I SKELS ANAVA AQUEST
/*  public static ERemote loadERef (Properties env) throws RemoteException {
    try {
      String className = env.getProperty (Context.CLASS_NAME);
      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (className);
      loader.close();

      Class params[] = new Class[1];
      params[0] = env.getClass();
      Constructor theConstructor = theClass.getConstructor (params);
      Object args[] = new Object[1];
      args[0] = env;
      ERemote ref = (ERemote) theConstructor.newInstance (args);
      return ref;
    } catch (ClassNotFoundException e3) {
      throw new RemoteException (e3.getMessage());
    } catch (NoSuchMethodException e4) {
      throw new RemoteException (e4.getMessage());
    } catch (InstantiationException e5) {
      throw new RemoteException (e5.getMessage());
    } catch (IllegalAccessException e6) {
      throw new RemoteException (e6.getMessage());
    } catch (InvocationTargetException e7) {
      throw new RemoteException (e7.getMessage());
    }
  }
*/

  /**
   * Returns a reference (stub) for the remote object associated with the specified information in the properties object.
   * The stub is not initialized and it is not connected to the event bus. This method is internally used to pass remote objects by reference.
   * @param env Properties Containing object location
   * @throws RemoteException If the connection with the event service fails.
   * @return ERemote Reference to the remote object (stub not initialized)
   */
  public static ERemote loadStub (Properties env) throws RemoteException {
    try	{
      String className = env.getProperty (Context.CLASS_NAME);

      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (className);
      loader.close();

      Constructor theConstructor = theClass.getConstructor();
      ERemote ref = (ERemote) DermiProxy.newInstance (theConstructor.newInstance(), env, new String());
      return ref;
    } catch (ClassNotFoundException e3) {
      throw new RemoteException (e3.getMessage());
    } catch (NoSuchMethodException e4) {
      throw new RemoteException (e4.getMessage());
    } catch (InstantiationException e5) {
      throw new RemoteException (e5.getMessage());
    } catch (IllegalAccessException e6) {
      throw new RemoteException (e6.getMessage());
    }catch (InvocationTargetException e7) {
      throw new RemoteException (e7.getMessage());
    }
  }


  /**
   * Returns a reference to an Interceptor that intercepts object calls to remote object instantiated with properties p.
   * @param p Properties Object's properties
   * @param intClass String Name of the interceptor class
   * @throws RemoteException If the connection to the event service fails.
   * @return EInterceptor Reference to the remote interceptor
   */
  public static EInterceptor loadInterceptor (Properties p, String intClass) throws RemoteException {
    try {
      Properties env = p;
      String uidf = UID.getUID();
      env.setProperty (Context.INTERCEPTOR_UID, uidf);

      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (intClass);
      loader.close();

      Class params[] = new Class[1];
      params[0] = env.getClass();
      Constructor theConstructor = theClass.getConstructor (params);
      Object args[] = new Object[1];
      args[0] = env;
      EInterceptor ref = (EInterceptor) theConstructor.newInstance (args);
      return ref;
    } catch (ClassNotFoundException ex1) {
      throw new RemoteException (ex1.getMessage());
    } catch (NoSuchMethodException ex2) {
      throw new RemoteException (ex2.getMessage());
    } catch (IllegalAccessException ex3) {
      throw new RemoteException (ex3.getMessage());
    } catch (InstantiationException ex4) {
      throw new RemoteException (ex4.getMessage());
    } catch (InvocationTargetException ex5) {
      throw new RemoteException (ex5.getMessage());
    }
  }

// EL QUE FUNCIONAVA ABANS AMB EL DOLR ES AQUEST!!!!
  /**
   * Returns a reference to an Interceptor that intercepts object calls to remote object objId in the registry.
   * @param objId String Object's name in the registry
   * @param intClass String Name of the interceptor class
   * @throws RemoteException If the connection to the event service fails.
   * @return EInterceptor Reference to the remote interceptor
   */
/*  public static EInterceptor loadInterceptor (String objId, String intClass) throws RemoteException {
    try {
      ERemote cl = (ERemote) Naming.lookup (objId);
      cl.close();

      Properties env = cl.getERef();
      String uidf = UID.getUID();
      env.setProperty (Context.INTERCEPTOR_UID, uidf);

      BusClassLoader loader = new BusClassLoader (env);
      Class theClass = loader.loadClass (intClass + "Skel");
      loader.close();

      Class params[] = new Class[1];
      params[0] = env.getClass();
      Constructor theConstructor = theClass.getConstructor (params);
      Object args[] = new Object[1];
      args[0] = env;
      EInterceptor ref = (EInterceptor) theConstructor.newInstance (args);
      return ref;
    } catch (ClassNotFoundException ex1) {
      throw new RemoteException (ex1.getMessage());
    } catch (NoSuchMethodException ex2) {
      throw new RemoteException (ex2.getMessage());
    } catch (IllegalAccessException ex3) {
      throw new RemoteException (ex3.getMessage());
    } catch (InstantiationException ex4) {
      throw new RemoteException (ex4.getMessage());
    } catch (InvocationTargetException ex5) {
      throw new RemoteException (ex5.getMessage());
    }
  } */
}

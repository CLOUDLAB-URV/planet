/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry;

import dermi.*;
import dermi.util.*;

import java.io.*;
import java.util.*;

/**
 * This class encapsulates a record in the registry
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class RegistryRecord implements Serializable {
  static final long serialVersionUID = 10L;

  // Object properties
  private Properties props;

  /**
   * Constructor
   * @param ref Properties Object properties
   */
  public RegistryRecord (Properties ref) {
    props = ref;
  }

  /**
   * Get object's URI
   * @return String Object's URI
   */
  public String getObjectURI() {
    return props.getProperty (Context.DERMI_DOLR_UNIQUE_URI);
  }

  /**
   * Get object's name
   * @return String Object's name
   */
  public String getObjectName() {
    String objectName = null;
    StringTokenizer tokens = new StringTokenizer (props.getProperty (Context.DERMI_DOLR_UNIQUE_URI));
    while (tokens.hasMoreTokens()) {
      objectName = tokens.nextToken();
    }
    return objectName;
  }

  /**
   * Get object's children in the hierarchy
   * @return Collection Object's children
   */
  public Collection getChildren() {
    return (Collection) props.get (Context.DERMI_DOLR_CHILDREN);
  }

  /**
   * Get all object's properties
   * @return Properties Object's properties
   */
  public Properties getProperties() {
    return props;
  }
}

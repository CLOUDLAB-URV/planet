/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry.pastry;

import java.io.*;
import java.util.*;

import bunshin.util.*;
import dermi.*;
import dermi.core.*;
import dermi.util.*;
import dermi.exception.*;
import dermi.registry.*;
import dermi.util.*;
import dermi.util.pastry.*;

/**
 * The Naming class provides methods for storing and obtaining references to remote objects
 * in the remote object registry.<br><br>
 * The dermi.Naming API (unlike Java RMI) does not use URLs, but properties objects or files
 * containing connection parameters. It is then mandatory to call the <i>loadRegistry</i> method
 * before using the functionality of the registry.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar
 * @version 1.2
 */
public class Naming implements dermi.registry.Naming {
  // Singleton
  private static Naming instance;

  private static Registry registry = null;
  private static DermiConnection connection = null;

  // Singleton design pattern
  private Naming() {
  }

  // Singleton design pattern
  public static Naming getInstance() {
    if (instance == null) {
      return new Naming ();
    }
    else {
      return instance;
    }
  }

  /**
   * It connects to the decentralized registry
   * @param FACTORY IdFactory Factory for Id creation
   * @param conn DermiConnection The Dermi node where the registry will run on
   * @param REPLICATION_FACTOR int Replication factor
   * @throws RemoteException If registry cannot be created
   */
  public void loadRegistry (rice.p2p.commonapi.IdFactory FACTORY, DermiConnection conn, int REPLICATION_FACTOR) throws RemoteException {
    if (registry == null) {
      registry = new Registry (FACTORY, (rice.p2p.commonapi.Node) conn.getLocalNode(), REPLICATION_FACTOR);
      connection = conn;
      connection.loadActivator();
    }
  }

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public void loadRegistry (String ref) throws RemoteException {
    if (registry == null) {
      try {
        FileInputStream fis = new FileInputStream (ref);
        Properties env = new Properties();
        env.loadFromXML (fis);
        String hostName = env.getProperty (Context.PROVIDER_HOST);
        int port = (new Integer (env.getProperty (Context.PROVIDER_PORT))).intValue();

        Class[] cl = {Object[].class};
        Object[] objs1 = {hostName, port, null, new Integer (env.getProperty (Context.PROTOCOL))};
        Object[] objs = {objs1};
        String className = "dermi.core." + env.getProperty (Context.UNDERLYING_DHT) + ".DermiConnection";
        connection = (DermiConnection) Class.forName (className).getConstructor (cl).newInstance (objs);

        // Necessary time to allow correct initialization
        Thread.currentThread().sleep (5000);
      } catch (Exception e) {
        e.printStackTrace();
        throw new RemoteException (e.getMessage ());
      }
    }
  }

  /**
   * It closes the connection and kills the node
   * @throws RemoteException If the connection with the event service fails.
   */
  public void leave() throws RemoteException {

  	registry.leave();

  	//waiting while the registry executes the leave method
  	try {
  	  Thread.sleep(2000);
  	}
    catch (InterruptedException ex) {}

  	//connection.close();
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (name);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name, String communityId, String className) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (connection, name, communityId, className);
  }

  /**
   * Returns a serializable object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Serializable Object's reference
   */
  public Serializable lookupSer (Id id) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup ((dermi.core.Id) id);
  }

  public Serializable lookupSer (String componentURL) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (HashGenerator.generateHash (componentURL));
  }

  /**
   * Method used to know if the registry is already connected to a Pastry node
   * @return boolean true if it is connected
   */
  public boolean isConnected () {
    return (connection != null);
  }

  /**
   * Method used to get the connection to the Pastry node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public DermiConnection getConnection() {
    return connection;
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, ERemote ref) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.bind (name, ref.getERef());
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties env) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.bind (name, env);
  }

  public void bindSer (dermi.core.Id id, Serializable object) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.insert (id, object, true);
  }

  /**
   * Unbinds the specified  name from a remote object.
   * @param name Id of the remote object
   * @throws dermi.NotBoundException - if the Registry does not contains this Id.
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
     public void unbind (String name) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.unbind (name);
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bindRoot() throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    // System.out.println ("[DERMI REGISTRY] - Looking for base root...");
    try {
      Properties p = (Properties) registry.lookup (HashGenerator.generateHash ("p2p://"));

    } catch (NotBoundException ne) {
      // System.out.println ("[DERMI REGISTRY] - Base root not bound... Binding 'p2p://'");
      Properties p = new Properties();
      p.setProperty (Context.DERMI_DOLR_UNIQUE_URI, "p2p://");
      p.put (Context.DERMI_DOLR_CHILDREN, new ArrayList<Properties>());
      registry.insert (HashGenerator.generateHash ("p2p://"), p, true);
    }
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void rebind (String name, ERemote ref) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.rebind (name, ref.getERef());
  }

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public Collection list (String root) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.list(root);
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand implements rice.Continuation {
    boolean received;
    Properties eref;

    public NamingCommand (boolean received, Properties eref) {
      this.received = received;
      this.eref = eref;
    }

    public void receiveResult (Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}

    public void receiveException(Exception e) {
      e.printStackTrace();
      System.out.println ("receiveException on NamingCommand");
    }
  }

  /* DERMI SEARCH METHODS */

  public void insert(String keywords, String key, Serializable value)  throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    registry.insert (keywords,key,value);
  }

  public ResultSortedQueue query(String keywords)  throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    return registry.query (keywords);
  }

  public void remove(String keywords, String key) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.remove(keywords,key);
  }
}

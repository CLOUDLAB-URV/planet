/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry;

import java.io.*;
import java.util.*;

import bunshin.util.*;
import dermi.*;
import dermi.core.*;
import dermi.exception.*;

/**
 * Interface to the Naming class. It follows the singleton design pattern.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public interface Naming {

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public void loadRegistry (String ref) throws RemoteException;

  /**
  * It closes the connection and kills the node
  * @throws RemoteException If the connection with the event service fails.
  */
  public void leave() throws RemoteException;

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException;

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name, String communityId, String className) throws RemoteException;

  /**
   * Returns a serializable object associated with the specified name.
   * @param String object's url
   * @throws RemoteException If the connection with the event service fails.
   * @return Serializable Object's value
   */
  public Serializable lookupSer (Id id) throws RemoteException;

  /**
   * Returns a serializable object associated with the specified name.
   * @param String object's url
   * @throws RemoteException If the connection with the event service fails.
   * @return Serializable Object's value
   */
  public Serializable lookupSer (String componentURL) throws RemoteException;

  /**
   * Method used to know if the registry is already connected to a node
   * @return boolean true if it is connected
   */
  public boolean isConnected ();

  /**
   * Method used to get the connection to the node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public DermiConnection getConnection();

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, ERemote ref) throws RemoteException;

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties env) throws RemoteException;

   /**
   * Unbinds the specified name from a remote object.
   * @param name Id of the remote object
   * @throws RemoteException If the connection with the event service fails.
   */
  public void unbind (String name) throws RemoteException;



  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bindRoot() throws RemoteException;

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void rebind (String name, ERemote ref) throws RemoteException;

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public Collection list (String root) throws RemoteException;

  public void bindSer (dermi.core.Id id, Serializable object) throws RemoteException;

  /* DERMI SEARCH METHODS */

  public void insert (String keywords, String key, Serializable value) throws RemoteException;

  public ResultSortedQueue query (String keywords)  throws RemoteException;

  public void remove (String keywords, String key) throws RemoteException;

}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.*;
import dermi.util.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.registry.FileRegistry;
import dermi.core.NodeHandle;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.logging.*;

/**
 * This class implements the generic skeleton class for any Dermi object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public abstract class DermiRemoteObject extends EventServer implements RemoteEventListener {
  private Hashtable msg = new Hashtable();
  private Hashtable subs = new Hashtable();
  private Hashtable receivedEvents = new Hashtable();
  private boolean exception = false;

  // This attribute marks if this is a replicated object
  private boolean isStatefulReplica = false;

  // This attribute marks the replica's state as up to date or not
  private boolean isReplicaReady = false;

  // Primitive types and their wrappers
  private String[] basicTypes = {"int", "char", "double", "float", "long", "boolean", "byte", "short"};
  private String[] wrappers = {"java.lang.Integer", "java.lang.Character", "java.lang.Double", "java.lang.Float", "java.lang.Long", "java.lang.Boolean", "java.lang.Byte", "java.lang.Short"};

  protected transient Logger logger = Logger.getLogger (this.getClass().getName());

  /**
   * Local constructor: Entry point to the skeleton class
   */
  public DermiRemoteObject() { }

  /**
   * Constructor: Entry point to the skeleton class
   * @param env Properties Environment properties
   * @throws RemoteException When something goes wrong ;-)
   */
  public DermiRemoteObject (Properties env) throws RemoteException {
    super (env);
    className = this.getClass().getName();
    uid = dermi.util.UID.getUID();

    // If this is a replica, the UID will come from the environment properties
    if (env.getProperty (Context.CLASS_NAME).equals (className)) {
      if (env.getProperty (Context.CLASS_ID) != null) {
        uid = env.getProperty (Context.CLASS_ID);
      }
    }
    subs.put (Context.OBJECTID, uid);
    try {
      conn.subscribe (this, subs);

      // TODO: Implement this over the DOLR service (!!)
      storeNodeHandle();
    } catch (Exception e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * This method starts load replica state mechanism
   * @throws RemoteException If replica state cannot be loaded
   */
  protected void loadReplicaState() throws RemoteException {
    // Check whether this object is to be replicated (statefully)
    Class[] interfaces = this.getClass().getInterfaces();
    for (int i = 0; i < interfaces.length; i++) {
      if ((interfaces[i].getName()).contains ("StatefulReplica")) {
        isStatefulReplica = true;
        // Get state from any of the replicas (if none, default value)
        getReplicaState();
      }
    }
  }

  /**
   * Stores server's NodeHandle on disk (used by the FileRegistry)
   * @throws RemoteException
   */
  private void storeNodeHandle() throws RemoteException {
    try {
      FileOutputStream fos = new FileOutputStream ("nodehandle.data");
      ObjectOutputStream bo = new ObjectOutputStream (fos);
      logger.fine ("Server NodeHandle = " + conn.getLocalNodeHandle());
      bo.writeObject (conn.getLocalNodeHandle());
    }
    catch (Exception e) {
      throw new RemoteException ("Impossible to store node handle in the File Registry.");
    }
  }

  /**
   * Method for obtaining the object's state from any of the available replicas
   */
  public void getReplicaState() throws RemoteException {
    // Wait a certain time for joining to be complete
    try {
      Thread.sleep (1000);
    } catch (Exception e) {}
    // If replica, we must update our status
    try {
      Method m = this.getClass().getMethod ("loadRemoteObjectState");
      m.invoke (this, (Object[]) null);
    } catch (Exception e) {
      if (e instanceof InvocationTargetException)
       if (((InvocationTargetException) e).getTargetException() instanceof NotSatisfiedException) {
        // Unable to load replica state: assume it is the first replica
        isReplicaReady = true;
      }
      else {
        throw new RemoteException (e.getMessage ());
      }
    }
  }

  /**
   * Method invoked each time the skeleton receives an event
   * @param evt Hashtable Information about the received event
   */
  public void eventArrived (Hashtable evt) {
    String method = (String) evt.get (Context.METHOD);

    // Dynamic class loading method
    if (method.equals ("getBytes")) {
      try {
        String fileClass = classStore + className;
        byte data[] = getBytes (fileClass);
        Hashtable msg = new Hashtable ();
        msg.put (Context.OBJ, uid + Context.APPEND_RESULT_DYNAMIC);
        msg.put (Context.TYPE, Context.DISPATCH);
        msg.put (Context.METHOD, "getBytes");
        msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
        dispatchEvent (msg, data);
      }
      catch (IOException ex1) {
        Hashtable msg = new Hashtable ();
        msg.put (Context.OBJ, uid + Context.APPEND_RESULT_DYNAMIC);
        msg.put (Context.TYPE, Context.EXCEPTION);
        msg.put (Context.METHOD, "getBytes");
        msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
        try {
          dispatchEvent (msg, ex1);
        }
        catch (RemoteException e2) {
          e2.printStackTrace ();
        }
      }
      catch (RemoteException ex2) {
        ex2.printStackTrace ();
      }

    }
    else {
      try {
        if (!isStatefulReplica || method.equals ("getRemoteObjectState") || (isStatefulReplica && isReplicaReady)) {
          if (method.equals ("getRemoteObjectState")) {
            receivedEvents.put ("loadState" + evt.get (Context.TIMESTAMP), evt.get (Context.OBJECTCONTENT));
            if (((String) evt.get (Context.TYPE)).equals (Context.EXCEPTION)) {
              exception = true;
            }
            return;
          }

          Vector args = (Vector) evt.get (Context.OBJECTCONTENT);

          if (args == null) {
            args = new Vector ();
          }
          Method m = loadMethod (method, args);

          Object[] objs = new Object[args.size ()];

          // Load object arguments array
          for (int i = 0; i < args.size (); i++) {
            objs[i] = args.elementAt (i);
          }

          // Check whether this method returns any value
          boolean hasReturnValue = (m.getReturnType () != void.class);
          Object res = null;

          if (hasReturnValue) {
            if (receivedEvents.get (method + evt.get (Context.TIMESTAMP)) != null) {
              res = receivedEvents.get (method + evt.get (Context.TIMESTAMP));
            }
            else {
              // Method is invoked
              res = m.invoke (this, objs);
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), res);
            }
          }
          else {
            if (receivedEvents.get (method + evt.get (Context.TIMESTAMP)) == null) {
              m.invoke (this, objs);
              receivedEvents.put (method + (evt.get (Context.TIMESTAMP)), new Integer ( -1));
            }
          }

          Hashtable msg = new Hashtable ();
          msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
          msg.put (Context.TYPE, Context.DISPATCH);
          msg.put (Context.METHOD, method);
          msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
          if (hasReturnValue) {
            msg.put (Context.OBJECTCONTENT, res);
          }
          try {
            // Event is dispatched using the event service (response is sent to MANY objects)
            if (evt.get (Context.SOURCE_NODEHANDLE) == null) {
              dispatchEvent (msg);
            }
            else {
              // Event is dispatched routing a direct message to stub source (response is sent to ONE object)
              msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              dispatchDirectEvent (msg);
            }
          }
          catch (RemoteException e2) {
            e2.printStackTrace ();
          }
        }
      } catch (Exception eex) {
        Exception ex = null;
        if (eex instanceof InvocationTargetException) {
          ex = (Exception) ((InvocationTargetException) eex).getTargetException ();
        }
        else {
          ex = eex;
        }
        Hashtable msg = new Hashtable ();
        msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
        msg.put (Context.TYPE, Context.EXCEPTION);
        msg.put (Context.METHOD, method);
        msg.put (Context.TIMESTAMP, (String) evt.get (Context.TIMESTAMP));
        receivedEvents.put (method + evt.get (Context.TIMESTAMP), ex);
        try {
          // Event is dispatched using the event service (response is sent to MANY objects)
          if (evt.get (Context.SOURCE_NODEHANDLE) == null) {
            dispatchEvent (msg, ex);
          }
          else {
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            // Event is dispatched routing a direct message to stub source (response is sent to ONE object)
            dispatchDirectEvent (msg, ex);
          }
        } catch (RemoteException e2) {
          e2.printStackTrace ();
        }
      }
      }
  }

  /**
   * Method invoked each time the skeleton receives an anycall event
   * @param evt Hashtable Information about the received event
   */
  public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
    String method = (String) evt.get (Context.METHOD);
    Vector args = (Vector) evt.get (Context.OBJECTCONTENT);

    try {
      if (method.equals ("getRemoteObjectState")) {
        Serializable res = null;
        Hashtable oldEvent = (Hashtable) receivedEvents.get (method + evt.get (Context.TIMESTAMP));
        if (oldEvent != null) {
          return oldEvent;
        }
        else {
          // Replica's state must not be stale
          if (isReplicaReady) {
            Method m = loadMethod (method, args);
            res = (Serializable) m.invoke (this, (Object[]) null);
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJECTID, uid);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.OBJECTCONTENT, res);
            msg.put (Context.REPLICA, new Boolean (true));
            msg.put (Context.ANYCALL_RESULT, new Boolean (false));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            return msg;
          }
          else {
            // Replica's state is stale, message is routed to another member of the replica group
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJECTID, uid);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.OBJECTCONTENT, evt.get (Context.OBJECTCONTENT));
            msg.put (Context.REPLICA, new Boolean (true));
            msg.put (Context.RESULT, Context.VOID);
            msg.put (Context.ANYCALL_RESULT, new Boolean (true));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            return msg;
          }
        }
      }
      else {
      Method m = loadMethod (method, args);
      Method conditionMethod = loadMethod (method + "Condition", args);
      Method globalConditionMethod = null;
      try {
        globalConditionMethod = loadMethod (method + "GlobalCondition", args);
      } catch (Exception e) {
        // Method unavailable: anycall. If available we are dealing with a manycall.
      }

      Object[] objs = new Object[args.size ()];

      // Load object arguments array
      for (int i = 0; i < args.size (); i++) {
        objs[i] = args.elementAt (i);
      }

      // Check whether this method returns any value
      boolean hasReturnValue = (m.getReturnType () != void.class);

      Object res = null;

      Hashtable oldEvent = (Hashtable) receivedEvents.get (method + evt.get (Context.TIMESTAMP));
      if (oldEvent != null) {
        return oldEvent;
      }
      else {
        // Check for local condition
        if (((Boolean) conditionMethod.invoke (this, objs)).booleanValue()) {
          if (globalConditionMethod != null) {
            // Manycall
            res = m.invoke (this, objs);
            Object[] tempArgs = (Object[]) objs.clone();
            objs[0] = res;
            if (((Boolean) globalConditionMethod.invoke (this, objs)).booleanValue()) {
              // Global condition met, returning results
              Hashtable msg = new Hashtable();
              msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
              msg.put (Context.TYPE, Context.DISPATCH);
              msg.put (Context.METHOD, method);
              msg.put (Context.ANYCALL_RESULT, new Boolean (false));
              msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
              msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
              if (hasReturnValue) {
                msg.put (Context.OBJECTCONTENT, res);
              }
              return msg;
            }
            else {
              // Global condition not met, message will be routed to another member of the group
              Hashtable evt2 = (Hashtable) evt.clone();
              Vector args2 = new Vector();
              args2.add (res);

              // Add parameters (if any)
              if (args != null) {
                for (int i = 1; i < args.size(); i++) {
                  args2.add (args.elementAt (i));
                }
              }
              evt2.put (Context.STATUS, Context.MANYCALL);
              evt2.put (Context.ANYCALL_RESULT, new Boolean (true));
              evt2.put (Context.OBJECTCONTENT, args2);
              evt2.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
              evt2.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
              receivedEvents.put (method + evt.get (Context.TIMESTAMP), evt2);
              return evt2;
            }
          }
          else {
            // Anycall (local condition met)
            res = m.invoke (this, objs);
            Hashtable msg = new Hashtable();
            msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
            msg.put (Context.TYPE, Context.DISPATCH);
            msg.put (Context.METHOD, method);
            msg.put (Context.ANYCALL_RESULT, new Boolean (false));
            msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
            msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
            receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
            if (hasReturnValue) {
              msg.put (Context.OBJECTCONTENT, res);
            }
            return msg;
          }
        }
        else {
          // Local condition not met, message will be routed to another member of the group
          Hashtable msg = new Hashtable();
          msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
          msg.put (Context.TYPE, Context.DISPATCH);
          msg.put (Context.METHOD, method);
          if (globalConditionMethod != null) {
            msg.put (Context.OBJECTCONTENT, args);
          }
          else {
            msg.put (Context.OBJECTCONTENT, evt.get (Context.OBJECTCONTENT));
          }
          msg.put (Context.RESULT, Context.VOID);
          msg.put (Context.ANYCALL_RESULT, new Boolean (true));
          msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
          msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
          receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
          return msg;
        }
      }
      }
    } catch (Exception eex) {
      Exception ex = null;
      if (eex instanceof InvocationTargetException) {
        ex = (Exception) ((InvocationTargetException) eex).getTargetException ();
      }
      else if (eex instanceof NoSuchMethodException) {
        ex = new UnmatchedAnycallMethodException (method);
      }
      else {
        ex = eex;
      }
      Hashtable msg = new Hashtable();
      msg.put (Context.OBJ, uid + Context.APPEND_RESULT);
      msg.put (Context.TYPE, Context.EXCEPTION);
      msg.put (Context.METHOD, method);
      msg.put (Context.OBJECTCONTENT, ex);
      msg.put (Context.ANYCALL_RESULT, new Boolean (false));
      msg.put (Context.TIMESTAMP, evt.get (Context.TIMESTAMP));
      msg.put (Context.SOURCE_NODEHANDLE, evt.get (Context.SOURCE_NODEHANDLE));
      receivedEvents.put (method + evt.get (Context.TIMESTAMP), msg);
      return msg;
    }
  }

  /**
   * This method triggers an event (used in listeners)
   * @param res Serializable The event to trigger
   * @throws RemoteException If something goes wrong ;-)
   */
  public void triggerEvent (Serializable res) throws RemoteException {
    Hashtable msg = new Hashtable();
    msg.put (Context.OBJ, uid + ":RESULT:" + res.getClass().getName());
    msg.put (Context.TYPE, Context.DISPATCH);
    try {
      dispatchEvent (msg, res);
    } catch (RemoteException e2) {
      e2.printStackTrace();
    }
  }

  /**
   * This method is used for a not updated replica in order to obtain
   * the object's state
   */
  public Serializable loadState() throws RemoteException {
    int timeout = 0;
    // Set timestamp for this event and its possible retransmissions
    String tstamp = "" + System.currentTimeMillis();
    String method2 = "getRemoteObjectState";
    String method = "loadState";

    for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
      Hashtable evt = new Hashtable();
      evt.put (Context.OBJECTID, uid);
      evt.put (Context.TYPE, Context.DISPATCH);
      evt.put (Context.METHOD, method2);
      evt.put (Context.TIMESTAMP, tstamp);
      evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
      evt.put (Context.OBJECTCONTENT, new Vector());
      try {
        conn.anycall (evt);
      }
      catch (SessionException ex1) {
        throw new RemoteException (ex1.getMessage());
      }
      timeout = 0;
      while (!contains (receivedEvents, method + tstamp) && timeout < Context.TIMEOUT) {
        try {
          Thread.currentThread().sleep (Context.DELAY);
        } catch (InterruptedException ex) {
          ex.printStackTrace();
        }
        timeout++;
      }
      if (exception) {
        exception = false;
        Exception ex = (Exception) receivedEvents.get (method + tstamp);

        if (ex instanceof RemoteException) {
          throw (RemoteException) ex;
        }

        throw new RemoteException (ex.getMessage());
      } else if (timeout == Context.TIMEOUT) {
        retransmission++;
        continue;
      }
      break;
    }
    if (timeout == Context.TIMEOUT) {
      throw new TimeoutException ("Object seems to be down.");
    }
    else {
      // Replica's state now up to date
      isReplicaReady = true;
      logger.info ("Object's state restored from replica.");

      return (Serializable) receivedEvents.get (method + tstamp);
    }
  }

  /**
   * Closes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void close() throws RemoteException {
    try {
      conn.unsubscribe (this, subs);
      dermi.util.Bus.close();
    } catch (SessionException e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * Initializes the skeleton
   * @throws RemoteException If something goes wrong ;-)
   */
  public void init() throws RemoteException {
    conn = dermi.util.Bus.getBus (eref);
    try {
      conn.subscribe (this, subs);
    } catch (SessionException e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * Returns a stub copy of this class
   * @throws RemoteException If something goes wrong ;-)
   * @return ERemote The returned stub
   */
  public ERemote copy() throws RemoteException {
    ERemote ref = FileRegistry.loadStub (getERef());
    return (ERemote) ref;
  }

  private Method loadMethod (String methodName, Vector args) throws Exception {
    // Get class reference
    Class thisClass = this.getClass ();
    Class[] c = new Class[args.size ()];

    // Load class arguments array
    for (int i = 0; i < args.size(); i++) {
      c[i] = args.elementAt (i).getClass ();
    }

    Method m = null;

    // Find method to invoke
    try {
      m = thisClass.getMethod (methodName, c);
    }
    catch (NoSuchMethodException nse) {
      // try the same method using primitive types
      Method[] ms = thisClass.getMethods ();

      boolean found = false;
      for (Method mm : ms) {
        // Find method name
        if (mm.getName ().equals (methodName)) {
          // Equal number of input parameters?
          if (mm.getParameterTypes ().length == args.size ()) {
            // Check method signature
            Class[] cs = mm.getParameterTypes ();

            boolean argsOK = true;
            for (int i = 0; i < args.size (); i++) {
              try {
                if (!(basicTypes[findType (args.elementAt (i).getClass ().getName ())].equals (cs[i].getName ()))) {
                  argsOK = false;
                }
              }
              catch (TypeNotFoundException tnf) {
                continue;
              }
            }
            // Method signature OK: it is the same method with primitive types
            if (argsOK) {
              m = mm;
              found = true;
              break;
            }
          }
        }
      }
      if (!found) {
        throw nse;
      }
    }
    return m;
  }

  private int findType (String type) throws TypeNotFoundException {
    for (int i = 0; i < wrappers.length; i++) {
      if (wrappers[i].equals (type)) {
        return i;
      }
    }
    throw new TypeNotFoundException ("Primitive type " + type + " is unknown.");
  }

  // Utility method
  private boolean contains (Hashtable results, String tstamp) {
    Iterator i = results.keySet().iterator();
    while (i.hasNext()) {
      Object ob = i.next();
      if (results.get (tstamp) != null) {
        return true;
      }
    }
    return false;
  }
}

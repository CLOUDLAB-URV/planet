/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.util;

import java.util.Properties;

import dermi.*;
import dermi.exception.*;

/**
 * This class encapsulates the bus used by the Session object
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class Bus {
  public static Session bus = null;
  public static int count = 0;

  /**
   * Creates a session and obtains a reference to the event bus
   * @param env Properties Environment properties
   * @throws RemoteException If something goes wrong ;-)
   * @return Session Recently created session
   */
  public static Session getBus (Properties env) throws RemoteException {
    if (bus == null) {
      count++;
      try {
        bus = SessionFactory.createSession (env);
      } catch (SessionException e1) {
        throw new ConnectionException (e1.getMessage());
      }
    }
    else {
      count++;
    }
    return bus;
  }

  /**
   * Closes the session with the current event bus
   */
  public static void close() {
    count--;
    if (count <= 0) {
      try {
        bus.close();
        bus = null;
        count = 0;
      } catch (SessionException e1) {
        e1.getException().printStackTrace();
      }
    }
  }

  /**
   * This method returns the fully qualified class name for a class
   * @param className String the class
   * @return String the fully qualified name of the class
   */
  public static String getClassName (String className) {
    try {
      Class theClass = Class.forName (className);
      Package pac = theClass.getPackage();

      if (pac != null) {
        int length1 = pac.getName().length();
        String cls = className.substring (length1 + 1, className.length());
        return cls;
      }
      else {
        return className;
      }
    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
    return null;
  }
}

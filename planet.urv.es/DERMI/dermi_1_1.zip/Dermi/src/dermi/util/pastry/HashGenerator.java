/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.util.pastry;

import dermi.core.*;
import dermi.util.Context;

import java.util.*;
import java.util.logging.*;
import java.security.*;

/**
 * Utility class for generating SHA-1 hashes
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class HashGenerator {
  private static transient Logger logger = Logger.getLogger (HashGenerator.class.getName());

  /**
   * Generates a hash for the keys contained in the hashtable
   * @param data Hasthable containing the keys
   * @return The NodeId hash object
   */
  public static Id generateHash (Hashtable data) {
    MessageDigest md = null;

    try {
      md = MessageDigest.getInstance ("SHA");
    }
    catch (NoSuchAlgorithmException e) {
      logger.severe ("No SHA support!");
    }

    Iterator i = data.keySet().iterator();

    String keys = "";

    while (i.hasNext()) {
      keys += (String) i.next();
    }

    logger.fine ("[generateHash - KeyString] = " + keys);
    md.update(keys.getBytes());
    byte[] digest = md.digest();

    Id newId = new dermi.core.pastry.Id (digest);

    return newId;
  }

  /**
   * Generates a hash for the specified string
   * @param data String to be hashed
   * @return The NodeId hash object
   */
  public static Id generateHash (String data) {
    MessageDigest md = null;

    try {
      md = MessageDigest.getInstance ("SHA");
    }
    catch (NoSuchAlgorithmException e) {
      logger.severe ("No SHA support!");
    }

    md.update(data.getBytes());
    byte[] digest = md.digest();

    Id newId = new dermi.core.pastry.Id (digest);

    return newId;
  }

  /**
   * Helper method to generate a hash for the keys contained in the hashtable
   *
   * @param data Hasthable containing the keys
   *
   * @return The NodeId hash object
   */
  public static Id generateSessionHash (Hashtable data) {
    MessageDigest md = null;

    try {
      md = MessageDigest.getInstance ("SHA");
    } catch (NoSuchAlgorithmException e) {
      logger.severe ("No SHA support!");
    }

    String keys = "";
    if (data.containsKey ("subject")) {
      keys = "subject_" + (String)data.get("subject");
    }
    else if (data.containsKey (Context.OBJECTID)) {
      keys = Context.OBJECTID + "_" + (String) data.get (Context.OBJECTID);
    }
    else if (data.containsKey (Context.OBJ)) {
      keys = Context.OBJ + "_" + (String) data.get (Context.OBJ);
    }
    else {
      Iterator i = data.keySet().iterator();

      while (i.hasNext()) {
        keys += (String) i.next() + "_";
      }
    }

    md.update (keys.getBytes());
    byte[] digest = md.digest();

    Id newId = new dermi.core.pastry.Id (digest);
    return newId;
  }

  /**
   * Helper method to generate an id string
   *
   * @param data hashtable containing object data
   *
   * @return string containing object id
   */
  public static String generateKeyId (Hashtable data) {
    String keys = "";
    if (data.containsKey (Context.OBJECTID)) {
      keys = Context.OBJECTID + "_" + (String) data.get (Context.OBJECTID);
    }
    else if (data.containsKey (Context.OBJ)) {
      keys = Context.OBJ + "_" + (String) data.get (Context.OBJ);
    }
    else {
      Iterator i = data.keySet().iterator();

      while (i.hasNext()) {
        keys += (String) i.next() + "_";
      }
    }

    return keys;
  }
}

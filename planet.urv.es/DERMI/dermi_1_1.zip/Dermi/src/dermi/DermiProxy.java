/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.util.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.lang.reflect.*;

/**
 * This class is the Dynamic Proxy that replaces all static stubs that had to be pregenerated
 * in previous versions of Dermi using the 'dermic' tool
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class DermiProxy extends EventServer implements InvocationHandler, RemoteEventListener {
  // Proxy's object implementation
  private Object obj;

  // Private variables
  private Hashtable subs = new Hashtable();
  private Hashtable results = new Hashtable();
  private boolean exception = false;
  private String method;
  private int timeout;
  private HashSet receivedEvents = new HashSet();
  private int listenerCount = 0;
  private Vector listeners = new Vector();

  protected transient Logger logger = Logger.getLogger (this.getClass().getName());

  // Provisional: for direct calls (reference is not yet obtained using DOLR!)
  private dermi.core.NodeHandle serverNh;

  /**
   * This method returns a new instance of a DermiProxy
   * @param obj Object Object to be intercepted by the proxy
   * @param props Properties Object's initialization properties
   * @return Object Proxy instance
   */
  public static Object newInstance (Object obj, Properties props) {
    DermiProxy p = new DermiProxy (obj);
    p.start (props);
    return java.lang.reflect.Proxy.newProxyInstance (obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), p);
  }

  /**
   * This method returns a new instance of a DermiProxy
   * @param obj Object Object to be intercepted by the proxy
   * @param props Properties Object's initialization properties
   * @return Object Proxy instance
   */
  public static Object newInstance (Object obj, Properties props, String s) {
    DermiProxy p = new DermiProxy (obj);
    p.start (props, s);
    return java.lang.reflect.Proxy.newProxyInstance (obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), p);
  }

  /**
   * Default constructor: private access only
   * @param obj Object Object to be intercepted by the proxy
   */
  private DermiProxy (Object obj) {
    this.obj = obj;
  }

  /**
   * Internal method for initializing proxy's internal object
   * @param env Properties Object initialization properties
   */
  protected void start (Properties env) {
    try {
      super.start (env);
      String muid = env.getProperty (Context.CLASS_ID);
      uid = muid;
      subs.put (Context.OBJ, uid + Context.APPEND_RESULT);
      conn.subscribe (this, subs);

      // Provisional: Direct calls should use DOLR!!!
      try {
        FileInputStream fos = new FileInputStream ("nodehandle.data");
        ObjectInputStream bo = new ObjectInputStream (fos);
        serverNh = (dermi.core.NodeHandle) bo.readObject();

        // VERY UGLY (AND SPECIFIC TO PASTRY!!!)
        ((rice.pastry.NodeHandle) serverNh).setLocalNode ((rice.pastry.PastryNode) conn.getLocalNode());
      } catch (Exception e) {
        e.printStackTrace();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Constructor: entry point to the stub class
   * @param env Properties Environment properties
   * @param stub String Stub name
   * @throws RemoteException If something goes wrong ;-)
   */
  protected void start (Properties env, String stub) {
    try {
      super.start (env);
      String muid = env.getProperty (Context.CLASS_ID);
      uid = muid;
      subs.put (Context.OBJ, uid + Context.APPEND_RESULT);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * This method is called by the Proxy before invoking the interface method
   * @param proxy Object Proxy class object
   * @param m Method Method to invoke
   * @param arguments Object[] Arguments packed in an object array
   * @throws Throwable
   * @return Object Invocation result
   */
  public Object invoke (Object proxy, Method m, Object[] arguments) throws Throwable {
    Object result = null;
    try {
      // Dermi object internal methods
      if (m.getName().equals ("init")) {
        this.init();
      }
      else if (m.getName().equals ("close")) {
        this.close();
      }
      else if (m.getName().equals ("writeObject")) {
        this.writeObject ((ObjectOutputStream) arguments[0]);
      }
      else if (m.getName().equals ("readObject")) {
        this.readObject ((ObjectInputStream) arguments[0]);
      }
      else if (m.getName().equals ("equals")) {
        return this.equals (arguments[0]);
      }
      else if (m.getName().equals ("copy")) {
        return this.copy();
      }
      else {
        // Dermi methods
        Class[] interfaces = obj.getClass().getInterfaces();

        // Find DermiRemoteInterface for this class
        Class interf = null;

        for (Class intf : interfaces) {
          DermiRemoteInterface annot = (DermiRemoteInterface) intf.getAnnotation (DermiRemoteInterface.class);
          if (annot != null) {
            interf = intf;
            break;
          }
        }

        if (interf == null) {
          throw new NoSuchDermiObjectException ("Class: " + obj.getClass() + " Method: " + m.getName());
        }

        Method[] methods = interf.getMethods();

        for (Method aMethod : methods) {
          if (aMethod.getName().equals (m.getName())) {
            RemoteMethod annotation = (RemoteMethod) aMethod.getAnnotation (RemoteMethod.class);

            if (annotation != null) {
              boolean isVoidReturnType = (m.getReturnType() == void.class);

              if (annotation.granularity() == Granularity.MULTICALL || annotation.granularity() == Granularity.DIRECTCALL) {
                // Synchronous Multicall / Synchronous Directcall
                if (annotation.type() == SynchronyType.SYNCHRONOUS) {
                  if (annotation.granularity() == Granularity.MULTICALL) {
                    logger.fine ("Synchronous multicall: " + m.getName ());
                  }
                  if (annotation.granularity() == Granularity.DIRECTCALL) {
                    logger.fine ("Synchronous directcall: " + m.getName ());
                  }
                  // Set timestamp for this event and its possible retransmissions
                  String tstamp = "" + System.currentTimeMillis();

                  for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
                    Hashtable evt = new Hashtable();
                    evt.put (Context.OBJECTID, uid);
                    evt.put (Context.TYPE, Context.DISPATCH);
                    evt.put (Context.METHOD, m.getName());
                    evt.put (Context.TIMESTAMP, tstamp);
                    evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());

                    if (annotation.granularity() == Granularity.DIRECTCALL) {
                      evt.put (Context.DESTINATION_NODEHANDLE, serverNh);
                    }

                    Vector args = new Vector();

                    // Add parameters (if any)
                    if (arguments != null) {
                      for (Object obj : arguments) {
                        args.add (obj);
                      }
                      if (annotation.granularity() == Granularity.DIRECTCALL) {
                        dispatchDirectEvent (evt, args);
                      }
                      else {
                        dispatchEvent (evt, args);
                      }
                    }
                    else {
                      if (annotation.granularity() == Granularity.DIRECTCALL) {
                        dispatchDirectEvent (evt);
                      }
                      else {
                        dispatchEvent (evt);
                      }
                    }
                    timeout = 0;
                    while (!contains (results, m.getName() + tstamp) && timeout < Context.TIMEOUT) {
                      try {
                        Thread.currentThread().sleep (Context.DELAY);
                      }
                      catch (InterruptedException ex) {
                        ex.printStackTrace();
                      }
                      timeout++;
                    }
                    if (exception) {
                      exception = false;
                      Exception ex = (Exception) results.get (m.getName() + tstamp);
                      throw ex;
                    }
                    else if (timeout == Context.TIMEOUT) {
                      retransmission++;
                      continue;
                    }
                    break;
                  }
                  if (timeout == Context.TIMEOUT) {
                    throw new TimeoutException ("Object seems to be down.");
                  }
                  else {
                    if (!isVoidReturnType) {
                      return results.get (m.getName() + tstamp);
                    }
                    else {
                      return null;
                    }
                  }
                }
                // Asynchronous Multicall
                else {
                  if (annotation.granularity() == Granularity.MULTICALL) {
                    logger.fine ("Asynchronous multicall: " + m.getName ());
                  }
                  if (annotation.granularity() == Granularity.DIRECTCALL) {
                    logger.fine ("Asynchronous directcall: " + m.getName ());
                  }
                  // Set timestamp for this event
                  String tstamp = "" + System.currentTimeMillis();

                  Hashtable evt = new Hashtable();
                  evt.put (Context.OBJECTID, uid);
                  evt.put (Context.TYPE, Context.DISPATCH);
                  evt.put (Context.METHOD, m.getName());
                  evt.put (Context.TIMESTAMP, tstamp);
                  evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
                  Vector args = new Vector();

                  // Add parameters (if any)
                  if (arguments != null) {
                    for (Object obj : arguments) {
                      args.add (obj);
                    }
                    if (annotation.granularity() == Granularity.DIRECTCALL) {
                      dispatchDirectEvent (evt, args);
                    }
                    else {
                      dispatchEvent (evt, args);
                    }
                  }
                }
              }
              if (annotation.granularity() == Granularity.ANYCALL) {
                logger.fine ("Anycall: " + m.getName());
                // Set timestamp for this event and its possible retransmissions
                String tstamp = "" + System.currentTimeMillis();

                for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
                  Hashtable evt = new Hashtable();
                  evt.put (Context.OBJECTID, uid);
                  evt.put (Context.TYPE, Context.DISPATCH);
                  evt.put (Context.METHOD, m.getName());
                  evt.put (Context.TIMESTAMP, tstamp);
                  evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
                  Vector args = new Vector();

                  // Add parameters (if any)
                  if (arguments != null) {
                    for (Object obj : arguments) {
                      args.add (obj);
                    }
                  }

                  evt.put (Context.OBJECTCONTENT, args);
                  conn.anycall (evt);
                  timeout = 0;
                  while (!contains (results, m.getName() + tstamp) && timeout < Context.TIMEOUT) {
                    try {
                      Thread.currentThread().sleep (Context.DELAY);
                    } catch (InterruptedException ex) {
                      ex.printStackTrace();
                    }
                    timeout++;
                  }
                  if (exception) {
                    exception = false;
                    Exception ex = (Exception) results.get (m.getName() + tstamp);
                    throw ex;
                  } else if (timeout == Context.TIMEOUT) {
                    retransmission++;
                    continue;
                  }
                  break;
                }
                if (timeout == Context.TIMEOUT) {
                  throw new TimeoutException ("Object seems to be down.");
                }
                else {
                  if (!isVoidReturnType) {
                    return results.get (m.getName() + tstamp);
                  }
                  else {
                    return null;
                  }
                }
              }
              if (annotation.granularity() == Granularity.MANYCALL) {
                logger.fine ("Manycall: " + m.getName());
                // Set timestamp for this event and its possible retransmissions
                String tstamp = "" + System.currentTimeMillis();

                for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
                  Hashtable evt = new Hashtable();
                  evt.put (Context.OBJECTID, uid);
                  evt.put (Context.TYPE, Context.DISPATCH);
                  evt.put (Context.METHOD, m.getName());
                  evt.put (Context.TIMESTAMP, tstamp);
                  evt.put (Context.SOURCE_NODEHANDLE, conn.getLocalNodeHandle());
                  Vector args = new Vector();

                  // Add parameters (if any)
                  if (arguments != null) {
                    for (Object obj : arguments) {
                      args.add (obj);
                    }
                  }

                  evt.put (Context.OBJECTCONTENT, args);
                  conn.anycall (evt);
                  timeout = 0;
                  while (!contains (results, m.getName() + tstamp) && timeout < Context.TIMEOUT) {
                    try {
                      Thread.currentThread().sleep (Context.DELAY);
                    } catch (InterruptedException ex) {
                      ex.printStackTrace();
                    }
                    timeout++;
                  }
                  if (exception) {
                    exception = false;
                    Exception ex = (Exception) results.get (m.getName() + tstamp);
                    throw ex;
                  } else if (timeout == Context.TIMEOUT) {
                    retransmission++;
                    continue;
                  }
                  break;
                }
                if (timeout == Context.TIMEOUT) {
                  throw new TimeoutException ("Object seems to be down.");
                }
                else {
                  if (!isVoidReturnType) {
                    return results.get (m.getName() + tstamp);
                  }
                  else {
                    return null;
                  }
                }
              }
              if (annotation.granularity() == Granularity.LISTENER) {
                logger.fine ("Listener method: " + m.getName());
                if (m.getName().startsWith ("add")) {
                  if (listenerCount == 0) {
                    Hashtable lsubs = new Hashtable();
                    lsubs.put (Context.OBJ, uid + ":RESULT:" + ((Class) arguments[0]).getName());
                    try {
                      conn.subscribe (new RemoteEventListener() {
                        public void eventArrived (Hashtable evt) {
                          Serializable result = (Serializable) evt.get (Context.OBJECTCONTENT);
                          Vector clisteners = (Vector) listeners.clone();
                          Iterator it = clisteners.iterator();
                          while (it.hasNext()) {
                            BasicListener aListener = (BasicListener) it.next();
                            aListener.onEvent (result);
                          }
                        }
                        public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
                          return null;
                        }
                      }, lsubs);
                    } catch (SessionException ex) {
                      throw new ConnectionException ("Problem subscribing listener.");
                    }
                  }
                  listeners.add (arguments[1]);
                  listenerCount++;
                }
                else if (m.getName().startsWith ("remove")) {
                  listeners.remove (arguments[1]);
                  listenerCount--;
                  if (listenerCount == 0) {
                    Hashtable lsubs = new Hashtable();
                    lsubs.put (Context.OBJ, uid + ":RESULT:" + ((Class) arguments[0]).getName());
                    try {
                      conn.unsubscribe (this, lsubs);
                    } catch (SessionException ex) {
                      throw new ConnectionException ("Problem unsubscribing listener.");
                    }
                  }
                }
              }
            }
            // The method contains no annotations: it is not a Dermi method
            else {
              logger.fine ("Method " + aMethod.getName() + " contains no annotations.");
            }
          }
        }
      }
    } catch (Exception e) {
      if (e instanceof RemoteException) {
        throw e;
      }
      e.printStackTrace();
      throw new RuntimeException ("Method invocation refused");
    }
    return result;
  }

  // Utility method
  private synchronized boolean contains (Hashtable results, String tstamp) {
    Iterator i = results.keySet().iterator();
    while (i.hasNext()) {
      Object ob = i.next();
      if (results.get (tstamp) != null) {
        return true;
      }
    }
    return false;
  }

  /**
   * Method invoked each time the proxy receives an event
   * @param evt Hashtable Information about the event received
   */
  public synchronized void eventArrived (Hashtable evt) {
    method = (String) evt.get (Context.METHOD);
    if (!receivedEvents.contains (method + (String) evt.get (Context.TIMESTAMP))) {
      // Void return type
      if (evt.get (Context.OBJECTCONTENT) == null) {
        results.put (method + evt.get (Context.TIMESTAMP), -1);
      }
      else {
        results.put (method + evt.get (Context.TIMESTAMP), evt.get (Context.OBJECTCONTENT));
      }
      String type = (String) evt.get (Context.TYPE);
      if (type.equals (Context.EXCEPTION)) {
        exception = true;
      }
      receivedEvents.add (method + (String) evt.get (Context.TIMESTAMP));
    }
  }

  // Method not used by the dynamic proxy
  public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
    return null;
  }


  /**
   * Closes the stub
   * @throws RemoteException  If something goes wrong ;-)
   */
  public void close() throws RemoteException {
    try {
      conn.unsubscribe (this, subs);
      dermi.util.Bus.close();
    } catch (SessionException e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * Initializes the stub
   * @throws RemoteException  If something goes wrong ;-)
   */
  public void init() throws RemoteException {
    conn = dermi.util.Bus.getBus (eref);
    try {
      conn.subscribe (this, subs);
    } catch (SessionException e) {
      throw new ConnectionException (e.getMessage());
    }
  }

  /**
   * Writes the current object to a stream
   * @param out ObjectOutputStream Data stream
   * @throws IOException  If something goes wrong ;-)
   */
  private void writeObject (ObjectOutputStream out) throws IOException {
    out.defaultWriteObject();
  }

  /**
   * Reads an object from a stream
   * @param in ObjectInputStream Data stream
   * @throws IOException  If something goes wrong ;-)
   * @throws ClassNotFoundException  If something goes wrong ;-)
   */
  private void readObject (ObjectInputStream in) throws IOException, ClassNotFoundException {
    try {
      in.defaultReadObject();
      init();
    } catch (RemoteException e) {
      e.printStackTrace();
    }
  }

  /**
   * Compares this object with another
   * @param obj Object The other object
   * @return boolean true if both equal
   */
  public boolean equals (Object obj) {
    if (obj instanceof ERemote) {
      ERemote ref = (ERemote) obj;
      return ref.getERef().equals (getERef());
    }
    return false;
  }

  /**
   * Returns a stub copy of this class
   * @throws RemoteException If something goes wrong ;-)
   * @return ERemote The returned stub
   */
  public ERemote copy() throws RemoteException {
    ERemote ref = dermi.registry.FileRegistry.loadStub (getERef());
    return (ERemote) ref;
  }
}

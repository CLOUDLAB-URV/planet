/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.replicastate;

import dermi.*;
import dermi.exception.*;

import java.io.Serializable;
import java.util.Properties;

/**
 * This class contains the trivial implementation of the Sprite server methods
 * It is a stateful replicated method. Note that it implements the StatefulReplica
 * interface
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class SpriteImpl extends DermiRemoteObject implements Sprite, StatefulReplica {
  private int x;

  // Dermi constructor: REQUIRED
  public SpriteImpl() {
  }

  // Dermi constructor: REQUIRED
  public SpriteImpl (int x, Properties env) throws RemoteException {
    super (env);
    // Default x value
    this.x = x;

    // Load replica state
    super.loadReplicaState();
    System.out.println ("[Sprite] object created.");
  }

  public int getX() throws RemoteException {
    System.out.println ("[getX] called: " + x);
    return x;
  }

  public void setX (int x) throws RemoteException {
    System.out.println ("[setX] called.");
    this.x = x;
  }

  /**
   * Method for loading state into this object
   * @param data SpriteValues Object state
   */
  public void loadRemoteObjectState() throws RemoteException {
    SpriteData data = (SpriteData) super.loadState();
    this.x = data.getX();
    System.out.println ("[loadRemoteObjectState] - new state loaded: " + x);
  }

  /**
   * Method for obtaining this object's state
   * @return SpriteData
   */
  public Serializable getRemoteObjectState() {
    return new SpriteValues (x);
  }
}

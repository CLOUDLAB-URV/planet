/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.replicastate;

import dermi.*;
import dermi.registry.*;
import dermi.exception.*;

/**
 * This class encapsulates a client willing to access the Sprite object server
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class SpriteClient {
  public static void main (String[] args) throws RemoteException {
    // If we do not want to use the decentralized registry, uncomment this line
    // and comment the next two
    // Sprite client = (Sprite) FileRegistry.loadERef ("dermi-config.xml");

    // Load the registry first
    Registry.loadRegistry ("registry-config.xml");

    // Look up an object in the registry
    Sprite client = (Sprite) Registry.lookup ("p2p://replicas");

    int s = client.getX();
    System.out.println (s);

    client.setX (50);
    client.close();
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.reference;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * This class contains the implementation of the User server object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class UserImpl extends DermiRemoteObject implements User {
  String name;

  // Dermi constructor: REQUIRED
  public UserImpl() {
  }

  // Dermi constructor: REQUIRED
  public UserImpl (String name, Properties env) throws RemoteException {
    super (env);
    this.name = name;
    System.out.println ("[User] object created.");
  }

  public void setName (String name) {
    System.out.println ("[setName] called.");
    this.name = name;
  }

  public String getName() {
    System.out.println ("[getName] called.");
    return name;
  }
}

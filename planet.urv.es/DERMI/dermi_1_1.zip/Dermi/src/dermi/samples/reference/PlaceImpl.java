/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.reference;

import dermi.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * This is the place object implementation
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class PlaceImpl extends DermiRemoteObject implements Place {
  String name;
  Vector users = new Vector();

  // Dermi constructor: REQUIRED
  public PlaceImpl() {
  }

  // Dermi constructor: REQUIRED
  public PlaceImpl (String name, Properties env) throws RemoteException {
    super (env);
    this.name = name;
    System.out.println ("[Place] object created.");
  }

  public void join (User aUser) throws RemoteException {
    System.out.println ("[join] called.");
    users.add (aUser);
  }

  public void leave (User aUser) throws RemoteException	{
    System.out.println ("[leave] called.");

    if (!remove (aUser)) {
      throw new RemoteException ("User trying to leave was not found.");
    }
  }

  public Vector getUsers() throws RemoteException {
    System.out.println ("[getUsers] called.");
    Vector result = new Vector();

    Iterator it = users.iterator();
    while (it.hasNext()) {
      User a = (User) it.next();
      result.add (a.copy());
    }

    return result;
  }

  private boolean remove (User aUser) throws RemoteException {
    Iterator it = users.iterator();
    while (it.hasNext()) {
      User a = (User) it.next();
      if (a.getName().equals (aUser.getName())) {
        it.remove();
        return true;
      }
    }
    return false;
  }

}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.reference;

import dermi.*;

import java.util.*;

/**
 * This class implements the User server object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class UserServer {
  public static void main (String[] args) {
    try {
      // If you want to use the File registry, uncomment the next line and comment
      // the next two
      //Place thePlace = (Place) FileRegistry.loadERef ("dermi-config.xml");

      // Load the registry first
      Registry.loadRegistry ("registry-config.xml");

      Place thePlace = (Place) Registry.lookup ("p2p://place");

      Properties env = Registry.getEnvironment ("dermi-config.xml");

      UserImpl server0 = new UserImpl ("gojiita", env);
      UserImpl server1 = new UserImpl ("cpairot", env);
      UserImpl server2 = new UserImpl ("pgarcia", env);
      UserImpl server3 = new UserImpl ("bart", env);

      thePlace.join (server0);
      thePlace.join (server1);
      thePlace.join (server2);
      thePlace.join (server3);

      System.out.println ("Users gojiita, cpairot, pgarcia, bart have joined the place.\nPress <RETURN> for gojiita to leave the place...");
      System.in.read();
      thePlace.leave (server0);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.reference;

import dermi.*;

import java.io.*;
import java.util.*;

/**
 * This class encapsulates a client willing to access the User object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class UserClient {
  public static void main (String[] args) throws Exception {
    // If you want to use the File registry, uncomment the next line and comment
    // the next two
    // Place thePlace = (Place) FileRegistry.loadERef ("dermi-config.xml");

    // Load the registry first
    Registry.loadRegistry ("registry-config.xml");

    Place thePlace = (Place) Registry.lookup ("p2p://place");

    Vector users = thePlace.getUsers();
    Iterator it = users.iterator();
    while (it.hasNext()) {
      User a = (User) it.next();
      System.out.println (a.getName());
      a.close();
    }
    thePlace.close();
    System.exit (0);
  }
}

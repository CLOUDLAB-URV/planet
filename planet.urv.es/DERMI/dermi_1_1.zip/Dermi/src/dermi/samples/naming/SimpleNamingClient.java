/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.naming;

import dermi.*;
import dermi.samples.simple.*;

/**
 * This class encapsulates the Simpleconn.getNaming() client object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class SimpleNamingClient {
  public static void main (String[] args) throws Exception {
    // Load the registry first
    Registry.loadRegistry ("registry-config.xml");

    // Look up an object in the registry
    System.out.println ("\nLooking up p2p://simple1...");
    Simple client = (Simple) Registry.lookup ("p2p://simple1");
    System.out.println ("\nCalling p2p://simple1 methods...");

    // Execute object's methods
    client.setAge ("30");
    String s = client.getAge();
    System.out.println (s);
    client.setAge ("99");
    String res = client.merge (new Integer (3), "544", new Integer (33));
    System.out.println (res);

    // Check other lookups
    System.out.print ("\nLooking up p2p://simple2...\t\t\t\t");
    Registry.lookup ("p2p://simple2");
    System.out.print ("OK\nLooking up p2p://simple3...\t\t\t\t");
    Registry.lookup ("p2p://simple3");
    System.out.print ("OK\nLooking up p2p://simple4...\t\t\t\t");
    Registry.lookup ("p2p://simple4");
    System.out.print ("OK\nLooking up p2p://simple1/simpler1...\t\t\t");
    Registry.lookup ("p2p://simple1/simpler1");
    System.out.print ("OK\nLooking up p2p://simple1/simpler1/thesimplest...\t");
    Registry.lookup ("p2p://simple1/simpler1/thesimplest");
    System.out.println ("OK\n");

    client.close();
    System.exit(0);
  }
}

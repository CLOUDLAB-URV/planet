/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.timing;

import dermi.*;
import dermi.exception.*;
import dermi.registry.*;

/**
 * This class encapsulates a client willing to access the Simple object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class SimpleClient {
  public static void main (String[] args) throws RemoteException {
    Simple client = null;
    long iniTime, endTime;

    // Load the registry first
    Registry.loadRegistry ("registry-config.xml");

    try {
      client = (Simple) Registry.lookup ("p2p://timing");
      // client = (Simple) FileRegistry.loadERef ("dermi-config.xml");
    } catch (RemoteException ex) {
      System.err.println ("ERROR: Impossible to load object reference.");
      System.exit (-1);
    }

    try {
      for (int i = 0; i < 100; i++) {
        iniTime = System.currentTimeMillis();
        client.setAge ("30");
        endTime = System.currentTimeMillis();
        System.out.println ("(setAge) Call time: " + (endTime - iniTime) + " ms");
      }

      System.out.println ("\n\n");

      for (int i = 0; i < 100; i++) {
        iniTime = System.currentTimeMillis();
        String s = client.getAge();
        endTime = System.currentTimeMillis();
        System.out.println ("(getAge) Call time: " + (endTime - iniTime) + " ms");
      }

      System.out.println ("\n\n");

      for (int i = 0; i < 100; i++) {
        iniTime = System.currentTimeMillis();
        String res = client.merge (new Integer (3), "543", new Integer (33));
        endTime = System.currentTimeMillis();
        System.out.println ("(merge) Call time: " + (endTime - iniTime) + " ms");
      }

      System.out.println ("\n");

    } catch (RemoteException re) {
      re.printStackTrace();
    }
    client.close();
    System.exit(0);
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.interception;

import dermi.*;
import dermi.exception.*;

import java.util.*;

/**
 * This is the implementation of the log interceptor object. Its methods will be
 * called each time a call is made to the destination object (in this case Simple)
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class LogInterceptorImpl extends DermiRemoteInterceptorObject implements LogInterceptor {
  // Dermi constructor: REQUIRED
  public LogInterceptorImpl() {
  }

  // Dermi constructor: REQUIRED
  public LogInterceptorImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[LogInterceptor] object created.");
  }

  public Vector setAge (String p0) throws RemoteException {
    System.out.println ("[LogInterceptor - setAge: adding two more years] " + p0);

    // If we wished to change the value of parameters, simply change them
    // and pile them up in order in the returned Vector
    Vector v = new Vector();
    v.add (new String ("" + (Integer.parseInt (p0) + 2)));
    return v;
  }

  public void getAge() throws RemoteException {
    System.out.println ("[LogInterceptor - getAge]");
  }

  public Vector merge (Integer p0, String p1, Integer p2) throws RemoteException {
    System.out.println ("[LogInterceptor - merge] " + p0 + " " + p1 + " " + p2);

    // If we wished to change the value of parameters, simply change them
    // and pile them up in order in the returned Vector
    Vector v = new Vector();
    v.add (p0);
    v.add (new String ("merge intercepted ;-)"));
    v.add (p2);
    return v;
  }
}

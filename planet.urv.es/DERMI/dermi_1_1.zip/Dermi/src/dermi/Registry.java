/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.util.*;
import dermi.exception.*;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * This class provides Decentralized Registry's static and generic methods
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class Registry {
  private static dermi.registry.Naming dolr;

  /**
   * Returns the object's environment properties
   *
   * @param filename String Object properties filename
   * @throws RemoteException If something goes wrong ;-)
   * @return Properties Object properties
   */
  public static Properties getEnvironment (String filename) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (filename);
      Properties p = new Properties();
      p.loadFromXML (fis);

      return p;
    } catch (Exception e) {
      throw new RemoteException ("Impossible to get object properties.");
    }
  }

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void loadRegistry (String ref) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (ref);
      Properties env = new Properties();
      env.loadFromXML (fis);
      String hostName = env.getProperty (Context.PROVIDER_HOST);
      int port = (new Integer (env.getProperty (Context.PROVIDER_PORT))).intValue();

      Class[] cl = {};
      Object[] objs = {};
      String className = "dermi.registry." + env.getProperty (Context.UNDERLYING_DHT) + ".Naming";
      Class cls = Class.forName (className);
      Method meth = cls.getMethod ("getInstance", cl);
      dolr = (dermi.registry.Naming) meth.invoke (null, objs);
      dolr.loadRegistry (ref);
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e.getMessage ());
    }
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name) throws RemoteException {
    return dolr.lookup (name);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name, String communityId, String className) throws RemoteException {
    return dolr.lookup (name, communityId, className);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (dermi.core.Id id) throws RemoteException {
    return dolr.lookupSer (id);
  }

  /**
   * Method used to know if the registry is already connected to a node
   * @return boolean true if it is connected
   */
  public static boolean isConnected () {
    if (dolr == null) {
      return false;
    }
    else {
      return dolr.isConnected ();
    }
  }

  /**
   * Method used to get the connection to the node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public static dermi.core.DermiConnection getConnection() {
    return dolr.getConnection();
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, ERemote ref) throws RemoteException {
    dolr.bind (name, ref);
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, Properties env) throws RemoteException {
    dolr.bind (name, env);
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bindRoot() throws RemoteException {
    dolr.bindRoot();
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void rebind (String name, ERemote ref) throws RemoteException {
    dolr.rebind (name, ref);
  }

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public static Collection list (String root) throws RemoteException {
    return dolr.list (root);
  }

  public static void setInstance (dermi.registry.Naming reg) {
    dolr = reg;
  }
}

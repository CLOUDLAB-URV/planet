/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.activation;

import dermi.*;
import dermi.util.*;
import dermi.exception.RemoteException;

import java.util.*;

/**
 * Implementation of object's methods
 * Note that this implementation does not care about remote state propagation
 * This will be taken into account by the object's skeleton
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class ActivatorImpl extends ActivatorSkel {
  private Hashtable classRepository = new Hashtable();
  private Vector activeObjects = new Vector();

  public ActivatorImpl (Properties env) throws RemoteException {
    super (env);
    // Get state from any of the replicas (if none, default value)
    super.getReplicaState();
    System.out.println ("[Activator] object created.");
  }

  /**
   * Method for registering a class into the community this Activator belongs to
   * @param className String Interface class to be added
   * @param skelClass byte[] Skeleton class raw bytes
   * @param implClass byte[] Implementation class raw bytes
   * @param stubClass byte[] Stub class raw bytes
   */
  public void addClass (String className, byte[] skelClass, byte[] implClass, byte[] stubClass) {
    BusClassLoader loader = new BusClassLoader();
    loader.defineClass (className + "Skel", skelClass);
    classRepository.put (className + "Skel", new ByteWrapper (skelClass));
    loader.defineClass (className + "Impl", implClass);
    classRepository.put (className + "Impl", new ByteWrapper (implClass));
    loader.defineClass (className + "Stub", stubClass);
    classRepository.put (className + "Stub", new ByteWrapper (stubClass));
    System.out.println ("[Activator] all classes defined and stored.");
  }

  /**
   * Method for activating a single object
   * @param env Properties Object's properties
   */
  public Properties activateObject (Properties env) throws RemoteException {
    try {
      String className = env.getProperty (Context.CLASS_NAME);
      className = className.replaceAll ("Stub", "Impl");
      Class[] cl = {Properties.class};
      Object[] objs = {env};
      ERemote er = (ERemote) Class.forName (className).getConstructor (cl).newInstance (objs);
      activeObjects.add (er);
      System.out.println ("[Activator] activate object: " + env.getProperty (Context.CLASS_ID));
      Registry.bind (env.getProperty (Context.CLASS_ID), env);
      System.out.println ("[Activator] registered object: " + env.getProperty (Context.CLASS_ID));
      return er.getERef();
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException ("Unable to activate object.");
    }
  }

  /**
   * Method for activating multiple objects (this method will be called in ALL
   * activator members of the community)
   * @param env Properties Object's properties
   */
  public Properties activateMultipleObjects (Properties env) throws RemoteException {
    return this.activateObject (env);
  }

  /**
   * Method for loading state into this object
   */
  public void dermiLoadState() throws RemoteException {
    ActivatorData data = (ActivatorData) super.loadState();
    this.classRepository = data.getClasses();
  }

  /**
   * Method for obtaining this object's state
   * @return ActivatorData
   */
  public ActivatorData dermiGetState() {
    return new ActivatorValues (classRepository);
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

public class Lease extends Thread {
  private long initialLeaseTime = 0;
  private long remainingLeaseTime = 0;
  private Activatable object = null;

  public Lease (long initialLeaseTime, Activatable object) {
    super();
    this.initialLeaseTime = System.currentTimeMillis() + initialLeaseTime;
    this.remainingLeaseTime = initialLeaseTime;
    this.object = object;
    super.start();
  }

  public long renew (long newLeaseTime) {
    this.initialLeaseTime = System.currentTimeMillis() + newLeaseTime;
    this.remainingLeaseTime = newLeaseTime;
    return initialLeaseTime;
  }

  public void run() {
    for (;;) {
      try {
        Thread.sleep (1000);
      } catch (InterruptedException e) { }
      remainingLeaseTime -= 1000;
      if (remainingLeaseTime <= 0) {
        object.leaseTimeout();
        break;
      }
    }
  }
}

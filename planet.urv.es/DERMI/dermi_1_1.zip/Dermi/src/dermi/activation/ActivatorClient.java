/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.activation;

import dermi.*;
import dermi.util.*;
import dermi.registry.*;
import dermi.exception.*;

import java.util.*;
import java.util.logging.*;

/**
 * This class encapsulates a client willing to access the Activator object server
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class ActivatorClient {
  private Activator client = null;
  private BusClassLoader loader = null;
  private transient Logger logger = Logger.getLogger (this.getClass().getName());

  public ActivatorClient (Properties env) {
    try {
      client = (Activator) FileRegistry.loadERef (env);
    } catch (RemoteException e) {
      logger.severe ("Unable to start activator client object.");
    }
    loader = new BusClassLoader();
  }

  /**
   * Method for adding a class into this activator object community
   * @param className String Class name
   */
  public void addClass (String className) {
    EventServer cli = (EventServer) client;
    try {
      byte[] skelClass = cli.getBytes (cli.getClassStore() + className + "Skel");
      byte[] implClass = cli.getBytes (cli.getClassStore() + className + "Impl");
      byte[] stubClass = cli.getBytes (cli.getClassStore() + className + "Stub");
      client.addClass (className, skelClass, implClass, stubClass);
    } catch (Exception cnf) {
      logger.severe ("Unable to load class.");
      cnf.printStackTrace();
    }
  }

  /**
   * Activate a single instance of an object into this community
   * @param env Properties Object's properties
   */
  public Properties activateObject (Properties env) {
    try {
      return (Properties) client.activateObject (env);
    } catch (RemoteException e) {
      logger.severe ("Unable to activate object.");
      e.printStackTrace();
      return null;
    }
  }

  /**
   * Activate an instance of an object into all members of this community
   * @param env Properties Object's properties
   */
  public Properties activateMultipleObjects (Properties env) {
    try {
      return client.activateMultipleObjects (env);
    } catch (RemoteException e) {
      logger.severe ("Unable to activate multiple objects.");
      e.printStackTrace();
      return null;
    }
  }

  /**
   * Close client
   * @throws RemoteException If something goes wrong ;-)
   */
  public void close() throws RemoteException {
    client.close();
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import dermi.util.*;
import dermi.exception.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Utility class that connects to the notification service using environment parameters and
 * instantiates the appropriate class provider.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class SessionFactory {

  /**
   * Method used to create a session
   * @param env Hashtable Environment connection properties
   * @throws SessionException Error produced in the connection phase
   * @return Session Returns a session of the type specified in the environment properties
   */
  public static Session createSession (Hashtable env) throws SessionException {
    try {
      Session ses = (Session) Class.forName ((String) env.get (Context.PROVIDER_CLASS)).newInstance();
      ses.open (env);
      return ses;
    } catch (ClassNotFoundException e1) {
      throw new SessionException (e1);
    } catch (InstantiationException e2) {
      throw new SessionException (e2);
    } catch (IllegalAccessException e3) {
      throw new SessionException (e3);
    }
  }

  /**
   * Method used to create a session
   * @param envFile Name of the file containing environment connection properties
   * @return Session Returns a Session of the type specified in Environment properties
   * @throws SessionException Error produced in the connection phase
   */
  public static Session createSession (String envFile) throws SessionException {
    try	{
      FileInputStream  fis = new FileInputStream (envFile);
      Properties env = new Properties();
      env.load (fis);

      Session ses = (Session) Class.forName ((String)env.get (Context.PROVIDER_CLASS)).newInstance();
      ses.open (env);
      return ses;
    } catch (ClassNotFoundException e1) {
      throw new SessionException (e1);
    } catch (InstantiationException e2) {
      throw new SessionException (e2);
    } catch (IllegalAccessException e3) {
      throw new SessionException (e3);
    } catch (FileNotFoundException e4) {
      throw new SessionException (e4);
    } catch (IOException e5) {
      throw new SessionException (e5);
    }
  }


  /**
   * Method used to create a session
   * @param fileUrl URL of the file containing environment connection properties
   * @return Session Returns a Session of the type specified in environment properties
   * @throws SessionException Error produced in the connection phase.
   */
  public static Session createSession (URL fileUrl) throws SessionException {
    try {
      Properties env = new Properties();
      env.load (fileUrl.openStream());
      Session ses = (Session) Class.forName ((String) env.get (Context.PROVIDER_CLASS)).newInstance();
      ses.open (env);
      return ses;
    } catch (ClassNotFoundException e1) {
      throw new SessionException (e1);
    } catch (InstantiationException e2) {
      throw new SessionException (e2);
    } catch (IllegalAccessException e3) {
      throw new SessionException (e3);
    } catch (IOException e5) {
      throw new SessionException (e5);
    }
  }
}

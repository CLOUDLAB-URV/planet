/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.annotation;

/**
 * This is an enumeration class for the different Dermi call granularities
 * @author Carles Pairot <cpairot@etse.urv.es>
 * @version 1.1
 */
public enum Granularity {
    /** One-to-one direct call */
    DIRECTCALL,

    /** One-to-many call */
    MULTICALL,

    /** Anycall */
    ANYCALL,

    /** Manycall */
    MANYCALL,

    /** Listener method */
    LISTENER,

    /** Anycall condition method */
    ANYCALL_CONDITION,

    /** Manycall local condition method */
    MANYCALL_LOCAL_CONDITION,

    /** Manycall global condition method */
    MANYCALL_GLOBAL_CONDITION
}

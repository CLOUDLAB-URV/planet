/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.annotation;

/**
 * This enumeration class defines the different blocking policies for Dermi's RPC calls
 * @author Carles Pairot <cpairot@etse.urv.es>
 * @version 1.1
 */
public enum SynchronyType {
    /** The call blocks until a specified % of responses are received */
    SYNCHRONOUS,

    /** The call does not block */
    ASYNCHRONOUS,

    /** The call unblocks when at least one response is received */
    AT_LEAST_ONE
}

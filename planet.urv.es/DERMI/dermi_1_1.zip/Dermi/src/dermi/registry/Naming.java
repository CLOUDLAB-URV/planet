/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry;

import java.io.*;
import java.util.*;

import dermi.*;
import dermi.core.*;
import dermi.exception.*;
import dermi.util.*;

/**
 * Interface to the Naming class. It follows the singleton design pattern.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public interface Naming {

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public void loadRegistry (String ref) throws RemoteException;

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException;

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name, String communityId, String className) throws RemoteException;

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public Serializable lookupSer (Id id) throws RemoteException;

  /**
   * Method used to know if the registry is already connected to a node
   * @return boolean true if it is connected
   */
  public boolean isConnected ();

  /**
   * Method used to get the connection to the node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public DermiConnection getConnection();

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, ERemote ref) throws RemoteException;

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties env) throws RemoteException;

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bindRoot() throws RemoteException;

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void rebind (String name, ERemote ref) throws RemoteException;

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public Collection list (String root) throws RemoteException;
}

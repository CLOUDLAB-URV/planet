/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.messaging.pastry;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;

/**
 * Message sent when willing to subscribe an interceptor to an object group
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class InterceptorSubscribeMessage extends ScribeMessage {
  // the content of this message
  protected NodeHandle interceptor;

  // the interceptor identifier
  protected String intId;

  /**
   * Constructor
   * @param source NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param interceptor NodeHandle Interceptor's node handle
   * @param intId String Interceptor id
   */
  public InterceptorSubscribeMessage (NodeHandle source, Topic topic, NodeHandle interceptor, String intId) {
    super (source, topic);
    this.interceptor = interceptor;
    this.intId = intId;
  }

  /**
   * Returns the interceptor's NodeHandle
   * @return NodeHandle Interceptor's NodeHandle
   */
  public NodeHandle getInterceptorHandle() {
    return interceptor;
  }

  /**
   * Returns the interceptor's identifier
   * @return String Interceptor's identifier
   */
  public String getInterceptorId() {
    return intId;
  }

  public String toString() {
    return "InterceptorSubscribeMessage" + topic + ":" + intId + " " + interceptor;
  }
}

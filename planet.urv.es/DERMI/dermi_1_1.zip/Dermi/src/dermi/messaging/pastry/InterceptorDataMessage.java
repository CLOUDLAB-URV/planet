/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.messaging.pastry;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;

import java.util.*;

/**
 * This class wraps an interception data message
 * This kind of messages are sent when a rendezvous point change is detected
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class InterceptorDataMessage extends ScribeMessage {

  // List of interceptors
  protected ArrayList interceptors;

  /**
   * Constructor
   * @param source NodeHandle Source nodehandle
   * @param topic Topic Group's identifier
   * @param interceptors ArrayList List of interceptors
   */
  public InterceptorDataMessage (NodeHandle source, Topic topic, ArrayList interceptors) {
    super (source, topic);
    this.interceptors = interceptors;
  }

  /**
   * Get interceptors
   * @return ArrayList Interceptors
   */
  public ArrayList getInterceptors() {
    return interceptors;
  }

  public String toString() {
    return "InterceptorDataMessage " + topic + ":" + interceptors;
  }
}

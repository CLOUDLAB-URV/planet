/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session;

import dermi.Session;
import java.util.Hashtable;

/**
 * This class implements a thread controlling the liveness of objects
 * @author Ruben Mondejar
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class AliveThread extends Thread {
  private String subject;
  private boolean close;
  private long timemillis;
  private Hashtable alive;
  private Session session;

  /**
   * Constructor
   */
  public AliveThread (Session session, String subject) {
    this.subject = subject;
    this.session = session;
    alive = new Hashtable();
    alive.put ("subject", subject);
    alive.put ("connection_event", "i'm alive");
    close = false;
  }

  public synchronized void time() {
    timemillis = System.currentTimeMillis();
  }

  public synchronized void die() {
    close = true;
  }

  public void run() {
    while (!close) {
      try {
        Thread.sleep (1000);
        long time2 = System.currentTimeMillis();
        if (time2 - timemillis > 2000) {
          session.publish (alive);
        }
      } catch (Exception e) {}
    }
  }
}

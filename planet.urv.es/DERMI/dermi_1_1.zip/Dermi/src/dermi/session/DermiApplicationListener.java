/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session;

import dermi.core.*;

import java.util.*;

/**
 * Interface to be implemented by applications that must be notified
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public interface DermiApplicationListener extends Client {

  /**
   * Sets the specified connection to this application
   *
   * @param conn Connection
   */
  public void setConnection (DermiConnection conn);

  /**
   * Upcall when an interceptor message is received
   */
  public void receiveInterceptorMessage (Hashtable msg, ArrayList interceptors);

  /**
   * Method required for manycalls, in case the contents of the message
   * must be changed on-the-fly
   *
   * @param tpc Topic Group's topic
   * @param cnt ScribeContent Original content
   * @return ScribeContent Modified content
   */
  public DermiContent interceptAnycast (Topic tpc, DermiContent cnt);
}

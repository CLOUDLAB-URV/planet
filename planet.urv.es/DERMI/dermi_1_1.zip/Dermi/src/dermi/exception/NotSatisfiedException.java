/*******************************************************************************
 * DERMI: A Decentralised Peer-to-Peer Event-Based Object Middleware
 *        for Distributed Components.
 * Copyright (C) 2003 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.exception;

/**
 * Exception class that is thrown when an anycall/manycall condition was unable
 * to be satisfied by any of the group members.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class NotSatisfiedException extends RemoteException {
  static final long serialVersionUID = 10L;

  public NotSatisfiedException() {
    super ("Unable to satisfy any/manycall. Objects cannot meet the required condition.");
  }

  public NotSatisfiedException(String desc) {
    super (desc);
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;
import junit.framework.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.direct.*;

import java.util.*;

/**
 * This is the direct call test suite
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class DirectcallTest extends TestCase {
  SimpleImpl server;

  public DirectcallTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[DirectcallTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new SimpleImpl (env);
      server.writeERef ("dermi-config.xml");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[DirectcallTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (DirectcallTest.class);
  }

  public void testSyncCall() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("dermi-config.xml");

    client.setAge ("27");

    String s = client.getAge();
    assertEquals (s, "27");
   }
 }

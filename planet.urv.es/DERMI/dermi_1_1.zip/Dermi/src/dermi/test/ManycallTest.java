/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;
import junit.framework.*;

import java.util.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.manycall.*;

/**
 * This is the manycall abstraction testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class ManycallTest extends TestCase {

  VotingImpl server, server2;

  public ManycallTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[ManycallTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new VotingImpl (env);
      server.writeERef ("dermi-config.xml");
      server2 = new VotingImpl (env);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[ManycallTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
  } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (ManycallTest.class);
  }

  public void testManyCall() throws Exception {
    Voting client = (Voting) FileRegistry.loadERef ("dermi-config.xml");

    // Ballot using only one server
    Integer s = client.vote (new Integer(0), new Integer (15), "Party time!");
    assertEquals (s.intValue(), 15);
    Thread.sleep (50);

    // We need two server votes for this manycall to be correct
    s = client.vote (new Integer (0), new Integer (25), "Party time!");
    assertEquals (s.intValue(), 30);
    Thread.sleep (50);

    // Negative ballot
    try {
      s = client.vote (new Integer (0), new Integer (15), "Simulate");
      fail ("Ballot negative");
    }
    catch (Exception e) {
      assertEquals (true, true);
    }
    client.close();
  }
}

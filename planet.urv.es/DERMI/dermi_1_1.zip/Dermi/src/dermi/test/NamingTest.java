/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.util.*;

import dermi.*;
import dermi.exception.*;
import dermi.samples.simple.*;

/**
 * The Decentralized object location testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class NamingTest extends TestCase {
  SimpleImpl server, server2;

  public NamingTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[NamingTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new SimpleImpl (env);
      Registry.loadRegistry ("registry-config.xml");
      Registry.bind ("p2p://simple", server);
      server2 = new SimpleImpl (env);
      Registry.bind ("p2p://simple2", server);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[NamingTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try	{
      server.close();
      Thread.sleep (1000);
      server2.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (SimpleTest.class);
  }

  public void testRegistry() throws Exception {
    Registry.lookup ("p2p://simple");

    Collection list = Registry.list ("p2p://");
    int size = list.size();

    assertEquals (2, size);
  }

  public void testNamingNotBound() throws Exception {
    try {
      Simple client = (Simple) Registry.lookup ("/no");
      fail ("Looked up unexistent object!");
    } catch (NotBoundException ex) {
      assertEquals (true, true);
    }
  }
}

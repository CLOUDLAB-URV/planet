/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.asyncmulticall.*;

import java.util.*;

/**
 * Asynchronous multicall test case
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class AsyncMulticallTest extends TestCase {
  SimpleImpl server;

  public AsyncMulticallTest(String name) {
    super (name);
  }

  /**
   * Method executed at the beginning of the testcase
   */
  protected void setUp() {
    System.out.println ("[AsyncMulticallTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new SimpleImpl (env);
      server.writeERef ("dermi-config.xml");

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Method executed at the end of the testcase
   */
  protected void tearDown() {
    System.out.println ("[AsyncMulticallTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
   } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Test asynchronous multicall in set method
   * @throws Exception If something goes wrong ;-)
   */
  public void testAsyncMulticall() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("dermi-config.xml");
    String s = client.getAge();
    assertEquals ("12", s);
    client.setAge ("30");
    s = client.getAge();
    client.close();
  }
}

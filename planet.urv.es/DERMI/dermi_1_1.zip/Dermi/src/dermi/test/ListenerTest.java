/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.util.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.listener.*;
import dermi.samples.listener.TestListener;

/**
 * This is the listener testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 * @version 1.1
 */
public class ListenerTest extends TestCase {
  SpriteImpl server;

  public ListenerTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[ListenerTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new SpriteImpl ("yeah!", env);
      server.writeERef ("dermi-config.xml");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[ListenerTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try	{
      server.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (ListenerTest.class);
  }


  public void testListener() throws Exception {
    Sprite client = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    TestListener l1 = new TestListener();
    TestListener l2 = new TestListener();
    TestListener l3 = new TestListener();

    client.addSpriteListener(SpriteEvent.class, l1);
    client.addSpriteListener(SpriteEvent.class, l2);
    client.addSpriteListener(SpriteEvent.class, l3);

    Sprite client2 = (Sprite) FileRegistry.loadERef ("dermi-config.xml");;
    client2.setX ("OH YEAH!");

    assertEquals (l1.getValue(), "OH YEAH!");
    assertEquals (l2.getValue(), "OH YEAH!");
    assertEquals (l3.getValue(), "OH YEAH!");

    client.removeSpriteListener (SpriteEvent.class, l1);
    client.removeSpriteListener (SpriteEvent.class, l2);
    client.removeSpriteListener (SpriteEvent.class, l3);

/*    for (int i = 0; i < 100; i++) {
      client2.setX ("MEGAYEAH");
    }

    assertEquals (l1.getValue(), "MEGAYEAH");
    assertEquals (l2.getValue(), "MEGAYEAH");
    assertEquals (l3.getValue(), "MEGAYEAH");
*/
    client.close();
    Thread.sleep (1000);
    client2.close();
  }

  public void testRemoteListener() throws Exception {
    Sprite client = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    TestListener l1 = new TestListener();
    TestListener l2 = new TestListener();

    client.addSpriteListener (SpriteEvent.class, l1);

    Sprite client2 = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    client2.addSpriteListener (SpriteEvent.class, l2);

    Sprite client3 = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    client3.setX ("YEAH!, YEAH!");

    assertEquals (l1.getValue(), "YEAH!, YEAH!");
    assertEquals (l2.getValue(), "YEAH!, YEAH!");

    client.removeSpriteListener (SpriteEvent.class, l1);
    client2.removeSpriteListener (SpriteEvent.class, l2);

    client.close();
    Thread.sleep (1000);
    client2.close();
    Thread.sleep (1000);
    client3.close();
  }

  public void testCountListener() throws Exception {
    Sprite client = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    TestListener l1 = new TestListener();
    TestListener l2 = new TestListener();
    client.addSpriteListener (SpriteEvent.class, l1);

    Sprite client2 = (Sprite) FileRegistry.loadERef ("dermi-config.xml");
    client2.addSpriteListener (SpriteEvent.class, l2);

    Sprite client3 = (Sprite) FileRegistry.loadERef ("dermi-config.xml");

    for (int i = 0; i < 30; i++) {
      client3.setX (i + "");
      Thread.sleep (10);
    }

    assertEquals ("Listener 1", "29", l1.getValue());
    assertEquals ("Listener 2", "29", l2.getValue());

    assertEquals ("Listener 1", 30, l1.getCnt());
    assertEquals ("Listener 2", 30, l2.getCnt());

    client.removeSpriteListener (SpriteEvent.class, l1);
    client2.removeSpriteListener (SpriteEvent.class, l2);

    client.close();
    Thread.sleep (1000);
    client2.close();
    Thread.sleep (1000);
    client3.close();
  }
}

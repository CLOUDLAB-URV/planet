/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.util.*;

import dermi.*;
import dermi.registry.*;
import dermi.samples.anycall.*;

/**
 * Anycall functionality testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class AnycallTest extends TestCase {
  SetiImpl server;

  public AnycallTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[AnycallTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = Registry.getEnvironment ("dermi-config.xml");
      server = new SetiImpl (env);
      server.writeERef ("dermi-config.xml");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[AnycallTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
       server.close();
       Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (AnycallTest.class);
  }

  public void testAnycall() throws Exception {
    Seti client = (Seti) FileRegistry.loadERef ("dermi-config.xml");
    for (int i = 0; i < 3; i++) {
      String s = client.getDataUnit ("United Devices");
      assertEquals ("63666737873_UD", s);
      Thread.sleep (50);
    }

    for (int i = 0; i < 2; i++) {
      String s = client.getDataUnit ("SETI@Home");
      assertEquals ("46672872982_SaH", s);
      Thread.sleep (50);
    }

    try {
      String s = client.getDataUnit ("SETI@Home");
      fail ("NotSatisfiedException not thrown when data units exhausted!");
    } catch (dermi.exception.NotSatisfiedException ne) {
      assertEquals (true, true);
    }

    client.close();
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.core.pastry;

import java.io.*;

import rice.p2p.commonapi.*;
import rice.p2p.scribe.*;

/**
 * This class contains interceptor application's vital data (specific to Scribe)
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @version 1.1
 */
public class InterceptorApp implements dermi.core.InterceptorApp {
  // Interceptor id
  private String key;

  // Interceptor application
  private transient ScribeClient app;

  // Node handle where the interceptor application resides
  private rice.p2p.commonapi.NodeHandle handle;

  /**
   * Constructor
   * @param key String Interceptor id
   * @param client ScribeClient Interceptor application
   * @param handle NodeHandle Node handle where the interceptor application resides
   */
  public InterceptorApp (String key, rice.p2p.scribe.ScribeClient client, rice.p2p.commonapi.NodeHandle handle) {
    this.key = key;
    this.app = (ScribeClient) client;
    this.handle = handle;
  }

  /**
   * Get interceptor id
   * @return String Interceptor id
   */
  public String getInterceptorId() {
    return key;
  }

  /**
   * Get interceptor application
   * @return ScribeClient Interceptor application
   */
  public ScribeClient getApplication() {
    return app;
  }

  /**
   * Get interceptor application's node handle
   * @return NodeHandle Application's node handle
   */
  public rice.p2p.commonapi.NodeHandle getApplicationNodeHandle() {
    return handle;
  }

  public String toString() {
    return "InterceptorKey: " + key + " InterceptorApp: " + app; // + " InterceptorHandle: " + handle;
  }
}

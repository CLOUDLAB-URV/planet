/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.core;

import dermi.*;
import dermi.session.*;
import dermi.exception.*;

import rice.p2p.commonapi.*;
import rice.pastry.*;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;
import rice.p2p.scribe.*;

import java.util.*;
import java.io.*;
import java.net.*;
import java.nio.channels.*;

/**
 * This class wraps a connection to Pastry and is used by Dermi as its main
 * routing substrate.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class DermiConnection {
  // ----- VARIABLES -----

  // the collection of nodes which have been created
  protected Node[] nodes;

  // the number of nodes to create
  public static int NUM_NODES = 10;

  // ----- PASTRY SPECIFIC VARIABLES -----

  // the factory for creating pastry nodes
  protected PastryNodeFactory factory;

  // the simulator, in case of direct
  protected NetworkSimulator simulator;

  // ----- TESTING SPECIFIC FIELDS -----

  // the direct protocol
  public static final int PROTOCOL_DIRECT = -138;

  // the possible network simulation models
  public static final int SIMULATOR_SPHERE = -1;
  public static final int SIMULATOR_EUCLIDEAN = -2;

  // the factory which creates pastry ids
  public static IdFactory FACTORY = new PastryIdFactory();

  // ----- PASTRY SPECIFIC FIELDS -----

  // the port to begin creating nodes on
  public static int PORT = 5009;

  // the host to boot the first node off of
  public static String BOOTSTRAP_HOST = "localhost";

  // the port on the bootstrap to contact
  public static int BOOTSTRAP_PORT = 5009;

  // the procotol to use when creating nodes
  public static int PROTOCOL = DistPastryNodeFactory.PROTOCOL_WIRE;

  // the simulator to use in the case of direct
  public static int SIMULATOR = SIMULATOR_SPHERE;

  // the instance name to use
  public static String INSTANCE_NAME = "Dermi";

  // Scribe reference
  private DermiKernel bus;

  private PastryNode pn;

  // ----- ATTEMPT TO LOAD LOCAL HOSTNAME -----
  static {
    try {
      BOOTSTRAP_HOST = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      System.out.println ("Error determining local host: " + e);
    }
  }

  /**
   * This method creates a new node which will serve as the underlying p2p layer
   * for Dermi
   * @param bootHost String Bootstrap host
   * @param bootPort int Bootstrap port
   * @param fac PastryNodeFactory The node factory to use
   * @param protocol int The protocol to be used
   * @throws ConnectionException If connection cannot be established against the bootstrap
   */
  public DermiConnection (String bootHost, int bootPort, PastryNodeFactory fac, int protocol) throws ConnectionException {
    if (!bootHost.equalsIgnoreCase ("auto")) {
      BOOTSTRAP_HOST = bootHost;
    }
    BOOTSTRAP_PORT = bootPort;
    PROTOCOL = protocol;

    if (SIMULATOR == SIMULATOR_SPHERE) {
      simulator = new SphereNetwork();
    } else {
      simulator = new EuclideanNetwork();
    }

    if (PROTOCOL == PROTOCOL_DIRECT) {
      factory = new DirectPastryNodeFactory (new RandomNodeIdFactory(), simulator);
      nodes = new Node[NUM_NODES];
    }

    // If Id factory is null, a new one is created
    if (fac == null) {
      int newPort = PORT;

      // If working in remote mode, check if port is already bound (this way
      // we allow several Dermis running on the same machine)
      if (PROTOCOL != PROTOCOL_DIRECT) {
        while (true) {
          DatagramChannel channel = null;
          try {
            channel = DatagramChannel.open();
            channel.configureBlocking (false);
            InetSocketAddress isa = new InetSocketAddress (newPort);
            channel.socket().bind (isa);
            channel.socket().close();
            channel.close();

            factory = DistPastryNodeFactory.getFactory (new RandomNodeIdFactory(), PROTOCOL, newPort);
            break;
          } catch (IOException e) {
            newPort += 100;
            System.out.println ("Port " + (newPort - 100) + " already bound. Trying " + newPort + "...");
          }
          finally {
            channel.socket().close();
            try {
              channel.close();
            }
            catch (IOException ex) {
              throw new ConnectionException (ex);
            }
          }
        }
      }
      else {
        factory = fac;
      }

      // Get bootstrap reference
      rice.pastry.NodeHandle bootstrap = getBootstrap();

      pn = factory.newNode (bootstrap);   // internally initiateJoins

      // Initialize Event bus
      bus = new DermiKernel (INSTANCE_NAME, this);

      // Initialize DOLR layer
      // Only initialize it if it has not been previously initialized in the
      // same node
      if (!(Naming.isConnected())) {
        try {
          Naming.loadRegistry (FACTORY, pn, Context.REPLICATION_FACTOR);
          // Bind special root object
          Naming.bindRoot();
        } catch (RemoteException re) {
          throw new ConnectionException ("Unable to connect to decentralized object location registry!");
        }
      }
    }
    System.out.println ("Dermi layer initialized OK.");
  }

  /**
   * Gets a handle to a bootstrap node.
   *
   * @return handle to bootstrap node, or null.
   */
  protected rice.pastry.NodeHandle getBootstrap() {
    if (PROTOCOL == PROTOCOL_DIRECT) {
      return ((DirectPastryNode) nodes[0]).getLocalHandle();
    } else {
      InetSocketAddress address = new InetSocketAddress (BOOTSTRAP_HOST, BOOTSTRAP_PORT);
      return ((DistPastryNodeFactory) factory).getNodeHandle (address);
    }
  }

  /**
   * Method for subscribing an application to a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to subscribe
   */
  public void subscribe (Topic topic, ScribeClient subscriber) {
      bus.subscribe (topic, subscriber);
  }

  /**
   * Method for unsubscribing an application from a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to unsubscribe
   */
  public void unsubscribe (Topic topic, ScribeClient subscriber) {
      bus.unsubscribe (topic, subscriber);
  }

  /**
   * Method for publishing data
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void publish (Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.publish (topic, dat);
  }

  /**
   * Method for publishing data directly to a node
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void publishDirect (Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.publishDirect (topic, dat);
  }

  /**
   * Method for anycalling to a group of objects
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void anycall (Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.anycast (topic, dat);
  }

  /**
   * Utility method for obtaining the local node handle
   * @return NodeHandle Local node handle
   */
  public rice.p2p.commonapi.NodeHandle getLocalNodeHandle() {
    return bus.getLocalNodeHandle();
  }

  /**
   * Utility method for obtaining the local node
   * @return Node Local node
   */
  public rice.p2p.commonapi.Node getLocalNode() {
    return pn;
  }

  /**
   * Method for adding an interceptor to an object group
   * @param npar NotificationParser Interceptor application
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public void addInterceptor (NotificationParser npar, rice.p2p.commonapi.Id subsKey, String interceptorId) {
    bus.addInterceptor (npar, new Topic (subsKey), interceptorId + getLocalNodeHandle().getId());
  }

  /**
   * Method for removing an interceptor from an object group
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public void removeInterceptor (rice.p2p.commonapi.Id subsKey, String interceptorId) {
    bus.removeInterceptor (new Topic (subsKey), interceptorId + getLocalNodeHandle().getId());
  }

  /**
   * Method for resume the interception process. Automatically called
   * by interceptor skeletons
   * @param evt Hashtable
   * @param interceptors ArrayList
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors) {
    bus.continueInterception (evt, interceptors);
  }

  /**
   * Method for closing a connection, thus killing the node
   */
  public void close() {
    pn.kill();
  }
}

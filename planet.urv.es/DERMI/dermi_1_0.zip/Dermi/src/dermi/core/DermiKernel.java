/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.core;

import java.util.*;

import dermi.util.*;
import dermi.session.*;
import dermi.messaging.*;
import dermi.exception.*;

import rice.p2p.scribe.*;
import rice.p2p.scribe.messaging.*;
import rice.p2p.commonapi.*;

/**
 * This class implements the kernel of Dermi. It extends the Scribe event
 * service to provide all the features and services
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class DermiKernel extends ScribeImpl {
  private DermiConnection conn = null;

  /**
   * The kernel constructor
   * @param instance String Instance name
   * @param conn DermiConnection The connection node
   */
  public DermiKernel (String instance, DermiConnection conn) {
    super (conn.getLocalNode(), instance);
    this.conn = conn;
  }

  /**
   * Method for adding an interceptor object to an object group
   * @param client ScribeClient Interceptor application
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  public void addInterceptor (ScribeClient client, Topic topic, String intId) {
    // System.out.println ("Adding interceptor...");
    TopicManager manager = (TopicManager) topics.get (topic);

    if (manager == null) {
      // System.out.println ("Creating topic manager on this node...");
      manager = new TopicManager (topic);
      topics.put (topic, manager);
    }

    // Send a message to the group's root so as the new interceptor is added.
    // If root is local node, the message is not sent remotely
    manager.addInterceptor (intId, client, this.getLocalNodeHandle());
    sendInterceptorSubscribeMsg (handle, topic, intId);
  }

  /**
   * For sending an interceptor subscribe message
   * @param handle NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  private void sendInterceptorSubscribeMsg (NodeHandle handle, Topic topic, String intId) {
    endpoint.route (topic.getId(), new InterceptorSubscribeMessage (handle, topic, handle, intId), null);
  }

  /**
   * For sending an interceptor unsubscribe message
   * @param handle NodeHandle Source node handle
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  private void sendInterceptorUnsubscribeMsg (NodeHandle handle, Topic topic, String intId) {
    endpoint.route (topic.getId(), new InterceptorUnsubscribeMessage (handle, topic, intId), null);
  }

  /**
   * Method for removing an interceptor from an object group
   * @param topic Topic Group's identifier
   * @param intId String Interceptor id
   */
  public void removeInterceptor (Topic topic, String intId) {
    // System.out.println ("Removing interceptor...");
    TopicManager manager = (TopicManager) topics.get (topic);

    if (manager == null) {
    //  System.out.println ("Nothing to remove here...");
    }

    // Send a message to the group's root so as the new interceptor is removed.
    // If root is local node, the message is not sent remotely
    manager.removeInterceptor (intId);
    sendInterceptorUnsubscribeMsg (handle, topic, intId);
  }

  /**
   * Returns the local node handle
   * @return NodeHandle Returned node handle
   */
  public NodeHandle getLocalNodeHandle() {
    return handle;
  }

  /**
   * Publishes a direct message to the topic. (This means sending it not via
   * the rendezvous point, but directly to the destination peer)
   *
   * @param topic The topic to publish to
   * @param content The content to publish
   */
  public void publishDirect (Topic topic, DermiContent content) {
    NodeHandle nh = null;
    if (((Hashtable) content.getData()).get ("DEST_NHANDLE") != null) {
      nh =(NodeHandle) ((Hashtable) content.getData()).get ("DEST_NHANDLE");
    }
    else {
      nh = (NodeHandle) ( (Hashtable) content.getData()).get ("SOURCE_NHANDLE");
    }
    endpoint.route (nh.getId(), new DirectMessage (handle, topic, content), nh);
  }

  /**
   * This method is invoked to inform the application that the given node has either joined or left
   * the neighbor set of the local node, as the set would be returned by the neighborSet call.
   *
   * @param handle The handle that has joined/left
   * @param joined Whether the node has joined or left
   */
  public void update (NodeHandle handle, boolean joined) {
    Set set = topics.keySet();
    Iterator e = set.iterator();
    TopicManager manager;
    Topic topic;

    while (e.hasNext()){
      topic = (Topic)e.next();
      manager = (TopicManager) topics.get (topic);

      if (joined) {
        // check if new guy is root, we were old root, then subscribe
        if (manager.getParent() == null){
          // send subscribe message
          super.sendSubscribe (topic, null, null);
          // send interceptor data
          if (manager.containsInterceptors()) {
            sendInterceptorData (topic, manager);
          }
        }
      } else {
        if (isRoot (topic) && (manager.getParent() != null)) {
          endpoint.route (manager.getParent().getId(), new UnsubscribeMessage (handle, topic), manager.getParent());
          manager.setParent (null);
        }
      }
    }
  }

  /**
   * Method for sending interceptor data
   * @param topic Topic Group's identifier
   * @param manager TopicManager The group's manager
   */
  private void sendInterceptorData (Topic topic, TopicManager manager) {
    endpoint.route (topic.getId(), new InterceptorDataMessage (getLocalNodeHandle(), topic, manager.getInterceptors()),null);
  }

  /**
   * The Common API forward method has been changed to first pass the RouteMessage to Dermi's notification
   * parser, so as to be able to route new messages with contents changes (useful in manycalls)
   *
   * @param message RouteMessage Received message
   * @return boolean true if message has to be routed further
   */
  public boolean forward (final RouteMessage message) {
    log.finest(endpoint.getId() + ": Forward called with " + message.getMessage());

    if (message.getMessage() instanceof AnycastMessage) {
      AnycastMessage aMessage = (AnycastMessage) message.getMessage();

      // get the topic manager associated with this topic
      TopicManager manager = (TopicManager) topics.get (aMessage.getTopic());

      // if it's a subscribe message, we must handle it differently
      if (message.getMessage() instanceof SubscribeMessage) {
        SubscribeMessage sMessage = (SubscribeMessage) message.getMessage();

        // if this is our own subscribe message, ignore it
        if (sMessage.getSource().getId().equals(endpoint.getId())) {
          return true;
        }

        if (manager != null) {
          // first, we have to make sure that we don't create a loop, which would occur
          // if the subcribing node's previous parent is on our path to the root
          Id previousParent = sMessage.getPreviousParent();
          List path = Arrays.asList(manager.getPathToRoot());

          if (path.contains(previousParent)) {
            log.info(endpoint.getId() + ": Rejecting subscribe message from " +
                      sMessage.getSubscriber() + " for topic " + sMessage.getTopic() +
                      " because we are on the subscriber's path to the root.");
            return true;
          }
        }

        ScribeClient[] clients = new ScribeClient[0];
        NodeHandle[] handles = new NodeHandle[0];

        if (manager != null) {
          clients = manager.getClients();
          handles = manager.getChildren();
        }

        // check if child is already there
        if (Arrays.asList(handles).contains (sMessage.getSubscriber())){
          return false;
        }

        // see if the policy will allow us to take on this child
        if (policy.allowSubscribe(sMessage, clients, handles)) {
          log.finer(endpoint.getId() + ": Hijacking subscribe message from " +
            sMessage.getSubscriber() + " for topic " + sMessage.getTopic());

          // if so, add the child
          addChild(sMessage.getTopic(), sMessage.getSubscriber());
          return false;
        }

        // otherwise, we are effectively rejecting the child
        log.finer(endpoint.getId() + ": Rejecting subscribe message from " +
          sMessage.getSubscriber() + " for topic " + sMessage.getTopic());

        // if we are not associated with this topic at all, we simply let the subscribe go
        // closer to the root
        if (manager == null) {
          return true;
        }
      } else {
        // if we are not associated with this topic at all, let the
        // anycast continue
        if (manager == null) {
          return true;
        }

        ScribeClient[] clients = manager.getClients();

        // see if one of our clients will accept the anycast
        for (int i = 0; i < clients.length; i++) {
          if (clients[i] instanceof dermi.session.DermiApplicationListener) {
            aMessage.setContent (((dermi.session.DermiApplicationListener) clients[i]).interceptAnycast (aMessage.getTopic(), aMessage.getContent()));
          }
          if (clients[i].anycast(aMessage.getTopic(), aMessage.getContent())) {
            log.finer(endpoint.getId() + ": Accepting anycast message from " +
              aMessage.getSource() + " for topic " + aMessage.getTopic());

            return false;
          }
        }

        // if we are the orginator for this anycast and it already has a destination,
        // we let it go ahead
        if (aMessage.getSource().getId().equals(endpoint.getId()) &&
            ( message.getNextHopHandle() != null) &&
            (! handle.equals(message.getNextHopHandle()))) {
          return true;
        }

        log.finer(endpoint.getId() + ": Rejecting anycast message from " +
          aMessage.getSource() + " for topic " + aMessage.getTopic());
      }

      // add the local node to the visited list
      aMessage.addVisited (endpoint.getLocalNodeHandle());

      // allow the policy to select the order in which the nodes are visited
      policy.directAnycast (aMessage, manager.getParent(), manager.getChildren());

      // reset the source of the message to be us
      aMessage.setSource (endpoint.getLocalNodeHandle());

      // get the next hop
      NodeHandle handle = aMessage.getNext();

      // make sure that the next node is alive
      while ((handle != null) && (!handle.isAlive())) {
        handle = aMessage.getNext();
      }

      log.finer(endpoint.getId() + ": Forwarding anycast message for topic " + aMessage.getTopic() + "on to " + handle);

      if (handle == null) {
        System.err.println (endpoint.getId() + ": Anycast " + aMessage + " failed.");

        // Any/Many call unsatisfied by any of the group members
        DermiContent dc = (DermiContent) aMessage.getContent();
        Hashtable ht = (Hashtable) dc.getData();

        Hashtable send = new Hashtable();
        if (ht.get("OBJECT") != null) {
          send.put ("OBJ", ht.get ("OBJECT") + ":RESULT");
        }
        else {
          send.put ("OBJ", ht.get ("OBJ"));
        }
        send.put ("TYPE", "EXCEPTION");
        send.put ("METHOD", ht.get ("METHOD"));
        send.put ("TIMESTAMP", ht.get ("TIMESTAMP"));
        send.put ("object", new dermi.exception.NotSatisfiedException ());

        NodeHandle nh = (NodeHandle) (ht.get ("SOURCE_NHANDLE"));
        DermiContent content = new DermiContent (send);

        endpoint.route (nh.getId(), new PublishRequestMessage (nh, new Topic (dermi.util.HashGenerator.generateSessionHash (send)), content), nh);

        // if it's a subscribe message, send a subscribe failed message back
        // as a courtesy
        if (aMessage instanceof SubscribeMessage) {
          SubscribeMessage sMessage = (SubscribeMessage) aMessage;
          log.finer(endpoint.getId() + ": Sending SubscribeFailedMessage to " + sMessage.getSubscriber());

          endpoint.route(sMessage.getSubscriber().getId(),
                         new SubscribeFailedMessage(handle, sMessage.getTopic(), sMessage.getId()),
                         sMessage.getSubscriber());
        }
      } else {
        endpoint.route (handle.getId(), aMessage, handle);
      }

      return false;
    }

    return true;
  }

  /**
   * This method is called on the application at the destination node for the given id.
   *
   * @param id The destination id of the message
   * @param message The message being sent
   */
  public void deliver (Id id, Message message) {
    if (message instanceof InterceptorSubscribeMessage) {
      InterceptorSubscribeMessage iMessage = (InterceptorSubscribeMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        // System.out.println ("The root has no manager for this topic!!!");
      }
      else {
        // Add interceptor application. The root will know it is a remote interceptor, because
        // null client is specified
        // System.out.println ("Added new interceptor to the root.");
        manager.addInterceptor (iMessage.getInterceptorId(), null, iMessage.getInterceptorHandle());
      }
      return;
    }

    if (message instanceof InterceptorUnsubscribeMessage) {
      InterceptorUnsubscribeMessage iMessage = (InterceptorUnsubscribeMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        System.out.println ("The root has no manager for this topic!!!");
      }
      else {
        // Remove interceptor application.
        // System.out.println ("Removed interceptor from the root.");
        manager.removeInterceptor (iMessage.getInterceptorId());
      }
      return;
    }

    if (message instanceof InterceptorDataMessage) {
      InterceptorDataMessage iMessage = (InterceptorDataMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        // System.out.println ("The root has no manager for this topic!!!");
      }
      else {
        // System.out.println ("Received interceptor data from old root...");
        Iterator it = iMessage.getInterceptors().iterator();

        while (it.hasNext()) {
          // System.out.println ("Interceptor clients received by the message: " + iMessage.getInterceptors());
          // System.out.println ("Interceptor clients in the topic manager: " + manager.getInterceptors() + "\n");
          InterceptorApp intApp = (InterceptorApp) it.next();
          if (!manager.existsInterceptor (intApp.getInterceptorId())) {
            // System.out.println ("Adding new interceptor.");
            manager.addInterceptor (intApp.getInterceptorId(), intApp.getApplication(), intApp.getApplicationNodeHandle());
          }
        }
      }

      return;
    }

    if (message instanceof DirectMessage) {
      DirectMessage dMessage = (DirectMessage) message;
      TopicManager manager = (TopicManager) topics.get (dMessage.getTopic());
      if (manager != null) {
        ScribeClient[] clients = manager.getClients();

        for (int i = 0; i < clients.length; i++) {
          clients[i].deliver (dMessage.getTopic(), dMessage.getContent());
        }
      }
      return;
    }

    if (message instanceof PublishRequestMessage) {
      PublishRequestMessage prMessage = (PublishRequestMessage) message;
      TopicManager manager = (TopicManager) topics.get(prMessage.getTopic());

      log.finer(endpoint.getId() + ": Received publish request message with data " +
                prMessage.getContent() + " for topic " + prMessage.getTopic());

      // if message is for a non-existant topic, drop it on the floor (we are the root, after all)
      // otherwise, turn it into a publish message, and forward it on
      if (manager == null) {
        log.fine(endpoint.getId() + ": Received publish request message for non-existent topic " +
                 prMessage.getTopic() + " - dropping on floor.");
      } else {

        // if the root has interceptors, we must forward the message to the first one, before forwarding it to the members
        // of the group
        while (manager.containsInterceptors()) {
          // System.out.println ("Entering interception phase...");
          ArrayList interceptors = manager.getInterceptors();
          InterceptorApp app = (InterceptorApp) interceptors.get (0);
          // System.out.println ("The next interceptor is alive? " + app.getApplicationNodeHandle().isAlive());
          if (app.getApplicationNodeHandle().isAlive()) {
            endpoint.route (app.getApplicationNodeHandle().getId(), new InterceptorMessage (getLocalNodeHandle(), prMessage.getSource(), prMessage.getTopic(), prMessage.getContent(), interceptors), app.getApplicationNodeHandle());
            return;
          }
        }
        // System.out.println ("Publishing without interception.");
        deliver (prMessage.getTopic().getId(), new PublishMessage (prMessage.getSource(), prMessage.getTopic(), prMessage.getContent()));
        return;
      }
    }

    if (message instanceof InterceptorMessage) {
      // System.out.println ("Interception message received.");
      InterceptorMessage iMessage = (InterceptorMessage) message;
      TopicManager manager = (TopicManager) topics.get (iMessage.getTopic());

      if (manager == null) {
        System.out.println(endpoint.getId() + ": Received interceptor message for non-existent topic " +
                 iMessage.getTopic() + " - dropping on floor.");
      }
      else {
        // Check if already intercepted message has reached the root
        if (isRoot (iMessage.getTopic()) && iMessage.isInterceptionFinished()) {
          // System.out.println ("Publishing normally after interception...");
          deliver (iMessage.getTopic().getId(), new PublishMessage (getLocalNodeHandle(), iMessage.getTopic(), iMessage.getContent()));
        }

        else {
          // System.out.println ("Intercepting...");
          ArrayList interceptors = iMessage.getInterceptors();
          try {
            InterceptorApp app = (InterceptorApp) interceptors.get (0);
            interceptors.remove (0);
            String intKey = app.getInterceptorId();

            // Look for this key in the topic manager's interceptor clients and
            // execute the callback
            NotificationParser np = (NotificationParser) manager.getInterceptorClient (intKey);
            Hashtable content = (Hashtable) ((DermiContent) iMessage.getContent()).getData();
            np.receiveInterceptorMessage (content, interceptors);
          } catch (IndexOutOfBoundsException abe) {
            // Interceptor unavailable (maybe interceptor data has not reached the root yet)
            // System.out.println ("Distributed interception failure!!! - Sending message to group members without being intercepted.");
            endpoint.route (iMessage.getTopic().getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), iMessage.getTopic(), iMessage.getContent(), interceptors, true), null);
          }
        }
      }
      return;
    }

    // To deal with other kinds of standard Scribe messages
    super.deliver (id, message);
  }

  /**
   * Method invoked by interceptor skeletons to resume the interception process
   * @param evt Hashtable Event data
   * @param interceptors ArrayList Remaining interceptors to be traversed
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors) {
    Topic topic = new Topic (HashGenerator.generateSessionHash (evt));

    // Check whether it is the last interceptor on the queue
    while (interceptors.size() != 0) {
      InterceptorApp iApp = (InterceptorApp) interceptors.get (0);
      NodeHandle interceptorHandle = iApp.getApplicationNodeHandle();
      // System.out.println ("Resuming interception process... - to interceptor " + iApp.getInterceptorId());
      if (interceptorHandle.isAlive()) {
        endpoint.route (interceptorHandle.getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), topic, new DermiContent (evt), interceptors), interceptorHandle);
        return;
      }
      // System.out.println ("Interceptor dead... Proceeding to next one...");
      interceptors.remove (0);
    }
    // Should be routed directly to root ?
    // System.out.println ("Sending message back to multicast group root...");
    endpoint.route (topic.getId(), new InterceptorMessage (getLocalNodeHandle(), getLocalNodeHandle(), topic, new DermiContent (evt), interceptors, true), null);
  }
}

/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import java.io.*;
import java.net.*;
import java.util.*;

import dermi.exception.*;
import dermi.util.*;

/**
 * This is a custom class loader that makes a request to the remote object for the stub class when this is not found
 * on the local machine. The remote object then sends the stub class using the event service and the BusClassLoader
 * loads it in the custom virtual machine enabling highly dynamic remote applications.<br>
 * The difference between Java <RMI is that each object is then responsible for returning the stub class for remote clients.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class BusClassLoader extends ClassLoader implements RemoteEventListener {
  private String baseUrl;
  private Hashtable cache = new Hashtable();
  private Hashtable evt = new Hashtable();
  private Hashtable subs = new Hashtable();
  private Session conn = null;
  private byte data[];
  private boolean resultArrived = false;
  private boolean exception = false;
  private Properties env;

  /**
   * Class constructor
   * @param env Properties Environment properties
   */
  public BusClassLoader (Properties env) {
    super();
    this.env = env;

    String uid = env.getProperty (Context.CLASS_ID);
    subs.put ("OBJ", uid + ":RESULTDYNAMIC");
    evt.put ("OBJECT", uid);
    evt.put ("TYPE", "DISPATCH");
    evt.put ("METHOD", "getBytes");
  }

  /**
   * This method is called whenever an event is received
   * @param evt Hashtable Event data
   */
  public void eventArrived (Hashtable evt) {
    String type = (String) evt.get ("TYPE");
    if (type.equals ("EXCEPTION")) {
      exception = true;
    }
    else {
      ByteWrapper bw = (ByteWrapper) evt.get ("object");
      data = bw.getBytes();
    }
    resultArrived = true;
  }

  /**
   * This method should be used before closing any instance of this class
   */
  public void close() {
    if (conn != null) {
      Bus.close();
      conn = null;
    }
  }

  /**
   * Method used for class data loading
   * @param name String Class name
   * @throws ClassNotFoundException If class cannot be found
   * @return byte[] Class data
   */
  private byte[] loadClassData (String name) throws ClassNotFoundException {
    String urlName = baseUrl + (baseUrl.endsWith("/") ? "":"/") + name.replace('.','/') + ".class";

    try {
      URL url = new URL (urlName);
      URLConnection connection = url.openConnection();
      connection.connect();

      int len = connection.getContentLength();
      if (len == -1) {
        throw new ClassNotFoundException();
      }

      byte[] result = new byte[len];
      InputStream input = connection.getInputStream();

      int offset = 0;
      int nb;

      while((nb = input.read (result,offset,len)) != -1){
	offset+=nb;
	len-=nb;
      }

      input.close();
      return result;
    } catch(Exception e) {
      throw new ClassNotFoundException();
    }
  }

  /**
   * Method for remote class to load the specifed class
   * @param name Complete class name
   * @param resolve Boolean look up remotely.
   * @throws ClassNotFoundException Problem with the loaded class: not found.
   */
  public synchronized Class loadClass (String name, boolean resolve) throws ClassNotFoundException {
    try {
      return findSystemClass (name);
    }
    catch (Exception e) {
      Class c = (Class) cache.get (name);
      if (c == null) {
        System.out.println("DERMI: Loading remote class...");
        try {
          conn = Bus.getBus (env);
          conn.subscribe (this, subs);
        } catch (SessionException ex) {
          throw new ClassNotFoundException ("DERMI: Problems with the Event service.");
        } catch (RemoteException ex2) {
          throw new ClassNotFoundException ("DERMI: Problems with the Event service.");
        }

        String tstamp = "" + System.currentTimeMillis();
        for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
          try {
            evt.put ("TIMESTAMP", tstamp);
            conn.publish (evt);
          } catch (SessionException ex) {
            throw new ClassNotFoundException ("DERMI: Problems with the Event service.");
          }
          int timeout = 0;
          while (!resultArrived && timeout < Context.TIMEOUT) {
            try {
              Thread.currentThread().sleep (Context.DELAY);
            } catch (InterruptedException ex) {
              ex.printStackTrace();
            }
            timeout++;
          }
          if (exception) {
            exception = false;
            throw new ClassNotFoundException ("DERMI: Remote class is unavailable.");
          } else if (timeout == Context.TIMEOUT) {
            retransmission++;
            continue;
          }
          break;
        }
        c = defineClass (null, data, 0, data.length);
        cache.put (name, c);
      }

      if (resolve) {
        resolveClass(c);
      }
      return c;
    }
  }
}

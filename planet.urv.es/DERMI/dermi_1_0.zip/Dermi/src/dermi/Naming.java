/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import java.io.*;
import java.util.*;

import dermi.core.*;
import dermi.exception.*;
import dermi.registry.*;
import dermi.util.*;

import rice.p2p.commonapi.*;
import rice.p2p.commonapi.Id;
import rice.pastry.*;

/**
 * The Naming class provides methods for storing and obtaining references to remote objects
 * in the remote object registry.<br><br>
 * The dermi.Naming API (unlike Java RMI) does not use URLs, but properties objects or files
 * containing connection parameters. It is then mandatory to call the <i>loadRegistry</i> method
 * before using the functionality of the registry.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Ruben Mondejar
 */
public class Naming {
  private static Registry registry = null;
  private static DermiConnection connection = null;

  /**
   * It connects to the decentralized registry
   * @param FACTORY IdFactory Factory for Id creation
   * @param pn Node The node where the registry will run on
   * @param REPLICATION_FACTOR int Replication factor
   * @throws RemoteException If registry cannot be created
   */
  public static void loadRegistry (IdFactory FACTORY, Node pn, int REPLICATION_FACTOR) throws RemoteException {
    if (registry == null) {
      registry = new Registry (FACTORY, (PastryNode) pn, REPLICATION_FACTOR);
    }
  }

  /**
   * It connects to the Registry (by creating a pastry node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void loadRegistry (String ref) throws RemoteException {
    if (registry == null) {
      try {
        FileInputStream fis = new FileInputStream (ref);
        Properties env = new Properties();
        env.load (fis);
        String hostName = env.getProperty (dermi.Context.PROVIDER_HOST);
        int port = (new Integer (env.getProperty(dermi.Context.PROVIDER_PORT))).intValue();

        connection = new DermiConnection (hostName, port, null, new Integer (env.getProperty (dermi.Context.PROTOCOL)).intValue());
      } catch (FileNotFoundException e) {
        throw new RemoteException(e.getMessage());
      } catch (IOException e2) {
        throw new RemoteException(e2.getMessage());
      }
    }
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (name);
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (Id id) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.lookup (id);
  }

  /**
   * Method used to know if the registry is already connected to a Pastry node
   * @return boolean true if it is connected
   */
  public static boolean isConnected () {
    return (connection != null);
  }

  /**
   * Method used to get the connection to the Pastry node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public static DermiConnection getConnection() {
    return connection;
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, ERemote ref) throws RemoteException {
    if (registry == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    registry.bind (name, ref.getERef());
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bindRoot() throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");

    // System.out.println ("[DERMI REGISTRY] - Looking for base root...");
    try {
      Properties p = (Properties) registry.lookup (HashGenerator.generateHash ("p2p://"));
      registry.insert (HashGenerator.generateHash ("p2p://"), p);

    } catch (NotBoundException ne) {
      // System.out.println ("[DERMI REGISTRY] - Base root not bound... Binding 'p2p://'");
      Properties p = new Properties();
      p.setProperty (Context.DERMI_DOLR_UNIQUE_URI, "p2p://");
      p.put (Context.DERMI_DOLR_CHILDREN, new ArrayList());
      registry.insert (HashGenerator.generateHash ("p2p://"), p);
    }
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void rebind (String name, ERemote ref) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    registry.rebind (name, ref.getERef());
  }

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public static Collection list (String root) throws RemoteException {
    if (registry == null)
      throw new RegistryNotLoadedException ("Registry not loaded");
    return registry.list(root);
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand implements rice.Continuation {
    boolean received;
    Properties eref;

    public NamingCommand (boolean received, Properties eref) {
      this.received = received;
      this.eref = eref;
    }

    public void receiveResult (Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}

    public void receiveException(Exception e) {
      e.printStackTrace();
      System.out.println ("receiveException on NamingCommand");
    }
  }
}

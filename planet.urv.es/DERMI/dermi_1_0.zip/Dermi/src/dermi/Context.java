/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

/**
 *   Context contains dermi middleware constants like connection timeouts, block delays
 *   and String constants for the properties objects.
 *
 */

/**
 * This class contains Dermi's constants, like connection timeouts, synchronous blocking
 * delays, and String constants for the properties objects.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class Context {

  /**
   * Timeout constant. All timeouts will be consumend once TIMEOUT*DELAY milliseconds have been elapsed
   */
  public static int TIMEOUT = 200;

  /**
   * Default delay for synchronous calls
   */
  public static int DELAY = 10;

  /**
   * Number of event retransmissions in case all timeouts have been consumed
   */
  public static int RETRANSMISSIONS = 1000;

  /**
   * Number of replicas to use for PAST
   */
  public static int REPLICATION_FACTOR = 3;

  /**
   * The name of the constant containing the directory with loadable remote stubs
   */
  public static final String CLASS_STORE = "dermi.classStore";

  /**
   * The name of the constant containing the name of the Stub class for the properties reference
   */
  public static final String CLASS_NAME = "dermi.className";

  /**
   * CLASS_ID is the unique identifier assigned to an object server. It is used for all subscriptions
   * related to this object
   */
  public static final String CLASS_ID = "dermi.classID";

  /**
   * DERMI_DOLR_NAMING represents the DERMI naming distributed object location and routing facility
   */
  public static final String DERMI_DOLR_NAMING = "DERMI_DOLR_NAMING";

  /**
   * DERMI_DOLR_UNIQUE_URI represents the object URI identifier associated to an object
   */
  public static final String DERMI_DOLR_UNIQUE_URI = "DERMI_DOLR_UNIQUE_URI";

  /**
   * DERMI_DOLR_CHILDREN refers to the name of the field containing children objects for any object
   */
  public static final String DERMI_DOLR_CHILDREN = "DERMI_DOLR_CHILDREN";

  /**
   * DERMI_DOLR_PARENT refers to the parent of an object (in the naming hierarchy)
   */
  public static final String DERMI_DOLR_PARENT = "DERMI_DOLR_PARENT";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the class factory provider
   * to use.
   */
  public static final String PROVIDER_CLASS = "dermi.sessionClass";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the service provider
   * to use.
   */
  public static final String PROVIDER_HOST = "dermi.host";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the port numberof the  provider
   * to use.
   */
  public static final String PROVIDER_PORT = "dermi.port";

  /**
   * Constant that holds the protocol used by Dermi to communicate between remote nodes
   */
  public static final String PROTOCOL = "dermi.protocol";
}

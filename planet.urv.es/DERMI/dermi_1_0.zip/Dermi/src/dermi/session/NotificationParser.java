/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session;

import java.util.*;

import dermi.*;
import dermi.util.*;
import dermi.core.*;
import dermi.exception.*;

import rice.p2p.scribe.Topic;
import rice.p2p.scribe.ScribeContent;
import rice.p2p.commonapi.NodeHandle;

/**
 * This class encapsulates a notification parser which is notified about
 * events, and dispatches them to the different clients subscribed
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Ruben Mondejar
 */
public class NotificationParser implements DermiApplicationListener {
  private RemoteEventListener subs = null;
  private RemoteInterceptorListener intSubs = null;
  private ConnectionListener connSubs = null;
  private TimerThread tt;
  private DermiConnection conn;
  private Hashtable anycastResult = null;

  /**
   * Constructor
   * @param subs RemoteEventListener Application to be notified
   */
  public NotificationParser (RemoteEventListener subs) {
    this.subs = subs;
  }

  /**
   * Constructor
   * @param filtsubs RemoteInterceptorListener Interceptor application to be notified
   */
  public NotificationParser (RemoteInterceptorListener filtsubs) {
    this.intSubs = filtsubs;
  }

  /**
   * Constructor
   * @param connsubs ConnectionListener Connection listener to be notified
   */
  public NotificationParser (ConnectionListener connsubs) {
    this.connSubs = connsubs;
    tt = new TimerThread(connsubs);
  }

  /**
   * Sets this parser's connection
   * @param conn DermiConnection
   */
  public void setConnection (DermiConnection conn) {
    this.conn = conn;
  }

  /**
   * Invoked when an anycast event is received
   * @param topic Topic Group's identifier
   * @param cnt ScribeContent Anycast's content
   * @return boolean false if message must not be routed further
   */
  public boolean anycast (Topic topic, ScribeContent cnt) {
    if (anycastResult != null) {
      boolean notProcessed = ((Boolean) anycastResult.get ("ANYCALL_RESULT")).booleanValue();
      if (!notProcessed) {
        conn.publishDirect (new Topic (dermi.util.HashGenerator.generateSessionHash (anycastResult)), anycastResult);
        // Finally stop routing anycast message
        return true;
      }
      else {
        // Manycall
        if (anycastResult.get ("STATUS") != null) {
          // Continue routing modified anycast message
          return false;
        }
      }
    }
    return false;
  }

  /**
   * Invoked when an anycast event is received
   * @param topic Topic Group's identifier
   * @param cnt ScribeContent Original anycast message
   * @return ScribeContent Modified anycast message
   */
  public ScribeContent interceptAnycast (Topic topic, ScribeContent cnt) {
    DermiContent res = null;
    Hashtable data = (Hashtable) (((DermiContent) cnt).getData());

    try {
      anycastResult = ((RemoteAnycallEventListener) subs).anycallEventArrived (data);
      res = new DermiContent (anycastResult);
    }
    catch (UnmatchedAnycallMethodException ex) {
      // No method matching this anycall found, routing to another one
      return null;
    }

    return res;
  }

  /**
   * Closes bus connection
   */
  public void close() {
    if (connSubs != null) {
      tt.die();
    }
  }

  /**
   * Invoked when an interception message is received
   * @param msg Hashtable The message data
   * @param interceptors ArrayList Remaining interceptors list
   */
  public void receiveInterceptorMessage (Hashtable msg, ArrayList interceptors) {
    try {
      intSubs.interceptorEventArrived (msg, interceptors);
    }
    catch (RemoteException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Invoked when an event is received
   *
   * @param topic Topic Group's identifier
   * @param scribeContent ScribeContent Message content
   */
  public void deliver (Topic topic, ScribeContent scribeContent) {
    Hashtable ht = (Hashtable) ((DermiContent) scribeContent).getData();
    boolean special = ht.containsKey ("connection_event");

    if (connSubs != null) {
       if (tt.isAlive()) tt.alive();
       else tt.start();

      if (special) {
        String reason = (String) ht.get ("connection_event");
        if (reason.equals ("unregister")) {
          connSubs.publisherUnsubscribed();
        }
        else if (reason.equals ("close")) {
          connSubs.publisherClosed();
        }
        else if (reason.equals ("i'm alive")) {
          tt.alive();
        }
      }
    }
    else if (!special) {
      Dispatcher sP = new Dispatcher (subs, ht);
      sP.start();
    }
  }

  /**
   * Activated when a child is added to this node in the multicast group
   *
   * @param topic Topic Group's identifier
   * @param nodeHandle NodeHandle Child's node handle
   */
  public void childAdded (Topic topic, NodeHandle nodeHandle) {
  }

  /**
   * Activated when a child is removed from this node in the multicast group
   *
   * @param topic Topic Group's identifier
   * @param nodeHandle NodeHandle Child's node handle
   */
  public void childRemoved (Topic topic, NodeHandle nodeHandle) {
  }

  /**
   * Activated when a subscription failure is detected
   *
   * @param topic Topic Group's identifier
   */
  public void subscribeFailed (Topic topic) {
  }
}

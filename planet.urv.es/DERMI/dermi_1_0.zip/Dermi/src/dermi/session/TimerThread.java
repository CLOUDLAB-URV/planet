/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.session;

import dermi.*;

/**
 * This class is a timer thread that checks the liveness of a publisher
 *
 * @author Ruben Mondejar
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class TimerThread extends Thread {
  private ConnectionListener connsubs;
  private boolean close;
  private long timemillis;
  private int lost = 0;

  /**
   * Constructor
   * @param connsubs ConnectionListener ConnectionListener to notify
   */
  public TimerThread (ConnectionListener connsubs) {
    this.connsubs = connsubs;
    close = false;
  }

  /**
   * Executed when alive
   */
  public synchronized void alive() {
    timemillis = System.currentTimeMillis();
    lost = 0;
  }

  /**
   * Executed when dead
   */
  public synchronized void die() {
    close = true;
  }

  /**
   * Thread's main method
   */
  public void run() {
    while (!close) {
      try {
        Thread.sleep(1000);
        long time2 = System.currentTimeMillis();
        if (time2 - timemillis > 5000) {
          timemillis = System.currentTimeMillis();
          lost++;
        }

        if (lost > 2) {
          connsubs.publisherCrashed();
          close = true;
        }
      } catch (Exception e) {}
    }
  }
}

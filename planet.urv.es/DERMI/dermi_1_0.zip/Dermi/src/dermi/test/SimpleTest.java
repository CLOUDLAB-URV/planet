/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import dermi.samples.simple.*;
import dermi.registry.*;

import java.util.*;

/**
 * Dermi's main testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class SimpleTest extends TestCase {
  SimpleImpl server;

  public SimpleTest(String name) {
    super (name);
  }

  /**
   * Method executed at the beginning of the testcase
   */
  protected void setUp() {
    System.out.println ("[SimpleTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = FileRegistry.getEnvironment ("env.properties");
      server = new SimpleImpl (env);
      server.writeERef ("env.properties");

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Method executed at the end of the testcase
   */
  protected void tearDown() {
    System.out.println ("[SimpleTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
   } catch (Exception e) {
      e.printStackTrace();
    }
  }


  public static Test suite() {
    TestSuite t = new TestSuite();
    t.addTestSuite (ListenerTest.class);
    t.addTestSuite (ReferenceTest.class);
    t.addTestSuite (SimpleTest.class);
    t.addTestSuite (BasicTypesTest.class);
    t.addTestSuite (AnycallTest.class);
    t.addTestSuite (DynamicTest.class);
    t.addTestSuite (ExceptionTest.class);
    t.addTestSuite (MobileTest.class);
    t.addTestSuite (DirectcallTest.class);
    t.addTestSuite (ManycallTest.class);
    t.addTestSuite (InterceptorTest.class);
    t.addTestSuite (RemoveInterceptorTest.class);
    t.addTestSuite (NamingTest.class);
    return t;
  }

  /**
   * Test Simple client basic functionality: setter/getter methods
   * @throws Exception If something goes wrong ;-)
   */
  public void testSimpleClient() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("env.properties");
    client.setAge ("30");
    String s = client.getAge();
    assertEquals ("30", s);
    client.close();
  }
}

/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.util.*;

import dermi.samples.anycall.*;
import dermi.registry.*;

/**
 * Anycall functionality testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class AnycallTest extends TestCase {
  SetiImpl server;

  public AnycallTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[AnycallTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = FileRegistry.getEnvironment ("env.properties");
      server = new SetiImpl (env);
      server.writeERef ("env.properties");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[AnycallTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
       server.close();
       Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (AnycallTest.class);
  }

  public void testAnycall() throws Exception {
    Seti client = (Seti) FileRegistry.loadERef ("env.properties");
    for (int i = 0; i < 3; i++) {
      String s = client.anyGetDataUnit ("United Devices");
      assertEquals ("63666737873_UD", s);
      Thread.sleep (50);
    }

    for (int i = 0; i < 2; i++) {
      String s = client.anyGetDataUnit ("SETI@Home");
      assertEquals ("46672872982_SaH", s);
      Thread.sleep (50);
    }

    try {
      String s = client.anyGetDataUnit ("SETI@Home");
      assertEquals ("NotSatisfiedException not thrown when data units exhausted!", true, false);
    } catch (dermi.exception.NotSatisfiedException ne) {
      assertEquals (true, true);
    }

    client.close();
  }
}

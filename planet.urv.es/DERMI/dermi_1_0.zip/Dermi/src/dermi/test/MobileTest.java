/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import dermi.samples.simple.*;
import dermi.samples.mobile.*;
import dermi.registry.*;
import dermi.exception.*;

import java.util.*;

/**
 * The Mobile object testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class MobileTest extends TestCase {
  SimpleImpl server;
  TeleportImpl port;

  public MobileTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[MobileTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try	{
      Properties env = FileRegistry.getEnvironment ("env.properties");
      server = new SimpleImpl (env);
      server.writeERef ("env.properties");
      port = new TeleportImpl (env);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[MobileTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try	{
      server.close();
      Thread.sleep (1000);
      port.close();
      Thread.sleep (1000);
   } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (MobileTest.class);
  }

  public void testMobile() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("env.properties");
    client.setAge ("30");
    String s = client.getAge();
    assertEquals ("30", s);

    port.writeERef ("env.properties");

    Teleport airport = (Teleport) FileRegistry.loadERef ("env.properties");
    server.close();
    airport.send (server);
    airport.close();

    client.setAge ("40");
    s = client.getAge();
    assertEquals ("40", s);
  }
}

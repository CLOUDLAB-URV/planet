/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import dermi.samples.exception.*;
import dermi.registry.*;

import java.util.*;

/**
 * Exception testcase
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class ExceptionTest extends TestCase {
  SimpleImpl server;

  public ExceptionTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[ExceptionTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      Properties env = FileRegistry.getEnvironment ("env.properties");
      server = new SimpleImpl (env);
      server.writeERef ("env.properties");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[ExceptionTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try {
      server.close();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (ExceptionTest.class);
  }

  public void testException() throws Exception {
    Simple client = (Simple) FileRegistry.loadERef ("env.properties");

    try {
      client.merge (new Integer(1), "WW", new Integer(2));
      assertEquals ("MergeException has not been thrown.", true, false);
    } catch (MergeException ex)	{
      assertEquals (true, true);
    }
    client.close();
  }
}

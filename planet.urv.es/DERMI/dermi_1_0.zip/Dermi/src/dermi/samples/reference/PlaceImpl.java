/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.reference;

import dermi.exception.RemoteException;

import java.util.*;

/**
 * This is the place object implementation
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class PlaceImpl extends PlaceSkel {
  String name;
  Vector users = new Vector();

  public PlaceImpl (String name, Properties env) throws RemoteException {
    super (env);
    this.name = name;
    System.out.println ("[Place] object created.");
  }

  public void join (User aUser) throws RemoteException {
    System.out.println ("[join] called.");
    users.add (aUser);
  }

  public void leave (User aUser) throws RemoteException	{
    System.out.println ("[leave] called.");
    if (users.contains (aUser)) {
      users.remove (aUser);
    }
    else throw new RemoteException ("User trying to live was not found.");
  }

  public Vector getUsers() throws RemoteException {
    System.out.println ("[getUsers] called.");
    Vector result = new Vector();

    Iterator it = users.iterator();
    while (it.hasNext()) {
      User a = (User) it.next();
      result.add (a.copy());
    }

    return result;
  }
}

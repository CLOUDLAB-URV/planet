/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.interception;

import dermi.*;
import dermi.util.*;
import dermi.registry.*;

import java.util.*;
import java.io.*;

/**
 * This is the class that instantiates the log interceptor object
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garcia    <pgarcia@etse.urv.es>
 */
public class LogInterceptorServer {
  public static void main (String[] args) {
    try {
//      Naming.loadRegistry ("registry.properties");
      Properties p = FileRegistry.getEnvironment ("env.properties");
      LogInterceptorSkel server = (LogInterceptorSkel) FileRegistry.loadInterceptor (p, "dermi.samples.interception.LogInterceptor");
      BufferedReader dis = new BufferedReader (new InputStreamReader (System.in));

      System.out.println ("Enter 'quit' to remove the interceptor...");
      String input = "";
      while (!(input = dis.readLine()).equals ("quit"));
      System.out.println ("Removing interceptor...");
      server.removeInterceptor();
      System.in.read();
      server.close();
      System.exit (0);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.naming;

import dermi.*;
import dermi.registry.*;

import java.util.*;

/**
 * This class displays a list of bound objects available in the registry
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class SimpleNamingList {
  public static void main (String[] args) throws Exception {
    // Load registry first
    Naming.loadRegistry ("registry.properties");

    // Obtain a list of the available objects under certain hierarchy
    Collection list = Naming.list ("p2p://");
    System.out.println ("Getting all objects under p2p://...");
    if (list.size() != 0) {
      Iterator it = list.iterator();
      while (it.hasNext()) {
        RegistryRecord r = (RegistryRecord) it.next();
        System.out.println (r.getObjectName());
      }
    }
    else {
      System.out.println ("No entries.");
    }

    System.out.println ("\nGetting all objects under p2p://simple1...");
    list = Naming.list ("p2p://simple1");
    if (list.size() != 0) {
      Iterator it = list.iterator();
      while (it.hasNext()) {
        RegistryRecord r = (RegistryRecord) it.next();
        System.out.println (r.getObjectName());
      }
    }
    else {
      System.out.println ("No entries.");
    }

    System.out.println ("\nGetting all objects under p2p://simple1/simpler1...");
    list = Naming.list ("p2p://simple1/simpler1");
    if (list.size() != 0) {
      Iterator it = list.iterator();
      while (it.hasNext()) {
        RegistryRecord r = (RegistryRecord) it.next();
        System.out.println (r.getObjectName());
      }
    }
    else {
      System.out.println ("No entries.");
    }

    System.out.println ("\nGetting all objects under p2p://simple1/simpler1/thesimplest...");
    list = Naming.list ("p2p://simple1/simpler1/thesimplest");
    if (list.size() != 0) {
      Iterator it = list.iterator();
      while (it.hasNext()) {
        RegistryRecord r = (RegistryRecord) it.next();
        System.out.println (r.getObjectName());
      }
    }
    else {
      System.out.println ("No entries.");
    }

    System.exit(0);
  }
}

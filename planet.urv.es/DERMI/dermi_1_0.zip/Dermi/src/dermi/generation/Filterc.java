/*******************************************************************************
 * DERMI: A Decentralised Peer-to-Peer Event-Based Object Middleware
 *        for Distributed Components.
 * Copyright (C) 2003 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.generation;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/**
 * Interface class parser for remote filter skeleton generation.
 *
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Pedro Garc�a    <pgarcia@etse.urv.es>
 *
 * @deprecated As of Dermi v1.0 this class is deprecated. There is no substitute
 *             right now. Next version will include its refactoring
 */
public class Filterc {
  static Vector basicTypes = new Vector();
  static Vector wrappers = new Vector();

  public static void main(String[] args) throws Exception {
    String className = args[0];
    StringBuffer buf = new StringBuffer();

    basicTypes.add("int");
    basicTypes.add("char");
    basicTypes.add("double");
    basicTypes.add("float");
    basicTypes.add("long");
    basicTypes.add("boolean");

    wrappers.add("Integer");
    wrappers.add("Character");
    wrappers.add("Double");
    wrappers.add("Float");
    wrappers.add("Long");
    wrappers.add("Boolean");

    String interfaceName = className;
    className = getInterface(className);
    String cname = getClassName(className);
    String iname = getClassName(interfaceName);

    FileOutputStream fos = new FileOutputStream(iname + "Skel.java");
    PrintStream pos = new PrintStream(fos);
    pos.print(generateSkel(buf, interfaceName, className));
    pos.close();
  }

  public static String getInterface(String className) {
    try {
      int found = -1;
      Class theClass = Class.forName(className);
      Class interfaces[] = theClass.getInterfaces();
      for (int i = 0; i < interfaces.length; i++) {
        if (interfaces[i].getName().equals("dermi.EFilter")) {
          found = i;
        }
      }
      switch (found) {
        case -1:
          System.out.println("ERROR");
          System.exit(0);
          break;
        case 0:
          return interfaces[1].getName();
        case 1:
          return interfaces[0].getName();
      }

    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
    return "";

  }

  public static String getClassName(String className) {
    try {
      Class theClass = Class.forName(className);
      Package pac = theClass.getPackage();

      if (pac != null) {

        int length1 = pac.getName().length();
        String cls = className.substring(length1 + 1, className.length());
        return cls;
      }
      else {
        return className;
      }

    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
    return null;
  }

  public static String getPackageName(String className) {
    try {
      Class theClass = Class.forName(className);

      Package pac = theClass.getPackage();
      if (pac != null) {
        return pac.getName();
      }
      else {
        return "NOPACKAGE";
      }

    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
    return null;
  }

  public static String generateSkel(StringBuffer output, String iname,
                                    String className) {

    String cls, pName;
    try {
      Class theClass = Class.forName(iname);
      Package pac = theClass.getPackage();

      if (pac != null) {

        int length1 = pac.getName().length();
        cls = iname.substring(length1 + 1, iname.length());
        pName = pac.getName();

      }
      else {
        cls = iname;
        pName = "NOPACKAGE";
      }

      skelHeader(output, cls, pName);
      setSkelConstructor(output, cls, iname);
      setSkelHandler(output, className);
      setSkelMethods(output, className);
      setSkelFilterMethods(output, className);
      setCloseMethod(output, className);
      output.append("}\n");

    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }

    return output.toString();

  }

  static String clsName;

  public static void skelHeader(StringBuffer output, String className,
                                String tpackage) {
    if (!tpackage.equals("NOPACKAGE")) {
      output.append("package " + tpackage + ";\n\n");

    }
    output.append("import dermi.*;\n");
    output.append("import dermi.registry.*;\n");
    output.append("import cbus.*;\n");
    output.append("import java.util.*;\n");

    clsName = className;

    output.append("\n\n\n");
    output.append("public class " + className +
        "Skel extends EventServer implements InterceptorListener, dermi.EFilter, " +
                  className + "\n");
    output.append("{\n");
    output.append("String method;\n");
    output.append(className + "Impl intercept;\n");
    output.append("private int timeout;\n");
    output.append("private boolean resultArrived = false;\n");
    output.append("private boolean exception = false;\n");
    output.append("private Object result;\n");
    output.append("private Vector lastFilters;\n");
    output.append("private String type;\n");

    output.append("\n");
  }

  public static void setSkelConstructor(StringBuffer output, String className,
                                        String cls) {
    output.append("public " + className +
                  "Skel(Properties env) throws dermi.RemoteException\n");
    output.append("{\n");
    output.append("\tsuper(env);\n");
    output.append("\tuid = env.getProperty(dermi.Context.CLASS_ID);\n");
    output.append("\tSystem.out.println(\"READY!\");\n");
    output.append("\tclassName = \"" + cls + "\";\n");
    output.append("\taddFilter();\n");
    output.append("\tintercept = new " + className + "Impl(this);\n");

    output.append("}\n");

  }

  public static void setSkelHandler(StringBuffer output, String className) {
    boolean in = true;
    boolean out = true;
    try {

      output.append("public Hashtable interceptorEventArrived(Hashtable evt)\n");
      output.append("{\n");
      output.append(
          "\tlastFilters = (Vector) evt.get(\"FILTERS_REMAINING\");\n");
      output.append("\tmethod = (String)evt.get(\"METHOD\");\n");

      Class theClass = Class.forName(className);
      Method methods[] = theClass.getDeclaredMethods();

      Class params[], result;
      boolean isListener;
      for (int a = 0; a < methods.length; a++) {
        isListener = true;
        params = methods[a].getParameterTypes();
        in = true;
        out = true;

        String methodName = methods[a].getName();
        String mName = Character.toUpperCase(methodName.charAt(0)) +
            methodName.substring(1);
        isListener = (methodName.startsWith("add") ||
                      methodName.startsWith("remove")) &&
            methodName.endsWith("Listener");
        if (!isListener) {

          if (a == 0) {
            output.append("\tif (method.equals(\"" + methodName + "\"))\n");
          }
          else {
            output.append("\telse if (method.equals(\"" + methodName + "\"))\n");

          }
          output.append("\t{\n");
          result = methods[a].getReturnType();

          if (result.getName().equals("void")) {
            out = false;

          }
          if (params.length == 0) {
            in = false;

          }

          if (in == false && out == false) {
            output.append("\ttry {\n");
            output.append("\tif ((String) evt.get (\"OBJECT\") != null) {\n");
            output.append("\t\t\tintercept." + methods[a].getName() + "();\n");
            output.append("\t}");
            output.append("\telse if ((String) evt.get (\"OBJ\") != null) {\n");
            output.append("\t\tresult = evt.get(\"object\");\n");
            output.append("\t\ttype = (String) evt.get(\"TYPE\");\n");
            output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
            output.append("\t\t\texception = true;\n");
            output.append("\t\tresultArrived = true;\n");

            output.append("\t\t}catch(RemoteException ex){\n");
            output.append("\t\t}\n");
            output.append("\t\t}\n");

          }
          else if (in == false && out == true) {
            output.append("\ttry {\n");
            String type = result.getName();
            output.append("\tif ((String) evt.get (\"OBJECT\") != null) {\n");

            /*                                                          int found = find(type);
                 if (found>=0)
                                                                      {
                 String wrap = (String)wrappers.elementAt(found);
                                                                        output.append("\t\t\t"+result.getName()+" res2 = intercept."+methods[a].getName()+"();\n");
                 output.append("\t\t\t"+wrap+" res = new "+wrap+"(res2);\n");
                                                                      }else
                                                                      {
                                                                        output.append("\t\t\t"+result.getName()+" res = intercept."+methods[a].getName()+"();\n");
                                                                      }
             */
            output.append("\t\t\tintercept." + methods[a].getName() + "();\n");
            output.append("\t}");
            output.append("\telse if ((String) evt.get (\"OBJ\") != null) {\n");
            output.append("\t\tresult = evt.get(\"object\");\n");
            output.append("\t\ttype = (String) evt.get(\"TYPE\");\n");
            output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
            output.append("\t\t\texception = true;\n");
            output.append("\t\tresultArrived = true;\n");

            output.append("\t\t}\n");
            output.append("\t\t}catch(RemoteException ex){\n");
            output.append("\t\t}\n");
          }
          else if (in == true && out == false) {
            output.append("\t\ttry {\n");
            output.append("\tif ((String) evt.get (\"OBJECT\") != null) {\n");
            output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");
            output.append("\t\t\tintercept." + methods[a].getName() + "(");
            int i;
            for (i = 0; i < params.length - 1; i++) {

              String type = params[i].getName();
              int found = find(type);
              if (found >= 0) {
                String wrap = (String) wrappers.elementAt(found);
                output.append("((" + wrap + ")args.elementAt(" + i + "))." +
                              type + "Value(),");
              }
              else {
                output.append("(" + params[i].getName() + ")args.elementAt(" +
                              i + "),");
              }

              // if params[i].type in basictypes:
              // output.append("("+wrap+")args.elementAt("+i+")."+type+"Value(),");
            }
            String type = params[i].getName();
            int found = find(type);
            if (found >= 0) {
              String wrap = (String) wrappers.elementAt(found);
              output.append("((" + wrap + ")args.elementAt(" + i + "))." + type +
                            "Value());");
            }
            else {
              output.append("(" + params[i].getName() + ")args.elementAt(" + i +
                            "));\n");
            }
            // if params[i].type in basictypes:
            // output.append("("+wrap+")args.elementAt("+i+")."+type+"Value());");

            output.append("\t}");
            output.append("\telse if ((String) evt.get (\"OBJ\") != null) {\n");
            output.append("\t\tresult = evt.get(\"object\");\n");
            output.append("\t\ttype = (String) evt.get(\"TYPE\");\n");
            output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
            output.append("\t\t\texception = true;\n");
            output.append("\t\tresultArrived = true;\n");

            output.append("\t\t}\n");
            output.append("\t\t}catch(RemoteException ex){\n");
            output.append("\t\t}\n");

          }
          else if (in == true && out == true) {

            output.append("\t\ttry {\n");
            output.append("\tif ((String) evt.get (\"OBJECT\") != null) {\n");
            output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");

            // if result.type in basictypes:
            // output.append("\t\t"+result.type+" res2 = "+methods[a].getName()+"(");
            String resulttype = result.getName();
            String wrap1 = "";

            /*                                                          int found1 = find(resulttype);
                 if (found1>=0)
                                                                      {
                 wrap1 = (String)wrappers.elementAt(found1);
                                                                        output.append("\t\t\t"+resulttype+" res2 = intercept."+methods[a].getName()+"(");
                                                                      }else
                                                                      {
                                                                        output.append("	\t\t\t"+result.getName()+" res = intercept."+methods[a].getName()+"(");
                                                                      }
             */

            output.append("\t\t\tintercept." + methods[a].getName() + "(");

            int i;
            for (i = 0; i < params.length - 1; i++) {
              String type = result.getName();
              int found = find(type);
              if (found >= 0) {
                String wrap = (String) wrappers.elementAt(found);
                output.append("(" + wrap + ")args.elementAt(" + i + ")." + type +
                              "Value(),");
              }
              else {
                output.append("(" + params[i].getName() + ")args.elementAt(" +
                              i + "),");
              }
            }
            String type = result.getName();
            int found = find(type);
            if (found >= 0) {
              String wrap = (String) wrappers.elementAt(found);
              output.append("(" + wrap + ")args.elementAt(" + i + ")." + type +
                            "Value());");
            }
            else {
              output.append("(" + params[i].getName() + ")args.elementAt(" + i +
                            "));\n");
            }
//                                                          if (found1>=0)
//                                                            output.append("\t\t\t"+wrap1+" res = res2."+resulttype+"Value();\n");

            output.append("\t}");
            output.append("\telse if ((String) evt.get (\"OBJ\") != null) {\n");
            output.append("\t\tresult = evt.get(\"object\");\n");
            output.append("\t\ttype = (String) evt.get(\"TYPE\");\n");
            output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
            output.append("\t\t\texception = true;\n");
            output.append("\t\tresultArrived = true;\n");

            output.append("\t}\n");
            output.append("\t\t}catch(RemoteException ex){\n");
            output.append("\t\t}\n");
          }
          output.append("\treturn null;\n");
          output.append("\t}\n");
        }
      }
      output.append("}\n");
    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }

  }

  public static void setByteHandler(StringBuffer output) {

    output.append("\telse if (method.equals(\"getBytes\"))\n");
    output.append("\t{\n");

    output.append("\t\t try \n");
    output.append("\t\t{\n");

    output.append("\t\t\tString aClass = Rmic.getClassName(className);\n");
    output.append(
        "\t\t\tString fileClass = class_store+aClass+\"Stub.class\";\n");
    output.append("\t\t\tbyte data[] = getBytes(fileClass);\n");

    output.append("\t\t\tmsg.clear();\n");
    output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\t\tmsg.put(\"TYPE\",\"DYNAMIC\");\n");
    output.append("\t\t\tmsg.put(\"METHOD\",\"getBytes\");\n");

    output.append("\t\t\tdispatchEvent(msg,data);\n");
    output.append(
        "\t\t }catch (java.io.IOException ex1) {ex1.printStackTrace();} \n");

    output.append("\t}\n");

  }

  public static void setEvent2(StringBuffer output, String methodName) {
    output.append("\t\t\tmsg.clear();\n");
    output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
    output.append("\t\t\tmsg.put(\"METHOD\",\"" + methodName + "\");\n");

    output.append("\t\t\ttry{\n");
    output.append("\t\t\t\tdispatchEvent(msg,res);\n");
    output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
  }

  public static void setEvent11(StringBuffer output, String methodName) {
    output.append("\t\t\tHashtable mesg = new Hashtable();\n");
    output.append("\t\t\tmesg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\t\tmesg.put(\"TYPE\",\"EXCEPTION\");\n");
    output.append("\t\t\tmesg.put(\"METHOD\",\"" + methodName + "\");\n");
    //	output.append("\t\t\tmesg.put(\"RESULT\",ex);\n");
    output.append("\t\t\ttry{\n");
    output.append("\t\t\t\tdispatchEvent(mesg,ex);\n");
    output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
  }

  public static void setSkelMethods(StringBuffer output, String className) {
    String name;
    try {

      Class theClass = Class.forName(className);
      Method methods[] = theClass.getDeclaredMethods();
      Class params[], result;

      for (int i = 0; i < methods.length; i++) {
        name = methods[i].getName();
        if (name.startsWith("add") && name.endsWith("Listener")) {
          Class arg[] = methods[i].getParameterTypes();
          Method mListeners[] = arg[0].getMethods();
          Class paramsListener[] = mListeners[0].getParameterTypes();
          String event1 = paramsListener[0].getName();
          String event;
          Package pac = theClass.getPackage();
          if (pac != null) {
            int ll = pac.getName().length();

            event = event1.substring(ll + 1);
          }
          else {
            event = event1;
          }
          output.append("public void trigger" + event + "(" + event + " res)\n");
          output.append("{\n");
          setEvent2(output, event);

          output.append("}\n");

        }

      }

      setSkelMethods2(output, className);

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void setSkelFilterMethods(StringBuffer output, String className) {

    output.append("public void addFilter() throws RemoteException\n");
    output.append("{\n");
    output.append("try {\n");
    output.append("  Hashtable subs = new Hashtable();\n");
    output.append("  subs.put(\"OBJECT\", uid);\n");
    output.append("  conn.addFilter (this, subs);\n");
    output.append("\n");
    output.append(" subs = new Hashtable();\n");
    output.append(" subs.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append(" conn.addFilter (this, subs);\n");
    output.append("} catch (SessionException ex) {\n");
    output.append("  ex.printStackTrace();\n");
    output.append("}\n");
    output.append("}\n");

    output.append("public void removeFilter() throws RemoteException\n");
    output.append("{\n");
    output.append("try {\n");
    output.append("  Hashtable subs = new Hashtable();\n");
    output.append("  subs.put(\"OBJECT\", uid);\n");
    output.append("  conn.removeFilter (subs);\n");
    output.append("\n");
    output.append(" subs = new Hashtable();\n");
    output.append(" subs.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append(" conn.removeFilter (subs);\n");
    output.append("} catch (SessionException ex) {\n");
    output.append("  ex.printStackTrace();\n");
    output.append("}\n}\n");

  }

  public static void parseOnEvent(StringBuffer output, Method aMethod,
                                  int numMethod) {
    Class arg[] = aMethod.getParameterTypes();
    Method mListeners[] = arg[0].getMethods();
    Class paramsListener[] = mListeners[0].getParameterTypes();

    String event1 = paramsListener[0].getName();
    String event;
    Package pac = paramsListener[0].getPackage();
    if (pac != null) {
      int ll = pac.getName().length();
      event = event1.substring(ll + 1);
    }
    else {
      event = event1;
    }

    String methodName = aMethod.getName();
    String listener = methodName.substring(3, methodName.length());

    if (numMethod == 0) {
      output.append("\tif (method.equals(\"" + event + "\"))\n");

    }
    else {
      output.append("\telse if (method.equals(\"" + event + "\"))\n");

    }
    output.append("\t{\n");

    output.append("\t\t" + event + " result = (" + event +
                  ")evt.get(\"object\");\n");
    output.append("\t\tVector clisteners = (Vector)listeners.clone();\n");
    output.append("\t\tIterator it = clisteners.iterator();\n");
    output.append("\t\twhile (it.hasNext())\n");
    output.append("\t\t{\n");
    output.append("\t\t\t" + listener + " aListener = (" + listener +
                  ")it.next();\n");
    output.append("\t\t\taListener." + mListeners[0].getName() + "(result);\n");
    output.append("\t\t}\n");

  }

  public static void setSkelMethods2(StringBuffer output, String className) {
    boolean in = true;
    boolean out = true;
    try {

      Class theClass = Class.forName(className);
      Method methods[] = theClass.getDeclaredMethods();
      Class params[], result;

      for (int a = 0; a < methods.length; a++) {
        params = methods[a].getParameterTypes();
        in = true;
        out = true;

        String methodName = methods[a].getName();

        String mName = Character.toUpperCase(methodName.charAt(0)) +
            methodName.substring(1);
        boolean isListener = (methodName.startsWith("add") ||
                              methodName.startsWith("remove")) &&
            methodName.endsWith("Listener");

        /*                                        if (!isListener) {
             output.append("public void ignore" + mName + "Filtering (\n");
                                                  int j = 0;
                                                  if (params.length == 0) {
                                                    output.append(")\n");
                                                  }
             else if (params.length == 1) {
             output.append(params[0].getName() + " p0) \n");
                                                  }
                                                  else {
             for (j = 0; j < params.length - 1; j++) {
             output.append(params[j].getName() + " p" + j + ",");
                                                    }
             output.append(params[j].getName() + " p" + j + ") \n");
                                                  }
             parseIgnoreMethod (output, methods[a]);
                                                }
         */

        output.append("public " + methods[a].getReturnType().getName() + " " +
                      methodName + "(");
        int j = 0;
        if (params.length == 0) {
          output.append(")\n");
          if (!isListener) {
            output.append(" throws RemoteException\n");

          }

        }
        else if (params.length == 1) {
          output.append(params[0].getName() + " p0) \n");
          if (!isListener) {
            output.append(" throws RemoteException\n");
          }
        }
        else {
          for (j = 0; j < params.length - 1; j++) {
            output.append(params[j].getName() + " p" + j + ",");
          }
          output.append(params[j].getName() + " p" + j + ") \n");
          if (!isListener) {
            output.append(" throws RemoteException\n");
          }
        }

        parseMethod(output, methods[a]);

      }

    }
    catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }

  }

  /*        public static void parseIgnoreMethod (StringBuffer output, Method aMethod) {
            Class result = aMethod.getReturnType();
            Class params[] =aMethod.getParameterTypes();
            boolean in = true;
            boolean out = true;
            String methodName = aMethod.getName();
            String mName = Character.toUpperCase(methodName.charAt(0)) + methodName.substring(1);
            boolean isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
            if (result.getName().equals("void"))
              out = false;
            if (params.length==0)
              in = false;
            output.append("{\n");
            output.append ("\tHashtable evt = new Hashtable();\n");
            output.append ("\tevt.put(\"OBJECT\",uid);\n");
            output.append ("\tevt.put(\"TYPE\",\"DISPATCH\");\n");
            output.append ("\tevt.put(\"METHOD\",\""+ methodName +"\");\n");
            output.append("\tignoring = true;\n");
            if (in ==false)
            {
              output.append("\t((cbus.dermi.Session) conn).resumeFiltering(evt, lastFilters);\n");
            } else
            {
              output.append("\tVector args = new Vector();\n");
              for (int y = 0; y < params.length; y++) {
                String type = params[y].getName();
                int found = find(type);
                if (found >= 0) {
                  String wrap = (String) wrappers.elementAt(found);
                  output.append("\targs.add(new " + wrap + "(p" + y + "));\n");
                }
                else {
                  output.append("\targs.add(p" + y + ");\n");
                }
              }
              output.append("\tevt.put(\"object\", args);\n");
              output.append("\t((cbus.dermi.Session) conn).resumeFiltering(evt, lastFilters);\n");
            }
            output.append("}\n");
          }
   */
  public static void parseMethod(StringBuffer output, Method aMethod) {
    Class result = aMethod.getReturnType();
    Class params[] = aMethod.getParameterTypes();
    boolean in = true;
    boolean out = true;

    String methodName = aMethod.getName();
    String mName = Character.toUpperCase(methodName.charAt(0)) +
        methodName.substring(1);
    boolean isListener = (methodName.startsWith("add") ||
                          methodName.startsWith("remove")) &&
        methodName.endsWith("Listener");

    if (!isListener) {
      if (result.getName().equals("void")) {
        out = false;
      }
      if (params.length == 0) {
        in = false;

      }
      output.append("{\n");
      output.append("\tHashtable evt = new Hashtable();\n");
      output.append("\tevt.put(\"OBJECT\",uid);\n");
      output.append("\tevt.put(\"TYPE\",\"DISPATCH\");\n");
      output.append("\tevt.put(\"METHOD\",\"" + methodName + "\");\n");
      output.append("\tresultArrived = false;\n");

      if (in == false) {
        output.append(
            "\t((cbus.dermi.Session) conn).resumeFiltering(evt, lastFilters);\n");
        output.append("\tReceive" + mName + "Results r = new Receive" + mName +
                      "Results(this);\n");

      }
      else {
        output.append("\tVector args = new Vector();\n");

        for (int y = 0; y < params.length; y++) {

          String type = params[y].getName();
          int found = find(type);
          if (found >= 0) {
            String wrap = (String) wrappers.elementAt(found);
            output.append("\targs.add(new " + wrap + "(p" + y + "));\n");

          }
          else {
            output.append("\targs.add(p" + y + ");\n");
          }

          // if type = params[y].getClass().getName() is in (int,char,boolean,double,float,long)
          // wrap = type.toUpper(char0);
          // output.append("\targs.add(new "+wrap+"(p"+y+"));\n");

        }
        output.append("\tevt.put(\"object\", args);\n");
        output.append(
            "\t((cbus.dermi.Session) conn).resumeFiltering(evt, lastFilters);\n");
        output.append("\tReceive" + mName + "Results r = new Receive" + mName +
                      "Results(this);\n");

      }
      /*				output.append("\ttimeout=0;");
           output.append("\twhile (!resultArrived&&timeout<dermi.Context.TIMEOUT)\n");
          output.append("\t{\n");
          output.append("\t\ttry{\n");
           output.append("\t\t\tThread.currentThread().sleep(dermi.Context.DELAY);\n");
           output.append("\t\t}catch (InterruptedException ex){ex.printStackTrace();}\n");
          output.append("\t\ttimeout++;\n");
          output.append("\t}\n");
          output.append("\tif (exception){\n");
          output.append("\t\texception = false;\n");
          output.append("\t\tRemoteException ex = (RemoteException)result;\n");
          output.append("\t\tthrow ex;\n");
          output.append("\t} else if (timeout==dermi.Context.TIMEOUT){\n");
           output.append("\t\tthrow new TimeoutException(\"Server is not alive\");\n");
          output.append("\t} ");
       */
      if (out == true) {
//				output.append("\telse \n {");
        String type = result.getName();
        int found = find(type);

        if (found >= 0) {
          String wrap = (String) wrappers.elementAt(found);
          output.append("\t\t" + wrap + " res = (" + wrap + ")result;\n");
          output.append("\t\treturn res." + type + "Value();\n");

        }
        else {
          output.append("\t\t" + result.getName() + " res = (" + result.getName() +
                        ")result;\n");
          output.append("\t\treturn res;\n");
        }
//					output.append("\t}\n");
      }
      // if result.type in (basictypes):
      // wrap = ...
      //	output.append("\t"+wrap+" res = ("+wrap+")result;\n");
      //	output.append("\treturn res+"."+type+"Value();\n");

    }
    else {
      output.append("{\n");
      if (methodName.startsWith("add")) {
        output.append("\tlisteners.add(p0);\n");
      }
      else {
        output.append("\tlisteners.remove(p0);\n");
      }

    }

    output.append("}\n");
    setThreadReceiverMethod(output, aMethod);
  }

  public static void setThreadReceiverMethod(StringBuffer output,
                                             Method aMethod) {
    Class result = aMethod.getReturnType();
    Class params[] = aMethod.getParameterTypes();
    boolean in = true;
    boolean out = true;

    String methodName = aMethod.getName();
    String mName = Character.toUpperCase(methodName.charAt(0)) +
        methodName.substring(1);

    if (result.getName().equals("void")) {
      out = false;
    }
    if (params.length == 0) {
      in = false;

    }

    output.append("class Receive" + mName + "Results extends Thread {\n");
    output.append("\t" + clsName + "Skel fs;\n");
    output.append("\n");
    output.append("\tpublic Receive" + mName + "Results(" + clsName +
                  "Skel fs) {\n");
    output.append("\t\tsuper();\n");
    output.append("\t\tthis.fs = fs;\n");
    output.append("\t\tstart();\n");
    output.append("\t}\n");
    output.append("\n");
    output.append("\tpublic void run() {\n");
    output.append("\t\tint timeout = 0;\n");
    output.append("\n");
    output.append(
        "\t\twhile (!resultArrived && timeout < dermi.Context.TIMEOUT) {\n");
    output.append("\t\ttry {\n");
    output.append("\t\tThread.currentThread().sleep(dermi.Context.DELAY);\n");
    output.append("\t\t}\n");
    output.append("\t\tcatch (InterruptedException ex) {\n");
    output.append("\t\tex.printStackTrace();\n");
    output.append("\t\t}\n");
    output.append("\t\ttimeout++;\n");
    output.append("\t\t}\n");
    output.append("\t\tfs.retrieve" + mName + "Results();\n");
    output.append("\t}\n");
    output.append("}\n");

    output.append("\tpublic void retrieve" + mName + "Results() {\n");
    output.append("\t\tif (exception) {\n");
    output.append("\t\texception = false;\n");
    output.append("\t\tRemoteException ex = (RemoteException)result;\n");
    output.append("\t\tHashtable mesg = new Hashtable();\n");
    output.append("\t\tmesg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\tmesg.put(\"TYPE\",\"EXCEPTION\");\n");
    output.append("\t\tmesg.put(\"METHOD\",\"" + methodName + "\");\n");
    output.append("\t\tmesg.put(\"object\", ex);\n");
    output.append("\n");
    output.append(
        "\t\t((cbus.dermi.Session) conn).resumeFiltering(mesg, lastFilters);\n");
    output.append("\n");
    output.append("\t\tthrow new RuntimeException (ex);\n");
    output.append("\t\t} else if (timeout==dermi.Context.TIMEOUT){\n");
    output.append(
        "\t\tRemoteException ex = new RemoteException (\"Server is not alive\");\n");
    output.append("\t\tHashtable mesg = new Hashtable();\n");
    output.append("\t\tmesg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\tmesg.put(\"TYPE\",\"EXCEPTION\");\n");
    output.append("\t\tmesg.put(\"METHOD\",\"" + methodName + "\");\n");
    output.append("\t\tmesg.put(\"object\", ex);\n");
    output.append("\n");
    output.append(
        "\t\t((cbus.dermi.Session) conn).resumeFiltering(mesg, lastFilters);\n");
    output.append("\t\tthrow new RuntimeException (new TimeoutException(\"Server is not alive\"));\n");
    output.append("\t\t}\n");
    output.append("\t\telse {\n");
    output.append("\t\tHashtable msg = new Hashtable();\n");
    output.append("\t\tmsg.put(\"OBJ\",uid+\":RESULT\");\n");
    output.append("\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
    output.append("\t\tmsg.put(\"METHOD\",\"" + methodName + "\");\n");
    if (out) {
      output.append("\t\tmsg.put(\"object\",result);\n");
    }
    output.append("\n");
    output.append(
        "\t\t((cbus.dermi.Session) conn).resumeFiltering(msg, lastFilters);\n");
    output.append("\t\t}\n");
    output.append("\t}\n");
  }

  public static int find(String type) {
    int found = -1000;
    int i = 0;
    int length = basicTypes.size();

    while (found < 0 && i < length) {
      String elem = (String) basicTypes.elementAt(i);

      if (elem.equals(type)) {
        found = i;
      }
      else {
        i++;

      }
    }
    return found;

  }

  public static void setCloseMethod(StringBuffer output, String className) {

    output.append("public void close() throws dermi.RemoteException\n");
    output.append("{\n");
    output.append("}\n");

    output.append("public void init() throws dermi.RemoteException\n");
    output.append("{\n");
    output.append("\tconn = dermi.util.Bus.getBus(eref);\n");
    output.append("}\n");

    output.append("public ERemote copy() throws RemoteException\n");
    output.append("{\n");
    output.append("\tERemote ref = FileRegistry.loadStub(getERef());\n");
    output.append("\treturn (ERemote)ref;\n");
    output.append("}\n");

  }

}

/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry;

import java.util.*;
import java.io.*;

import dermi.*;
import dermi.exception.*;
import dermi.util.*;

import rice.p2p.commonapi.*;
import rice.p2p.commonapi.Id;
import rice.p2p.past.*;
import rice.pastry.*;
import rice.persistence.*;

/**
 * This class implements the decentralized object location registry
 * @author Carles Pairot   <cpairot@etse.urv.es>
 * @author Ruben Mondejar
 */
public class Registry {
  private Past pastInstance;
  private boolean bindResultArrived = false;
  private boolean lookupResultArrived = false;
  private Properties eref = null;
  private Serializable eser = null;

  /**
   * Constructor for the decentralized registry: entry point and local start
   * @param FACTORY IdFactory IdFactory used by the StorageManager in PAST
   * @param pn PastryNode PAST needs the Pastry node to build on top of
   * @param REPLICATION_FACTOR int Replication factor used: object handles will be inserted in at most REPLICATION_FACTOR nodes
   */
  public Registry (IdFactory FACTORY, PastryNode pn, int REPLICATION_FACTOR) {
    try {
      initRegistry (FACTORY, pn, REPLICATION_FACTOR);
    }
    catch (RemoteException ex) {
      System.out.println ("[DERMI REGISTRY] - Exception on start!!!!");
    }
  }

  /**
   * Connects to the registry and initialized PAST layer
   * @param FACTORY IdFactory IDFactory to be used
   * @param pn PastryNode Pastry node to be used
   * @param REPLICATION_FACTOR int Replication factor to be used
   * @throws RemoteException If impossible to start PAST layer
   */
  private void initRegistry (IdFactory FACTORY, PastryNode pn, int REPLICATION_FACTOR) throws RemoteException {
    // StorageManager for this node. Right now it is only stored in raw memory
    StorageManager storage = new StorageManager (FACTORY, new MemoryStorage (FACTORY), new LRUCache (new MemoryStorage(FACTORY), 100000));

    // Initialize PAST layer
    pastInstance = new PastImpl (pn, storage, REPLICATION_FACTOR, Context.DERMI_DOLR_NAMING);
    // System.out.println ("[DERMI REGISTRY] - started");
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name (or null if not bound)
   * @param name Name of the remote object in the Registry
   * @throws RemoteException If the connection fails
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException {
    int timeout = 0;
    if (pastInstance == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
      timeout = 0;
      lookupResultArrived = false;
      pastInstance.lookup (HashGenerator.generateHash(name), new NamingCommand() {
        public void receive (Object result) throws Exception {
          if (result != null && ! (result instanceof PastContentImpl)) {
            throw new ClassCastException(
                "Result received should be PastContentImpl and was " +
                result.getClass().getName());
          }

          synchronized (this) {
            if (result != null) {
              eref = (Properties) ( (PastContentImpl) result).getObject();
            }
            else {
              eref = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived && timeout < Context.TIMEOUT) {
          try {
            Thread.sleep (Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (eref == null) {
        // Should retry (PAST layer may not be ready yet (!!!))
        continue;
      }

      ERemote result = (ERemote) FileRegistry.loadERef(eref);
      return result;
    }
    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + name + "' not bound.");
  }

  /**
   * Returns a serializable object from the decentralized registry
   * @param id Id Object's Id
   * @throws RemoteException If unable to connect to the registry
   * @return Serializable Object from the registry returned
   */
  public Serializable lookup (Id id) throws RemoteException {
    int timeout = 0;
    if (pastInstance == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
      timeout = 0;
      lookupResultArrived = false;
      pastInstance.lookup (id, new NamingCommand() {
        public void receive(Object result) throws Exception {
          if (result != null && ! (result instanceof PastContentImpl)) {
            throw new ClassCastException(
                "Result received should be PastContentImpl and was " +
                result.getClass().getName());
          }

          synchronized (this) {
            if (result != null) {
              eser = (Serializable) ( (PastContentImpl) result).getObject();
            }
            else {
              eser = null;
            }

            lookupResultArrived = true;
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived && timeout < Context.TIMEOUT) {
          try {
            Thread.sleep (Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (eser == null) {
        // Should retry (PAST layer may not be ready yet (!!!))
        continue;
      }

      return eser;
    }

    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + id + "' not bound.");
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Name of the remote object to be used (should be unique)
   * @param ref Remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties ref) throws RemoteException {
    int timeout = 0;
    if (pastInstance == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    if (!name.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    // Tokenize object URI
    StringTokenizer tokens = new StringTokenizer (name, "/");
    int tokenCount = tokens.countTokens();

    // Check tokens size
    if (tokenCount < 2) {
      throw new NotBoundException ("Object URI incorrect: unable to bind multiple top-level roots");
    }

    // Obtain parent id
    String parentId = "p2p://";
    tokens.nextToken();   // Skip "p2p:"

    for (int i = 0; i < tokenCount - 2; i++) {
      parentId += tokens.nextToken() + "/";
    }
    if (!(parentId.endsWith ("p2p://"))) {
      parentId = parentId.substring (0, parentId.length() - 1);
    }

//    System.out.println ("[DERMI REGISTRY] - Updating parent record: " + parentId);

    // Children ArrayList is empty
    ref.put (Context.DERMI_DOLR_CHILDREN, new ArrayList());

    // Parent pointer
    Id parentNodeId = HashGenerator.generateHash(parentId);
    ref.setProperty(Context.DERMI_DOLR_PARENT, parentId);

    ref.setProperty (Context.DERMI_DOLR_UNIQUE_URI, name);
    insert (HashGenerator.generateHash(name), (Properties) ref.clone());

    synchronized (this) {
      while (!bindResultArrived && timeout < Context.TIMEOUT) {
        try {
          Thread.sleep (Context.DELAY);
        }
        catch (InterruptedException ex) {
        }
        timeout++;
      }
      bindResultArrived = false;
    }

    if (timeout == Context.TIMEOUT) {
      throw new RemoteException ("Unable to bind object.");
    }

    if (tokenCount > 1) {
      // Lookup parent object
      Properties parentProps = (Properties) lookup (parentNodeId);
      ArrayList parentChildren = (ArrayList) parentProps.get(Context.DERMI_DOLR_CHILDREN);
      if (parentChildren == null) {
        parentChildren = new ArrayList();
      }

      // FIX: Add only objectID! Now adding object meta-information...
      // Maybe this is better?
      parentChildren.add ((Properties) ref.clone());
      parentProps.put(Context.DERMI_DOLR_CHILDREN, parentChildren);

      insert (parentNodeId, parentProps);
    }
  }

  /**
   * Insert object's metadata into the registry
   * @param id Id Object's Id
   * @param props Properties Metadata to be inserted
   */
  public void insert (Id id, Properties props) {
    pastInstance.insert(new PastContentImpl(id, props),
                  new NamingCommand() {
      public void receive(Object result) throws Exception {
        if (result == null) {
          throw new NullPointerException(
              "Result received should not be null!");
        }
        if (! (result instanceof Boolean[])) {
          throw new ClassCastException(
              "Result received should be Boolean[] and was " +
              result.getClass().getName());
        }
//        System.out.println ("[DERMI REGISTRY] - Bind successful at " + ((Boolean[]) result).length + " replicas.");

        synchronized (this) {
          bindResultArrived = true;
        }
      }
    }
    );
  }

  /**
   * Unbinds the specified name from the registry.
   * @param name Id of the remote object
   * @throws dermi.NotBoundException - if the Registry does not contains this Id.
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void unbind (String name) throws RemoteException {
    if (pastInstance == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }
    System.err.println ("Not implemented yet!");
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void rebind (String name, Properties ref) throws RemoteException {
    bind (name, ref);
  }

  /**
   * Returns the list of objects bound below the specified root
   * @param root Hierarchical root (in the form "p2p://...")
   * @return A collection containing the object's list
   * @throws RemoteException
   */
  public Collection list (String root) throws RemoteException {
    if (pastInstance == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    if (!root.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    Properties props = (Properties) lookup (HashGenerator.generateHash(root));
    Collection c = (Collection) props.get(Context.DERMI_DOLR_CHILDREN);
    Iterator i = c.iterator();

    ArrayList result = new ArrayList();

    while (i.hasNext()) {
      result.add (new RegistryRecord ((Properties) i.next()));
    }
    return result;
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand extends Thread implements rice.Continuation {
    public void receiveResult(Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}
    public void receiveException (Exception e) {
//      e.printStackTrace();
      System.out.println ("receiveException on NamingCommand");
    }
  }

  /**
   * Utility class for past content objects
   */
  public static class PastContentImpl implements PastContent {

    protected rice.p2p.commonapi.Id id;
    protected java.io.Serializable obj;

    protected PastContent existing;

    public PastContentImpl(Id id, java.io.Serializable obj) {
      this.id = id;
      this.obj = obj;
    }

    public PastContent checkInsert (rice.p2p.commonapi.Id id, PastContent existingContent) throws PastException {
      existing = existingContent;
      return this;
    }

    public PastContentHandle getHandle(Past past) {
      return new PastContentImplHandle (past, id);
    }

    public rice.p2p.commonapi.Id getId() {
      return id;
    }

    public java.io.Serializable getObject() {
      return obj;
    }

    public boolean isMutable() {
      return true;
    }

    public boolean equals(Object o) {
      if (! (o instanceof PastContentImpl)) return false;

      return ((PastContentImpl) o).id.equals(id);
    }

    public String toString() {
      return "PastContentImpl(" + id + ")";
    }
  }

  /**
   * Utility class for past content object handles
   */
  protected static class PastContentImplHandle implements PastContentHandle {
    protected rice.p2p.commonapi.NodeHandle handle;
    protected rice.p2p.commonapi.Id id;

    public PastContentImplHandle(Past past, rice.p2p.commonapi.Id id) {
      this.handle = past.getLocalNodeHandle();
      this.id = id;
    }

    public rice.p2p.commonapi.Id getId() {
      return id;
    }

    public rice.p2p.commonapi.NodeHandle getNodeHandle() {
      return handle;
    }
  }

  public void insert (Id id, java.io.Serializable ser) {
    pastInstance.insert(new PastContentImpl(id, ser),
                  new NamingCommand() {
      public void receive(Object result) throws Exception {
        if (result == null) {
          throw new NullPointerException(
              "Result received should not be null!");
        }
        if (! (result instanceof Boolean[])) {
          throw new ClassCastException(
              "Result received should be Boolean[] and was " +
              result.getClass().getName());
        }

        synchronized (this) {
          bindResultArrived = true;
        }
      }
    }
    );
  }
}

/*******************************************************************************
 * DERMI: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.exception;

/**
 * A ConnectionException is thrown if an Exception occurs in the event middleware.
 * @author Carles Pairot   <cpairot@etse.urv.es>
 */
public class ConnectionException extends RemoteException {

  public ConnectionException (Exception e) {
    super (e.getMessage());
    e.printStackTrace();
  }

  public ConnectionException (String msg) {
    super (msg);
  }
}

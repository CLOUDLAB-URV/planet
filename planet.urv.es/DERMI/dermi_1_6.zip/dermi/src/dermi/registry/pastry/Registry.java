/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry.pastry;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;

import dermi.*;
import dermi.exception.*;
import dermi.registry.*;
import dermi.util.*;
import dermi.util.pastry.*;

import rice.p2p.commonapi.*;
import rice.pastry.PastryNode;

import bunshin.*;
import bunshin.util.*;
import bunshin.storage.*;
import bunshin.listeners.*;

/**
 * This class implements the decentralized object location registry
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar  <ruben.mondejar@urv.net>
 * @version 1.2
 */
public class Registry {
  private Bunshin bunshinApp;
  private String registryContext = "registry";
  private final String field = "DERMI";

  private Hashtable lookupResultArrived = new Hashtable();
  private Hashtable bindResultArrived = new Hashtable();

  private transient Logger logger = Logger.getLogger (this.getClass().getName());

  // Constructor only used for the DHTHandler class !!
  public Registry (String bunshinProperties) throws RemoteException {}

  /**
   * Constructor for the decentralized registry: entry point and local start
   * @param pn Node Bunshin needs the Pastry node to build itself on top of
   */
  public Registry (Node pn, Properties bunshinProperties) {
    try {
      initRegistry ((PastryNode) pn, bunshinProperties);
    }
    catch (RemoteException ex) {
      logger.severe ("Exception starting registry.");
      ex.printStackTrace();
    }
  }

 /**
   * Connects to the registry and initialized Bunshin layer
   * @param FACTORY IdFactory IDFactory to may be used
   * @param pn PastryNode Pastry node to be used
   * @param REPLICATION_FACTOR int Replication factor to be used
   * @throws RemoteException If impossible to start Bunshin layer
   */
  private void initRegistry (PastryNode pn, Properties prop) throws RemoteException {
    // Initialize Bunshin layer
    try {
      String id = (String) prop.get (bunshin.Context.ID_APPLICATION);
      StorageManager manager = (StorageManager) Class.forName ((String) prop.get (bunshin.Context.STORAGE_MANAGER)).newInstance();
      manager.init (prop);
      int replicaFactor = Integer.parseInt ((String) prop.get (bunshin.Context.REPLICA_FACTOR));
      boolean cache = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.CACHE));
      boolean debug = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.DEBUG));

      bunshinApp = new BunshinImpl (id);
      bunshinApp.setStorageManager (manager);
      bunshinApp.setReplicationFactor (replicaFactor);
      if (cache) bunshinApp.activateCache();
      if (debug) bunshinApp.activateDebug();
      Endpoint endPoint = pn.registerApplication ((Application) bunshinApp, id);
      bunshinApp.setEndPoint (endPoint);

      logger.fine ("Dermi naming registry started.");
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e);
    }
  }

  public void setInfoContext(String context, String path, String url, URL[] URLsList) throws RemoteException {
    bunshinApp.setInfoContext(context,path,url,URLsList);
  }

  /**
   * It left the Bunshin Application
   * @throws RemoteException If the connection with the event service fails.
   */
  public void leave() throws RemoteException {
    bunshinApp.leave();
  }


  public void remove(String context, dermi.core.Id id, String field) {
    bunshinApp.remove(context, (Id) id, field);
  }

  public void remove(String context, dermi.core.Id id, String field, BunshinRemoveClient listener) {
	    bunshinApp.remove(context, (Id) id, field,listener);
	  }

    public void removeSer(dermi.core.Id id) {
    bunshinApp.remove(registryContext,(Id) id);
  }

   public void removeSer(String key) {
   	Id id = Utilities.generateHash (key);
    bunshinApp.remove(registryContext,id);
  }

   public void removeSer(String context,String key) {
	   	Id id = Utilities.generateHash (key);
	    bunshinApp.remove(context,id);
	  }
   public void removeSer(String context,String key,String field) {
	   	Id id = Utilities.generateHash (key);
	    bunshinApp.remove(context,id,field);
	  }

  /**
   * Returns a reference, for the remote object associated with the specified name (or null if not bound)
   * @param name Name of the remote object in the Registry
   * @throws RemoteException If the connection fails
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException {
    int timeout = 0; int nullTries = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    Id key = Utilities.generateHash (name);
    final String requestId = key.toStringFull() + "_" + System.currentTimeMillis();

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;
      if (retransmission == 1) {
        System.out.print ("[Registry] - Lookup retransmissions... ");
      }
      if (retransmission != 0) {
        System.out.print (retransmission + " ");
      }
      bunshinApp.get (registryContext, key, new DermiLookupListener (requestId) {
        public void get (Object result) {
          synchronized (this) {
            Hashtable eref = null;
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                eref = (Hashtable) ((bunshin.util.Values) result).get (field);
              }
              else {
                eref = (Hashtable) result;
              }
            }
            else {
              eref = null;
            }
            if (eref != null) {
              lookupResultArrived.put (requestId, eref);
            }
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived.containsKey (requestId) && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (!lookupResultArrived.containsKey (requestId)) {
        if (nullTries < 10) {
          nullTries++;
          continue;
        }
        else {
          logger.warning ("Received 10 null lookup results. Object is considered to be not bound.");
          break;
        }
      }
      Properties p = new Properties();
      p.putAll((Hashtable) lookupResultArrived.remove (requestId));
      ERemote result = (ERemote) FileRegistry.loadERef (p);

      return result;
    }

    System.out.println();
    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + name + "' not bound.");
  }

  public ERemote lookup (dermi.core.DermiConnection connection, String name, String communityId, String className) throws RemoteException {
/*    try {
      return this.lookup (name);
    } catch (NotBoundException e) {
      // Object was not bound, therefore we should activate it remotely in the specified community
      // Security: Note that it is mandatory to belong to the community in order to be able to activate objects there
      // Could be solved using a DermiConnection method for sending the activation event!
      dermi.activation.ActivatorClient ac = connection.getActivator (communityId);
      if (ac != null) {
        Hashtable env = dermi.Registry.getEnvironment ("dermi-config.xml");
        env.setProperty (Context.CLASS_ID, name);
        env.setProperty (Context.CLASS_NAME, className);
        env.setProperty (Context.COMMUNITYID, communityId);
        // TODO: Use one (activateObject) or another (activateMultipleObjects) depending on class' attributes!!!!!
        return (ERemote) FileRegistry.loadERef (ac.activateMultipleObjects (env));
      }
      throw new NotBoundException ("Unable to remotely activate object " + name + ". Security error: you don't belong to community " + communityId + ".");
    }
*/
    return null;
  }

  /**
   * Returns a serializable object from the decentralized registry
   * @param id Id Object's Id
   * @throws RemoteException If unable to connect to the registry
   * @return Serializable Object from the registry returned
   */

  public Serializable lookup (dermi.core.Id id) throws RemoteException {
    return lookup (registryContext, id, field);
  }

  public Serializable lookup (String context, dermi.core.Id id) throws RemoteException {
    return lookup (context, id, field);
  }

  public Serializable lookup (String context, dermi.core.Id id, final String f) throws RemoteException {
    return lookupSecure (context, id, f, null);
  }

  public void lookup (String context, dermi.core.Id id, String f, BunshinGetClient listener) throws RemoteException {
	    bunshinApp.get(context, (Id) id, f, listener);
  }

  public Serializable lookupSecure (String context, final dermi.core.Id id, final String f, String pass) throws RemoteException {
    int timeout = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    final String requestId = ((rice.pastry.Id)id).toStringFull() + "_" + System.currentTimeMillis();
    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;
      if (retransmission == 1) {
        System.out.print ("[Registry] - Lookup retransmissions... ");
      }
      if (retransmission != 0) {
        System.out.print (retransmission + " ");
      }
      bunshinApp.getSecure (context,(Id) id, f, pass, new DermiLookupListener (requestId) {
        public void get (Object result) {
          synchronized (this) {
            Serializable eser = null;
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                eser = (Serializable) ((bunshin.util.Values) result).get (f);
              }
              else {
                eser = (Serializable) result;
              }
            }
            else {
              eser = null;
            }
            if (eser != null) {
              lookupResultArrived.put (requestId, eser);
            }
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived.containsKey (requestId) && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (!lookupResultArrived.containsKey (requestId)) {
        continue;
      }

      return (Serializable) lookupResultArrived.remove (requestId);
    }

    System.out.println();
    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + id + "' not bound.");
  }

  public URL lookupURL (String context, dermi.core.Id id, final String f) throws RemoteException {
    int timeout = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    final String requestId = ((rice.pastry.Id) id).toStringFull() + "_" + System.currentTimeMillis();

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;

      if (retransmission == 1) {
        System.out.print ("[Registry] - Lookup URL retransmissions... ");
      }
      if (retransmission != 0) {
        System.out.print (retransmission + " ");
      }

      bunshinApp.getURL (context,(Id) id, f, new DermiURLListener (requestId) {
        public void get (URL result) {
          synchronized (this) {
            URL eurl = null;
            if (result != null) {
              eurl = result;
            }
            else {
              eurl = null;
            }
            if (eurl != null) {
              lookupResultArrived.put (requestId, eurl);
            }
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived.containsKey (requestId) && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (!lookupResultArrived.containsKey (requestId)) {
        // Should retry (Bunshin layer may not be ready yet (!!!))
        continue;
      }

      return (URL) lookupResultArrived.remove (requestId);
    }

    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + id + "' not bound.");
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Name of the remote object to be used (should be unique)
   * @param ref Remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Hashtable pref) throws RemoteException {
    int timeout = 0;

    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    if (!name.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    // Tokenize object URI
    StringTokenizer tokens = new StringTokenizer (name, "/");
    int tokenCount = tokens.countTokens();

    // Check tokens size
    if (tokenCount < 2) {
      throw new NotBoundException ("Object URI incorrect: unable to bind multiple top-level roots");
    }

    Hashtable ref = null;

    //if (pref instanceof Properties) {

    	ref = new Hashtable();
		Iterator it = pref.keySet().iterator();
		while (it.hasNext())  {
			  Object key = it.next();
			  Object value = pref.get(key);
			  ref.put(key,value);

		}

    //}
    //else {
    //  ref = pref;
    //}

    // Obtain parent id
    String parentId = "p2p://";
    tokens.nextToken();   // Skip "p2p:"

    for (int i = 0; i < tokenCount - 2; i++) {
      parentId += tokens.nextToken() + "/";
    }
    if (!(parentId.endsWith ("p2p://"))) {
      parentId = parentId.substring (0, parentId.length() - 1);
    }

    logger.fine ("Updating parent record: " + parentId);

    // Children ArrayList is empty
    ref.put (dermi.util.Context.DERMI_DOLR_CHILDREN, new ArrayList<Hashtable>());

    // Parent pointer
    dermi.core.Id parentNodeId = HashGenerator.generateHash (parentId);
    ref.put (dermi.util.Context.DERMI_DOLR_PARENT, parentId);

    ref.put (dermi.util.Context.DERMI_DOLR_UNIQUE_URI, name);
    if (!insert (registryContext, HashGenerator.generateHash (name), (Hashtable) ref.clone(), field)) {
      throw new RemoteException ("Unable to bind object.");
    }

/*    synchronized (this) {
      while (!bindResultArrived && timeout < dermi.util.Context.TIMEOUT) {
        try {
          Thread.sleep (dermi.util.Context.DELAY);
        }
        catch (InterruptedException ex) {
        }
        timeout++;
      }
      bindResultArrived = false;
    }

    if (timeout == dermi.util.Context.TIMEOUT) {
      throw new RemoteException ("Unable to bind object.");
    }
*/
    if (tokenCount > 1) {
      // Lookup parent object
   	  Hashtable parentProps = (Hashtable) lookup (parentNodeId);
      ArrayList<Hashtable> parentChildren = (ArrayList<Hashtable>) parentProps.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
      if (parentChildren == null) {
        parentChildren = new ArrayList<Hashtable>();
      }

      // FIX: Add only objectID! Now adding object meta-information...
      // Maybe this is better?
      if (!exists (parentChildren, ref)) {
        parentChildren.add ((Hashtable) ref.clone ());
        parentProps.put (dermi.util.Context.DERMI_DOLR_CHILDREN, parentChildren);
        if (!insert (registryContext, parentNodeId, parentProps, field)) {
          throw new RemoteException ("Unable to bind object.");
        }
      }
    }
  }

  private boolean exists (ArrayList<Hashtable> parent, Hashtable propz) {
    Iterator<Hashtable> i = parent.iterator();

    while (i.hasNext()) {
    	Hashtable p = i.next();
      if (p.get (dermi.util.Context.DERMI_DOLR_UNIQUE_URI).equals (propz.get (dermi.util.Context.DERMI_DOLR_UNIQUE_URI))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Insert object's metadata into the registry
   * @param id Id Object's Id
   * @param props Hashtable Metadata to be inserted
   * @param boolean exclusive - Tells whether inserted value overwrites a previously existing one
   */

  public boolean insert (dermi.core.Id id, Serializable props, String f) {
    return insertSecure (registryContext, id, props, f,null);
  }

  public boolean insert (String context, dermi.core.Id id, Serializable props, String f) {
    return insertSecure (context, id, props, f, null);
  }

  public void insert (String context, dermi.core.Id id, Serializable props, String f, BunshinPutClient listener) {
	    bunshinApp.put (context, (Id) id, props, f, listener);
  }

  public boolean insertSecure (String context, dermi.core.Id id, Serializable props, String f, String pass) {

	  return insertSecure (context, id, props, f, pass, true);
	  }

  public boolean insertSecure (String context, dermi.core.Id id, Serializable props, String f, String pass, boolean getcheck) {
    int timeout = 0;

    final String requestId = ((rice.pastry.Id) id).toStringFull() + "_" + System.currentTimeMillis();

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS; retransmission++) {
      if (retransmission == 1) {
        System.out.print ("[Registry] - Insert retransmissions... ");
      }
      if (retransmission != 0) {
        System.out.print (retransmission + " ");
      }

      timeout = 0;
      bunshinApp.putSecure (context,(Id) id, props,f, pass, getcheck, new DermiBindListener (requestId) {
        public void put (boolean ack, NodeHandle nh) {
          synchronized (this) {
            bindResultArrived.put (requestId, ack);
          }
        }
      }
      );

      synchronized (this) {
        while (!bindResultArrived.containsKey (requestId) && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      if (bindResultArrived.containsKey (requestId)) {
        return (Boolean) bindResultArrived.remove (requestId);
      }
    }
    if (bindResultArrived.containsKey (requestId)) {
      return (Boolean) bindResultArrived.remove (requestId);
    } else {
     return false;
    }
  }



  /**
   * Unbinds the specified name from the registry.
   * @param name Id of the remote object
   * @throws dermi.NotBoundException - if the Registry does not contains this Id.
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void unbind (String name) throws RemoteException {
    int timeout = 0;

    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

/*    if (!name.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }
*/
    // Tokenize object URI
    StringTokenizer tokens = new StringTokenizer (name, "/");
    int tokenCount = tokens.countTokens();

    // Check tokens size
    if (tokenCount < 2) {
      throw new NotBoundException ("Object URI incorrect: unable to bind multiple top-level roots");
    }

    // Obtain parent id
    String parentId = "p2p://";
    tokens.nextToken();   // Skip "p2p:"

    for (int i = 0; i < tokenCount - 2; i++) {
      parentId += tokens.nextToken() + "/";
    }
    if (!(parentId.endsWith ("p2p://"))) {
      parentId = parentId.substring (0, parentId.length() - 1);
    }

    logger.fine ("Updating parent record: " + parentId);

    // Children ArrayList is empty
    //ref.put (Context.DERMI_DOLR_CHILDREN, new ArrayList());

    // Parent pointer
    dermi.core.Id parentNodeId = HashGenerator.generateHash (parentId);

    //ref.setProperty(Context.DERMI_DOLR_PARENT, parentId);

    //ref.setProperty (Context.DERMI_DOLR_UNIQUE_URI, name);
    //insert (HashGenerator.generateHash(name), (Hashtable) ref.clone(), true);
    Id key = Utilities.generateHash (name);
    bunshinApp.remove (registryContext, key, field);

    if (tokenCount > 1) {
      // Lookup parent object
    	Hashtable parentProps = (Hashtable) lookup (registryContext,parentNodeId);
      ArrayList<Hashtable> parentChildren = (ArrayList<Hashtable>) parentProps.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
      if (parentChildren != null) {

      	boolean found = false;

        for(int i=0;i<parentChildren.size() && !found ;i++) {

          String s = (String) parentChildren.get(i).get (dermi.util.Context.DERMI_DOLR_UNIQUE_URI);
          if (name.equals(s)) {
            found = true;
            parentChildren.remove(i);
          }
        }

        if (found) {
        	parentProps.put (dermi.util.Context.DERMI_DOLR_CHILDREN, parentChildren);
        }
      }
    }
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void rebind (String name, Hashtable ref) throws RemoteException {
    bind (name, ref);
  }

  public Hashtable getStorageInfo() {
  	return bunshinApp.getStorageInfo();
  }

  public Hashtable getReplicaInfo() {
  	return bunshinApp.getReplicaInfo();
  }


  /**
   * Returns the list of objects bound below the specified root
   * @param root Hierarchical root (in the form "p2p://...")
   * @return A collection containing the object's list
   * @throws RemoteException
   */
  public Collection list (String root) throws RemoteException {
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    if (!root.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    Hashtable props = (Hashtable) lookup (registryContext, HashGenerator.generateHash (root));
    Collection c = (Collection) props.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
    Iterator i = c.iterator();

    ArrayList<RegistryRecord> result = new ArrayList<RegistryRecord>();

    while (i.hasNext()) {
      result.add (new RegistryRecord ((Hashtable) i.next()));
    }
    return result;
  }

  //DERMI SEARCH METHOD
  private Set getKeywords(String tokens) {
    StringTokenizer st = new StringTokenizer(tokens);
    Set keyworks = new TreeSet();

    while(st.hasMoreTokens()) {
      String token = st.nextToken();
      if (token.length()>2) {
        keyworks.add(token);
      }
    }
    return keyworks;
  }


  //DERMI SEARCH METHOD
  public void insert(String context, String tokens, String id, Serializable value)  throws RemoteException {
    dermi.core.Id idValue = HashGenerator.generateHash (id);

    Set keywords = getKeywords(tokens);

  	insert(context,idValue,(Serializable)keywords,"#keywords");
  	insert(context,idValue,value,field);

  	Iterator it = keywords.iterator();
  	while(it.hasNext()) {

  	  String token = (String) it.next();

  	  Set keywords1 = (Set) ((TreeSet) keywords).clone();

      dermi.core.Id key = HashGenerator.generateHash (token);
      Hashtable prop = null;
      try {
  	    prop = (Hashtable) lookup(context, key, "#index");
      } catch(Exception e) {
    	prop = null;
      }

  	  if (prop==null) {
  	  	System.out.println("> New prop ("+token+") : "+keywords1);
  	    prop = new Hashtable();
  	    prop.put(idValue,keywords1);
  	  }
  	  else {
  	  	Set previous = (Set) prop.get(idValue);
  	  	System.out.println("> Old prop ("+token+") "+previous);
  	    System.out.println("> Adding   ("+token+") "+keywords1);
  	  	if (previous!=null) keywords1.addAll(previous);
  	  	prop.put(idValue,keywords1);
  	  }
  	  System.out.println("> Update prop ("+token+") : "+prop);
  	  insert (context,key,(Serializable) prop, "#index");
  	}
  }

  //DERMI SEARCH METHOD
  public ResultSortedQueue query(String context,String query_key)  throws RemoteException {
    Set keywords = getKeywords(query_key);
    ResultSortedQueue result = new ResultSortedQueue(keywords);

    Hashtable merge = new Hashtable();

    Iterator it = keywords.iterator();
    while(it.hasNext()) {

      String token = (String) it.next();
      dermi.core.Id key = HashGenerator.generateHash (token);

      Hashtable prop = null;
      try {
        prop = (Hashtable) lookup(context,key,"#index");
        System.out.println("> Request prop ("+token+") : "+prop);
      } catch (Exception e) {
    	  prop = null;
    	  System.out.println("> Request prop ("+token+"): NULL ");
      }

      if (prop!=null) {
        Iterator it2 = prop.keySet().iterator();
        while(it2.hasNext()) {
          Id idValue = (Id) it2.next();
          if (merge.containsKey(idValue)) {
            Set keywordSet = (Set) merge.get(idValue);
	        System.out.println("previous "+keywordSet+" + new "+keywords);
	        keywordSet.add(token);
	        merge.put(idValue,keywordSet);

          }
          else {
            Set keywordSet = new TreeSet();
	        keywordSet.add(token);
	        merge.put(idValue,keywordSet);
          }
        }
      }
    }

    //Insert merge result in the HashSortedQueue
    Iterator it2 = merge.keySet().iterator();
    while (it2.hasNext()) {
      Id idValue = (Id) it2.next();
      Set elems = (Set) merge.get(idValue);
      result.add(idValue,elems);
    }

    return result;
  }

  //DERMI SEARCH METHOD
  public void remove(String context, String tokens, String id) throws RemoteException {

	    dermi.core.Id idValue = HashGenerator.generateHash (id);
	    Set keywords = null;
		if (tokens!=null) {
	  	  keywords = getKeywords(tokens);
		}

		if (keywords==null || keywords.isEmpty()) {
		  try {
		  keywords = (Set) lookup(context,idValue,"#keywords");
		  } catch (Exception e) {
			  keywords = null;
		  }
		}
		removeSer(context,id,"#keywords");
		removeSer(context,id,field);

	  	if (keywords!=null) {
	  	  Iterator it = keywords.iterator();
	  	  while(it.hasNext()) {

	  	    String token = (String) it.next();

	  	    Set keywords1 = (Set) ((TreeSet) keywords).clone();

	  	    dermi.core.Id key = HashGenerator.generateHash (id);
	  	  Hashtable prop = null;
	        try {
	          prop = (Hashtable) lookup(context,key,"#index");
	        } catch (Exception e) {
	    	  prop = null;
	        }

	  	    if (prop!=null) {
	  	  	  Set previous = (Set) prop.get(idValue);
	  	  	  if (previous!=null) {
	  	  	    prop.remove(idValue);
	  	  	    insert(context,key,(Serializable)prop,"#index");
	  	  	}
	  	  }
	    }
	  }

  }

  public void insertURL (String context, dermi.core.Id id, java.net.URL url, String f) {
    bunshinApp.putURL (context, (Id) id, url, f);
  }


  public void modify (String context,dermi.core.Id id, Object value, String f, boolean add) {
    bunshinApp.modify (context, (Id) id, value, f, add);
  }

  public void modify (String context,dermi.core.Id id, Collection values, String f, boolean add) {
    bunshinApp.modify (context,(Id) id, values, f, add);
  }

  public void setRemoteListener (String context,dermi.core.Id id, RemoteListener listener, String f) {
    bunshinApp.setRemoteListener (context,(Id) id, listener, f);
  }

  public void removeRemoteListener (String context,dermi.core.Id id, String f) {
    bunshinApp.removeRemoteListener (context,(Id) id, f);
  }

  public Collection getIncomingLinks(String context,dermi.core.Id id) throws RemoteException {
    Collection result = (Collection) lookup (context, id, "IncomingLinks");
    return result;
  }

  public Collection getOutgoingLinks (String context,dermi.core.Id id) throws RemoteException {
    Collection result = (Collection) lookup (context, id, "OutgoingLinks");
    return result;
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand extends Thread implements rice.Continuation {
    public void receiveResult(Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}
    public void receiveException (Exception e) {
      e.printStackTrace();
      logger.warning ("receiveException on NamingCommand");
    }
  }


 // public void insert (Id id, java.io.Serializable ser, boolean exclusive) {
 //   bunshinApp.put ((Id) id, (Object) ser, field);
 // }

  abstract class DermiLookupListener implements BunshinGetClient {
     private String requestId;

     public DermiLookupListener (String requestId) {
       this.requestId = requestId;
     }
   }

   abstract class DermiURLListener implements BunshinURLClient {
      private String requestId;

      public DermiURLListener (String requestId) {
        this.requestId = requestId;
      }
    }

    abstract class DermiBindListener implements BunshinPutClient {
       private String requestId;

       public DermiBindListener (String requestId) {
         this.requestId = requestId;
       }
     }
}

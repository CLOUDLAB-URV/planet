/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package dermi.samples.url;

import dermi.*;
import dermi.core.Id;
import dermi.exception.*;
import dermi.util.pastry.*;

//import bunshin.*;


import javax.swing.*;
import java.util.*;
import java.io.*;
import java.net.*;

/**
 *  Stores an image URL and restores it.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class DermiURLTest {

	public static void show(ImageIcon logo) {

		JFrame frame = new JFrame("Dermi");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   

		JPanel panel= new JPanel();
		JLabel label = new JLabel();

		label.setIcon(logo);  
		panel.add(label);
		
		frame.getContentPane().add(panel);  
		frame.setSize(400,450);
		frame.setVisible(true);

	}

	public static void main(String args[]) {
		try {
			
			
			Properties env = Registry.getEnvironment ("dermi-config.xml");
                        Registry.loadRegistry ("dermi-config.xml");
			
			DHTHandler dht = new DHTHandler ("./","url_test" , "./url_test" , "http://localhost:8080/webapps", null);
			
			Id id = HashGenerator.generateHash("dermilogo");
			
	         
			URL url = new URL("http://ants.etse.urv.es/DERMI/images/dermilogo.jpg");
			
		        dht.insertURL(id,url);     
			
			Thread.sleep(2000);
			System.out.println("URL : "+dht.retrieveURL(id));
			byte[] bytes = (byte[]) dht.retrieve(id,"URL");
			ImageIcon logo=new ImageIcon(bytes);
			show(logo);

			System.out.println("Press <RETURN> to exit...");
  			System.in.read();
			dht.leave();
			System.exit(0);
		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}
}    

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.listener;

import dermi.*;
import dermi.registry.*;

/**
 * This class encapsulates a client willing to access to Sprite server
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class SpriteClient2 {
  public static void main (String[] args) throws Exception {
    // If we do not want to use the decentralized registry, uncomment this line
    // and comment the next two
    // Sprite client = (Sprite) FileRegistry.loadERef ("dermi-config.xml");

    // Load the registry first
    Registry.loadRegistry ("dermi-config.xml");

    // Look up object in the registry
    Sprite client = (Sprite) Registry.lookup ("p2p://sprite");
    client.addSpriteListener (SpriteEvent.class, new MyListener());
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.samples.replicastate;

import dermi.*;
import dermi.registry.*;
import dermi.exception.*;

import java.util.*;

/**
 * This class implements the Sprite server object
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class SpriteServer {
  public static void main (String[] args) {
    SpriteImpl server = null;
    Properties objProps = null;
    try {
      Registry.loadRegistry ("dermi-config.xml");
      Properties env = Registry.getConnectionProperties();
      try {
        objProps = (Properties) Registry.lookupSer ("p2p://replicas");
        server = new SpriteImpl (5, objProps);
      } catch (NotBoundException ne) {
        server = new SpriteImpl (5, env);
        objProps = env;
        Registry.bind ("p2p://replicas", server);
      }

      // For the file registry (deprecated)
      // server.writeERef ("dermi-config.xml");

      System.in.read();
      server.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

package dermi.samples.bittorrent;

import java.util.Collection;
import java.util.Iterator;

import org.gudy.azureus2.core3.util.DisplayFormatters;

import dermi.BittorrentHandler;
import dermi.Registry;
import dermi.bittorrent.ISummary;
import dermi.bittorrent.SingletonHandler;
import dermi.bittorrent.azureus.Show;

public class BTTest {

	 public static void main(String[] args) {    
		    
		    try {
		    	
                try {
		    	  Registry.loadRegistry ("dermi-config.xml");
                } catch (Exception e) {
                	e.printStackTrace();
                }
	
		    	//BittorrentHandler ah = new AzureusHandler();	     
		    	//ah.connect();
                
                BittorrentHandler ah = SingletonHandler.getInstance("dermi.bittorrent.azureus.AzureusHandler");
                ah.connect();
                Thread.sleep(5000);
                ah.removeAll();
		    	String hash1 = ah.addFind("file1.torrent", "out");
		    	String hash2 = ah.addFind("file2.torrent", "out");
		    	String hash3 = ah.addFind("file3.torrent", "out");
		    	Thread.sleep(5000);
		    	ah.startAll();
		    	
		    	//System.out.println("Hash : "+hash);
			    //System.in.read();
			    	    	
		    	while(true) {
		    	  Collection c = ah.getAllTorrentSummary();
		    	  System.out.println("Num. torrent = "+c.size());
		    	  Iterator it = c.iterator();	    	  
		    	  while(it.hasNext()) {
		    		  ISummary s = (ISummary) it.next();
		    		  System.out.println(s);
		    	  }
		    	  Thread.sleep(5000);
		    	  //ah.startAll();
		    	  
		    	}
		    	/*
		    	  ah.showTorrents();
		    	  Thread.sleep(5000);
		    	  ah.stop(hash);
		    	  ah.showTorrents();
		    	  Thread.sleep(5000);
		    	  ah.start(hash);
		    	  ah.showTorrents();
		    	  Thread.sleep(5000);
		    	  ah.check(hash);
		    	  ah.showTorrents();
		    	  Thread.sleep(35000);
		    	  ah.remove(hash);
		    	  //ah.removeAll();
		    	  
		    	  
		    	  ah.showTorrents();
		    	  
		    	  ah.shutdown();
		    	  */
		    	//}
		    	
		        }catch( Exception e ){
		    	
		    	System.out.println( "Start fails:" );
		    	
		    	e.printStackTrace();
		    }
		  }

}

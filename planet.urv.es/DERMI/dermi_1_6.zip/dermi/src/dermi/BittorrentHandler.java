 /*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import java.io.*;
import java.util.*;

/**
 *
 * @author  Ruben Mondejar
 */

public interface BittorrentHandler {
     
  public void connect();
  public boolean isConnected();
  public void shutdown();
  
  /**
   * Add a download from the given .torrent file path or url. Example: 'add /path/to/the.torrent' or 'add http://www.url.com/to/the.torrent'
   * @param torrentSource - could be url, directory, file or pattern eg: d:\*.torrent   
   * @param outputDir directory to save files from torrent to	 
   * @throws IOException 
   */
  public String addFind(String torrentSource, String outputDir) throws IOException;
  
  public void showTorrents();
  
  public Collection getAllTorrentSummary();		
		
  public void remove(String hash);    	    	
   	  
  public void removeAll();
    
  public void start(String hash);
	  
  public void startAll();
		  
  public void stop(String hash);
    
  public void stopAll();
    		
  public void check(String hash);
  
  public void checkAll();
    		  
  public void queue(String hash);
    	
  public void queueAll();
    
  public void host(String hash);
    	    
  public void hostAll();
    	  
  public void forceStart(String hash);
    
  public void forceStartAll();
    	  
  //move : move torrent from to to. If to is omitted, the torrent is moved to top or to the bottom if given negative.
  
  //share : share a file or folder(s).
  
  //set : method that allows manipulation of Azureus' runtime properties.
  
  //hack : modify torrent settings
  
  //xml : output stats in xml format	
	
  public void makeTorrent(String urlParam, String fileParam);
  
}

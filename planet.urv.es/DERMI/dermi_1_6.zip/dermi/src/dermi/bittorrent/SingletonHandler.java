 /*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.bittorrent;

import dermi.BittorrentHandler;

/**
 *
 * @author  Ruben Mondejar
 */

public class SingletonHandler {
          
  private static BittorrentHandler bh;	
  
  public static BittorrentHandler getInstance(String className) {
     
	  if (bh==null) { 
	    
	    try {
	    	
	    	bh = (BittorrentHandler)Class.forName(className).newInstance();
		
		}catch (ClassNotFoundException e1){
			e1.printStackTrace();
		}catch (InstantiationException e2){
  			e2.printStackTrace();		
		}catch (IllegalAccessException e3){
			e3.printStackTrace();
		}	    
		
		bh.connect();
	    
	  }
	  
	  return bh; 
	 
	  
  }  
 
    
}

package dermi.bittorrent.azureus;

import java.util.List;

import com.aelitis.azureus.core.*;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;

/**
 * torrent method to initiate recheck of a torrent.
 * code was originally in Torrent class authored by tobias 
 */
public class CheckMethod implements TorrentMethod {

	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args) {
		try {
			if (dm.canForceRecheck()) {
				dm.forceRecheck();
				return true;
			} else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public String getAction() {
	  return "Initiating recheck of";
	}

	public String getCommandName() {
	  return "check";	
	}

}

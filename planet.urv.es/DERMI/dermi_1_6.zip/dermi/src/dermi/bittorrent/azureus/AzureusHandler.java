package dermi.bittorrent.azureus;

import java.io.*;
import java.net.URL;
import java.util.*;

import dermi.BittorrentHandler;

import org.gudy.azureus2.core3.config.COConfigurationManager;
import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.download.DownloadManagerStats;
import org.gudy.azureus2.core3.peer.PEPeerManagerStats;
import org.gudy.azureus2.core3.torrentdownloader.TorrentDownloaderFactory;
import org.gudy.azureus2.core3.util.ByteFormatter;
import org.gudy.azureus2.core3.util.DisplayFormatters;

import com.aelitis.azureus.core.*;
import com.aelitis.azureus.ui.console.MakeTorrent;

import org.gudy.azureus2.core3.global.GlobalManager;
import org.pf.file.FileFinder;
import org.pf.text.StringUtil;

/**
 *
 * @author  Ruben Mondejar
 */

public class AzureusHandler implements BittorrentHandler {
     
  private AzureusCore	core;
  private GlobalManager gm;
  
  private List torrents = new ArrayList();
  private File[] adds = null;
  private boolean connected = false;
      
  public void connect() {

	if (core==null)  {
      core = AzureusCoreFactory.create();
	}
	else {
        
      	core.start();
	    gm = core.getGlobalManager();
	           
        TorrentDownloaderFactory.initManager(gm, true, true, COConfigurationManager.getStringParameter("Default save path") );
        connected = true;        
	}
        
  }  
 
  public void shutdown() {   
    if ( core != null )	{
    	core.stop();
    	connected = false;
    }
  }
  
  public boolean isConnected() {
	  return connected;
  }

  /**
   * Add a download from the given .torrent file path or url. Example: 'add /path/to/the.torrent' or 'add http://www.url.com/to/the.torrent'
   * @param torrentSource - could be url, directory, file or pattern eg: d:\*.torrent   
   * @param outputDir directory to save files from torrent to	 
   * @throws IOException 
   */
  public String addFind(String torrentSource, String outputDir) throws IOException {
	 return addFind(torrentSource,outputDir,true,true);	  
  }
  /**
   * Add a download from the given .torrent file path or url. Example: 'add /path/to/the.torrent' or 'add http://www.url.com/to/the.torrent'
   * @param torrentSource - could be url, directory, file or pattern eg: d:\*.torrent   
   * @param outputDir directory to save files from torrent to	 
   * @param finding if true, don't start downloading the files; simply add them to the 'found' list
   * @param scansubdir if true, will recurse subdirectories looking for files to add
   * @throws IOException 
   */
  private String addFind(String torrentSource, String outputDir, boolean finding, boolean scansubdir) throws IOException {
	   
	   String hash = null;
	   if (outputDir==null)
			outputDir = COConfigurationManager.getDirectoryParameter("Default save path");
	   
	   if (!torrentSource.toUpperCase().startsWith("HTTP://")) {
		   DownloadManager dm = addLocal(torrentSource, outputDir, scansubdir, finding);
		   if (dm!=null) hash = ByteFormatter.nicePrintTorrentHash(dm.getTorrent(), true);
		   
	   } 
	   return hash;
	   //else TorrentDownloaderFactory.downloadManaged(torrentSource,outputDir);
				   
	   

  }
	/**
	 * attempt a local add (arg may be a directory, a file or a pattern eg: d:/*.torrent)
	 * @param torrentSource - could be directory, file or pattern eg: d:\*.torrent
	 * @param outputDir directory to save files from torrent to
	 * @param scansubdir if true, will recurse subdirectories looking for files to add
	 * @param finding if true, don't start downloading the files; simply add them to the 'found' list
	 */
	private DownloadManager addLocal(String torrentSource, String outputDir, boolean scansubdir, boolean finding) {
	
	    DownloadManager dm = null;
	    
		// substitute ~ for home directory, if specified
		if( torrentSource.startsWith("~/") || torrentSource.equals("~") )	{
			torrentSource = StringUtil.current().replaceAll(torrentSource, "~", System.getProperty("user.home"));
		}
		
		// see if the argument is an existing file or directory
		File test = new File(torrentSource);
		if (test.exists()) {
			if (test.isDirectory()) {
				File[] toadd = FileFinder.findFiles(torrentSource, "*.torrent;*.tor", scansubdir);								
				if ((toadd != null) && (toadd.length > 0)) {
					dm = addFiles(toadd, finding, outputDir );
				} else {
					adds = null;
					System.out.println("> Directory '" + torrentSource + "' seems to contain no torrent files.");
				}
			} else {
				dm = gm.addDownloadManager(torrentSource, outputDir);
				System.out.println("> '" + torrentSource + "' added.");
				torrents.clear();
			}
			return dm;
		} 

		// check to see if they are numeric and if so, try and add them from the 'adds' in ci
		try {
			int id = Integer.parseInt(torrentSource);
			if( adds != null && adds.length > id )
			{
				String torrentPath = adds[id].getAbsolutePath();
				dm = gm.addDownloadManager(torrentPath, outputDir);
				System.out.println("> '" + torrentPath + "' added.");
				torrents.clear();
			}
			else
			{
				System.out.println("> No such file id '" + id + "'. Try to list available files");
			}
			return dm;
		} catch (NumberFormatException e)
		{
			System.err.println("> Id number format error");
		}
		// last resort - try to process it as a directory/pattern eg: c:/torrents/*.torrent
		String dirName = test.getParent();
		if( dirName == null )
			dirName = ".";
		String filePattern = test.getName();
		File []files = FileFinder.findFiles(dirName, filePattern, false);
		if ((files != null) && (files.length > 0)) {
			dm = addFiles(files, finding, outputDir );
		} else {
			adds = null;
			System.out.println("> No files found. Searched for '" + filePattern + "' in '" + dirName + "'");
		}
		
		return dm;

	}

	/**
	 * if finding is set, just print the available files and add them to the 'add' list inside the consoleinput object,
	 * otherwise actually add the torrents, saving to the specified output directory
	 * @param toadd
	 * @param finding
	 * @param outputDir
	 */
	private DownloadManager addFiles(File[] toadd, boolean finding, String outputDir) {
		
		DownloadManager dm = null;
		
		System.out.println("> -----");
		System.out.println("> Found " + toadd.length + " files:");
		
		if( finding )
		{
			adds = toadd;			
		}
		else
		{
			for (int i = 0; i < toadd.length; i++) {
				dm = gm.addDownloadManager(toadd[i].getAbsolutePath(), outputDir);
				System.out.println("> '" + toadd[i].getAbsolutePath() + "' added.");
				torrents.clear();
			}
		}
		System.out.println("> -----");
        
		return dm;
	}
  
	public void showTorrents() {
	
			System.out.println("> -----");
			torrents.clear();
			torrents.addAll(gm.getDownloadManagers());
			Collections.sort(torrents, new Show.TorrentComparator());

			if (torrents.isEmpty()) {
				System.out.println("No Torrents");
				System.out.println("> -----");
				return;
			}
			
			DownloadManager dm;
			Iterator torrent = torrents.iterator();
			long totalReceived = 0;
			long totalSent = 0;
			long totalDiscarded = 0;
			int connectedSeeds = 0;
			int connectedPeers = 0;
			PEPeerManagerStats ps;
			int nrTorrent = 0;
			boolean bShowOnlyActive = true;
			boolean bShowOnlyComplete = true;
			boolean bShowOnlyIncomplete = true;
			
			while (torrent.hasNext()) {
				nrTorrent++;
				dm = (DownloadManager) torrent.next();
				DownloadManagerStats stats = dm.getStats();

				boolean bDownloadCompleted = stats.getDownloadCompleted(false) == 1000;
				boolean bCanShow = ((bShowOnlyComplete == bShowOnlyIncomplete) || (bDownloadCompleted && bShowOnlyComplete) || (!bDownloadCompleted && bShowOnlyIncomplete));

				if (bCanShow && bShowOnlyActive) {
					int dmstate = dm.getState();
					bCanShow = (dmstate == DownloadManager.STATE_SEEDING) || (dmstate == DownloadManager.STATE_DOWNLOADING) || (dmstate == DownloadManager.STATE_CHECKING) || (dmstate == DownloadManager.STATE_INITIALIZING) || (dmstate == DownloadManager.STATE_ALLOCATING);
				}

				if (bCanShow) {
					try {
						ps = dm.getPeerManager().getStats();
					} catch (Exception e) {
						ps = null;
					}
					if (ps != null) {
						totalReceived += dm.getStats().getTotalDataBytesReceived();
						totalSent += dm.getStats().getTotalDataBytesSent();
						totalDiscarded += ps.getTotalDiscarded();
						connectedSeeds += dm.getNbSeeds();
						connectedPeers += dm.getNbPeers();
					}				
					System.out.print(((nrTorrent < 10) ? " " : "") + nrTorrent + " ");
					System.out.println(Show.getTorrentSummary(dm));
					System.out.println();
				}
			}
			System.out.println("Total Speed (down/up): " + DisplayFormatters.formatByteCountToKiBEtcPerSec(gm.getStats().getDataReceiveRate() + gm.getStats().getProtocolReceiveRate() ) + " / " + DisplayFormatters.formatByteCountToKiBEtcPerSec(gm.getStats().getDataSendRate() + gm.getStats().getProtocolSendRate() ));

			System.out.println("Transferred Volume (down/up/discarded): " + DisplayFormatters.formatByteCountToKiBEtc(totalReceived) + " / " + DisplayFormatters.formatByteCountToKiBEtc(totalSent) + " / " + DisplayFormatters.formatByteCountToKiBEtc(totalDiscarded));
			System.out.println("Total Connected Peers (seeds/peers): " + Integer.toString(connectedSeeds) + " / " + Integer.toString(connectedPeers));
			System.out.println("> -----");	
	
	}	
	
	public Collection getAllTorrentSummary() {		
		
		Collection ts = new Vector();
		
		torrents.clear();
		torrents.addAll(gm.getDownloadManagers());
		Collections.sort(torrents, new Show.TorrentComparator());
		
		DownloadManager dm;
		Iterator torrent = torrents.iterator();
		
		while (torrent.hasNext()) {			
		
			dm = (DownloadManager) torrent.next();			

			ts.add(Summary.getTorrentSummary(dm));
	 	}
		
		return ts;
    }	


    public void remove(String hash) {    	    	
   	  List args = new ArrayList(); args.add("hash"); args.add(hash);
      executeTorrentMethod(new RemoveMethod(),args);    	
    }
    
    public void removeAll() {    	
	  List args = new ArrayList();  args.add("all");
	  executeTorrentMethod(new RemoveMethod(),args);    	
    }
    
    public void start(String hash) {
      List args = new ArrayList(); args.add("hash"); args.add(hash);
      executeTorrentMethod(new StartMethod(),args);
    }
	  
    public void startAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new StartMethod(),args);
    }
		  
    public void stop(String hash) {
    	List args = new ArrayList(); args.add("hash"); args.add(hash);
    	executeTorrentMethod(new StopMethod(),args);
    }
    
    public void stopAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new StopMethod(),args);
    }
		
    public void check(String hash) {
    	List args = new ArrayList(); args.add("hash"); args.add(hash);
    	executeTorrentMethod(new CheckMethod(),args);
    }
    
    public void checkAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new CheckMethod(),args);
    }
	  
    public void queue(String hash) {
    	List args = new ArrayList(); args.add("hash"); args.add(hash);
    	executeTorrentMethod(new QueueMethod(),args);
    }
    
    public void queueAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new QueueMethod(),args);
    }
    
    public void host(String hash) {
    	List args = new ArrayList(); args.add("hash"); args.add(hash);
    	executeTorrentMethod(new HostMethod(),args);
    }
    
    public void hostAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new HostMethod(),args);
    }
    	  
    public void forceStart(String hash) {
    	List args = new ArrayList(); args.add("hash"); args.add(hash);
    	executeTorrentMethod(new ForceStartMethod(),args);
    }
    
    public void forceStartAll() {
    	List args = new ArrayList();  args.add("all");
    	executeTorrentMethod(new ForceStartMethod(),args);
    }
	
    
	private void executeTorrentMethod(TorrentMethod tm, List args) {
		
		if (!args.isEmpty()) {
		    String subcommand = (String) args.remove(0);
			
			String name;
			DownloadManager dm;
			if ("all".equalsIgnoreCase(subcommand)) {
			  Iterator torrent = torrents.iterator();
			  while (torrent.hasNext()) {
			    dm = (DownloadManager) torrent.next();
			    
			    if (dm.getDisplayName() == null) name = "?";
			    else name = dm.getDisplayName();
			    
			    if (tm.performMethod(core,dm,gm, args))  System.out.println("> " + tm.getAction() + " Torrent #" + subcommand + " (" + name + ") succeeded.");
				else  System.out.println("> " + tm.getAction() + " Torrent #" + subcommand + " (" + name + ") failed.");
		  	  }
			} 
			else if ("hash".equalsIgnoreCase(subcommand)) {
			  String hash = (String) args.remove(0); 
			  List torrents = gm.getDownloadManagers();
			  boolean foundit = false;
			  if (!torrents.isEmpty()) {
				Iterator torrent = torrents.iterator();
				while (torrent.hasNext()) {
				  dm = (DownloadManager) torrent.next();
				  if (hash.equals(ByteFormatter.nicePrintTorrentHash(dm.getTorrent(), true))) {
				     if (dm.getDisplayName() == null) name = "?";
					 else name = dm.getDisplayName();
					
				     if (tm.performMethod(core,dm,gm, args))	System.out.println("> " + tm.getAction() + " Torrent " + hash + " (" + name + ") succeeded.");
					 else System.out.println("> " + tm.getAction() + " Torrent " + hash + " (" + name + ") failed.");
					 foundit = true;
					 break;
				   } 
			     }
			     if (!foundit)  System.out.println("> Command '" + tm.getCommandName() + "': Hash '" + hash + "' unknown.");
			   }
			   else System.out.println("> Command '" + tm.getCommandName() + "': Subcommand '" + subcommand + "' unknown.");					
			}
			else System.out.println("> Incorrect arg, not hash or all case");
			
		} else System.out.println("> Missing subcommand for '" + tm.getCommandName() + "'");
			
		
	}
	
  
  //move : move torrent from to to. If to is omitted, the torrent is moved to top or to the bottom if given negative.
  
  //share : share a file or folder(s).
  
  //set : method that allows manipulation of Azureus' runtime properties.
  
  //hack : modify torrent settings
  
  //xml : output stats in xml format
	
	
  public void makeTorrent(String urlParam, String fileParam) {

		    Map parameters = new HashMap();
		   
		    File f = new File(fileParam);
		    if(!f.exists()) {
		      System.out.println(fileParam + " is not a valid file / directory");
		      System.exit(-1);
		    }
		    URL url = null;
		    try {
		      url = new URL(urlParam);
		    } catch(Exception e) {
		      System.out.println(urlParam + " is not a valid url");
		      System.exit(-1);
		    }
		    new MakeTorrent(fileParam,url,parameters);    
  }	

  
}

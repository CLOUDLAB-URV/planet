package dermi.bittorrent.azureus;

import com.aelitis.azureus.core.*;

import java.util.List;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;

/**
 * torrent method to stop a torrent.
 * extracted from the Torrent class written by tobias
 */
public class StopMethod implements TorrentMethod {

	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args) {
		try {
			dm.stopIt( DownloadManager.STATE_STOPPED, false, false );
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public String getAction() {
		  return "Stopping";
		}

		public String getCommandName() {
		  return "stop";	
		}

	
}

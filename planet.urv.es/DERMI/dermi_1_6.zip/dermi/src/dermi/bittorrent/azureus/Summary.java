package dermi.bittorrent.azureus;

import java.text.DecimalFormat;

import org.gudy.azureus2.core3.disk.DiskManagerFileInfo;
import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.download.DownloadManagerStats;
import org.gudy.azureus2.core3.tracker.client.TRTrackerScraperResponse;
import org.gudy.azureus2.core3.util.DisplayFormatters;

import dermi.bittorrent.ISummary;

public class Summary implements ISummary {	

		private int state;
		private int completed;
		private String displayName;
		private long size;
		private long eta;
		private double tot;
		private long dataReceivedRate;
		private long dataSendRate;
		private DownloadManagerStats stats;
		private long totalDataBytesSent;
		private int nbSeeds;
		private int nbPeers;
		private int downloadSpeed;
		private int uploadSpeed;
		private int seeds;
		private int peers;

	
		
	/* (non-Javadoc)
	 * @see dermi.bittorrent.azureus.ISummary#getCompleted()
	 */
	public int getCompleted() {
			return completed;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getDataReceivedRate()
		 */
		public long getDataReceivedRate() {
			return dataReceivedRate;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getDataSendRate()
		 */
		public long getDataSendRate() {
			return dataSendRate;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getDisplayName()
		 */
		public String getDisplayName() {
			return displayName;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getDownloadSpeed()
		 */
		public int getDownloadSpeed() {
			return downloadSpeed;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getEta()
		 */
		public long getEta() {
			return eta;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getNbPeers()
		 */
		public int getNbPeers() {
			return nbPeers;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getNbSeeds()
		 */
		public int getNbSeeds() {
			return nbSeeds;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getPeers()
		 */
		public int getPeers() {
			return peers;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getSeeds()
		 */
		public int getSeeds() {
			return seeds;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getSize()
		 */
		public long getSize() {
			return size;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getState()
		 */
		public int getState() {
			return state;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getStats()
		 */
		public DownloadManagerStats getStats() {
			return stats;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getTot()
		 */
		public double getTot() {
			return tot;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getTotalDataBytesSent()
		 */
		public long getTotalDataBytesSent() {
			return totalDataBytesSent;
		}

		/* (non-Javadoc)
		 * @see dermi.bittorrent.azureus.ISummary#getUploadSpeed()
		 */
		public int getUploadSpeed() {
			return uploadSpeed;
		}

	public String toString() {
		
		DecimalFormat df = new DecimalFormat("000.0%");
		
		return "["+Show.getShortStateString(state)+"] "
		+df.format(completed/1000.0)+"\t"
		+displayName
		+" ("+DisplayFormatters.formatByteCountToKiBEtc(size)
		+") ETA: "+DisplayFormatters.formatETA(eta)+"\r\n"
		+df.format(tot)
		+"\tSpeed: "+DisplayFormatters.formatByteCountToKiBEtcPerSec(dataReceivedRate)+downloadSpeed
		+" / "+DisplayFormatters.formatByteCountToKiBEtcPerSec(dataSendRate)+uploadSpeed
		+"\tAmount: "+DisplayFormatters.formatDownloaded(stats)+" / "+DisplayFormatters.formatByteCountToKiBEtc(totalDataBytesSent)+
		"\tConnections: "+nbSeeds+"("+seeds+") / "
		+nbPeers+"("+peers+")";
	}

	/**
	 * returns the summary details for the specified torrent. - we do this by obtaining
	 * the summary format and then performing variable substitution 
	 * NOTE: we currently reprocess
	 * the summary format string each time however we could pre-parse this once.. its 
	 * probably not that important though.
	 * @return
	 */
	public static ISummary getTorrentSummary(DownloadManager dm) {
		
		Summary ts = new Summary();		    
		
		ts.state = dm.getState(); //DownloadManager.STATE_????
		ts.completed = dm.getStats().getCompleted();
		
		if (dm.getState() == DownloadManager.STATE_ERROR)
		  ts.displayName = dm.getErrorDetails();
		else {
		  if (dm.getDisplayName() == null)
			  ts.displayName = "?";
		  else
			  ts.displayName = dm.getDisplayName();
		}
		
		ts.size = dm.getSize();
		ts.eta = dm.getStats().getETA();
	
		long to = 0;
		long tot = 0;
		if (dm.getDiskManager() != null) {
			DiskManagerFileInfo files[] = dm.getDiskManager().getFiles();
			if (files != null) {
				if (files.length>1) { 
					int c=0;
					for (int i = 0; i < files.length; i++) {
						if (files[i] != null) {
						if (!files[i].isSkipped()) {
							c += 1;
							tot += files[i].getLength();
							to += files[i].getDownloaded();
						}
					}
				}
			    if (c == files.length)
				  tot = 0;
				}
		    }
		}
		
		if (tot > 0) {
		  ts.tot = to * 1.0 / tot;
		}
		else ts.tot = 0;
				
		ts.dataReceivedRate = dm.getStats().getDataReceiveRate();
		ts.dataSendRate = dm.getStats().getDataSendRate();
		ts.stats = dm.getStats();
		ts.totalDataBytesSent = dm.getStats().getTotalDataBytesSent();
		ts.nbSeeds = dm.getNbSeeds();
		ts.nbPeers = dm.getNbPeers();	

		ts.downloadSpeed = dm.getStats().getDownloadRateLimitBytesPerSecond();
		ts.uploadSpeed = dm.getStats().getUploadRateLimitBytesPerSecond();
	
		TRTrackerScraperResponse hd = dm.getTrackerScrapeResponse();
		if (hd != null && hd.isValid()) {
		  ts.seeds = hd.getSeeds();
		  ts.peers = (hd.getPeers());
		}		
		return ts;
		
	}
	

}

package dermi.bittorrent.azureus;

import java.util.List;

import com.aelitis.azureus.core.*;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;

/**
 * Interface that publicises the torrent performMethod. 
 */

public interface TorrentMethod {
	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args);

	public String getAction();

	public String getCommandName();
}

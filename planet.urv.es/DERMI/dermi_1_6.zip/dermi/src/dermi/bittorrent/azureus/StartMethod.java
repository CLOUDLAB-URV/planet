package dermi.bittorrent.azureus;

import java.util.List;
import java.util.Vector;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;

import com.aelitis.azureus.core.AzureusCore;

/**
 * torrent to start a torrent.
 * extracted from the Torrent class written by tobias
 */
public class StartMethod implements TorrentMethod {

	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args) {
	
		try {
			dm.setState(DownloadManager.STATE_WAITING);
			dm.startDownloadInitialized(true);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public String getAction() {
		  return "Starting";
		}

		public String getCommandName() {
		  return "start";	
		}

	
}

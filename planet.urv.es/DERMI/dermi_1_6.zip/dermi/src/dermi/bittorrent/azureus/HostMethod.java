package dermi.bittorrent.azureus;

import java.util.List;

import com.aelitis.azureus.core.*;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;
import org.gudy.azureus2.core3.torrent.TOTorrent;
import org.gudy.azureus2.core3.tracker.host.TRHostException;


/**
 * torrent method to host a torrent.
 * extracted from the Torrent class written by tobias
 */
public class HostMethod implements TorrentMethod {

	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args) {
		
		TOTorrent torrent = dm.getTorrent();
        if (torrent != null) {
          try {
            core.getTrackerHost().hostTorrent(torrent,true, false);
          } catch (TRHostException e) {
            e.printStackTrace();
            return false;
          }
          return true;
        }
        return false;
	}
	
	
	public String getAction() {
		  return "Hosting";
		}

		public String getCommandName() {
		  return "host";	
		}

}

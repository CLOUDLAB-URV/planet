package dermi.bittorrent.azureus;

import java.util.List;

import com.aelitis.azureus.core.*;

import org.gudy.azureus2.core3.download.DownloadManager;
import org.gudy.azureus2.core3.global.GlobalManager;


/**
 * torrent method to force start a torrent.
 * extracted out of the Torrent class written by tobias
 */
public class ForceStartMethod implements TorrentMethod {

	public boolean performMethod(AzureusCore core, DownloadManager dm, GlobalManager gm, List args) {
		try {
	          dm.setForceStart(true);
        } catch (Exception e) {
          e.printStackTrace();
          return false;
        }
        return true;
	}
	
	public String getAction() {
		  return "Force Starting";
		}

		public String getCommandName() {
		  return "forcestart";	
		}


}

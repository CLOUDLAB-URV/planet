package dermi.bittorrent;

public interface ISummary {

	public int getCompleted();

	public long getDataReceivedRate();

	public long getDataSendRate();

	public String getDisplayName();

	public int getDownloadSpeed();

	public long getEta();

	public int getNbPeers();

	public int getNbSeeds();

	public int getPeers();

	public int getSeeds();

	public long getSize();

	public int getState();

	public double getTot();

	public long getTotalDataBytesSent();

	public int getUploadSpeed();

}
package dermi;

import dermi.*;
import dermi.core.Id;
import dermi.dht.DHTGetClient;
import dermi.dht.DHTPutClient;
import dermi.dht.DHTRemoveClient;
import dermi.exception.*;

import bunshin.*;
import bunshin.util.*;

import java.util.*;
import java.net.*;
import java.io.*;

import bunshin.storage.StorageManager;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.Application;
import java.util.logging.Logger;

import dermi.*;
import dermi.util.pastry.HashGenerator;

public class DHTHandler {

  private transient Logger logger = Logger.getLogger (this.getClass().getName());
  private String context;

  public DHTHandler (String bunshinPropsPath, String context, String path, String url, URL[] URLsList) throws RemoteException {
    System.out.println ("Loading DHTHandler layer. WEBSERVER: " + url + " PATH: " + path);
    if (!dermi.Registry.isConnected()) {
      throw new RemoteException ("Before using the DHTHandler you must be connected to the overlay network!");
    }
    this.context = context;
    Registry.setInfoContext(context,path,url, URLsList);
  }

  public void insert (Id id, Serializable value) throws RemoteException {
    Registry.bindSer (context,id, value);
  }
  public void insert (Id id, Serializable value, String field, DHTPutClient listener) throws RemoteException {
    Registry.bindSer (context,id, value,field,listener);
  }

  public void insert (String str, Serializable value) throws RemoteException {
    Registry.bindSer (context, str, value);
  }

  public Serializable retrieve (Id id) throws RemoteException {
    return Registry.lookupSer (context,id);
  }

  public void retrieve (Id id, String field, DHTGetClient listener) throws RemoteException {
     Registry.lookupSer (context,id, field,listener);
  }

  public Serializable retrieve (Id id, String field) throws RemoteException {
	    return Registry.lookupSer (context,id, field);
  }
  
  public Serializable retrieve (String key) throws RemoteException {
    return Registry.lookupSer (context,key);
  }

  public void remove(Id id, String field)throws RemoteException {
        Registry.removeSer(context,id,field);
  }
  
  public void remove(Id id, String field, DHTRemoveClient listener)throws RemoteException {
      Registry.removeSer(context,id,field,listener);
}


  public void insertURL (Id id, URL url) throws RemoteException {
    Registry.insertURL (context,id, url, "URL");
  }

  public URL retrieveURL (Id id) throws RemoteException {
    return Registry.lookupURL (context, id, "URL");
  }


  public void removeURL (Id id) throws RemoteException {
    Registry.removeSer (context, id, null);
  }

  /*** SECURE *****/
  public boolean insertSecure (Id id, Serializable value, String pass) throws RemoteException {
    return Registry.bindSecure (context,id, value, pass);
  }
  
  /*** SECURE *****/
  public boolean insertSecure (Id id, Serializable value, String pass, boolean getcheck) throws RemoteException {
    return Registry.bindSecure (context,id, value, pass, getcheck);
  }


  public Serializable retrieveSecure (Id id, String pass) throws RemoteException {
    return Registry.lookupSecure (context,id, pass);
  }


  /*** SEARCH *****/

  public void insert (String keywords, String key, Serializable value) throws RemoteException {
    Registry.insert (context,keywords, key, value);
}

  public ResultSortedQueue query (String keywords) throws RemoteException {
    return Registry.query (context,keywords);
  }


  public void remove (String keywords, String key) throws RemoteException {
    Registry.remove (context,keywords, key);
  }

  public void leave() throws RemoteException {
    Registry.leave();
  }

  /*** LINKS & LISTENERS *****/

  /**
   *  Puts the outgoing links of a specific identifier in the networks and
   *  notifier with a notify message to the id owners.
   *  @param Id of the key
   *  @param Collection of the links ids
   */
  public void addLinks (Id id, Collection links) throws RemoteException {
    Registry.modify (context,id, links, "OutgoingLinks", true);
    Iterator it = links.iterator();
    while (it.hasNext()) {
      Id key = (Id) it.next();
      Registry.modify (context,key, id, "IncomingLinks", true);
    }
  }

  /**
   *  Removes the outgoing links of a specific identifier in the networks and
   *  notifier with a notify message to the id owners.
   *  @param Id of the key
   *  @param Collection of the links ids
   */
  public void removeLinks(Id id, Collection links) throws RemoteException {
    Registry.modify (context,id, links, "OutgoingLinks", false);
    Iterator it = links.iterator();
    while (it.hasNext()) {
      Id key = (Id) it.next();
      Registry.modify (context,key, id, "IncomingLinks", false);
    }
  }

  /**
   *  Sets a remote callback which notifies the link updates
   *  @param Id of the key
   *  @param RemoteListener callback
   */
  public void setLinkListener (Id id, bunshin.RemoteListener listener) throws RemoteException {
    Registry.setRemoteListener (context,id, listener, "IncomingLinks");
  }

  /**
   *  Removes the remote callback which notifies the link updates
   *  @param Id of the key
   */
  public void removeLinkListener (Id id) throws RemoteException {
    Registry.removeRemoteListener (context, id, "IncomingLinks");
  }

  /**
   *  Returns the incoming links of the specific key
   *  @param Id of the key
   *  @param Collection of the links ids
   */
  public Collection getIncomingLinks (Id key) throws RemoteException {
    Collection result = Registry.getIncomingLinks (context, key);
    return result;
  }


  /**
   *  Returns the outgoing links of the specific key
   *  @param Id of the key
   *  @param Collection of the links ids
   */
  public Collection getOutgoingLinks (Id key) throws RemoteException {
    Collection result = Registry.getOutgoingLinks (context, key);
    return result;
  }
}

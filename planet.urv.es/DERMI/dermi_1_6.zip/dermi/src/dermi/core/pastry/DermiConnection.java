/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package dermi.core.pastry;

import dermi.*;
import dermi.core.*;
import dermi.core.Node;
import dermi.core.NodeHandle;
import dermi.util.*;
import dermi.session.*;
import dermi.exception.*;
import dermi.activation.*;

import rice.environment.Environment;
import rice.p2p.commonapi.*;
import rice.pastry.*;
import rice.pastry.commonapi.*;
import rice.pastry.socket.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;
import rice.pastry.dist.DistPastryNodeFactory;
import rice.p2p.scribe.*;
import rice.p2p.scribe.Topic;

import java.util.*;
import java.util.logging.*;
import java.io.*;
import java.net.*;
import java.nio.channels.*;

/**
 * This class wraps a connection to Pastry and is used by Dermi as its main
 * routing substrate.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class DermiConnection extends dermi.core.DermiConnection {
  // ----- VARIABLES -----
	  // Loads pastry settings
	  public static Environment env = new Environment();

	  // the port to begin creating nodes on
	  public static int PORT = 5009;

	  // the port on the bootstrap to contact
	  public static int BOOTSTRAP_PORT = 5009;

	  // the host to boot the first node off of
	  public static String BOOTSTRAP_HOST = "localhost";

	  // Reference to the Pastry node
	  private PastryNode pn;

 
  // the instance name to use
  public static String INSTANCE_NAME = "Dermi";

  // Reference to Dermi's kernel specific to Pastry protocol (in this case, Scribe)
  private DermiKernel bus;

  /**
   * This method creates a new node which will serve as the underlying p2p layer
   * for Dermi
   * @param args Constructor arguments: 0 - String bootstrap host; 1 - int bootstrap port; 2 - PastryNodeFactory factory; 3 - int protocol
   * @throws ConnectionException If connection cannot be established against the bootstrap
   */
  public DermiConnection (Object ... args) throws ConnectionException {
    String bootHost = (String) args[0];
    int bootPort = (Integer) args[1];
    PastryNodeFactory fac = (PastryNodeFactory) args[2];
    int protocol = (Integer) args[3];
    configurationFile = (String) args[4];

    if (!bootHost.equalsIgnoreCase ("auto")) {
      BOOTSTRAP_HOST = bootHost;
    }
    PORT = BOOTSTRAP_PORT = bootPort;
    BOOTSTRAP_PORT = bootPort;
    PORT = bootPort;

//  Generate the NodeIds Randomly
    NodeIdFactory nidFactory = new RandomNodeIdFactory(env);

    PastryNodeFactory factory = null;
    //PastryNodeFactory factory = new DirectPastryNodeFactory (new RandomNodeIdFactory(env), new SphereNetwork(env), env);
 
      int newPort = PORT;

      // If working in remote mode, check if port is already bound 
        while (true) {
          DatagramChannel channel = null;
          try {
            channel = DatagramChannel.open();
            channel.configureBlocking (false);
            InetSocketAddress isa = new InetSocketAddress (newPort);
            channel.socket().bind (isa);
            channel.socket().close();
            channel.close();
      
//          construct the PastryNodeFactory, this is how we use rice.pastry.socket
            factory = new SocketPastryNodeFactory(nidFactory, newPort, env);
            break;
          } catch (Exception e) {
            newPort += 100;
            System.out.println ("Port " + (newPort - 100) + " already bound. Trying " + newPort + "...");
          }
          finally {
            channel.socket().close();
            try {
              channel.close();
            }
            catch (IOException ex) {

            }
          }
        }      
              
        // Get bootstrap reference
        InetSocketAddress address = new InetSocketAddress (BOOTSTRAP_HOST, BOOTSTRAP_PORT);     

        // This will return null if we there is no node at that location
        dermi.core.NodeHandle bootHandle = (dermi.core.NodeHandle) ((SocketPastryNodeFactory) factory).getNodeHandle(address);
        
    Properties props = null;
    try {
      props = Registry.getEnvironment (configurationFile);
    }
    catch (RemoteException ex2) {
      ex2.printStackTrace();
      throw new ConnectionException ("Unable to load configuration file " + configurationFile);
    }

    // construct a node, passing the null boothandle on the first loop will cause the node to start its own ring
    pn = factory.newNode((rice.pastry.NodeHandle) bootHandle);
    
    // The node may require sending several messages to fully boot into the ring
    while (!pn.isReady()) {
    // Delay so don't busy-wait
    try {
      Thread.sleep (100);
    }
    catch (InterruptedException ex1) {
    }
}

    // Initialize Event bus
    bus = new DermiKernel (INSTANCE_NAME, this);

    // Initialize DOLR layer
    // Only initialize it if it has not been previously initialized in the
    // same node
    if (!(Registry.isConnected())) {
      try {
        dermi.registry.pastry.Naming n = dermi.registry.pastry.Naming.getInstance();
        Registry.setInstance (n);
        n.loadRegistry (this, props);
//        Thread.currentThread().sleep (2000);
        // Bind special root object
        Registry.bindRoot();
      } catch (Exception re) {
        re.printStackTrace();
        throw new ConnectionException ("Unable to connect to decentralized object location registry!");
      }
    }
    logger.info ("Dermi layer initialized OK.");
  }

  /**
   * Method for subscribing an application to a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to subscribe
   */
  public void subscribe (dermi.core.Topic topic, Client subscriber) {
      bus.subscribe (topic, subscriber);
  }

/*  public boolean isSubscribed (dermi.core.Topic topic) {
    return bus.isSubscribed (topic);
  }
*/
  /**
   * Method for unsubscribing an application from a multicast group
   * @param topic Topic The group's identifier
   * @param subscriber ScribeClient The application to unsubscribe
   */
  public void unsubscribe (dermi.core.Topic topic, Client subscriber) {
      bus.unsubscribe (topic, subscriber);
  }

  /**
   * Method for publishing data
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void publish (dermi.core.Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.publish (topic, dat);
  }

  /**
   * Method for publishing data directly to a node
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void publishDirect (dermi.core.Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.publishDirect (topic, dat);
  }

  /**
   * Method for anycalling to a group of objects
   * @param topic Topic The group's identifier
   * @param data Serializable Data to publish
   */
  public void anycall (dermi.core.Topic topic, Serializable data) {
    DermiContent dat = new DermiContent (data);
    bus.anycast (topic, dat);
  }

  /**
   * Utility method for obtaining the local node handle
   * @return NodeHandle Local node handle
   */
  public dermi.core.NodeHandle getLocalNodeHandle() {
    return (dermi.core.NodeHandle) bus.getLocalNodeHandle();
  }

  /**
   * Utility method for obtaining the local node
   * @return Node Local node
   */
  public dermi.core.Node getLocalNode() {
    return pn;
  }

  /**
   * Utility method for obtaining the local node id
   * @return Id Local node id
   */
  public dermi.core.Id getLocalNodeId() {
    return new dermi.core.pastry.Id (bus.getLocalNodeHandle().getId().toByteArray());
  }

  /**
   * Returns a set of suitable replica nodes for such Id
   * @param id Id Which id to replicate
   * @param maxRank int Maximum number of replicas
   * @return Collection Set of replicas
   */
  public Collection getReplicaSet (dermi.core.Id id, int maxRank) {
    return bus.getReplicaSet (id, maxRank);
  }

  
  /**
   * Returns a set of suitable neighbour nodes for such Id
   * @param maxRank int Maximum number of neightbours
   * @return Collection Set of neighbours
   */
  
  public Collection getNeighbourSet (int maxRank) {
	return bus.getNeighbourSet(maxRank);
  }
  
  /**
   * Returns the list of children for a given topic
   *
   * @param topic The topic to return the children of
   * @return The children of the topic
   */
  public Collection getChildren(dermi.core.Topic topic) {
    rice.p2p.commonapi.NodeHandle[] children = bus.getChildren((Topic)topic);
    Collection result = new Vector(); 
    for(rice.p2p.commonapi.NodeHandle nh:children) {
      result.add((NodeHandle)nh);	
    }
   	return result;
  }

  /**
   * Returns the parent for a given topic
   *
   * @param topic The topic to return the parent of
   * @return The parent of the topic
   */
  public NodeHandle getParent(dermi.core.Topic topic) {
     return (NodeHandle) bus.getParent((Topic) topic);
  }

  /**
   * Returns whether or not this Scribe is the root for the given topic
   *
   * @param topic The topic in question
   * @return Whether or not we are currently the root
   */
  public boolean isRoot(dermi.core.Topic topic) {
    return bus.isRoot((Topic) topic);
  } 
  
  /**
   * Returns the list of all subscribed topics.
   * @return The list of topics
   */
  public dermi.core.Topic[] getAllTopics() {
    return (dermi.core.Topic[]) bus.getAllTopics();
  } 
  
  /**
   * Allows to run a node on a clock that is offset from your computers clock. 
   * @return the current time in millis
   */
  public long getNetworkTime() {
	 return env.getTimeSource().currentTimeMillis(); 
  }

  
  /**
   * Method for adding an interceptor to an object group
   * @param npar NotificationParser Interceptor application
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public void addInterceptor (DermiApplicationListener npar, dermi.core.Id subsKey, String interceptorId) {
    bus.addInterceptor (npar, new dermi.core.pastry.Topic (subsKey), interceptorId + ((rice.p2p.commonapi.NodeHandle) getLocalNodeHandle()).getId());
  }

  /**
   * Method for removing an interceptor from an object group
   * @param subsKey Id Subscription key
   * @param interceptorId String Interceptor id
   */
  public void removeInterceptor (dermi.core.Id subsKey, String interceptorId) {
    bus.removeInterceptor (new rice.p2p.scribe.Topic ((rice.p2p.commonapi.Id) subsKey), interceptorId + ((rice.p2p.commonapi.NodeHandle) getLocalNodeHandle()).getId());
  }

  /**
   * Method for resume the interception process. Automatically called
   * by interceptor skeletons
   * @param evt Hashtable
   * @param interceptors ArrayList
   */
  public void continueInterception (Hashtable evt, ArrayList interceptors) {
    bus.continueInterception (evt, interceptors);
  }

/*
  public int getMembers (dermi.core.Topic topic) {
    return bus.getMembers (topic);
  }
*/
  /**
   * Method for closing a connection, thus killing the node
   */
  public void close() {
    try {
      if (activatorImpl != null) activatorImpl.close();
      if (activatorClient != null) activatorClient.close();
    } catch (RemoteException e) {
      logger.warning ("Unable to close activator object.");
    }
    //pn.resign();
    pn.destroy();
  }

  public PriorityList getComponentHops (String componentId) {
    return bus.getComponentHops (componentId);
  }
}

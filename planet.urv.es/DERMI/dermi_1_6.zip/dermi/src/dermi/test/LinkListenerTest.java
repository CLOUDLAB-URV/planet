/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.test;

import junit.framework.*;

import java.util.*;

import dermi.*;
import dermi.core.Id;
import dermi.exception.*;
import dermi.util.pastry.*;
import dermi.samples.simple.*;

import bunshin.RemoteListener;

/**
 * The DermiSearch methods testcase
 * @author Ruben Mondejar   <ruben.mondejar@urv.net>
 * @version 1.0
 */
public class LinkListenerTest extends TestCase {
  DermiSearch search;
  Id global_id;

  public LinkListenerTest (String name) {
    super (name);
  }

  protected void setUp() {
    System.out.println ("[LinkListenerTest] - Setting >>>>>>>>> UP <<<<<<<<<<<");
    try {
      search = new DermiSearch();      

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void tearDown() {
    System.out.println ("[LinkListenerTest] - Tearing >>>>>>>>> DOWN <<<<<<<<<<\n");
    try	{
      search.leave();
      Thread.sleep (1000);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static Test suite() {
    return new TestSuite (LinkListenerTest.class);
  }

  public void testLinkListener() throws Exception {
  	
		//key unique
		String google_url = "http://www.google.com";
		//generate Id
		Id google_id = HashGenerator.generateHash(google_url);
  	
		Hashtable google_info = new Hashtable();
		google_info.put("url",google_url);
		google_info.put("date",new Date());
  	
		//insert key,value
		search.insert(google_id,google_info);
		Thread.currentThread().sleep(2000);
  	
		String etse_url = "http://www.etse.urv.es";
		//generate Id
		Id etse_id = HashGenerator.generateHash(etse_url);
  	
		Hashtable etse_info = new Hashtable();
		etse_info.put("url",etse_url);
		etse_info.put("date",new Date());
  	
		//insert key,value
		search.insert(etse_id,etse_info);  	  	
		Thread.currentThread().sleep(2000);

	    //test 1 = insert/retreive test

	    Hashtable retreived = (Hashtable) search.retrieve(etse_id);
	    assertEquals(etse_url,retreived.get("url"));
	
		global_id = null;
		//add listener 
		search.setLinkListener(etse_id,new RemoteListener() 	{
			public void eventArrived(Object value, boolean added)	{  	  	
				if (value instanceof Collection) 
				{
					Iterator it = ((Collection) value).iterator();  	    
					global_id = (dermi.core.Id) it.next();
				}
				else if (value instanceof Id) {
			        global_id = (Id) value;
				}
				System.out.println("\n New incoming link to http://www.etse.urv.es -> link_id : "+global_id+" \n");  	    
			}
		});
	  
		//add link
		Vector google_links = new Vector();
		google_links.add(etse_id);
		search.addLinks(google_id,google_links);
		Thread.currentThread().sleep(5000);
        
	  //test 2 = listener test
	    assertEquals(google_id,global_id);
	    
	  Thread.currentThread().sleep(1000);
  	    
	  Object value = search.getIncomingLinks(etse_id);
	  Iterator it = ((Collection) value).iterator();  	    
	  global_id = (Id) it.next();

	  //test 3 = incoming links test
		assertEquals(google_id,global_id);
  		
	}
}

package dermi.util;

import java.util.*;
import java.io.*;

 public class ByteClassLoader extends ClassLoader {
   private static Hashtable<String, Class> cache = new Hashtable<String, Class>();
   byte[] source;
   private ClassLoader contextLoader;

   public ByteClassLoader (byte[] bytes, ClassLoader contextLoader) {
     super();
     source = bytes;
     this.contextLoader = contextLoader;
   }

   public Class loadClass (String name, boolean resolve) throws ClassNotFoundException {
     try {
       return contextLoader.loadClass (name);
     } catch (ClassNotFoundException cnf) {
       return this.findClass (name);
     }
   }

   public Class findClass (String name) {
     if (cache.get (name) != null) {
       return (Class) cache.get (name);
     }
     else {
       byte[] b = loadClassData (name);
       Class c = super.defineClass (name, b, 0, b.length);
       cache.put (name, c);
       return c;
     }
   }

   private byte[] loadClassData (String name) {
     return source;
   }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi;

import bunshin.*;
import bunshin.util.*;

import dermi.util.*;
import dermi.dht.DHTGetClient;
import dermi.dht.DHTPutClient;
import dermi.dht.DHTRemoveClient;
import dermi.exception.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * This class provides Decentralized Registry's static and generic methods
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class Registry {
  private static dermi.registry.Naming naming;
  private static Properties connectionProperties = null;

  /**
   * Returns the object's environment properties
   *
   * @param filename String Object properties filename
   * @throws RemoteException If something goes wrong ;-)
   * @return Properties Object properties
   */
  public static Properties getEnvironment (String filename) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (filename);
      connectionProperties = new Properties();
      connectionProperties.loadFromXML (fis);

      connectionProperties.setProperty (dermi.util.Context.CONFIG_FILE, filename);

      return connectionProperties;
    } catch (Exception e) {
      throw new RemoteException ("Impossible to get object properties.");
    }
  }

  public static Properties getConnectionProperties() {
    return connectionProperties;
  }

  /**
   * It connects to the Registry (by creating a node!)
   * @param ref Name of properties file containing connection parameters.
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void loadRegistry (String ref) throws RemoteException {
    try {
      FileInputStream fis = new FileInputStream (ref);
      Properties env = new Properties();
      env.loadFromXML (fis);
      String hostName = env.getProperty (dermi.util.Context.PROVIDER_HOST);
      int port = (new Integer (env.getProperty (dermi.util.Context.PROVIDER_PORT))).intValue();

      Class[] cl = {};
      Object[] objs = {};
      String className = "dermi.registry." + env.getProperty (dermi.util.Context.UNDERLYING_DHT) + ".Naming";
      Class cls = Class.forName (className);
      Method meth = cls.getMethod ("getInstance", cl);
      naming = (dermi.registry.Naming) meth.invoke (null, objs);
      naming.loadRegistry (ref);
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e.getMessage ());
    }
  }


  public static Hashtable getStorageInfo() throws RemoteException {
  	return naming.getStorageInfo();
  }
  
  public static Hashtable getReplicaInfo() throws RemoteException {
  	return naming.getReplicaInfo();
  }


  public static void setInfoContext(String context, String path, String url, URL[] URLsList) throws RemoteException {
    naming.setInfoContext(context,path,url, URLsList);
  }
  
   /**
   * It closes the connection and kills the node
   * @throws RemoteException If the disconnection with the event service fails.
   */
  public static void leave() throws RemoteException {
    naming.leave();
  }

  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * @param name Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name) throws RemoteException {
    return naming.lookup (name);
  }


  /**
   * Returns a reference, a stub, for the remote object associated with the specified name.
   * Should this reference be not bound, start it remotely in the community, register it and
   * return the newly-created reference
   * @param name Id of the remote object in the Registry
   * @param communityId Id of the community where the object is to be activated (if necessary)
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static ERemote lookup (String name, String communityId, String className) throws RemoteException {
    return naming.lookup (name, communityId, className);
  }

  /**
   * Returns a serialized object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (String context, dermi.core.Id id) throws RemoteException {
    return naming.lookupSer (context, id);
  }

  public static Serializable lookupSer (String context, dermi.core.Id id, String field) throws RemoteException {
    return naming.lookupSer (context, id, field);
  }
  
  public static void lookupSer (String context, dermi.core.Id id, String field, DHTGetClient listener) throws RemoteException {
	    naming.lookupSer (context, id, field,listener);
  }
  
  public static URL lookupURL (String context, dermi.core.Id id, String field) throws RemoteException {
    return naming.lookupURL (context, id, field);
  }

  /**
   * Returns a serialized object associated with the specified name.
   * @param id Id of the remote object in the Registry
   * @throws RemoteException If the connection with the event service fails.
   * @return Eremote Reference to the remote object
   */
  public static Serializable lookupSer (String url) throws RemoteException {
    return naming.lookupSer (url);
  }

  public static Serializable lookupSer (String context, String url) throws RemoteException {
    return naming.lookupSer (context, url);
  }


  /**
   * Method used to know if the registry is already connected to a node
   * @return boolean true if it is connected
   */
  public static boolean isConnected () {
    if (naming == null) {
      return false;
    }
    else {
      return naming.isConnected ();
    }
  }

  /**
   * Method used to get the connection to the node (for reutilization purposes)
   * @return DermiConnection The connection
   */
  public static dermi.core.DermiConnection getConnection() {
    return naming.getConnection();
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, ERemote ref) throws RemoteException {
    naming.bind (name, ref);
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Id of the remote object
   * @param env Object properties
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bind (String name, Hashtable env) throws RemoteException {
    naming.bind (name, env);
  }

  /**
   * Unbinds the specified name from a remote object.
   * @param name Id of the remote object
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void unbind (String name) throws RemoteException {
    naming.unbind (name);
  }

  /**
   * Special root ("p2p://") bind method
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void bindRoot() throws RemoteException {
    naming.bindRoot();
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public static void rebind (String name, ERemote ref) throws RemoteException {
    naming.rebind (name, ref);
  }

  /**
   * Returns a Vector of the names bound in the registry.
   * The Vector contains a snapshot of the names present in the registry at the time of the call.
   * @throws dermi.RemoteException If the connection with the event service fails.
   * @return Vector A list of Ids from remote objects.
   */
  public static Collection list (String root) throws RemoteException {
    return naming.list (root);
  }

  public static void setInstance (dermi.registry.Naming reg) {
    naming = reg;
  }

  public static boolean bindSer (dermi.core.Id id, Serializable object) throws RemoteException {
    return naming.bindSer (id, object);
  }

  
  public static boolean bindSer (String name, Serializable object) throws RemoteException {
    return naming.bindSer (name, object);
  }

  public static boolean bindSer(String context, dermi.core.Id id, Serializable object) throws RemoteException {
    return naming.bindSer (context, id, object);
  }

  public static void bindSer (String context, dermi.core.Id id, Serializable object, String field, DHTPutClient listener) throws RemoteException {
	    naming.bindSer (context,id, object, field, listener);
	  }

  public static boolean bindSer (String context, String name, Serializable object) throws RemoteException {
    return naming.bindSer (context, name, object);
  }
  
  public static void removeSer (dermi.core.Id id) throws RemoteException {
    naming.removeSer (id);
  }

  public static void removeSer (String name) throws RemoteException {
    naming.removeSer (name);
  }
  
  public static void removeSer(String context, dermi.core.Id id, String field) throws RemoteException {
  	naming.removeSer(context, id, field);
  }
  
  public static void removeSer(String context, dermi.core.Id id, String field, DHTRemoveClient listener) throws RemoteException {
	  naming.removeSer(context, id, field,listener);
  }

   /* SECURE */
  public static boolean bindSecure (String context, dermi.core.Id id, Serializable object, String pass) throws RemoteException {
    return naming.bindSecure (context, id, object, pass);
  } 
  
  public static boolean bindSecure (String context, dermi.core.Id id, Serializable object, String pass, boolean getcheck) throws RemoteException {
	    return naming.bindSecure (context, id, object, pass, getcheck);
  } 
  
  public static Serializable lookupSecure (String context, dermi.core.Id id, String pass) throws RemoteException {
    return naming.lookupSecure (context, id, pass);
  }
   
   
  /* DERMI EXTRA METHODS */

  public static void insertURL (String context, dermi.core.Id key, java.net.URL url, String field) throws RemoteException {
    naming.insertURL (context, key, url, field);
 }

  public static void modify (String context, dermi.core.Id key, Object value, String field, boolean add) throws RemoteException {
    naming.modify (context, key, value, field, add);
  }

  public static void modify (String context, dermi.core.Id key, Collection values, String field, boolean add) throws RemoteException {
    naming.modify (context, key, values, field, add);
  }

  public static void setRemoteListener (String context, dermi.core.Id id, RemoteListener listener, String field) throws RemoteException {
    naming.setRemoteListener (context, id, listener, field);
  }

  public static void removeRemoteListener(String context, dermi.core.Id id, String field) throws RemoteException {
    naming.removeRemoteListener (context, id, field);
  }

  public static Collection getIncomingLinks (String context, dermi.core.Id id) throws RemoteException {
    return naming.getIncomingLinks (context, id);
  }

  public static Collection getOutgoingLinks(String context, dermi.core.Id id) throws RemoteException {
    return naming.getOutgoingLinks (context, id);
  }

  /* DERMI SEARCH METHODS */

  public static void insert(String context, String keywords, String key, Serializable value)  throws RemoteException {
    naming.insert (context, keywords, key, value);
  }

  public static ResultSortedQueue query(String context, String keywords)  throws RemoteException {
    return naming.query (context, keywords);
  }

  public static void remove(String context, String keywords, String key) throws RemoteException {
    naming.remove (context, keywords, key);
  }
}

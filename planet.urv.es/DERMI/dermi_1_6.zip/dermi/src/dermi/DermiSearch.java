package dermi;

import dermi.*;
import dermi.core.Id;
import dermi.exception.*;

import bunshin.*;
import bunshin.util.*;

import java.util.*;
import java.io.*;
import java.net.*;


public class DermiSearch {

   public DermiSearch() throws RemoteException {

     Properties env = Registry.getEnvironment ("dermi-config.xml");
     Registry.loadRegistry ("dermi-config.xml");
   }

	public DermiSearch(String path) throws RemoteException
	{
		Properties env = Registry.getEnvironment (path);
		Registry.loadRegistry (path);
	}

	public void insertURL(Id id, URL url)  throws RemoteException
	{
		Registry.insertURL("search",id,url,"URL");
	}

	 public void insert(Id id, Serializable value)  throws RemoteException  {
		   Registry.bindSer("search",id,value);
	 }

	public void insert(String keywords, String key, Serializable value)  throws RemoteException {
   	  Registry.insert ("search",keywords,key,value);
   }

   public ResultSortedQueue query(String keywords)  throws RemoteException {
   	 return Registry.query ("search",keywords);
   }



   public Serializable retrieve(String key)  throws RemoteException {
   	 return Registry.lookupSer("search",key);
   }

   public Serializable retrieve(Id key)  throws RemoteException {
   	 return Registry.lookupSer("search",key);

   }

  public Serializable retrieveURL (Id id) throws RemoteException {
    return Registry.lookupSer ("search", id, "URL");
  }

   public void remove(String keywords, String key) throws RemoteException {
   	 Registry.remove("search",keywords,key);
   }

   public void leave() throws dermi.exception.RemoteException {
     Registry.leave();
   }

/*** LINKS & LISTENERS *****/

	/**
	 *   Puts the outgoing links of a specific identifier in the networks and
	 *  notifier with a notify message to the id owners.
	 *  @param Id of the key
	 *  @param Collection of the links ids
	 */
	public void addLinks(Id id, Collection links) throws dermi.exception.RemoteException {
		Registry.modify("search",id,links,"OutgoingLinks",true);
		Iterator it = links.iterator();
		while(it.hasNext()) {
			Id key = (Id) it.next();
			Registry.modify("search",key,id,"IncomingLinks",true);
		}
	}

	/**
	 *   Removes the outgoing links of a specific identifier in the networks and
	 *  notifier with a notify message to the id owners.
	 *  @param Id of the key
	 *  @param Collection of the links ids
	 */
	public void removeLinks(Id id, Collection links) throws dermi.exception.RemoteException {
		Registry.modify("search",id,links,"OutgoingLinks",false);
		Iterator it = links.iterator();
		while(it.hasNext()) {
			Id key = (Id) it.next();
			Registry.modify("search",key,id,"IncomingLinks",false);
		}
	}

	/**
	 *   Sets a remote callback which notifies the link updates
	 *  @param Id of the key
	 *  @param RemoteListener callback
	 */
	public void setLinkListener(Id id, bunshin.RemoteListener listener) throws dermi.exception.RemoteException {
		Registry.setRemoteListener("search",id,listener,"IncomingLinks");
	}

	/**
	 *   Removes the remote callback which notifies the link updates
	 *  @param Id of the key
	 */
	public void removeLinkListener(Id id) throws dermi.exception.RemoteException {
		Registry.removeRemoteListener("search",id,"IncomingLinks");
	}

	/**
	 *   Returns the incoming links of the specific key
	 *  @param Id of the key
	 *  @param Collection of the links ids
	 */
	public Collection getIncomingLinks(Id key) 	throws dermi.exception.RemoteException {


		Collection result = Registry.getIncomingLinks("search",key);
		return result;
	}


	/**
	 *   Returns the outgoing links of the specific key
	 *  @param Id of the key
	 *  @param Collection of the links ids
	 */
	public Collection getOutgoingLinks(Id key) 	throws dermi.exception.RemoteException {

		Collection result = Registry.getOutgoingLinks("search",key);
		return result;
	}



}

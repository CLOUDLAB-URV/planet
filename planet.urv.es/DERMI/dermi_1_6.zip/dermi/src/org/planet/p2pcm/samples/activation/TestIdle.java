// Aquest a classe mostra com instanciar un component (Slides) que ja estigui previament registrat
// (deployed) a Dermi i el seu arbre de directoris descentralitzat.
package org.planet.p2pcm.samples.activation;

import org.planet.p2pcm.*;
import org.planet.p2pcm.samples.stateful.*;

import java.net.URL;

public class TestIdle {
    public TestIdle() {
        ComponentFactory pfac = null, sfac = null;
        try {
            // Busquem la factoria del component al DOLR de Dermi
            pfac = (PlaceFactory) ComponentUtil.getComponentFactory ("p2p://place-stateful.deim.etse.urv.es");
            sfac = (SlidesFactory) ComponentUtil.getComponentFactory ("p2p://slides-stateful.deim.etse.urv.es");
        } catch (ComponentNotRegisteredException e) {
            System.out.println ("Component not registered, unable to continue.");
            System.exit (-1);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        try {
            Place place = (Place) pfac.createInstance ("org.planet.p2pcm.samples.stateful.Place", "place-gnatz");
//            Slides slides = (Slides) sfac.createInstance ("org.planet.p2pcm.samples.stateful.Slides", "slides000002", "slide1");
//            Slides slides2 = (Slides) sfac.createInstance ("org.planet.p2pcm.samples.stateful.Slides", "slides000003", "slide2");
//            Slides slides3 = (Slides) sfac.createInstance ("org.planet.p2pcm.samples.stateful.Slides", "slides000004", "slide3");
//            Slides slides4 = (Slides) sfac.createInstance ("org.planet.p2pcm.samples.stateful.Slides", "slides000005", "slide4");
//            Slides slides5 = (Slides) sfac.createInstance ("org.planet.p2pcm.samples.stateful.Slides", "slides000006", "slide5");

            // Ara interactuem amb el component via una de les seves interficies (Controls)
//            slides.first();

//            place.addThing (new SlidesImpl());
//            place.addThing (slides2);
//            place.addThing (slides3);
//            place.addThing (slides4);
//            place.addThing (slides5);

/*            java.util.Iterator i = place.getThings().iterator();

            while (i.hasNext()) {
              Slides s = (Slides) i.next();
              System.out.println ("Iterating... " + s.getCurrentImageSet());
            }
*/
            System.out.println ("---------------------------------------------");
        } catch (InterfaceNotFoundException e) {
            System.out.println ("Interface cannot be found, unable to continue.");
        } catch (Exception ex) {
          ex.printStackTrace();
        }
    }

    public static void main (String[] args) throws Exception {
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/slides-stateful.jar"));
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/place-stateful.jar"));
      TestIdle ex = new TestIdle ();
    }
}

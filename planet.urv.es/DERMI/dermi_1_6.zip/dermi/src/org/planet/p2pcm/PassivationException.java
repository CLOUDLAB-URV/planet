package org.planet.p2pcm;

/**
 * This exception is thrown whenever a component cannot be passivated
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class PassivationException extends Exception {
  public PassivationException (String msg) {
    super (msg);
  }
}

package org.planet.p2pcm;

/**
 * This class wraps an ComponentDeploymentException, which may occur
 * when deploying a component
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ComponentDeploymentException extends Exception {
    public ComponentDeploymentException (String msg) {
        super (msg);
    }
}

package org.planet.p2pcm;

/**
 * Exception that occurs when trying to look up a component which has not yet been deployed
 * on Dermi (it thus cannot be found by Dermi's DOLR service)
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ComponentNotRegisteredException extends Exception {
    public ComponentNotRegisteredException (String msg) {
        super (msg);
    }
}

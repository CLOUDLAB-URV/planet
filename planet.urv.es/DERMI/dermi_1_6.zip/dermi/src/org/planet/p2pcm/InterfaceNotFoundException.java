package org.planet.p2pcm;

/**
 * This exception is thrown whenever trying to get a component interface which does not
 * provide an implementation
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class InterfaceNotFoundException extends Exception {
  public InterfaceNotFoundException (String msg) {
    super (msg);
  }
}

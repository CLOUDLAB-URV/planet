/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package org.planet.p2pcm.samples.listener;

import org.planet.p2pcm.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * This is the component's base class. In this case, it implements all the component's interfaces.
 * It is in fact a special Dermi Remote Object that must extend the Component class, and be
 * labelled with @DCMImplementation annotation tag.
 *
 * In this case, we show the utilization of listeners in Dermi components.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DCMImplementation
public class PlaceImpl extends Component implements Place /* , StatefulReplica */ {
  private ArrayList<User> users = new ArrayList<User>();

  // Dermi stub constructor: REQUIRED
  public PlaceImpl() {
  }

  // Dermi skel constructor: REQUIRED
  public PlaceImpl (Properties env) throws RemoteException {
    super (env);
    System.out.println ("[Place] - component created.");
  }

  public void join (User u) throws RemoteException {
    if (!users.contains (u)) {
      users.add ((User) u);
      System.out.println ("[Place] - User " + u.getName() + " added.");
      triggerEvent (new UserEvent (u.getName(), true));

      // This is a local call to addUserListener, and so the dynamic proxy will not be called
      // It is therefore needed to implement the addUserListener / removeUserListener methods
      // which basically do the same as their homonyms in DermiProxy class
      addUserListener (UserEvent.class, new UserListener (u.getName()));
    }
  }

  public void leave (User u) throws RemoteException {
    System.out.println ("[Place] - User " + u.getName() + " removed.");
    users.remove (u);
    triggerEvent (new UserEvent (u.getName(), false));
  }

  public void addUserListener (Class eventClass, BasicListener sL) throws RemoteException {
    super.addListener (eventClass, sL);
  }

  public void removeUserListener (Class eventClass, BasicListener sL) throws RemoteException {
    super.removeListener (eventClass, sL);
  }

  public Collection getUsers() throws RemoteException {
    System.out.println ("[Place] - Returning users vector...");
    return users;
  }

  /**
   * The queryInterface method must return a suitable component implementation
   * for the specified interface
   * @param interf String The desired interface implementation
   * @return ComponentInterface The desired implementation instance
   * @throws InterfaceNotFoundException If the component does not provide an implementation for such specified interface
   */
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException {
    try {
      if (interf.equals ("org.planet.p2pcm.ComponentInterface") || interf.equals ("org.planet.p2pcm.samples.listener.Place")) {
        // Stub will either be local or remote, depending on the case
        return (ComponentInterface) this.copy();
      }
    } catch (RemoteException re) {
      throw new InterfaceNotFoundException ("Unable to query for interface " + interf + ": " + re.getMessage());
    }
    throw new InterfaceNotFoundException ("Interface " + interf + " not implemented.");
  }
}


/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package org.planet.p2pcm.samples.comp;

import org.planet.p2pcm.*;
import dermi.exception.*;
import dermi.annotation.*;

/**
 * Slides component's factory class. Note that it must extend <b>ComponentFactory</b>
 * Moreover, it must provide a standard set of annotations which indicate the component's
 * metadata:
 *     - id         --  Component's unique ID
 *     - stateful   --  Whether it is stateful or stateless
 *     - persistent --  Which kind of persistence is applied: currently only PersistenceType.CONTAINER works
 *     - replicated --  Whether it is replicated or not (singleton)
 *     - url        --  URL where the component's metadata entry will be bound in the decentralized registry
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DCMFactory (
    id = "7cbc3a28-241b-4d00-b42c-8043677c308c",
    stateful = false,
    persistent = PersistenceType.CONTAINER,
    replicated = true,
    url = "p2p://slides-comp.deim.etse.urv.es"
    )
public class SlidesFactory extends ComponentFactory {
  /**
   * SlidesFactory's constructor -- REQUIRED
   * @param componentURL String Component's URL locator
   * @throws RemoteException If something goes wrong ;-)
   */
  public SlidesFactory (String componentURL) throws RemoteException {
    super (componentURL);
  }

  /**
   * This method creates an instance of this component (without arguments), and returns an implementation of the specified interface
   * @param interf String Interface name
   * @param instance String Instance name
   * @return ComponentInterface Returns an implementation of ComponentInterface
   * @throws InterfaceNotFoundException Thrown if specified interface cannot be found
   * @throws RemoteException Thrown if something else goes wrong ;-)
   */
  public ComponentInterface createInstance (String interf, String instance) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[SlidesFactory] - Trying to create instance without arguments...");
    return super.createInstance (interf, instance);
  }

  /**
   * This method creates an instance of this component (with arguments), and returns an implementation of the specified interface
   * @param interf String Interface name
   * @param instance String Instance name
   * @param args Object[] Component arguments
   * @return ComponentInterface Returns an implementation of ComponentInterface
   * @throws InterfaceNotFoundException Thrown if specified interface cannot be found
   * @throws RemoteException Thrown if something else goes wrong ;-)
   */
  public ComponentInterface createInstance (String interf, String instance, Object...args) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[SlidesFactory] - Trying to create instance with arguments...");
    return super.createInstance (interf, instance, args);
  }
}

package org.planet.p2pcm.samples.stateful;

import dermi.*;
import org.planet.p2pcm.*;
import dermi.util.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * Place component's factory class. Note that it must extend <b>ComponentFactory</b>
 * Moreover, it must provide a standard set of annotations which indicate the component's
 * metadata:
 *     - id         --  Component's unique ID
 *     - stateful   --  Whether it is stateful or stateless
 *     - persistent --  Which kind of persistence is applied: currently only PersistenceType.CONTAINER works
 *     - replicated --  Whether it is replicated or not (singleton)
 *     - url        --  URL where the component's metadata entry will be bound in the decentralized registry
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */

@DCMFactory (
    id = "819daf87-176f-49a1-a65d-d63e6dff7984",
    stateful = true,
    persistent = PersistenceType.CONTAINER,
    replicated = true,
    url = "p2p://place-stateful.deim.etse.urv.es"
    )
public class PlaceFactory extends ComponentFactory {
  public PlaceFactory() {
  }

  public PlaceFactory (String componentURL) throws RemoteException {
    super (componentURL);
  }

  public ComponentInterface createInstance (String interf, String instance) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[PlaceFactory] - Trying to create instance without arguments...");
    return super.createInstance (interf, instance);
  }

  public ComponentInterface createInstance (String interf, String instance, Object...args) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[PlaceFactory] - Trying to create instance with arguments...");
    return super.createInstance (interf, instance, args);
  }
}

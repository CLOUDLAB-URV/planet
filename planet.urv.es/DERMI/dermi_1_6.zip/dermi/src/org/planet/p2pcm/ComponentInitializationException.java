package org.planet.p2pcm;

/**
 * This class wraps an ComponentInitializationException, which may occur
 * when initializing a component
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class ComponentInitializationException extends Exception {
    public ComponentInitializationException (String msg) {
        super (msg);
    }
}

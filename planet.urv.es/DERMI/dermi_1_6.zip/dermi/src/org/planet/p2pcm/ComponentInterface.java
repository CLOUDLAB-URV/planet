package org.planet.p2pcm;

import dermi.*;
import dermi.annotation.*;

/**
 * This remote interface is implemented by any Dermi component.
 * All Dermi components exported interfaces must implement it.
 * It provides the activation and passivation callbacks as well as the
 * queryInterface method, � la COM's IUnknown
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public interface ComponentInterface extends ERemote {
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException;

  // These methods are not remote, hence the lack of annotations
  public void activate() throws ActivationException;
  public void passivate() throws PassivationException;
}

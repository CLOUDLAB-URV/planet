/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.util;

import dermi.*;
import dermi.listener.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;

import dermi.exception.*;

/**
 * This is a custom class loader that makes a request to the remote object for the stub class when this is not found
 * on the local machine. The remote object then sends the stub class using the event service and the BusClassLoader
 * loads it in the custom virtual machine enabling highly dynamic remote applications.<br>
 * The difference between Java RMI is that each object is then responsible for returning the stub class for remote clients.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class BusClassLoader extends ClassLoader implements RemoteEventListener {
  private Hashtable<String, Class> cache = new Hashtable<String, Class>();
  private Hashtable<String, Object> evt = new Hashtable<String, Object>();
  private Hashtable<String, Object> subs = new Hashtable<String, Object>();
  private ClassLoader contextLoader;
  private Session conn = null;
  private boolean resultArrived = false;
  private boolean exception = false;
  private Properties env;
  private byte[] data;
  private transient Logger logger = Logger.getLogger (this.getClass().getName());

  /**
   * Class constructor
   * @param env Properties Environment properties
   */
  public BusClassLoader (Properties env, ClassLoader contextLoader) {
    super();
    this.env = env;
    this.contextLoader = contextLoader;

    String muid = env.getProperty (Context.CLASS_ID);
    subs.put (Context.OBJ, muid + Context.APPEND_RESULT_DYNAMIC);
    evt.put (Context.OBJECTID, muid);
    evt.put (Context.TYPE, Context.DISPATCH);
    evt.put (Context.METHOD, "getBytes");
  }

  public BusClassLoader() {
    super();
  }

  /**
   * This method is called whenever an event is received
   * @param evt Hashtable Event data
   */
  public void eventArrived (Hashtable evt) {
    String type = (String) evt.get (Context.TYPE);
    if (type.equals (Context.EXCEPTION)) {
      exception = true;
    }
    else {
      ByteWrapper bw = (ByteWrapper) evt.get (Context.OBJECTCONTENT);
      data = bw.getBytes();
    }
    resultArrived = true;
  }

  public Hashtable anycallEventArrived (Hashtable evt) throws UnmatchedAnycallMethodException {
    return null;
  }

  /**
   * This method should be used before closing any instance of this class
   */
  public void close() {
    if (conn != null) {
      Bus.close();
      conn = null;
    }
  }

  /**
   * Method for remote class to load the specifed class
   * @param name Complete class name
   * @param resolve Boolean look up remotely.
   * @throws ClassNotFoundException Problem with the loaded class: not found.
   */
  public synchronized Class loadClass (String name, boolean resolve) throws ClassNotFoundException {
    try {
      // findSystemClass (name);
      return contextLoader.loadClass (name);
    }
    catch (Exception e) {
      Class c = (Class) cache.get (name);
      if (c == null) {
        logger.info ("Dermi: Loading remote class...: " + name);
        try {
          conn = Bus.getBus (env);
          conn.subscribe (this, subs);
        } catch (SessionException ex) {
          throw new ClassNotFoundException ("Dermi: Problems with the Event service.");
        } catch (RemoteException ex2) {
          throw new ClassNotFoundException ("Dermi: Problems with the Event service.");
        }

        String tstamp = "" + System.currentTimeMillis();
        for (int retransmission = 0; retransmission < Context.RETRANSMISSIONS;) {
          try {
            evt.put (Context.TIMESTAMP, tstamp);
            conn.publish (evt);
          } catch (SessionException ex) {
            throw new ClassNotFoundException ("Dermi: Problems with the Event service.");
          }
          int timeout = 0;
          while (!resultArrived && timeout < Context.TIMEOUT) {
            try {
              Thread.currentThread().sleep (Context.DELAY);
            } catch (InterruptedException ex) {
              ex.printStackTrace();
            }
            timeout++;
          }
          if (exception) {
            exception = false;
            throw new ClassNotFoundException ("Dermi: Remote class is unavailable.");
          } else if (timeout == Context.TIMEOUT) {
            retransmission++;
            continue;
          }
          break;
        }
        c = defineClass (null, data, 0, data.length);
        cache.put (name, c);
      }

      if (resolve) {
        resolveClass (c);
      }
      return c;
    }
  }

  public synchronized void defineClass (String className, byte[] data) {
    Class c = defineClass (null, data, 0, data.length);
    cache.put (className, c);
  }
}

/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.util;

/**
 * This class contains Dermi's constants, like connection timeouts, synchronous blocking
 * delays, and String constants for the properties objects.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Pedro Garcia    <pedro.garcia@urv.net>
 * @version 1.2
 */
public class Context {

  /**
   * Timeout constant. All timeouts will be consumend once TIMEOUT*DELAY milliseconds have been elapsed
   */
  public static int TIMEOUT = 200;

  /**
   * Default delay for synchronous calls
   */
  public static int DELAY = 10;

  /**
   * Number of event retransmissions in case all timeouts have been consumed
   */
  public static int RETRANSMISSIONS = 1000;

  /**
   * The name of the constant containing the directory with loadable remote stubs
   */
  public static final String CLASS_STORE = "dermi.classStore";

  /**
   * The name of the constant containing the name of the Stub class for the properties reference
   */
  public static final String CLASS_NAME = "dermi.className";

  /**
   * CLASS_ID is the unique identifier assigned to an object server. It is used for all subscriptions
   * related to this object
   */
  public static final String CLASS_ID = "dermi.classID";

  /**
   * DERMI_DOLR_NAMING represents the DERMI naming distributed object location and routing facility
   */
  public static final String DERMI_DOLR_NAMING = "DERMI_DOLR_NAMING";

  /**
   * DERMI_DOLR_UNIQUE_URI represents the object URI identifier associated to an object
   */
  public static final String DERMI_DOLR_UNIQUE_URI = "DERMI_DOLR_UNIQUE_URI";

  /**
   * DERMI_DOLR_CHILDREN refers to the name of the field containing children objects for any object
   */
  public static final String DERMI_DOLR_CHILDREN = "DERMI_DOLR_CHILDREN";

  /**
   * DERMI_DOLR_PARENT refers to the parent of an object (in the naming hierarchy)
   */
  public static final String DERMI_DOLR_PARENT = "DERMI_DOLR_PARENT";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the class factory provider
   * to use.
   */
  public static final String PROVIDER_CLASS = "dermi.sessionClass";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the service provider
   * to use.
   */
  public static final String PROVIDER_HOST = "dermi.host";

  /**
   * Constant that holds the name of the environment property for specifying configuration information for the port numberof the  provider
   * to use.
   */
  public static final String PROVIDER_PORT = "dermi.port";

  /**
   * Constant that holds the protocol used by Dermi to communicate between remote nodes
   */
  public static final String PROTOCOL = "dermi.protocol";

  public static final String NETWORK_PROXY = "dermi.networkProxy";

  public static final String NETWORK_PROXY_PORT = "dermi.networkProxyPort";

  /**
   * Constant that holds the community ID for an activator object
   */
  public static final String COMMUNITYID = "dermi.communityID";

  /**
   * Constant that holds the underlying DHT Dermi uses
   */
  public static final String UNDERLYING_DHT = "dermi.underlyingDHT";

  public static final String COMPONENT_FILE = "dermi-component.xml";

  public static final String COMPONENT_ID = "id";

  public static final String ACTIVATABLE = "remoteActivation";

  public static final String PERSISTENT = "persistent";

  public static final String REPLICATED = "replicated";

  public static final String STATEFUL = "stateful";

  public static final String ACTIVATION_THRESHOLD = "activationThreshold";

  public static final String PASSIVATION_THRESHOLD = "passivationThreshold";

  public static final String COMPONENT_URL = "url";

  public static final String REMOTE_OBJECT = "remote-object";

  public static final String INTERFACES = "interfaces";

  public static final String INTERFACE = "interface";

  public static final String IMPLEMENTATION_CLASS = "implementationClass";

  public static final String IMPLEMENTATION_NAME = "implementationName";

  public static final String INTERFACE_CLASS = "interfaceClass";

  public static final String INTERFACE_NAME = "interfaceName";

  public static final String FACTORY_CLASS = "factoryClass";

  public static final String FACTORY_NAME = "factoryName";

  // Other constants, used in event messages
  public static final String OBJECTID = "OBJECT";

  public static final String TIMESTAMP = "TIMESTAMP";

  public static final String OBJ = "OBJ";

  public static final String OBJECTCONTENT = "object";

  public static final String TYPE = "TYPE";

  public static final String DISPATCH = "DISPATCH";

  public static final String EXCEPTION = "EXCEPTION";

  public static final String METHOD = "METHOD";

  public static final String SOURCE_NODEHANDLE = "SOURCE_NHANDLE";

  public static final String RESULT = "RESULT";

  public static final String APPEND_RESULT = ":RESULT";

  public static final String APPEND_RESULT_DYNAMIC = ":RESULTDYNAMIC";

  public static final String VOID = "VOID";

  public static final String DESTINATION_NODEHANDLE = "DEST_NHANDLE";

  public static final String INTERCEPTOR_UID = "UIDF";

  public static final String ANYCALL_RESULT = "ANYCALL_RESULT";

  public static final String STATUS = "STATUS";

  public static final String MANYCALL = "MANYCALL";

  public static final String REPLICA = "REPLICA";

  public static final String MEMBERSHIP_METAINFO = "MEMBERSHIP_METAINFO";

  public static final String MEMBERSHIP_PERCENTAGE = "MEMBERSHIP_PERCENTAGE";

  public static final String GET_COMPONENT_INSTANCE = "GET_COMPONENT_INSTANCE";

  public static final String HOPPED = "HOPPEDCALL";

  public static final String DYNAMIC_HOPPED_CALL = "DYNAMIC_HOPPED_CALL";

  public static final String ACTIVATOR_ID = "dermi_activator_object";

  public static final String CONFIG_FILE = "dermi-config.xml";

  /**
   * Constant that holds the default passivation threshold for components:
   * If after PASV_THRESHOLD milliseconds, the component has not received any
   * invocations, it will be passivated.
   */
  public static final int PASV_THRESHOLD = 600000;

  /**
   * Constant that holds the default activation threshold for components:
   * If more than ACTV_THRESHOLD invocations are received in a second,
   * a new component instance will be activated in a replica node.
   */
  public static final int ACTV_THRESHOLD = 10;

  /**
   * Constant that holds the default free memory threshold for component passivation:
   * If less than FREEMEM_THRESHOLD bytes of memory are available in the JVM,
   * the component's instance will be passivated.
   */
  public static final long FREEMEM_THRESHOLD = 20000;

  // Annotation constants
  public static final String GRANULARITY = "GRANULARITY";

  public static final String SYNCHRONY = "SYNCHRONY";

  public static final String RETRIES = "RETRIES";
}

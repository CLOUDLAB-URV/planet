/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package dermi.registry.pastry;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;

import dermi.*;
import dermi.exception.*;
import dermi.registry.*;
import dermi.util.*;
import dermi.util.pastry.*;

import rice.p2p.commonapi.*;
import rice.p2p.commonapi.Id;
import rice.pastry.PastryNode;

import bunshin.*;
import bunshin.util.*;
import bunshin.storage.*;

/**
 * This class implements the decentralized object location registry
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @author Ruben Mondejar  <ruben.mondejar@estudiants.urv.es>
 * @version 1.2
 */
public class Registry {
  private Bunshin bunshinApp;
  private String registryContext = "registry";
  private final String field = "DERMI";

  private boolean bindResultArrived = false;
  private boolean lookupResultArrived = false;
  private Properties eref = null;
  private Serializable eser = null;
  private URL eurl = null;

  private transient Logger logger = Logger.getLogger (this.getClass().getName());

  // Constructor only used for the DHTHandler class !!
  public Registry (String bunshinProperties) throws RemoteException {
/*    // Initialize Bunshin layer
    try {
      FileInputStream fis = new FileInputStream (bunshinProperties);
      Properties prop = new Properties ();
      prop.load (fis);
      fis.close();

      String id = (String) prop.get (bunshin.Context.ID_APPLICATION);
      StorageManager manager = (StorageManager) Class.forName ((String) prop.get (bunshin.Context.STORAGE_MANAGER)).newInstance();
      manager.init (prop);
      int replicaFactor = Integer.parseInt ((String) prop.get (bunshin.Context.REPLICA_FACTOR));
      boolean cache = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.CACHE));
      boolean debug = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.DEBUG));

      bunshinApp = new BunshinImpl (id);
      bunshinApp.setStorageManager (manager);
      bunshinApp.setReplicationFactor (replicaFactor);
      if (cache) bunshinApp.activateCache();
      if (debug) bunshinApp.activateDebug();
      Endpoint endPoint = ((PastryNode) (dermi.Registry.getConnection().getLocalNode())).registerApplication ((Application) bunshinApp, id);
      bunshinApp.setEndPoint (endPoint);

      logger.fine ("DHTHandler started.");
    } catch (FileNotFoundException fe) {
      throw new RemoteException ("File not found initiating DHTHandler (dermi.registry.pastry.Registry).");
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e);
    }
*/
  }
  

  /**
   * Constructor for the decentralized registry: entry point and local start
   * @param pn Node Bunshin needs the Pastry node to build itself on top of
   */
  public Registry (Node pn, Properties bunshinProperties) {
    try {
      initRegistry ((PastryNode) pn, bunshinProperties);
    }
    catch (RemoteException ex) {
      logger.severe ("Exception starting registry.");
      ex.printStackTrace();
    }
  }

  /**
   * Connects to the registry and initializes Bunshin layer
   * @param FACTORY IdFactory IDFactory to may be used
   * @param pn PastryNode Pastry node to be used
   * @param REPLICATION_FACTOR int Replication factor to be used
   * @throws RemoteException If impossible to start Bunshin layer
   */
/*  private void initRegistry (IdFactory FACTORY, PastryNode pn, int REPLICATION_FACTOR, String bunshinProperties) throws RemoteException {
    // Initialize Bunshin layer
    try {
      FileInputStream fis = new FileInputStream (bunshinProperties);
      Properties prop = new Properties ();
      prop.load (fis);
      fis.close();

      String id = (String) prop.get (bunshin.Context.ID_APPLICATION);
      StorageManager manager = (StorageManager) Class.forName ((String) prop.get (bunshin.Context.STORAGE_MANAGER)).newInstance();
      manager.init (prop);
      int replicaFactor = Integer.parseInt ((String) prop.get (bunshin.Context.REPLICA_FACTOR));
      boolean cache = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.CACHE));
      boolean debug = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.DEBUG));

      bunshinApp = new BunshinImpl (id);
      bunshinApp.setStorageManager (manager);
      bunshinApp.setReplicationFactor (replicaFactor);
      if (cache) bunshinApp.activateCache();
      if (debug) bunshinApp.activateDebug();
      Endpoint endPoint = pn.registerApplication ((Application) bunshinApp, id);
      bunshinApp.setEndPoint (endPoint);

      logger.fine ("Dermi naming registry started.");
    } catch (FileNotFoundException fe) {
      throw new RemoteException ("File not found initiating registry.");
    } catch (Exception e) {
      throw new RemoteException (e);
    }
  }
*/
 /**
   * Connects to the registry and initialized Bunshin layer
   * @param FACTORY IdFactory IDFactory to may be used
   * @param pn PastryNode Pastry node to be used
   * @param REPLICATION_FACTOR int Replication factor to be used
   * @throws RemoteException If impossible to start Bunshin layer
   */
  private void initRegistry (PastryNode pn, Properties prop) throws RemoteException {
    // Initialize Bunshin layer
    try {
      String id = (String) prop.get (bunshin.Context.ID_APPLICATION);
      StorageManager manager = (StorageManager) Class.forName ((String) prop.get (bunshin.Context.STORAGE_MANAGER)).newInstance();
      manager.init (prop);
      int replicaFactor = Integer.parseInt ((String) prop.get (bunshin.Context.REPLICA_FACTOR));
      boolean cache = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.CACHE));
      boolean debug = bunshin.Context.TRUE.equals((String)prop.get (bunshin.Context.DEBUG));

      bunshinApp = new BunshinImpl (id);
      bunshinApp.setStorageManager (manager);
      bunshinApp.setReplicationFactor (replicaFactor);
      if (cache) bunshinApp.activateCache();
      if (debug) bunshinApp.activateDebug();
      Endpoint endPoint = pn.registerApplication ((Application) bunshinApp, id);
      bunshinApp.setEndPoint (endPoint);

      logger.fine ("Dermi naming registry started.");
    } catch (Exception e) {
      e.printStackTrace();
      throw new RemoteException (e);
    }
  }

  public void setInfoContext(String context, String path, String url) throws RemoteException {
    bunshinApp.setInfoContext(context,path,url);
  }

  /**
   * It left the Bunshin Application
   * @throws RemoteException If the connection with the event service fails.
   */
  public void leave() throws RemoteException {
    bunshinApp.leave();
  }

  /**
   * Returns a reference, for the remote object associated with the specified name (or null if not bound)
   * @param name Name of the remote object in the Registry
   * @throws RemoteException If the connection fails
   * @return Eremote Reference to the remote object
   */
  public ERemote lookup (String name) throws RemoteException {
    int timeout = 0; int nullTries = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;
      lookupResultArrived = false;

      Id key = Utilities.generateHash(name);

      bunshinApp.get(registryContext, key,new BunshinGetClient() {
        public void get (Object result) {
          synchronized (this) {
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                eref = (Properties) ((bunshin.util.Values) result).get (field);
              }
              else {
                eref = (Properties) result;
              }
            }
            else {
              eref = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (eref == null) {
        if (nullTries < 10) {
          nullTries++;
          continue;
        }
        else {
          logger.warning ("Received 10 null lookup results. Object is considered to be not bound.");
          break;
        }
      }
      ERemote result = (ERemote) FileRegistry.loadERef (eref);
      return result;
    }
    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + name + "' not bound.");
  }

  public ERemote lookup (dermi.core.DermiConnection connection, String name, String communityId, String className) throws RemoteException {
/*    try {
      return this.lookup (name);
    } catch (NotBoundException e) {
      // Object was not bound, therefore we should activate it remotely in the specified community
      // Security: Note that it is mandatory to belong to the community in order to be able to activate objects there
      // Could be solved using a DermiConnection method for sending the activation event!
      dermi.activation.ActivatorClient ac = connection.getActivator (communityId);
      if (ac != null) {
        Properties env = dermi.Registry.getEnvironment ("dermi-config.xml");
        env.setProperty (Context.CLASS_ID, name);
        env.setProperty (Context.CLASS_NAME, className);
        env.setProperty (Context.COMMUNITYID, communityId);
        // TODO: Use one (activateObject) or another (activateMultipleObjects) depending on class' attributes!!!!!
        return (ERemote) FileRegistry.loadERef (ac.activateMultipleObjects (env));
      }
      throw new NotBoundException ("Unable to remotely activate object " + name + ". Security error: you don't belong to community " + communityId + ".");
    }
*/
    return null;
  }

  /**
   * Returns a serializable object from the decentralized registry
   * @param id Id Object's Id
   * @throws RemoteException If unable to connect to the registry
   * @return Serializable Object from the registry returned
   */

  public Serializable lookup (dermi.core.Id id) throws RemoteException {
    return lookup (registryContext, id, field);
  }

  public Serializable lookup (String context, dermi.core.Id id) throws RemoteException {
    return lookup (context, id, field);
  }

  public Serializable lookup (String context, dermi.core.Id id, final String f) throws RemoteException {
    return lookupSecure(context,id,f,null);
  }

  public Serializable lookupSecure (String context, dermi.core.Id id, final String f, String pass) throws RemoteException {
    int timeout = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;
      lookupResultArrived = false;

      bunshinApp.getSecure (context,(Id) id, f, pass, new BunshinGetClient() {
        public void get (Object result) {

          synchronized (this) {
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                eser = (Serializable) ((bunshin.util.Values) result).get (f);
              }
              else {
                eser = (Serializable) result;
              }
            }
            else {
              eser = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );


      synchronized (this) {
        while (!lookupResultArrived && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (eser == null) {
        // Should retry (Bunshin layer may not be ready yet (!!!))
        continue;
      }

      return eser;
    }

    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + id + "' not bound.");
  }
  
  public URL lookupURL (String context, dermi.core.Id id, final String f) throws RemoteException {
    int timeout = 0;
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS;) {
      timeout = 0;
      lookupResultArrived = false;

      bunshinApp.getURL (context,(Id) id, f, new BunshinURLClient() {
        public void get (URL result) {

          synchronized (this) {
            if (result != null) {
              eurl = result;              
            }
            else {
              eurl = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );


      synchronized (this) {
        while (!lookupResultArrived && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
      retransmission++;

      if (eurl == null) {
        // Should retry (Bunshin layer may not be ready yet (!!!))
        continue;
      }

      return eurl;
    }

    // All retransmissions exhausted (no luck!)
    throw new NotBoundException ("Object '" + id + "' not bound.");
  }

  /**
   * Binds the specified name to a remote object.
   * @param name Name of the remote object to be used (should be unique)
   * @param ref Remote object reference to bind
   * @throws RemoteException If the connection with the event service fails.
   */
  public void bind (String name, Properties ref) throws RemoteException {
    int timeout = 0;

    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    if (!name.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    // Tokenize object URI
    StringTokenizer tokens = new StringTokenizer (name, "/");
    int tokenCount = tokens.countTokens();

    // Check tokens size
    if (tokenCount < 2) {
      throw new NotBoundException ("Object URI incorrect: unable to bind multiple top-level roots");
    }

    // Obtain parent id
    String parentId = "p2p://";
    tokens.nextToken();   // Skip "p2p:"

    for (int i = 0; i < tokenCount - 2; i++) {
      parentId += tokens.nextToken() + "/";
    }
    if (!(parentId.endsWith ("p2p://"))) {
      parentId = parentId.substring (0, parentId.length() - 1);
    }

    logger.fine ("Updating parent record: " + parentId);

    // Children ArrayList is empty
    ref.put (dermi.util.Context.DERMI_DOLR_CHILDREN, new ArrayList());

    // Parent pointer
    dermi.core.Id parentNodeId = HashGenerator.generateHash (parentId);
    ref.setProperty (dermi.util.Context.DERMI_DOLR_PARENT, parentId);

    ref.setProperty (dermi.util.Context.DERMI_DOLR_UNIQUE_URI, name);
    insert (registryContext, HashGenerator.generateHash(name), (Properties) ref.clone(), field);

    synchronized (this) {
      while (!bindResultArrived && timeout < dermi.util.Context.TIMEOUT) {
        try {
          Thread.sleep (dermi.util.Context.DELAY);
        }
        catch (InterruptedException ex) {
        }
        timeout++;
      }
      bindResultArrived = false;
    }

    if (timeout == dermi.util.Context.TIMEOUT) {
      throw new RemoteException ("Unable to bind object.");
    }

    if (tokenCount > 1) {
      // Lookup parent object
      Properties parentProps = (Properties) lookup (parentNodeId);
      ArrayList<Properties> parentChildren = (ArrayList<Properties>) parentProps.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
      if (parentChildren == null) {
        parentChildren = new ArrayList<Properties>();
      }

      // FIX: Add only objectID! Now adding object meta-information...
      // Maybe this is better?
      if (!exists (parentChildren, ref)) {
        parentChildren.add ((Properties) ref.clone ());
        parentProps.put (dermi.util.Context.DERMI_DOLR_CHILDREN, parentChildren);
        insert (registryContext, parentNodeId, parentProps, field);
      }
    }
  }

  private boolean exists (ArrayList<Properties> parent, Properties propz) {
    Iterator<Properties> i = parent.iterator();

    while (i.hasNext()) {
      Properties p = i.next();
      if (p.getProperty (dermi.util.Context.DERMI_DOLR_UNIQUE_URI).equals (propz.getProperty (dermi.util.Context.DERMI_DOLR_UNIQUE_URI))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Insert object's metadata into the registry
   * @param id Id Object's Id
   * @param props Properties Metadata to be inserted
   * @param boolean exclusive - Tells whether inserted value overwrites a previously existing one
   */

  public void insert (dermi.core.Id id, Serializable props, String f) {
    bunshinApp.put (registryContext,(Id) id, props, f);
    bindResultArrived = true;
  }

  public void insert (String context, dermi.core.Id id, Serializable props, String f) {
    bunshinApp.put (context, (Id) id, props, f);
    bindResultArrived = true;
  }

  public boolean insertSecure (String context, dermi.core.Id id, Serializable props, String f, String pass) {
    //bunshinApp.putSecure (context, (Id) id, props, f, pass);
    //bindResultArrived = true;
     int timeout = 0;

    for (int retransmission = 0; retransmission < dermi.util.Context.RETRANSMISSIONS; retransmission++) {
      timeout = 0;
      bindResultArrived = false;

      bunshinApp.putSecure (context,(Id) id, props,f, pass,new BunshinPutClient() {
        public void put (boolean ack) {

          synchronized (this) {            
            bindResultArrived = ack;
          }
        }
      }
      );


      synchronized (this) {
        while (!bindResultArrived && timeout < dermi.util.Context.TIMEOUT) {
          try {
            Thread.sleep (dermi.util.Context.DELAY);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }      
      return bindResultArrived;
    }
    return bindResultArrived;    
  }
    
  

  /**
   * Unbinds the specified name from the registry.
   * @param name Id of the remote object
   * @throws dermi.NotBoundException - if the Registry does not contains this Id.
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void unbind (String name) throws RemoteException {
    int timeout = 0;

    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

/*    if (!name.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }
*/
    // Tokenize object URI
    StringTokenizer tokens = new StringTokenizer (name, "/");
    int tokenCount = tokens.countTokens();

    // Check tokens size
    if (tokenCount < 2) {
      throw new NotBoundException ("Object URI incorrect: unable to bind multiple top-level roots");
    }

    // Obtain parent id
    String parentId = "p2p://";
    tokens.nextToken();   // Skip "p2p:"

    for (int i = 0; i < tokenCount - 2; i++) {
      parentId += tokens.nextToken() + "/";
    }
    if (!(parentId.endsWith ("p2p://"))) {
      parentId = parentId.substring (0, parentId.length() - 1);
    }

    logger.fine ("Updating parent record: " + parentId);

    // Children ArrayList is empty
    //ref.put (Context.DERMI_DOLR_CHILDREN, new ArrayList());

    // Parent pointer
    dermi.core.Id parentNodeId = HashGenerator.generateHash (parentId);

    //ref.setProperty(Context.DERMI_DOLR_PARENT, parentId);

    //ref.setProperty (Context.DERMI_DOLR_UNIQUE_URI, name);
    //insert (HashGenerator.generateHash(name), (Properties) ref.clone(), true);
    Id key = Utilities.generateHash (name);
    bunshinApp.remove (registryContext, key, field);

    if (tokenCount > 1) {
      // Lookup parent object
      Properties parentProps = (Properties) lookup (registryContext,parentNodeId);
      ArrayList<Properties> parentChildren = (ArrayList<Properties>) parentProps.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
      if (parentChildren != null) {

      	boolean found = false;

        for(int i=0;i<parentChildren.size() && !found ;i++) {

          String s = (String) parentChildren.get(i).getProperty (dermi.util.Context.DERMI_DOLR_UNIQUE_URI);
          if (name.equals(s)) {
            found = true;
            parentChildren.remove(i);
          }
        }

        if (found) {
        	parentProps.put (dermi.util.Context.DERMI_DOLR_CHILDREN, parentChildren);
        }
      }
    }
  }

  /**
   * Rebinds the specified name in the registry.
   * @param name Id of the remote object
   * @param ref remote object reference to bind
   * @throws dermi.RemoteException - if the connection with the event service fails.
   */
  public void rebind (String name, Properties ref) throws RemoteException {
    bind (name, ref);
  }

  /**
   * Returns the list of objects bound below the specified root
   * @param root Hierarchical root (in the form "p2p://...")
   * @return A collection containing the object's list
   * @throws RemoteException
   */
  public Collection list (String root) throws RemoteException {
    if (bunshinApp == null) {
      throw new RegistryNotLoadedException ("Registry not loaded");
    }

    if (!root.startsWith ("p2p://")) {
      throw new NotBoundException ("Object URI incorrect: must begin with 'p2p://'");
    }

    Properties props = (Properties) lookup (registryContext, HashGenerator.generateHash (root));
    Collection c = (Collection) props.get (dermi.util.Context.DERMI_DOLR_CHILDREN);
    Iterator i = c.iterator();

    ArrayList<RegistryRecord> result = new ArrayList<RegistryRecord>();

    while (i.hasNext()) {
      result.add (new RegistryRecord ((Properties) i.next()));
    }
    return result;
  }

  //DERMI SEARCH METHOD
  private Set getKeywords(String tokens) {
    StringTokenizer st = new StringTokenizer(tokens);
    Set keyworks = new TreeSet();

    while(st.hasMoreTokens()) {
      String token = st.nextToken();
      if (token.length()>2) {
        keyworks.add(token);
      }
    }
    return keyworks;
  }


  //DERMI SEARCH METHOD
  public void insert(String context, String tokens, String id, Serializable value)  throws RemoteException {
    dermi.core.Id idValue = HashGenerator.generateHash (id);

    Set keywords = getKeywords(tokens);
    insert (context, idValue, value, field);

    Iterator it = keywords.iterator();
    while(it.hasNext()) {

      String token = (String) it.next();

      Set keywords1 = (Set) ((TreeSet) keywords).clone();

      dermi.core.Id key = HashGenerator.generateHash (token);
      Properties prop = (Properties) lookup(context, key);

      if (prop==null) {
        System.out.println("New prop + "+keywords1);
        prop = new Properties();
        prop.put(idValue,keywords1);
      }
      else {
        Set previous = (Set) prop.get(idValue);
        if (previous!=null) keywords1.addAll(previous);
        prop.put(idValue,keywords1);
      }
      insert (context,key,(Serializable) prop, field);
    }
  }

  //DERMI SEARCH METHOD
  public ResultSortedQueue query(String context,String query_key)  throws RemoteException {
    Set keywords = getKeywords(query_key);
    ResultSortedQueue result = new ResultSortedQueue(keywords);

    Hashtable merge = new Hashtable();

    Iterator it = keywords.iterator();
    while(it.hasNext()) {

      String token = (String) it.next();
      dermi.core.Id key = HashGenerator.generateHash (token);
      Properties prop = (Properties) lookup(context,key);

      if (prop!=null) {
        Iterator it2 = prop.keySet().iterator();
        while(it2.hasNext()) {
          Id idValue = (Id) it2.next();
          if (merge.containsKey(idValue)) {
            Set keywordSet = (Set) merge.get(idValue);
            keywordSet.addAll(keywords);
            merge.put(idValue,keywordSet);
          }
          else {
            merge.put(idValue,keywords);
          }
        }
      }
    }

    //Insert merge result in the HashSortedQueue
    Iterator it2 = merge.keySet().iterator();
    while (it2.hasNext()) {
      Id idValue = (Id) it2.next();
      Set elems = (Set) merge.get(idValue);
      result.add(idValue,elems);
    }

    return result;
  }

  //DERMI SEARCH METHOD
  public void remove(String context, String tokens, String id) throws RemoteException {
    dermi.core.Id idValue = HashGenerator.generateHash (id);
    bunshinApp.remove (context,(Id) idValue);

    Set keywords = getKeywords(tokens);
    Iterator it = keywords.iterator();

    while(it.hasNext()) {
      String token = (String) it.next();
      Set keywords1 = (Set) ((TreeSet) keywords).clone();

      dermi.core.Id key = HashGenerator.generateHash (token);
      Properties prop = (Properties) lookup(context,key);

      if (prop!=null) {
        Set previous = (Set) prop.get(idValue);
        if (previous!=null) {
          prop.remove(idValue);
          insert (context,key, (Serializable) prop, field);
        }
      }
    }
  }

  public void insertURL (String context, dermi.core.Id id, java.net.URL url, String f) {
    bunshinApp.putURL (context, (Id) id, url, f);
  }


  public void modify (String context,dermi.core.Id id, Object value, String f, boolean add) {
    bunshinApp.modify (context, (Id) id, value, f, add);
  }

  public void modify (String context,dermi.core.Id id, Collection values, String f, boolean add) {
    bunshinApp.modify (context,(Id) id, values, f, add);
  }

  public void setRemoteListener (String context,dermi.core.Id id, RemoteListener listener, String f) {
    bunshinApp.setRemoteListener (context,(Id) id, listener, f);
  }

  public void removeRemoteListener (String context,dermi.core.Id id, String f) {
    bunshinApp.removeRemoteListener (context,(Id) id, f);
  }

  public Collection getIncomingLinks(String context,dermi.core.Id id) throws RemoteException {
    Collection result = (Collection) lookup (context, id, "IncomingLinks");
    return result;
  }

  public Collection getOutgoingLinks (String context,dermi.core.Id id) throws RemoteException {
    Collection result = (Collection) lookup (context, id, "OutgoingLinks");
    return result;
  }

  /**
   * Common superclass for data reception commands.
   */
  protected class NamingCommand extends Thread implements rice.Continuation {
    public void receiveResult(Object result) {
      try {
        receive (result);
      }
      catch (Exception e) {
        receiveException(e);
      }
    }
    public void receive (Object result) throws Exception {}
    public void receiveException (Exception e) {
      e.printStackTrace();
      logger.warning ("receiveException on NamingCommand");
    }
  }


 // public void insert (Id id, java.io.Serializable ser, boolean exclusive) {
 //   bunshinApp.put ((Id) id, (Object) ser, field);
 // }
}

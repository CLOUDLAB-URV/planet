/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.storage;

import java.io.*;
import java.util.*;
import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 * 
 * @author Ruben Mondejar
 */
public class DiskStorage implements StorageManager {

  private String PATH = "storage";
  private Bucket mem = new Bucket();  
  private long max = 1024*1024;
  
    
  public DiskStorage() {  
    loadAll();	
  }
  
  public DiskStorage(String path) {
  	PATH = path;
  	loadAll();
  }  
  
  public DiskStorage(String path, long max_size) {
  	PATH = path;
  	long max = max_size;  	
  	loadAll();
  }  
  
  public DiskStorage(long max_size)  {
  	long max = max_size;  	
  	loadAll();
  }
  
  public void init(Properties prop) {
  	
  	String path = (String)prop.get("BUNSHIN_STORAGE_ROOT_DIR");
  	if (path!=null) {
  	  PATH = path+PATH;
  	  System.out.println("PATH : "+PATH);
  	}
  }
  
  public void add(Bucket newBucket) throws StorageException {
  	mem.add(newBucket);
  	if (max==0 || memSize()<max) {
  	  try {  	  
  		saveAll();
  	  } catch(IOException ex) {
  	  	  throw new StorageException(ex);
  	  }
  	}
  	
  }
	
  public void insert(Id key, Object value, String field) throws StorageException {
    mem.insert(key,value,field);
    if (max==0 || memSize()<max) {
  	  try {  	  
  		save(key);
  	  } catch(IOException ex) {
  	  	  throw new StorageException(ex);
  	  }
  	}
  }
	
  public void overwrite(Id key, Object value) throws StorageException {
    mem.overwrite(key,value);
    if (max==0 || memSize()<max) {
  	  try {    	    	  
  		save(key);
  	  } catch(IOException ex) {
  	  	  throw new StorageException(ex);
  	  }
  	}
  }
  
  public Object remove(Id key) throws StorageException {                   
    Object obj = mem.remove(key);	
    if (max==0 || memSize()<max) {
  	  try {  	  
  		delete(key);
  	  } catch(IOException ex) {
  	  	  throw new StorageException(ex);
  	  }
  	}
  	return obj;
  } 
  
  public Object delete(Id key, String field) throws StorageException {
  	Object obj = mem.delete(key,field);	
    if (max==0 || memSize()<max) {
  	  try {  	  
  		save(key);
  	  } catch(IOException ex) {
  	  	  throw new StorageException(ex);
  	  }
  	}
  	return obj;
  	
  }
	
  public Object retreive(Id key, String field) { 	
    return mem.load(key,field);	
  }
  
  public Values extract(Id key) { 	
    return mem.extract(key);	
  }  
 
  
  public boolean exists(Id key) {
  	 return mem.containsKey(key);	    	  
  }  
 
  public Bucket getBucket() {
  	return mem;
  }   
  
  private void save(Id key) throws IOException {
  	
  	File dir = new File(PATH);	  	
  	if (!dir.exists()) {
  	  dir.mkdir(); 
  	}

  	Values values = mem.extract(key);
  	Pair pair = new Pair(key,values);
  	String name = ((rice.pastry.NodeId)key).toStringFull();  	  
  	File f = new File(PATH+"/"+name);
	f.createNewFile();
	FileOutputStream out = new FileOutputStream(f);
  	ObjectOutputStream oos = new ObjectOutputStream(out); 	     
  	oos.writeObject(pair);
  	oos.close();  	  
  	
  }
  
  private void delete(Id key) throws IOException {
  	
  	File dir = new File(PATH);
  	if (dir.exists()) {
  	   	    	  
  	  String name = ((rice.pastry.NodeId)key).toStringFull();  	    	  
  	  File f = new File(PATH+"/"+name);
	  f.delete();  
	  //System.out.println("removing file "+name);
  	}   
  	
  }
  
   private void saveAll() throws IOException {
  	
  	File dir = new File(PATH);	  	
  	if (!dir.exists()) {
  	  dir.mkdir(); 
  	}
  	
  	Collection c = mem.keySet();
  	Iterator it = c.iterator();
  	while(it.hasNext()) {  		
  	  Id key = (Id)it.next();
  	  Values values = mem.extract(key);
  	  Pair pair = new Pair(key,values);
  	  String name = ((rice.pastry.NodeId)key).toStringFull();  	  
  	  File f = new File(PATH+"/"+name);
	  f.createNewFile();
	  FileOutputStream out = new FileOutputStream(f);
  	  ObjectOutputStream oos = new ObjectOutputStream(out); 	     
  	  oos.writeObject(pair);
  	  oos.close();  	  
  	}
  }
  
   private void loadAll() {
  	
    File f = new File(PATH);
	  	
  	if (f.isDirectory()) {   	
  	  try {
  	  	File[] files = f.listFiles();
  	   	for (int i=0;i<files.length;i++) {
  	   	  //System.out.println("llegint "+files[i].getName());
  	   	   	   	  
  	   	  FileInputStream in = new FileInputStream(files[i]); 
  	      ObjectInputStream ois = new ObjectInputStream(in);
  	      Pair pair=(Pair) ois.readObject();
  	      Id key = pair.getKey();
  	      Values values= pair.getValues();
  	      ois.close(); 
  	      //System.out.println("Carregant "+key+","+files[i].getName()+","+values);
  	      mem.overwrite(key,values);
  	      
  	    }     
  	  }catch (IOException ex) {
  	  	ex.printStackTrace();
  	  }catch (ClassNotFoundException ex) {
  	  	ex.printStackTrace();
  	  }
  	}  	
  	//else no files...
  	System.out.println("Size "+memSize());
  }
  
  private long memSize() {
  	File f = new File(PATH);
	long size=0;  	
  	if (f.isDirectory()) {   	
  	  	File[] files = f.listFiles();
  	   	for (int i=0;i<files.length;i++) {
          size+=files[i].length();
        }
    }
    return size;
  }
  
  public boolean isFull() {
  	return (memSize()<max);  	
  }

  
 

  

}


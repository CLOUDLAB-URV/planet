/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.storage;

import java.util.*;
import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 * @author Ruben Mondejar
 */
public class MemStorage implements StorageManager {

  private Bucket mem = new Bucket();  
    
  public void init(Properties prop) {}
    
  public void add(Bucket newBucket) throws StorageException{
  	mem.add(newBucket);	  
  }
	
  public void insert(Id key, Object value,String field) throws StorageException {
    mem.insert(key,value,field);
  }
	
  public void overwrite(Id key, Object values) throws StorageException {
    mem.overwrite(key,values);    
  }

  public Object retreive(Id key,String field) { 	
    return mem.load(key,field);	
  }  
  
  public Values extract(Id key) { 	
    return mem.extract(key);	
  }  
  
  public Bucket getBucket() {
  	return mem;
  }   
  
  public Object remove(Id key) {                   
    return mem.remove(key);	    	  
  } 
  
  public Object delete(Id key, String field) {
  	return mem.delete(key,field);
  }
  
  public boolean exists(Id key) {
  	 return mem.containsKey(key);	    	  
  }  
 
  public boolean isFull() {
  	return false;
  }
  

}


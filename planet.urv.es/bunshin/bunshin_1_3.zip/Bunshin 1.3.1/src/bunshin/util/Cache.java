/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.util;

import rice.p2p.commonapi.*;
import java.util.*;
 
/**
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Cache {

  private int TTL = 0;
  private int MAX_ELEM = 0;
    
  private Hashtable elems = new Hashtable();
  private ArrayList queue = new ArrayList();
  private ArrayList ttls = new ArrayList();
  
  public Cache(int TTL, int MAX_ELEM) {
  	this.TTL = TTL;
  	this.MAX_ELEM = MAX_ELEM;
  	
  }
  
  public void put(Id key, Values values) {
    
    elems.put(key,values); 
    queue.add(key);  
    ttls.add(new Integer(0));
    
    if (queue.size()>MAX_ELEM) {
      Id id = (Id) queue.remove(0);
      ttls.remove(0);
      elems.remove(id);
    }	
  } 
  
  public Values get(Id key) {
  	return (Values)elems.get(key);
  }
  
  public boolean containsKey(Id key) {
  	return elems.containsKey(key);
  }
  
  public void incTime() {

    Iterator it = ttls.iterator();
    int i = 0;
    while (it.hasNext()) {
      int ttl = ((Integer) it.next()).intValue() + 1;	
      if (ttl>TTL) {
  	    Id id = (Id) queue.remove(i);
        ttls.remove(i);
        elems.remove(id);  	  	
  	  }
  	  else {  	  	
  	  	i++;
  	  }
      
    }  	
  
  }
  
  
  	
}
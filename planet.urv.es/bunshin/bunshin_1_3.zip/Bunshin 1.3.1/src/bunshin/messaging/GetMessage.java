/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.messaging;

/**
 *
 * The get message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

import rice.p2p.commonapi.*;

public class GetMessage implements Message {

  private String messageId;
  private Id key;
  private int phase;
  private Object value = null;  
  private NodeHandle nh = null;
  private NodeHandle previousNH = null;
	
  public GetMessage(Id key, NodeHandle nh) {  	
  	
  	this.phase = 1;	
    this.key = key;
    this.nh = nh; 
    this.previousNH = nh;
    
  }  
  
  public GetMessage(Id key, Object value) {  	
  	
  	this.phase = 2;  	
    this.key = key;
    this.value = value; 
    
  }  
  
  public void setPreviousNH(NodeHandle previous) {
  	previousNH = previous;  	
  }
  
  public int getPhase() {
  	return phase;
  }
  
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public NodeHandle getNH() {
  	return nh;  	
  }  
  
  public NodeHandle getPreviousNH() {
  	return previousNH;  	
  }
  
  public String toString() {
    return "GetMessage"+phase+" key : "+key+":"+value;
  }

}
/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.messaging;

import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 *
 * The put bucket message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PutBucketMessage implements Message {

  private String messageId;
  private Bucket bucket = null;
  private int phase;
  private NodeHandle nh = null;
	
  public PutBucketMessage(String messageId, NodeHandle nh, int phase) {  	
  	
  	this.phase = phase;
  	this.messageId = messageId;
  	
 
    this.nh = nh;  
  }  
  
  public PutBucketMessage(Bucket bucket) {  	
  	
  	this.phase = 3;  	
    this.bucket = bucket;
 
  }  
  
  public String getMessageId() {
  	return messageId;
  }
  
  public int getPhase() {
  	return phase;
  }
  
  public Bucket getBucket() {
  	return bucket;
  }
  
  public NodeHandle getNH() {
  	return nh;  	
  }
  
  public String toString() {
    return "PutBucketMessage "+bucket;
  }

}
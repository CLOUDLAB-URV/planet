/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin;

import bunshin.storage.*;
import java.util.Collection;
import rice.p2p.commonapi.*;
import java.net.*;

/**
 *
 * This interface is exported by all instances of Bunshin DHT. 
 * 
 * @author Ruben Mondejar
 */
public interface Bunshin {

  /**
   * Stores the (key,value) pair in the Bunshin DHT in a default field
   *
   * @param key Id of the value
   * @param value Object to store
   */
  public void put(Id key, Object value);
  
  /**
   * Stores the (key,value) pair in the Bunshin DHT in a specific field
   *
   * @param key Id of the value
   * @param value Object to store
   * @param field String key
   */  
  public void put(Id key, Object value, String field);


	/**
	 * Stores the (key,value) pair in the Bunshin DHT, when value is downloaded of the URL.
	 *
	 * @param key Id of the value
	 * @param value Object to store
	 * @param field String key
	 */
	public void putURL(Id key, URL url,String field);
  
  
  
  public void modify(Id key, Object value, String field, boolean add);
  
  public void modify(Id key, Collection values, String field, boolean add);
    
  

  /**
   * Removes the values with a specific key
   *
   * @param key Id of the value   
   */
  public void remove(Id key);
  
  public void remove(Id key, String field);

  /**
   * Returns the values with a specific key and sets the Client application 
   *
   * @param key Id of the value 
   * @param client listener that implements BunshinClient 
   */
  public void get(Id key, BunshinClient client);
  
  /**
   * Removes the Client application for this Bunshin DHT 
   *
   * @param key of the value
   * @param client listener that implements BunshinClient 
   * @return true if the value has been remove
  */
  public boolean removeClient(Id key, BunshinClient client);
  
  /**
   * Before leaving the network, the application must call to this method
   * 
   */
  public void leave();
  
  public void setRemoteListener(Id id, RemoteListener listener, String field);

  public void removeRemoteListener(Id id, String field);
  
  /**
   * Sets the number of replicas  
   *
   * @param the number of replicas 
   */
  public void setReplicationFactor(int replicas);
  
  /**
   * Sets the storage manager
   *
   * @param storage manager
   */  
   public void setStorageManager(StorageManager storage);
 	
  /**
   * Returns the number of replicas used 
   *
   * @return the number of replicas 
   */
  public int getReplicationFactor();
  
  public void setEndPoint (Endpoint ep);
  
  public StorageManager getStorageManager();
  
  public void activateCache();
  
  public void activateDebug();


  }


/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin;

import bunshin.util.*;
import bunshin.storage.*;
import bunshin.messaging.*;

import rice.p2p.commonapi.*;

import java.util.*;
import java.net.*;
import java.io.*;



/**
 *
 *  The provided implementation of Bunshin DHT. 
 * 
 * @author <a href="mailto: ruben.mondejar@estudiants.urv.es">Ruben Mondejar </a>
 *	 
 */

public class BunshinImpl implements Bunshin, Application {


  private boolean first = true;
   
  //ini params  
  private int time = 3000;
  
  private final int MAX_REQUEST_TIME = 30;
  
  private final int TTL_CACHE = 50;
  private final int MAX_CACHE = 16; 
  
  private int replicationFactor = 1;

	
  // My data
  private StorageManager storage;
  
  // Information about the nodes that replicate my data  
  private Hashtable replicaNHs = new Hashtable();
  
  // replicas from other nodes  
  private Hashtable replicaBuckets = new Hashtable(); //Node Id --> Bucket of pairs (key,value)
  private Hashtable replicaIdNH = new Hashtable();    //Node Id --> NodeHandle
  private Hashtable replicaKeyOwner = new Hashtable();  //Key --> Node Id
  
  //Cache support
  //private Hashtable cache = new Hashtable(); //ini_version, later --> Cache struct (fifo & temporal)
  private Cache cache = new Cache(TTL_CACHE,MAX_CACHE); //(fifo & temporal)
  
  private Hashtable control = new Hashtable();  
  
  
  private Hashtable listeners = new Hashtable();
  
  private Endpoint endPoint = null;  
  
  private PeriodicTask refreshTask = new PeriodicTask();

  private Timer timer = new Timer();
  

  
  private boolean debug = false;
  
  private boolean caching = false;
  
  /**
   * Identification of the application.
   */
  public static String applicationId= "Bunshin";
  /**
   * Identification of the application instance.
   */
  private String appId = applicationId;
  
  /**
   * Bunshin Clients
  */
  Hashtable clients = new Hashtable();
  
    
  /**
   * Constructor
   */
  public BunshinImpl() {  	
  }
  
  public BunshinImpl(String name) {
  	this.appId = name;
  }
  
  public void setId(String name) {
  	this.appId = name;
  }
  
  public boolean removeClient(Id key, BunshinClient client) {
    
    Vector id_clients;
  	
  	if (!clients.containsKey(key)) return false;
  	else id_clients =  id_clients = (Vector) clients.get(key);
  	
  	id_clients.remove(client);
  	clients.put(key,id_clients);
  	
  	return true;
  }
  
  /**
   * Gets the identification of the Application
   * @see planet.commonapi.Application#getId()
   */
  public String getId() {
   return appId; 
  }  
  
  public void setEndPoint (Endpoint ep) {
    endPoint = ep;	
    if (first) timer.schedule(refreshTask,0,time);
    else first=false;
    
    log("I'm node "+endPoint.getLocalNodeHandle().getId());
  }
  
  public void setStorageManager(StorageManager storage) {
  	this.storage = storage;
  }
  
  public void activateDebug() {  	
  	this.debug=true;
  	System.out.println("DEBUG ON");
  }

  public void activateCache() {
  	this.caching = true;
  	System.out.println("CACHE ON");
  }  
  
  public StorageManager getStorageManager() {
  	return storage;
  }
  
  
  private void log(String text) {
  	if (debug) System.out.println(text);
  }
  
  /**
   * Returns whether or not is the owner for the given key
   *
   * @param key The key in question
   * @return Whether or not we are currently the root
   */
   public boolean isOwner(Id key) {
    	NodeHandleSet set = endPoint.replicaSet(key, 1);

        if (set==null)
          return false;
        else {
          Id x = endPoint.getId();
         
          NodeHandle nh = set.getHandle(0);
          if (nh==null) {          	
          	return false;
          }	
          return nh.getId().equals(x);	
        }
          
    
  }
   
  /** 
   *  Sends to the first node of the replicaSet a special message to check if that have the replicated keys.
   * Remaining nodes are going to receive a normal message. 
   * 
   */
  public void leave () {
  	
  	timer.cancel(); 
  	  	
  	NodeHandle myNH = endPoint.getLocalNodeHandle();  	
  	Collection c = Utilities.convert(endPoint.replicaSet(myNH.getId(),2));
  	Iterator it = c.iterator();
  	it.next(); //myNH
  	if (it.hasNext()) {
  	  NodeHandle nextRoot = (NodeHandle) it.next(); 
  	
  	  //Send all info to new root
  	  LeaveMessage message = new LeaveMessage(myNH,storage.getBucket());  	
	  endPoint.route(null,message,nextRoot);  	  
	  log("Leave message "+message+" to "+nextRoot);
  	
  	
  	  //extract all replica nodes 
      HashSet all_set = new HashSet();
 	  it = replicaNHs.values().iterator();   	  
 	  while(it.hasNext()) {
 	    Collection key_set = (Collection)it.next();
 	    all_set.addAll(key_set);	
 	  }   	  
      all_set.remove(nextRoot);
       
      it = all_set.iterator();
      while (it.hasNext()) {  	   	
        message = new LeaveMessage(myNH);	  	
   	    NodeHandle to = (NodeHandle) it.next();  	  
   	    endPoint.route(null,message,to);
      }  
   	}
  }
   	 
   
  /**
   * Sets the number of replicas  
   *
   * @param the number of replicas 
   */
  public void setReplicationFactor(int replicas) {
  	replicationFactor=replicas;
  }
  
  /**
   * Returns the number of replicas used 
   *
   * @return the number of replicas 
   */
  public int getReplicationFactor() {
  	return replicationFactor;
  }
  
  /**
   * Checks that is the owner all keys are already  
   */  
  private void checkMyKeys(){
  	Bucket store = storage.getBucket();
  	Vector v = new Vector(store.keySet());
  	for(int i=0; i<v.size();i++) {
  	  Id key = (Id) v.get(i);
  	  if (!isOwner(key)) {
  	  	try {  	  	
  	  	  undoReplica(key);
  	  	  Object obj = storage.remove(key);
  	  	  //put the all values 
  	  	  put(key,obj);
  	  	} catch(StorageException ex) {
  	  		//non-critical exception
  	  	}
  	  }
  	}    	
  }
  
  private Collection remFailNH(Collection c) {
  	
  	Collection c2 = new Vector();
  	Iterator it2 = c.iterator();
	while (it2.hasNext()) {
	  NodeHandle nh = (NodeHandle) it2.next();
	  
	  if (nh.isAlive()) {
	  	c2.add(nh);
	  }	
	}	
	return c2;
  }  
  
  private void addReplica(Id key, Collection c) {  	
    
    NodeHandle localNH = endPoint.getLocalNodeHandle();
    Values values = storage.extract(key);
  	Collection v = Utilities.convert(endPoint.replicaSet(key,replicationFactor+1));  
  	v.removeAll(c);
  	Iterator it = v.iterator();
  	if (it.hasNext()) {
  	   NodeHandle nh = (NodeHandle) it.next();
  	   //if (nh!=null && !localNH.getId().equals(nh.getId())) {
  	   	if (nh!=null) {
  	   	 c.add(nh);  	   	 
  	   	 //new replica try sended
  	   	 endPoint.route(null,new ReplicaMessage(key,values,localNH),nh);  	   	 
  	   }
    }
  }
  
  /**
   * Checks the replica nodes that stores my keys/values  
   */
  private void checkMyReplicas() {  	  	
  	Bucket store = storage.getBucket();
  	Vector v = new Vector(store.keySet());
  	for(int i=0; i<v.size();i++) {
  	  Id key = (Id) v.get(i);
  	  Collection nhs = (Collection) replicaNHs.get(key);  		  		
  	  if (nhs!=null) {
      //Check to find some failed node
        Collection nhs2 = remFailNH(nhs);
      //Chech to find a not suficient number of copies of some key		  
        //System.out.println(nhs2.size()+" < "+replicationFactor+"?");
        int tries = replicationFactor - nhs2.size();
	  	for (int j=0;j<tries;j++) {
	      addReplica(key,nhs2);  		  
	  	}  	
  	  }
  	}
  }	
  
  private void checkReplicas() {
    Vector v = new Vector(replicaIdNH.values());
  	for(int i=0; i<v.size();i++) {
  	  NodeHandle nh = (NodeHandle) v.get(i);  	  
	  if (!nh.isAlive()) {
	  	//System.out.println("id "+endPoint.getId()+" checkReplica of "+nh+" is alive ?"+nh.isAlive());
	    replicaIdNH.remove(nh.getId());
	    
	    Bucket replicas = (Bucket) replicaBuckets.remove(nh.getId());
	    
	    Vector c = new Vector(replicas.keySet());
	  	while(!c.isEmpty()) {
	  	  Id key = (Id) c.firstElement();	  	  
	  	  Object obj = replicas.remove(key);	  	  
	  	  c.remove(key);
	  	  replicaKeyOwner.remove(key);
	  	  put(key,obj);	  	  
	  	} 
	  }
	}    	
  }
  
  /**
   * This method is invoked to inform the application that the given node has either joined or left
   * the neighbor set of the local node, as the set would be returned by the neighborSet call.
   *
   * @param handle The handle that has joined/left
   * @param joined Whether the node has joined or left
   */
  public void update(NodeHandle handle, boolean joined) {
  	   
  	  
      if (joined){      	
      	//only checkMyKeys();
      	refresh(1);
      	//System.out.println ("Update node ["+endPoint.getId()+"] : "+handle+" joined ");
      }
      else {
      	//call to  checkMyReplicas() &  	checkReplicas()
      	refresh(2);
      	//System.out.println ("Update node ["+endPoint.getId()+"] : "+handle+" left ");
      }   
      

  }
  
  /**
   * This method is invoked on applications when the underlying node
   * is about to forward the given message with the provided target to
   * the specified next hop.  Applications can change the contents of
   * the message, specify a different nextHop (through re-routing), or
   * completely terminate the message.
   *
   * @param message The message being sent, containing an internal message
   * along with a destination key and nodeHandle next hop.
   *
   * @return Whether or not to forward the message further
   */
 // public boolean forward(Message message) {
    //System.out.println ("Forward app ["+appId+"] node ["+endPoint.getId()+"]");
 //   return true;
//  }
  
  public boolean forward(RouteMessage message) {
    //System.out.println ("Forward app ["+appId+"] node ["+endPoint.getId()+"]");
    //System.out.println ("RouteMessage, prev : ["+message.getPrevNodeHandle()+"], next : ["+message.getNextHopHandle()+"]");
         
    boolean forward = true;
    
    Message msg = message.getMessage();
    
    if (caching && msg instanceof GetMessage) {
      GetMessage gmsg = (GetMessage) msg;	
      if (gmsg.getPhase()==1) {      
              
        Id key = gmsg.getKey();
        Object value = null;
        boolean haveValue = false;  
        
        
        if (isOwner(key)) {          
          value = storage.extract(key);
          if (value!=null) haveValue = true;
        }	
        
        //I'm not owner but I have replica
        else if (replicaKeyOwner.containsKey(key)) {  	
      	 
      	  value = getReplicaValue(key);      	  
          endPoint.route (null, new GetMessage(key,value), gmsg.getNH());       	
      	
      	  forward = false;
      	  haveValue = true;
      	  log ("Replica response "+key);   
        }
        //I'm not owner and don't have any replica, but I have value-cache
        else if (cache.containsKey(key)) {
          value = cache.get(key);      	  
          endPoint.route (null, new GetMessage(key,value), gmsg.getNH());       	
      	
      	  forward = false;
      	  haveValue = true;
      	  //CACHE_LOG
          log ("Cache response "+key);  
        }
        
        if (haveValue) {
                	
          NodeHandle previous = gmsg.getPreviousNH();          	
          Id obj_key = gmsg.getKey();
          
          //CONTROL VERSION
          PriorityList list = (PriorityList) control.get(obj_key);
          if (list==null) 
          	list = new PriorityList();
          
          list.update(previous);
          control.put(obj_key,list);
          log ("Request updated from "+previous.getId()+" key "+obj_key);  
          
        } 
        gmsg.setPreviousNH(endPoint.getLocalNodeHandle());           
      }   	
    } 
      
    return forward;
  }

  /**
   * This method is called on the application at the destination node
   * for the given id.
   *
   * @param id The destination id of the message
   * @param message The message being sent
   */
  public void deliver (Id id, Message message) {
  	
  	Id key;
  	Object value;
  	
  	//System.out.println ("Deliver app ["+appId+"] node ["+endPoint.getId()+"] \nmessage : "+message);
  	  	
	  if (message instanceof PutMessage) 
	  {

		  PutMessage mesg = (PutMessage) message; 
		  key = mesg.getKey();
		  value = mesg.getValue(); 
		  String field = mesg.getField();
        
		  try 
		  {		
			  if (field!=null) 
			  {
				  storage.insert(key,value,field);
				  remoteListeners(key,value,field,true);
			  }  
			  else 
			  {
				  storage.overwrite(key,value);
				  //remoteListeners(key,value,null,true);
			  }      
			  Values values = storage.extract(key);
			  //send replicas	    	    
			  replicate(key,values);
			  log("I'm the owner of the "+value);       	
		  }
		  catch(StorageException ex) 
		  {
			  ex.printStackTrace();
			  //activate threshold?
			  //send reject ack ?
		  }
	  }        
	  else if (message instanceof PutURLMessage) 
	  {
		  PutURLMessage mesg = (PutURLMessage) message; 
		  key = mesg.getKey();
		  URL url = mesg.getURL(); 
		  String field = mesg.getField();
          
          Values values = storage.extract(key);
          replicateURL(key,values,url,field);	
	  	  
		  value = download(url);
		  if (value!=null)  {
			  try 	{
		
				  storage.insert(key,value,field);				  
				  log("I'm the owner of the url value : "+url);
			  }
			  catch(StorageException ex)  {
				  ex.printStackTrace();
				  //activate threshold?
				  //send reject ack ?
			  }
		  }
	  } 
	  else if (message instanceof ModifyMessage) 
	  {
      
		  ModifyMessage mesg = (ModifyMessage) message;
		  key = mesg.getKey();
		  value = (Collection) mesg.getValue(); //MUST BE COLLECTION!
		  String field = mesg.getField();  
	  
		  try 
		  {	  
			  Collection c = null;
			  undoReplica(key); 
			  if (mesg.isAdd()) 
			  {
				  c = (Collection) storage.retreive(key,field);	
				  if (c==null) c = new Vector();
				  c.addAll((Collection)value);
				  storage.insert(key,c,field);
				  remoteListeners(key,value,field,true);	  	  
			  }
			  else 
			  {
				  c = (Collection) storage.retreive(key,field);	
				  if (c==null) c = new Vector();
				  else c.removeAll((Collection)value);
				  storage.insert(key,c,field);
				  remoteListeners(key,value,field,false);	
			  }
			  //update replicas
			  Values values = storage.extract(key);
			  replicate(key,values);     
		  }
		  catch(StorageException ex) 
		  {
			  ex.printStackTrace();
			  //activate threshold?
			  //send local reject ack
		  } 
	  }    
	  else if (message instanceof ListenerMessage) 
	  {
		  try 
		  {
			  ListenerMessage mesg = (ListenerMessage) message;
			  key = mesg.getKey();       
			  String field = mesg.getField();
      
			  undoReplica(key); 
			  Listeners ls = (Listeners) storage.retreive(key,"Listeners");
			  if (mesg.isAdd()) 
			  {      
				  if (ls==null) 
				  {
					  ls = new Listeners();
				  }  
				  ls.add(mesg.getNH(),mesg.getField());
			  }
			  else 
			  {
				  if (ls!=null) 
				  {
					  ls.remove(mesg.getNH(),mesg.getField());
				  }       
				  else ls = new Listeners();
			  }
			  storage.insert(key,ls,"Listeners");
			  Values values = storage.extract(key);
			  replicate(key,values); 
		  }
		  catch(StorageException ex) 
		  {
			  ex.printStackTrace();          
		  } 
	  }
	  else if (message instanceof NotifyMessage) 
	  {
    
		  NotifyMessage mesg = (NotifyMessage) message;
		  key = mesg.getKey();       
		  value = mesg.getValue();
            
		  RemoteListener rl = (RemoteListener) listeners.get(key);
		  if (rl!=null) rl.eventArrived(value,mesg.isAdd());      
      	
	  }
    
	  else if (message instanceof PutBucketMessage) 
	  {
		  PutBucketMessage mesg = (PutBucketMessage) message;   
		  int phase = mesg.getPhase();
		  switch(phase) 
		  {
			  case 1 :
				  //check if the insertion is possible!	
				  if (!storage.isFull()) endPoint.route(null, new PutBucketMessage(mesg.getMessageId(),endPoint.getLocalNodeHandle(),2), mesg.getNH());	
				  //else send reject ack
      	  
				  break;
			  case 2 :
				  Bucket bucket = (Bucket) replicaBuckets.remove(mesg.getNH());
				  if (bucket!=null) 
				  {
					  Iterator it = bucket.keySet().iterator();          
					  while(it.hasNext()) 
					  {
						  Id k = (Id) it.next();
						  Id owner = (Id) replicaKeyOwner.get(k);
						  if (owner.equals(mesg.getNH().getId())) replicaKeyOwner.remove(k);
					  }      
				  }
          
				  endPoint.route(null, new PutBucketMessage(bucket),mesg.getNH());	
				  break;
			  case 3 : 
				  bucket = mesg.getBucket();
				  try 
				  {      	  
					  storage.add(bucket);      	     	  
				  }
				  catch(StorageException ex) 
				  {
					  ex.printStackTrace();
					  //activate threshold?
					  //send reject ack ?
				  }  
				  break;      	
		  }              
	  }
      
	  else if (message instanceof RemoveMessage) 
	  {
		  RemoveMessage mesg = (RemoveMessage) message;
		  key = mesg.getKey();
		  String field = mesg.getField();
		  try 
		  {          
       
			  //remove replicas
			  undoReplica(key);        
			  log("Removing "+key);        
			  if (field!=null) 
			  {
				  value = storage.retreive(key,field);
				  storage.delete(key,field);
				  remoteListeners(key,value,field,false);
			  }   
			  else 
			  {
				  value = storage.extract(key);
				  storage.remove(mesg.getKey());
				  //remoteListeners(key,value,null,false);
			  }  
        
        
		  }
		  catch(StorageException ex) 
		  {
			  ex.printStackTrace();
			  //send reject ack ?
		  }    	
	  }
	  else if (message instanceof RemoveReplicaMessage) 
	  {
      
		  RemoveReplicaMessage mesg = (RemoveReplicaMessage) message; 
      
		  Id owner = (Id) replicaKeyOwner.remove(mesg.getKey());
      
		  if (owner!=null) 
		  {
			  Bucket replicas = (Bucket) replicaBuckets.get(owner);
			  log("Replicas "+replicas);
			  if (replicas!=null) 
			  {
				  replicas.remove(mesg.getKey());      
				  if (replicas.size()>0) replicaBuckets.put(mesg.getNH().getId(),replicas);
				  else replicaBuckets.remove(mesg.getNH().getId());
				  log("Replicas Final "+replicaBuckets);
			  }
		  }
      
	  }    
    
	  else if (message instanceof GetMessage) 
	  {	
		  GetMessage mesg = (GetMessage) message;
		  int phase = mesg.getPhase();      
		  switch(phase) 
		  {
			  case 1 :
				  key = mesg.getKey();
				  value = storage.extract(key);
      	  
				  //if owner is crashed, replica data contains value for this key?      	  
				  if (value==null) value = getReplicaValue(key);
      	  
				  endPoint.route (null, new GetMessage(key,value), mesg.getNH()); 
          
				  break;
			  case 2 :
				  key = mesg.getKey();
				  value = mesg.getValue();
   		  
				  if (clients!=null) 
				  {

					  //Client is only for one time
					  Vector id_clients = (Vector) clients.remove(key);
      	  	
					  for(int i=0; i<id_clients.size(); i++) 
					  {
						  BunshinClient client = (BunshinClient) id_clients.get(i);      	  	  
						  client.get(value);	
					  }  
				  }
      	  
				  break;
		  }
          
	  }
	  else if (message instanceof ReplicaMessage) {
		  ReplicaMessage mesg = (ReplicaMessage) message;
		  key = mesg.getKey();
		  Values values = mesg.getValues();      
		  if (mesg.isURLReplica()) {
			  value = download(mesg.getURL());
			  values.put(mesg.getField(),value);
		  } 
      
		  if (!storage.exists(key)) {
			  putReplica(mesg.getNH(),key,values);  
			  endPoint.route (null, new ReplicaAckMessage(key,endPoint.getLocalNodeHandle()), mesg.getNH());
			  log("Saving replica "+values+" of "+mesg.getNH().getId());
		  }
	  }  
	  else if (message instanceof ReplicaAckMessage) 
	  {
		  ReplicaAckMessage mesg = (ReplicaAckMessage) message;
		  key = mesg.getKey();
		  Collection c = (Collection) replicaNHs.get(key);
		  if (c==null) 
		  {
			  c = new Vector();
		  }
		  c.add(mesg.getNH());
		  replicaNHs.put(key,c);    
		  log("Replica ack "+key+" of "+mesg.getNH().getId());
	  }
    
	  else if (message instanceof LeaveMessage) 
	  {      	
		  LeaveMessage mesg = (LeaveMessage) message;
		  NodeHandle source = mesg.getNH();
      
		  if (mesg.isContent()) 
		  {      	        
			  Bucket newKeys = (Bucket) mesg.getContent();
      	
			  if (newKeys.size()>0) 
			  {      	        
				  try 
				  {      	
					  storage.add(newKeys);   
					  log("New keys received : "+newKeys);
				  }
				  catch(StorageException ex) 
				  {
					  ex.printStackTrace();
					  //activate threshold?
					  //send reject ack ?
				  }   
			  }
		  }
      
		  //System.out.println(replicaBuckets);
		  //System.out.println("Deleting "+mesg.getNH().getId()+" entries");
      	
		  //remove replicas of a given owner       	    	
		  replicaIdNH.remove(mesg.getNH().getId());	      	
		  Bucket bucket = (Bucket) replicaBuckets.remove(mesg.getNH().getId());
		  if (bucket!=null) 
		  {      
			  Iterator it = bucket.keySet().iterator();
			  while(it.hasNext()) 
			  {
				  Id k = (Id) it.next();
				  Id owner = (Id) replicaKeyOwner.get(k);
				  if (owner.equals(mesg.getNH().getId())) replicaKeyOwner.remove(k);
			  }
		  }	
		  //System.out.println(replicaBuckets);      
      
	  }
	  else if (message instanceof CacheMessage) 
	  {
		  if (caching) 
		  {
			  CacheMessage mesg = (CacheMessage) message;	
			  key = mesg.getKey();
			  Values values = mesg.getValues();      
      
			  if (values!=null) cache.put(key,values);	  
      
			  //CACHE_LOG
			  log("Cacheando key "+key);  	
		  }	  
	  }
	  else 
	  {
		  log ("Deliver Error : Wrong message : "+message);	
	  }
  }
  
  
  /**
   *  Sends a PutMessage to the root's key with a new value for the given key
   */
  public void put(Id key, Object value) {
  	  	put(key,value,null);  	 
  }  
  
  /**
   *  Sends a RemoveMessage to the root's key to indicate the key that it must eliminate.  
   */
  public void remove(Id key) {
  	remove(key,null);
  }  
  /**
   *  Sends a GetMessage following a 2 phases protocol. When the request is resolved, the method
   * get(key) of the BunshinClient returns the result.
   */
  public void get(Id key, BunshinClient client) {
  	
    if (isOwner(key)) {    
      Object value = storage.extract(key);
      client.get(value);
    }	       
    //I'm not owner but I have replica
    else if (replicaKeyOwner.containsKey(key)) {  	
      Object value = getReplicaValue(key);      	  
      client.get(value);  
    }
    //I'm not owner and don't have any replica, but I have value-cache
    else if (cache.containsKey(key)) {
   	  Object value = cache.get(key);      	  
      client.get(value); 
    }
    
  	else {
  	
      Vector id_clients;
  	
  	  if (!clients.containsKey(key)) id_clients = new Vector();
  	  else id_clients =  id_clients = (Vector) clients.get(key);
  	
  	  id_clients.add(client);
  	  clients.put(key,id_clients);
  	
  	  endPoint.route(key, new GetMessage(key,endPoint.getLocalNodeHandle()), null); 	
  	}  
  }
  
	 
	public void put(Id key, Object value, String field) 	{
	  	if (isOwner(key)) {
			try {  	  
				if (field!=null) {
				  storage.insert(key,value,field);
  			      remoteListeners(key,value,field,true);
			    }
	    	  	else storage.overwrite(key,value);    	    
	            
				//send replicas	    	    
	    	  	Values values = storage.extract(key);
	            replicate(key,values);
	            log("I'm the owner of the "+value);
	        }catch(StorageException ex) {
	        	ex.printStackTrace();
	          //activate threshold?
	        	//send local reject ack
	        }  
	   }
	   else {
	     endPoint.route(key, new PutMessage(key,value,field), null);  	
	   }
	} 


	public void putURL(Id key, URL url, String field) 	{
		//URL url = new URL(urlName);

		if (isOwner(key)) 	{
			try 	{  	  
				Values values = storage.extract(key);
				replicateURL(key,values,url,field);	

				Object value = download(url);
				if (value!=null) 
				{
					storage.insert(key,value,field);
                    remoteListeners(key,url,field,true);
					log("I'm the owner of the url value : "+url);
				}
			}
			catch(StorageException ex) 	{
				ex.printStackTrace();
				//activate threshold?
				//send local reject ack
			}  
		}
		else {
			endPoint.route(key, new PutURLMessage(key,url,field), null);  	
		}
	} 

	private Object download(URL url) {
		byte[] bite = null;
		try {
			//URL url = new URL("urltoyourfile");
			//InputStream is = url.openStream();
			//bite = new byte[is.available()];			
			//is.read(bite,0,is.available());			    
   			
			/*
			Object obj = url.getContent();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(bos);
			os.writeObject(obj);
			os.close();
		    bite = bos.toByteArray();
			*/
			URLConnection uc = url.openConnection();
			String contentType = uc.getContentType();
			int contentLength = uc.getContentLength();
			//if (contentType.startsWith("text/") || contentLength == -1 ) 
			//{
			//	throw new IOException("This is not a binary file.");
			//}

			InputStream raw = uc.getInputStream();
			InputStream in  = new BufferedInputStream(raw);

			bite = new byte[contentLength];
			int bytesRead = 0;
			int offset = 0;
			while (offset < contentLength) {
				bytesRead = in.read(bite, offset, bite.length-offset);
				if (bytesRead == -1) break;
				offset += bytesRead;
			}
			in.close();

			if (offset != contentLength) {
				throw new IOException("Only read " + offset + " bytes; Expected " + contentLength + " bytes");
			}

			/*
			String filename = url.getFile();
			filename = filename.substring(filename.lastIndexOf('/') + 1);
			FileOutputStream fout = new FileOutputStream(filename);
			fout.write(bites);
			fout.flush();
			fout.close();
            */

		}
		catch(Exception ex)	{
			ex.printStackTrace();
		}
		return bite; 
	}
	
	public void modify(Id key, Object value, String field, boolean add) {

	  	if (isOwner(key)) {
	    	  try {	  
	    	  	Collection c = null;
	    	  	undoReplica(key); 
	    	  	if (add) {
	    	  	  c = (Collection) storage.retreive(key,field);	
	    	  	  if (c==null) c = new Vector();
	    	  	  c.add(value);
	    	  	  if (field!=null) {
                     storage.insert(key,c,field);
                     remoteListeners(key,value,field,true);
                  }
	    	  	  else storage.overwrite(key,c);
	    	  	}
	    	  	else {
	    	  	  c = (Collection) storage.retreive(key,field);	
	    	  	  if (c==null) c = new Vector();
	    	  	  else c.remove(value);
	    	  	  if (field!=null) {
                     storage.insert(key,c,field);
                     remoteListeners(key,value,field,false);
                  }
	    	  	  else storage.overwrite(key,c);	
	    	  	}
	    	    //update replicas
	    	  	Values values = storage.extract(key);
	            replicate(key,values);     
	          }catch(StorageException ex) {
	        	ex.printStackTrace();
	          //activate threshold?
	        	//send local reject ack
	          }  
	    	}
	    	else {
	    	  Vector values = new Vector();	
	    	  values.add(value);
	    	  endPoint.route(key, new ModifyMessage(key,values,field,add), null); 	    	    	
	    	}
	}

	
	public void modify(Id key, Collection list, String field, boolean add) {

	  	if (isOwner(key)) {
	    	  try {	  
	    	  	Collection c = null;
	    	  	undoReplica(key); 
	    	  	if (add) {
	    	  	  c = (Collection) storage.retreive(key,field);
	    	  	  if (c==null) c = new Vector();	    	  	  
	    	  	  c.addAll(list);
	    	  	  if (field!=null) {
                    storage.insert(key,c,field);
                    remoteListeners(key,list,field,true);
                  }
	    	  	  else storage.overwrite(key,c);
	    	  	}
	    	  	else {
	    	  	  c = (Collection) storage.retreive(key,field);	
	    	  	  if (c==null) c = new Vector();
	    	  	  else c.removeAll(list);
	    	  	  if (field!=null) {
                     storage.insert(key,c,field);
                     remoteListeners(key,list,field,false);
                  }
	    	  	  else storage.overwrite(key,c);	
	    	  	}
	    	    //update replicas
	    	  	Values values = storage.extract(key);
	            replicate(key,values);     
	          }catch(StorageException ex) {
	        	ex.printStackTrace();
	          //activate threshold?
	        	//send local reject ack
	          }  
	    	}
	    	else {
	    	  endPoint.route(key, new ModifyMessage(key,list,field,add), null); 	    	    	
	    	}
	}

	public void remove(Id key, String field) {
		if (isOwner(key)) {
			try 
			{  	                  
				undoReplica(key);        
				log("Removing "+key);
				if (field!=null) {
				  Object value = storage.retreive(key,field);
				  storage.delete(key,field);
				  remoteListeners(key,value,field,false);
			    } 
				else storage.remove(key);   
		      }catch(StorageException ex) {
		      	ex.printStackTrace();
		        //activate threshold?
		      	//send local reject ack
		      }  
		  	}
		  else endPoint.route(key, new RemoveMessage(key,field), null);		
	}		
  
	public void setRemoteListener(Id id, RemoteListener listener, String field) {
       listeners.put(id,listener);
		if (isOwner(id)) 
		{
			try 
			{  	                  
				undoReplica(id); 
				Listeners ls = (Listeners) storage.retreive(id,"Listeners");
				if (ls==null) ls = new Listeners();				
				ls.add(endPoint.getLocalNodeHandle(),field);

				storage.insert(id,ls,"Listeners");
				Values values = storage.extract(id);
				replicate(id,values); 
			}
			catch(StorageException ex) 
			{
				ex.printStackTrace();
				//activate threshold?
			}  
		}
		else endPoint.route(id, new ListenerMessage(id,field,endPoint.getLocalNodeHandle(),true), null); 
	}
 	
    public void removeRemoteListener(Id id, String field) 	{
	   listeners.remove(id);
		if (isOwner(id)) 
		{
			try 
			{  	                  
				undoReplica(id); 
				Listeners ls = (Listeners) storage.retreive(id,"Listeners");
				if (ls!=null) ls.remove(endPoint.getLocalNodeHandle(),field);				
				else ls = new Listeners();

				storage.insert(id,ls,"Listeners");
				Values values = storage.extract(id);
				replicate(id,values); 			
			}
			catch(StorageException ex) 
			{
				ex.printStackTrace();
				//activate threshold?
			}  
		}
		else endPoint.route(id, new ListenerMessage(id,field,endPoint.getLocalNodeHandle(),false), null); 
	}

 
  
  /**
   * Inserts in the structure of replicas a new (key,value) from a specific node
   * 
   * @param own
   * @param key
   * @param value
   */
  private void putReplica(NodeHandle own, Id key, Values value) {
  	Bucket b;
  	if (replicaBuckets.containsKey(own.getId())) {
  	  b = (Bucket) replicaBuckets.get(own.getId());  	  
  	}
  	else {
  	  b = new Bucket();  	  
  	}
  	b.overwrite(key,value);
  	log("Put Replica "+key+" value "+value);
	replicaBuckets.put(own.getId(),b);
	replicaKeyOwner.put(key,own.getId());
	replicaIdNH.put(own.getId(),own); 	 	  	
  }
  
  /**
   * Sends a replica of the pair (key,value) to replicationFactor nodes from replicaSet
   *  
   * @param key
   * @param value
   */
  private void replicate(Id key, Values values) {
  	
  	//reset possible replicas
  	replicaNHs.remove(key);  
  	
  	NodeHandle nh = endPoint.getLocalNodeHandle();
  	Collection c = Utilities.convert(endPoint.replicaSet(key,replicationFactor+1));
  	if (c!=null) {
  	Iterator it = c.iterator();  	
  	while(it.hasNext()) {
  	  NodeHandle to = (NodeHandle) it.next();
	  if (!to.getId().equals(nh.getId())) {
	  	log("Sending replica to "+to.getId());
  	    endPoint.route(null,new ReplicaMessage(key,values,nh),to);
	  }
  	}
  	}
  }  

	private void replicateURL(Id key, Values values, URL url, String field) {
  	
		//reset possible replicas
		replicaNHs.remove(key);  
  	
		NodeHandle nh = endPoint.getLocalNodeHandle();
		Collection c = Utilities.convert(endPoint.replicaSet(key,replicationFactor+1));
		if (c!=null) 
		{
			Iterator it = c.iterator();  	
			while(it.hasNext()) 
			{
				NodeHandle to = (NodeHandle) it.next();
				if (!to.getId().equals(nh.getId())) 
				{
					log("Sending replica to "+to.getId());
					endPoint.route(null,new ReplicaMessage(key,values,nh,url,field),to);
				}
			}
		}
	}  
  
  /**
   * Sends remove replica of the all keys to replica nodes
   *  
   * @param key   
   */
  private void undoReplica(Id key) {
  	 	
  	Collection c = (Collection) replicaNHs.remove(key);
  	if (c!=null) {
  	  	
  	  Iterator it = c.iterator();  	
  	  while(it.hasNext()) {
  	    NodeHandle nh = (NodeHandle) it.next();
	  	log("Removing replica from "+nh.getId());
  	    endPoint.route(null,new RemoveReplicaMessage(nh,key),nh);

  	  }
  	}
  }  
  
  
  /**
   * Finds in the replicated buckets a specific value
   * 
   * @param key
   * @return Values values
   */
  private Values getReplicaValue(Id key) {
    Iterator it = replicaBuckets.values().iterator();
    boolean found = false;
    Values values = null;
    while(it.hasNext() && !found) {
      Bucket b = (Bucket) it.next();
      values = b.extract(key);
      found = (values!=null);
    }
    return values;
  }



  private void remoteListeners(Id key, Object value, String field, boolean add) {
    Listeners ls = (Listeners) storage.retreive(key,"Listeners");
    if (ls!=null && field!=null) {
      Collection c = ls.getSubscribers(field);
      if (c!=null) {
        Iterator it = c.iterator();
        while (it.hasNext()) {
    	  NodeHandle destiny = (NodeHandle) it.next();
    	  endPoint.route(null, new NotifyMessage(key,value,field,true), destiny);
        }  
      }
    }
  }
  
  private synchronized void refresh(int mode) 
  {
    
  	if ( mode==0) {  
      checkMyKeys();
      checkMyReplicas();
      checkReplicas();
  	}  	
  	else if (mode==1) {  
  	  checkMyKeys();	
  	}
  	else {
  	  checkMyReplicas();
  	  checkReplicas();  		
  	}
  	
  }
  
  class PeriodicTask extends TimerTask {
			
		public void run() {
			//keys and replicas
			refresh(0);
			
			//caches
			if (caching) {			  
		  	  cache.incTime();		
			
			  //caching?			
	  	      Iterator it = control.keySet().iterator();
  	          while (it.hasNext()) {
  	            Id key = (Id) it.next();	
  	            Values values = null;
  	          
  	            if (isOwner(key)) {          
                  values = storage.extract(key);         
                }	       
                else if (replicaKeyOwner.containsKey(key)) {  	      	 
      	          values = getReplicaValue(key);      	            
                }        
                else if (cache.containsKey(key)) {
                  values = cache.get(key);      	  
                }
         
  	            PriorityList pl = (PriorityList) control.get(key);
  	            log("cache key "+key+" max request : "+pl.getMax());
  	            if (pl.getMax()>MAX_REQUEST_TIME) {
  	          	  NodeHandle nh = (NodeHandle) pl.peak();
  	          	  log("send CacheMessage (key : "+key+", values : "+values);
  	          	  endPoint.route (null, new CacheMessage(key,values), nh);	
  	            }
  	            pl.clear();  	          
  	          }   	        
  	       }  
	    }
  }	
  
	
}

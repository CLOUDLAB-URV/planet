package bunshin;

/**
*		This interface represents a naming context, which consists of a set of name-to-object bindings
*   These constants will be used for connecting to different DHT services.
*/

public class Context {
	
	public static final String HOST				= "BUNSHIN_HOST";
	
	public static final String PORT 			= "BUNSHIN_PORT";	
	
	public static final String FACTORY 			= "BUNSHIN_FACTORY";
	
	public static final String PROTOCOL 		= "BUNSHIN_PROTOCOL";
	
	public static final String ID_APPLICATION 	= "BUNSHIN_ID_APPLICATION";		
	
	public static final String STORAGE_MANAGER 	= "BUNSHIN_STORAGE_MANAGER";
	
	public static final String REPLICA_FACTOR 	= "BUNSHIN_REPLICA_FACTOR";
	
	public static final String CACHE 			= "BUNSHIN_CACHE";
	
	public static final String DEBUG 			= "BUNSHIN_DEBUG";
	
	public static final String TRUE             = "TRUE";

	
}
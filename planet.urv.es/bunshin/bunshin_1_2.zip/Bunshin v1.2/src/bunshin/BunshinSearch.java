package bunshin;

import bunshin.*;
import bunshin.util.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import org.doomdark.uuid.*;


import java.io.*;
import java.util.*;
import java.net.*;
import java.nio.channels.*;

/**
 * @(#) BunshinSearchTest.java
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class BunshinSearch extends BunshinConnection {

 public BunshinSearch(String path) throws Exception {       
    super(path);    
  }
  
  public BunshinSearch(Properties prop) throws Exception { 
    super(prop);  
  }
  
  public BunshinSearch(String bootHost, int bootPort, PastryNodeFactory fac, int protocol) { 
    super(bootHost,bootPort,fac,protocol);
  }
  	
  private Set getKeywords(String tokens) {
  	
  	StringTokenizer st = new StringTokenizer(tokens);  	
  	Set keyworks = new TreeSet();
  	
  	while(st.hasMoreTokens()) {   	  
  	  String token = st.nextToken();  	  
  	  if (token.length()>2) {
  	  	keyworks.add(token);
  	  }	
  	}  	
  	return keyworks;
  }	  
  
  
  /**
   * Generate the key for one serializable value and inserts it.
   */
  public Id insert(String tokens, Serializable value) throws IOException {
  	
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
	ObjectOutputStream os = new ObjectOutputStream(bos);
	os.writeObject(value);
	os.close();		
	
	byte[] bytes = bos.toByteArray();	
	Id idValue = Utilities.generateHash(bytes);
	
    insert(tokens,idValue,value);	 	
    return idValue;
    
  }
  
  /**
   * �Inserts others keywords to improve search work, example :
   *  insert("java api", value1)      --> java.propierties = {IdValue1=(java,api)}
   * 								  --> api.propierties  = {IdValue1=(api,java)}
   *  insert("java languaje", value2) --> java.propierties = {IdValue1=(java,api); IdValue2=(java,languaje)}
   * 								  --> languajes.propierties = {IdValue2=(languajes, java)}  	  
   */     
  public void insert(String tokens, Id idValue, Serializable value) throws IOException {
  	
  	Set keywords = getKeywords(tokens);  
  	super.storeObject(idValue,value);
  	
  	Iterator it = keywords.iterator();
  	while(it.hasNext()) {   	  
  	 
  	  String token = (String) it.next();
  	  
  	  Set keywords1 = (Set) ((TreeSet) keywords).clone();  	    
  	  
  	  Id key = Utilities.generateHash(token);
  	  Properties prop = (Properties) super.retrieveObject(key);  	  
  	    
  	  if (prop==null) {
  	  	System.out.println("New prop + "+keywords1);
  	    prop = new Properties();  	    
  	    prop.put(idValue,keywords1);
  	  }	
  	  else {  	  	
  	  	Set previous = (Set) prop.get(idValue);  	  	
  	  	System.out.println("Old prop --> "+previous+" + "+keywords1);
  	  	if (previous!=null) keywords1.addAll(previous); 
  	  	prop.put(idValue,keywords1); 	  	
  	  } 	    	  	
  	  super.storeObject(token,(Serializable)prop);  	    	  
  	}    	  	
  }  	  
  
  /**
   *  Merges all properties, example for (query_key = java api)
   *  java.properties = {IdValue1=(api,docs); IdValue2=(languaje)}
   *  api.properties  = {IdValue1=(java,docs)}
   *  merge(java,api) = {IdValue1=(java,api,docs),IdValue2=(java,languaje)}  	 
   */
  public ResultSortedQueue query(String query_key) throws IOException {  	  	
  	
  	 Set keywords = getKeywords(query_key);  	   	  
  	 ResultSortedQueue result = new ResultSortedQueue(keywords);
  	 
  	 Hashtable merge = new Hashtable();
  	  
  	 Iterator it = keywords.iterator();
  	 while(it.hasNext()) {  	   
  	   
  	   String token = (String) it.next();
  	   Id key = Utilities.generateHash(token);
  	   Properties prop = (Properties) super.retrieveObject(key); 	    
  	  	  	    
  	   if (prop!=null) {
  	     
  	     Iterator it2 = prop.keySet().iterator();  	         	         	     
  	     while(it2.hasNext()) {
  	        Id idValue = (Id) it2.next();
  	        if (merge.containsKey(idValue)) {
  	          Set keywordSet = (Set) merge.get(idValue);
  	          System.out.println("previous "+keywordSet+" + new "+keywords);		          
  	          keywordSet.add(token);
  	          merge.put(idValue,keywordSet);
  	        }
  	        else {
  	          Set keywordSet = new TreeSet();	
  	          keywordSet.add(token);
  	          merge.put(idValue,keywordSet);
  	        } 	       
  	     }
  	   }	
     }
      	 
     //Insert merge result in the HashSortedQueue 	 
  	 Iterator it2 = merge.keySet().iterator();  
  	 while (it2.hasNext()) {
  	   Id idValue = (Id) it2.next();	
  	   Set elems = (Set) merge.get(idValue); 
  	   //System.out.println("!!! id "+idValue+" set :"+elems); 	   
  	   result.add(idValue,elems);  	   
  	 }
  	  
  	 return result; 
  }    
  
  public void remove(String tokens, Id idValue) throws IOException {
  	
  	Set keywords = getKeywords(tokens);  
  	super.removeObject(idValue);
  	
  	Iterator it = keywords.iterator();
  	while(it.hasNext()) {   	  
  	 
  	  String token = (String) it.next();
  	  
  	  Set keywords1 = (Set) ((TreeSet) keywords).clone();  	    
  	  
  	  Id key = Utilities.generateHash(token);
  	  Properties prop = (Properties) super.retrieveObject(key);  	  
  	    
  	 if (prop!=null) {  	  	
  	  	Set previous = (Set) prop.get(idValue);  	  	
  	  	if (previous!=null) {  	  	
  	  	  prop.remove(idValue);   	  	  	  	  
  	  	  super.storeObject(token,(Serializable)prop);  	    	  
  	  	}  	  	
  	  } 	    	  	
  	  
  	}    	  	
  }  

}

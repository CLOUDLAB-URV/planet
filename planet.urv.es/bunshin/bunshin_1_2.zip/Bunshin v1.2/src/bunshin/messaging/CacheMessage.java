package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) CacheMessage.java
 *
 * The cache message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class CacheMessage implements Message {

  private Id key;
  private Object value = null;  
  
  public CacheMessage(Id key, Object value) {  	
    this.key = key;
    this.value = value;     
  }  
 
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
    
  public String toString() {
    return "CacheMessage key "+key+" : "+value;
  }

}
package bunshin.messaging;

/**
 * @(#) GetMessage.java
 *
 * The get message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

import rice.p2p.commonapi.*;

public class GetMessage implements Message {

  private String messageId;
  private Id key;
  private int phase;
  private Object value = null;  
  private NodeHandle nh = null;
  private NodeHandle previousNH = null;
	
  public GetMessage(Id key, NodeHandle nh) {  	
  	
  	this.phase = 1;	
    this.key = key;
    this.nh = nh; 
    this.previousNH = nh;
    
  }  
  
  public GetMessage(Id key, Object value) {  	
  	
  	this.phase = 2;  	
    this.key = key;
    this.value = value; 
    
  }  
  
  public void setPreviousNH(NodeHandle previous) {
  	previousNH = previous;  	
  }
  
  public int getPhase() {
  	return phase;
  }
  
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public NodeHandle getNH() {
  	return nh;  	
  }  
  
  public NodeHandle getPreviousNH() {
  	return previousNH;  	
  }
  
  public String toString() {
    return "GetMessage"+phase+" key : "+key+":"+value;
  }

}
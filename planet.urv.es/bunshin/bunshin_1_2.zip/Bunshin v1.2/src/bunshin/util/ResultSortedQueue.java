package bunshin.util;

import rice.p2p.commonapi.*;
import java.util.*;


/**
 * Queue by the number of matches of the elems
 *
 * @author Ruben Mondejar
 *
 */ 
public class ResultSortedQueue {
    
    private Vector keyQueue,valueQueue;        
    private int[] limits; 
    private Set matches;
    
    //   0   -> limits[0] -> limits[1] -> ... -> limits[limits.length]
    // [ 0 matches ) [ 1 match  )          [  limits.length matches )
    
    public ResultSortedQueue(Set matches) {
      
      keyQueue = new Vector();
      valueQueue = new Vector();
      this.matches = matches;
      limits = new int[matches.size()+1];
      
    }
    
    private int matchesCalc(Set elems) {
    	
      int num = 0;
      
      Iterator it = matches.iterator();
      while (it.hasNext()) {
      	if (elems.contains(it.next())) {
      	  num++;
      	}
      }      
      return num;
    }
    
    private int getMatches(int pos) {
      
      boolean found = false;
      
      for (int i=0;i<limits.length-2;i++) {
        if (pos>limits[i] && pos<limits[i+1]) {
       	  return i;	
        }
      } 
      if (!found) return limits.length-1; 	
      else return -1;
    }
    
    
    public void add(Object key, Set elems) {
              
       int num = matchesCalc(elems);
       int pos = limits[num];
       for (int i=num+1;i<limits.length;i++) limits[i]++;
       
       keyQueue.add(pos,key);
       valueQueue.add(pos,elems);
            
    }
    
    public void delete(Object key) {
       
       int pos = keyQueue.indexOf(key);
       keyQueue.removeElementAt(pos); 
       valueQueue.removeElementAt(pos); 
       
       int limit = getMatches(pos);
       limits[limit]--;              
    } 
    
    public Iterator iterator() {
      return keyQueue.iterator();
    }   
    
    public String toString() {
      String s = "\nResultSortedQueue ("+keyQueue.size()+" elements) :\n";
      for (int i=keyQueue.size()-1; i>=0; i--) {
      	int num_matches = getMatches(i);
      	Object key =  keyQueue.get(i);
      	Object value =  valueQueue.get(i);  
      	int num = matchesCalc((Set)value);
        s+="Key : "+key+" ("+num+" matches) --> "+value+"\n";     
      }
      return s;
    }
}
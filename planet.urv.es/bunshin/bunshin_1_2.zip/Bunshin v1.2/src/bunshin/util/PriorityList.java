package bunshin.util;

import java.util.*;
 
/**
 * @(#) PriorityList.java
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PriorityList {

	private ArrayList list = new ArrayList();
	private ArrayList priorities = new ArrayList();

    //max properties
	private int indexMax = 0;
	private int max = 0;
		
	public void insert(Object elem, int priority) {
		
	  list.add(elem);	
	  int index = list.indexOf(elem);
	  priorities.add(index,new Integer(priority));
	  
	  if (priority>=max) {
	  	indexMax = index;
	  	max = priority;
	  }	  
	}
	
	public void update(Object elem) {
		
	  int index = list.indexOf(elem);
	  int priority = 0;
	  if (index<0) {
	  	list.add(elem);	
	    index = list.indexOf(elem);	  
	    priorities.add(index,new Integer(priority));
	  }
	  else {
	  	priority = ((Integer) priorities.get(index)).intValue() + 1;	  
	    priorities.set(index,new Integer(priority));
	  }
	  
	  if (priority>=max) {
	  	indexMax = index;
	  	max = priority;
	  	System.out.println("New max "+elem+" : "+max);
	  }
	  
	}
	
	public Object peak() {
	  return list.get(indexMax);		
	}
	
	public int getMax() {
	  return max;	
	}
	
	public void clear() {
	 
	  indexMax = 0;
	  max = 0;
		
	  priorities.clear();	
	  list.clear();	
	  
	}
	
	
	
}
package bunshin.util;

import rice.p2p.commonapi.*;
import java.util.*;
 
/**
 * @(#) Cache.java
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Cache {

  private int TTL = 0;
  private int MAX_ELEM = 0;
    
  private Hashtable elems = new Hashtable();
  private ArrayList queue = new ArrayList();
  private ArrayList ttls = new ArrayList();
  
  public Cache(int TTL, int MAX_ELEM) {
  	this.TTL = TTL;
  	this.MAX_ELEM = MAX_ELEM;
  	
  }
  
  public void put(Id key, Object value) {
    
    elems.put(key,value); 
    queue.add(key);  
    ttls.add(new Integer(0));
    
    if (queue.size()>MAX_ELEM) {
      Id id = (Id) queue.remove(0);
      ttls.remove(0);
      elems.remove(id);
    }	
  } 
  
  public Object get(Id key) {
  	return elems.get(key);
  }
  
  public boolean containsKey(Id key) {
  	return elems.containsKey(key);
  }
  
  public void incTime() {

    Iterator it = ttls.iterator();
    int i = 0;
    while (it.hasNext()) {
      int ttl = ((Integer) it.next()).intValue() + 1;	
      if (ttl>TTL) {
  	    Id id = (Id) queue.remove(i);
        ttls.remove(i);
        elems.remove(id);  	  	
  	  }
  	  else {  	  	
  	  	i++;
  	  }
      
    }  	
  
  }
  
  
  	
}
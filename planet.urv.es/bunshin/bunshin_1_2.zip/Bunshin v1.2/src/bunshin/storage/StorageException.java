package bunshin.storage;

/**
*		Wrapper Exception class to different Exceptions
*   It simply stores the incoming Exception and provides a method for obtaining the *real* exception.
*/

public class StorageException extends Exception {
	private Exception ex;
	
	
	public StorageException(Exception ex)
	{
		super(ex.getMessage());
		this.ex = ex;
	}

	/**
	*		Return the Exception produces in the notification service.
	* @return Exception the Exception occured in the underlying Notificacion Service.
	*/
	
	public Exception getException()
	{
		return ex;
	}

}
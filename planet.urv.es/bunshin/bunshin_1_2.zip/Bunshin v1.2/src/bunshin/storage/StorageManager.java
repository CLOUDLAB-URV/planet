package bunshin.storage;

import java.util.*;
import bunshin.util.Bucket;
import rice.p2p.commonapi.*;

/**
 * @(#) StorageManager.java
 *  
 * 
 * @author Ruben Mondejar
 */
public interface StorageManager {
 
  public void init(Properties prop);
  
  public void add(Bucket newBucket) throws StorageException ;
	
  public void insert(Id key, Object value) throws StorageException;
	
  public void overwrite(Id key, Object value) throws StorageException;	
  
  public Object remove(Id key) throws StorageException;
  
  public Bucket getBucket();
  
  public Object retreive(Id key) ;
  
  public boolean exists(Id key);
  
  public boolean isFull();  
  
}


package bunshin.storage;

import java.io.*;
import java.util.*;
import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 * @(#) MemStorage.java
 * 
 * @author Ruben Mondejar
 */
public class MemStorage implements StorageManager {

  private Bucket mem = new Bucket();  
    
  public Object retreive(Id key) { 	
    return mem.load(key);	
  }  
  
  public void init(Properties prop) {
    
  }
  
  public void add(Bucket newBucket) throws StorageException{
  	mem.add(newBucket);	  
  }
	
  public void insert(Id key, Object value) throws StorageException {
    mem.insert(key,value);
  }
	
  public void overwrite(Id key, Object value) throws StorageException {
    mem.overwrite(key,value);    
  }
	
  
  public Bucket getBucket() {
  	return mem;
  }   
  
  public Object remove(Id key) {                   
    return mem.remove(key);	    	  
  } 
  
  public boolean exists(Id key) {
  	 return mem.containsKey(key);	    	  
  }  
 
  public boolean isFull() {
  	return false;
  }
  

}


package bunshin.test;

import bunshin.*;
import bunshin.util.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import org.doomdark.uuid.*;


import java.io.*;
import java.util.*;
import java.net.*;
import java.nio.channels.*;

/**
 * @(#) BunshinSearchTest.java
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class BunshinSearchTest  {	
 
  public static void main(String args[]) {

  try {

  	BufferedReader dis = new BufferedReader(new InputStreamReader (System.in));
  	
    BunshinSearch c = new BunshinSearch("bunshin.properties");
    
    boolean end = false;
    int whatToDo = (Integer.valueOf(args[0])).intValue();
    System.out.println("whatToDo == "+whatToDo);
    if (whatToDo==0) {
      try {
       
        c.init("bunshin.properties");
        System.out.println("Press <RETURN> to exit...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      }
    }
    else if (whatToDo==1){
      try {
        
        c.init("bunshin.properties");

      	System.out.println ("Enter the Keyworks...");
    	String keywords = dis.readLine();    	
    	System.out.println ("Enter the String to store...");
    	String input = dis.readLine();    	        
        Id idValue = c.insert(keywords,input);
        System.out.println("Succefull insertion, generated id --> "+idValue);
         
        System.out.println("Press <RETURN> to exit...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      	ex.printStackTrace();
      }
    }
    else if (whatToDo==2){
        try {
        
          c.init("bunshin.properties");

      	  System.out.println ("Enter Keywords to search...");
          String keywords = dis.readLine();
          ResultSortedQueue rsq = c.query(keywords);
          if (rsq!=null) {
          	 System.out.println(rsq);
          	 Iterator it = rsq.iterator();
          	 System.out.print("Objects : ");
          	 while (it.hasNext()){
          	   Id key = (Id) it.next();
          	   Object obj = c.retrieveObject(key);	
          	   System.out.print(obj+", ");
          	 }
          	 System.out.println();
          }
          else System.out.println("Your search - "+keywords+" - did not match any objects");
  
          System.out.println("Press <RETURN> to exit...");
          System.in.read();
          c.leave();
        }
        catch (IOException ex) {
        	ex.printStackTrace();
        }
      }

    System.exit(0);
    }        catch (Exception ex) {
        	ex.printStackTrace();
        }
  }
}

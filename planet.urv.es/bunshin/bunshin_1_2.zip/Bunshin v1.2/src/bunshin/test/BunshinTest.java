package bunshin.test;

import bunshin.*;
import bunshin.util.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import java.io.*;
import java.net.*;
import java.nio.channels.*;

/**
 * @(#) BunshinTest.java
 *
 * This main class executes a test with a three diffreent rols. The first rol is a 
 * simple Pastry node and Bunshin application registered. In the second rol the application 
 * also stores a String in the DHT. The last rol restore the String with the given key.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class BunshinTest {
  
  public static void main(String args[]) {
   try {
   
  	BufferedReader dis = new BufferedReader(new InputStreamReader (System.in));
  	
    BunshinConnection c = new BunshinConnection("bunshin.properties");    
    boolean end = false;
    int whatToDo = (Integer.valueOf(args[0])).intValue();
    System.out.println("whatToDo == "+whatToDo);
    if (whatToDo==0) {
      try {
       
        c.init("bunshin.properties");
        
        System.out.println("Prem <RETURN> per finalitzar...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      }
    }
    else if (whatToDo==1){
      try {
        
        c.init("bunshin.properties");

      	System.out.println ("Enter the String to store...");
    	String input = dis.readLine();    	
        c.storeString(input);
         
        System.out.println("Press <RETURN> to exit...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      	ex.printStackTrace();
      }
    }
    else if (whatToDo==2){
        try {
               
          c.init("bunshin.properties");

        while (true) {
      	  System.out.println ("Enter the String to retrieve...");
          String input = dis.readLine();
          c.retrieveString(input, new BunshinApplication(input));
        }
          
        //System.out.println("Press <RETURN> to exit...");
         // System.in.read();
          //c.leave();
        }
        catch (IOException ex) {
        	ex.printStackTrace();
        }
      }
    else if (whatToDo==3){
        try {
        
          c.init("bunshin.properties");

      	  System.out.println ("Enter the String to remove...");
          String input = dis.readLine();
          c.removeString(input);
  
          System.out.println("Press <RETURN> to exit...");
          System.in.read();
          c.leave();
        }
        catch (IOException ex) {
        	ex.printStackTrace();
        }
      }
    System.exit(0);
    }  catch (Exception ex) {
        	ex.printStackTrace();
    }
  }
}

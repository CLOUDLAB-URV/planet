package bunshin.test;

import bunshin.*;
import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 * @(#) BunshinApplication.java
 *
 * This class implements the interface BunshinClient for BunshinTest, when the method
 * get is called, the result will be print on the standart out
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class BunshinApplication implements BunshinClient {     
    
    private String key;
	private Id id;
	
	public BunshinApplication(String key) {
	  this.key=key;	
	  id = Utilities.generateHash(key);
	}	
	
	public void get(Object value) {
      System.out.println("Get value returned! [ key : "+key+" id : "+id+" value : "+value+"]");
    }

}
/*******************************************************************************
 * Dermi: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2004 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package bunshin.test;

import junit.framework.*;
import bunshin.storage.*;
import bunshin.*;
import rice.p2p.commonapi.*;


/**
 * Bunshin's main testcase
 * @author Ruben Mondejar  <ruben.mondejar@estudiants.urv.es>
 */
public class SimpleTest extends TestCase {

  protected BunshinConnection[] bunshin;
  protected int num;

  public SimpleTest(String name) {
	super(name);
  }

  protected void setUp() {
		
    try {
      num = 10;
  	  bunshin = new BunshinConnection[num];
  	  for (int i=0; i<num; i++) {  	  	
  	  	bunshin[i] = new BunshinConnection("auto",5009,null,1);
  	  	Thread.sleep(2000);
  	    bunshin[i].init("BunshinTest", new DiskStorage(), 3,false,true);  	    
  	  }		  
	  
	} catch (Exception e1) {
	  e1.printStackTrace();	
	}	
  }


  public static Test suite() {
    return new TestSuite(SimpleTest.class);
  }

/*	
  public void testStore() throws Exception {    
	
    String id = "time";
    long time = System.currentTimeMillis();
                  
    Id key = bunshin[0].storeObject(id,new Long(time));    
      
    Thread.currentThread().sleep(5000);
    
    long time2 = System.currentTimeMillis();
                  
    bunshin[0].storeObject(id,new Long(time2));    
      
    Thread.currentThread().sleep(5000);
    
    Long tr = (Long) bunshin[num-1].retrieveObject(key);    
     		
	assertEquals(time,tr.longValue());
    
  }
  
*/
  public void testStoreDuplicate() throws Exception {    
	
    String id = "time";
    long time = System.currentTimeMillis();
                  
    Id key = bunshin[0].storeObject(id,new Long(time));    
      
    Thread.currentThread().sleep(5000);
    
    long time2 = System.currentTimeMillis();
                  
    bunshin[1].storeObject(id,new Long(time2),true);    
      
    Thread.currentThread().sleep(5000);
    
    Long tr = (Long) bunshin[num-1].retrieveObject(key);    
     		
	assertEquals(time2,tr.longValue());	
    
  }
  
  
    	
  	
}
/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.messaging;

import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;

import bunshin.util.Values;
import rice.p2p.commonapi.*;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;

/**
 *
 * The listener message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class NotifyMessage extends BunshinMessage {

  private Id key;
  private Object value;
  private String field;
  private boolean add;
  
  public NotifyMessage(Id key, Object value, String field, boolean add) {
  	this.key = key;
  	this.field = field;
  	this.value = value;
  	this.add = add;
  }

  public Id getKey() {
  	return key;  	
  }
  
  public String getField() {
  	return field;
  }
  
  public Object getValue() {
  	return value;
  }
  
  public boolean isAdd() {
  	return add;
  }
  
  public int getPriority() {
  	return Message.MEDIUM_PRIORITY;
  }
  
  public String toString() {
    return "NotifyMessage key "+key+" field : "+field+" value : "+value;
  }
  
  
  /***************** Raw Serialization ***************************************/

  protected static final short TYPE = MessageType.NOTIFY_MESSAGE;
  
  public short getType() {
	    return TYPE;
  }
  
  public void serialize(OutputBuffer buf) throws IOException {
	    
	    Hashtable content = new Hashtable();
	    if (key!=null) content.put("key", key);
	    if (field!=null) content.put("field", field);   
	    if (value!=null) content.put("value", value);   
	    content.put("add", new Boolean(add));
	    
	    	    
	    super.serialize(buf,content);
	   	   
	}

//	deserialize constructor
	public NotifyMessage(InputBuffer buf) throws IOException {	  
	  
	  	Hashtable content = super.deserialize(buf);
	  		  	
	  	key = (Id) content.get("key");
	  	field = (String) content.get("field");
	  	value = content.get("value");  	
	  	add  = (Boolean) content.get("add");
	  	
	  	
	}


}
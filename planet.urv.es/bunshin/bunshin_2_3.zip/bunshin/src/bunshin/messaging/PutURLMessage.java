/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.messaging;

import rice.p2p.commonapi.*;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;

import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;

import bunshin.util.Values;

/**
 *
 * The put url message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PutURLMessage extends BunshinMessage {

  private Id key;
  private URL url;
  private String field;
  
  public PutURLMessage(Id key, URL url, String field) {  	
    this.key = key;
    this.url = url; 
    this.field = field;
  }  
 
  public Id getKey() {
  	return key;  	
  }
  
  public URL getURL() {
  	return url;
  }
  
  public String getField() {
  	return field;
  }
  
  public int getPriority() {
	  	return Message.MEDIUM_HIGH_PRIORITY;
  }
  
  public String toString() {
    return "PutURLMessage key "+key+" field : "+field+" url : "+url;
  }
  
  /***************** Raw Serialization ***************************************/

  protected static final short TYPE = MessageType.PUT_URL_MESSAGE;
  
  public short getType() {
	    return TYPE;
  }


public void serialize(OutputBuffer buf) throws IOException {
    
    Hashtable content = new Hashtable();
    if (key!=null) content.put("key", key);
    if (url!=null) content.put("url", url);
    if (field!=null) content.put("field", field);   
  
    
    	    
    super.serialize(buf,content);
   	   
}

//deserialize constructor
public PutURLMessage(InputBuffer buf) throws IOException {	  
  
  	Hashtable content = super.deserialize(buf);
  		  	
  	key = (Id) content.get("key");
  	url = (URL) content.get("url");
  	field = (String) content.get("field");  	
    	
}


}
/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.messaging;

import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;

import rice.p2p.commonapi.*;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;
import bunshin.util.*;

/**
 *
 * The put message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PutMessage extends BunshinMessage {

  private Id key;
  private Object value = null;
  private String field;
  private NodeHandle source;
  private Password pwd = null;
  
  public PutMessage(Id key, Object value, String field, NodeHandle source) {  	
    this.key = key;
    this.value = value; 
    this.field = field;
    this.source = source;
  }  
 
 public PutMessage(Id key, Object value, String field, Password pwd, NodeHandle source) {  	
    this.key = key;
    this.value = value; 
    this.field = field;
    this.pwd = pwd;
    this.source = source;
  }  
  
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public String getField() {
  	return field;
  }
  
  public NodeHandle getNH() {
  	return source;
  }
  
  public Password getPassword() {
  	return pwd;
  }
  
  public int getPriority() {
  	return Message.MEDIUM_HIGH_PRIORITY;
  }
  
  public String toString() {
    return "PutMessage key "+key+" field : "+field+" value : "+value+" from "+source;
  }
  
  /***************** Raw Serialization ***************************************/

  protected static final short TYPE = MessageType.PUT_MESSAGE;
  
  public short getType() {
	    return TYPE;
  }
  
  public void serialize(OutputBuffer buf) throws IOException {
	    //key
	    //buf.writeShort(key.getType());
	    //key.serialize(buf);
	    
	    Hashtable content = new Hashtable();
	    if (key!=null) content.put("key", key);
	    if (value!=null) content.put("value", value);
	    if (field!=null) content.put("field", field);
	    if (source!=null) content.put("source", source);
	    if (pwd!=null) content.put("pwd", pwd);
	    	    
	    super.serialize(buf,content);

}

//deserialize constructor
public PutMessage(InputBuffer buf) throws IOException {	  
	  
	  	//key = rice.pastry.Id.build(buf);
	  	Hashtable content = super.deserialize(buf);
	  		  	
	  	key = (Id) content.get("key");
	  	value = content.get("value"); 
	  	field = (String) content.get("field");
	  	source 	  = (NodeHandle) content.get("source");
	  	pwd  = (Password) content.get("pwd");
	  	
}


}
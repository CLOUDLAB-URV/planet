/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin;

import bunshin.util.*;
import bunshin.storage.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.channels.*;

/**
 *
 * This class wraps a connection to Bunshin substrate and is used by the application as its main
 * DHT substrate.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class BunshinConnection {


  // ----- VARIABLES -----

  // the collection of nodes which have been created
  protected rice.p2p.commonapi.Node[] nodes;

  // the number of nodes to create
  public static int NUM_NODES = 10;

  // ----- PASTRY SPECIFIC VARIABLES -----

  // the factory for creating pastry nodes
  protected PastryNodeFactory factory;

  // the simulator, in case of direct
  protected NetworkSimulator simulator;

  // ----- TESTING SPECIFIC FIELDS -----

  // the direct protocol
  public static final int PROTOCOL_DIRECT = -138;

  // the possible network simulation models
  public static final int SIMULATOR_SPHERE = -1;
  public static final int SIMULATOR_EUCLIDEAN = -2;

  // the factory which creates pastry ids
  public static IdFactory FACTORY = new PastryIdFactory();

  // ----- PASTRY SPECIFIC FIELDS -----

  // the port to begin creating nodes on
  public static int PORT = 5009;

  // the port on the bootstrap to contact
  public static int BOOTSTRAP_PORT = 5009;

  // the procotol to use when creating nodes
  public static int PROTOCOL = DistPastryNodeFactory.PROTOCOL_SOCKET;

  // the simulator to use in the case of direct
  public static int SIMULATOR = SIMULATOR_SPHERE;

  // Reference to the Pastry node
  private PastryNode pn;

  // the host to boot the first node off of
  public static String BOOTSTRAP_HOST = "localhost";

  public BunshinImpl bunshinApp;

  public Endpoint endPoint;

  public Object value;
  public URL urlValue;

  boolean lookupResultArrived;

  // ----- ATTEMPT TO LOAD LOCAL HOSTNAME -----
  static {
    try {
      BOOTSTRAP_HOST = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
    }
  }

  /**
   * Creates a node and stablishs the connection with the network
   * @param String host
   * @param int port
   * @param PastryNodeFactory, may be null
   * @param int protocol, 2 for default behaviour
   *
   */
  public BunshinConnection(String bootHost, int bootPort, PastryNodeFactory fac, int protocol) {
    createNode(bootHost,bootPort,fac,protocol);
  }

  /**
   * Creates a node and stablishs the connection with the network
   * @param Properties bunshin file
   */
  public BunshinConnection(Properties prop) throws Exception {

      String bootHost =(String)prop.get(Context.HOST);
      if (bootHost==null) bootHost = "auto";

      int bootPort = Integer.parseInt((String)prop.get(Context.PORT));

     PastryNodeFactory fac = null;
     try {
       fac = (PastryNodeFactory)Class.forName((String)prop.get(Context.FACTORY)).newInstance();
     } catch (NullPointerException e) {}

      int protocol = Integer.parseInt((String)prop.get(Context.PROTOCOL));

      createNode(bootHost,bootPort,fac,protocol);
  }

  /**
   * Creates a node and stablishs the connection with the network
   * @param String of the path of the properties bunshin file
   */
  public BunshinConnection(String path) throws Exception {

    Properties prop = loadProp(path);

    String bootHost =(String)prop.get(Context.HOST);
    if (bootHost==null) bootHost = "auto";

    int bootPort = Integer.parseInt((String)prop.get(Context.PORT));

    PastryNodeFactory fac = null;
   try {
     fac = (PastryNodeFactory)Class.forName((String)prop.get(Context.FACTORY)).newInstance();
   } catch (NullPointerException e) {}

    int protocol = Integer.parseInt((String)prop.get(Context.PROTOCOL));

    createNode(bootHost,bootPort,fac,protocol);
  }


  private Properties loadProp(String path) throws Exception {
  	FileInputStream  fis = new FileInputStream(path);
	Properties prop = new Properties();
	prop.load(fis);
	fis.close();
  	return prop;
  }

  /**
   * This method creates a new node which will serve as the underlying p2p layer
   *
   * @param args Constructor arguments: 0 - String bootstrap host; 1 - int bootstrap port; 2 - PastryNodeFactory factory; 3 - int protocol
   */
  public void createNode (String bootHost, int bootPort, PastryNodeFactory fac, int protocol) {

    if (!bootHost.equalsIgnoreCase ("auto")) {
      BOOTSTRAP_HOST = bootHost;
    }
    BOOTSTRAP_PORT = bootPort;
    PORT = bootPort;

    PROTOCOL = protocol;

    if (SIMULATOR == SIMULATOR_SPHERE) {
      simulator = new SphereNetwork();
    } else {
      simulator = new EuclideanNetwork();
    }

    if (PROTOCOL == PROTOCOL_DIRECT) {
      factory = new DirectPastryNodeFactory (new RandomNodeIdFactory(), simulator);
      nodes = new Node[NUM_NODES];
    }

    // If Id factory is null, a new one is created
    if (fac == null) {
      int newPort = PORT;

      // If working in remote mode, check if port is already bound (this way
      // we allow several Dermis running on the same machine)
      if (PROTOCOL != PROTOCOL_DIRECT) {
        while (true) {
          DatagramChannel channel = null;
          try {
            channel = DatagramChannel.open();
            channel.configureBlocking (false);
            InetSocketAddress isa = new InetSocketAddress (newPort);
            channel.socket().bind (isa);
            channel.socket().close();
            channel.close();

            factory = DistPastryNodeFactory.getFactory (new RandomNodeIdFactory(), PROTOCOL, newPort);
            break;
          } catch (IOException e) {
            newPort += 100;
            System.out.println ("Port " + (newPort - 100) + " already bound. Trying " + newPort + "...");
          }
          finally {
            channel.socket().close();
            try {
              channel.close();
            }
            catch (IOException ex) {

            }
          }
        }
      }
    }
    else {
      factory = fac;
    }

    // Get bootstrap reference
    rice.pastry.NodeHandle bootstrap = getBootstrap();

    pn = factory.newNode (bootstrap);   // internally initiateJoins

    // The node may require sending several messages to fully boot into the ring
    while (!pn.isReady()) {
      // Delay so don't busy-wait
      try {
        Thread.sleep (100);
      }
      catch (InterruptedException ex1) {
      }
    }
  }

  /**
   * Gets a handle to a bootstrap node.
   *
   * @return handle to bootstrap node, or null.
   */
  protected rice.pastry.NodeHandle getBootstrap() {
    if (PROTOCOL == PROTOCOL_DIRECT) {
      return ((DirectPastryNode) nodes[0]).getLocalHandle();
    } else {
      InetSocketAddress address = new InetSocketAddress (BOOTSTRAP_HOST, BOOTSTRAP_PORT);
      return ((DistPastryNodeFactory) factory).getNodeHandle (address);
    }
  }

  /**
   * Initializes the Bunshin layer.
   *
   * @param String id of the application
   * @param StorageManager the object manager
   * @param int replicaFactor indicates the number of copies in the network
   * @param boolean activate cache mode
   * @param boolean activate debug mode
   */
  public void init(String id, StorageManager manager, int replicaFactor, boolean cache, boolean debug) {
  	bunshinApp = new BunshinImpl(id);
    bunshinApp.setStorageManager(manager);
    bunshinApp.setReplicationFactor(replicaFactor);
    if (cache) bunshinApp.activateCache();
    if (debug) bunshinApp.activateDebug();
    endPoint = pn.registerApplication (bunshinApp,id);
    bunshinApp.setRefreshTime(20000);
    bunshinApp.setEndPoint (endPoint);
  }	
  	
    /**
   * Initializes the Bunshin layer.
   *
   * @param String id of the application
   * @param StorageManager the object manager
   * @param int replicaFactor indicates the number of copies in the network
   * @param int refresh time period in seconds 
   * @param boolean activate cache mode
   * @param boolean activate debug mode
   */	  	
  public void init(String id, StorageManager manager, int replicaFactor, int time_sec, boolean cache, boolean debug) { 	
    bunshinApp = new BunshinImpl(id);
    bunshinApp.setStorageManager(manager);
    bunshinApp.setReplicationFactor(replicaFactor);
    if (cache) bunshinApp.activateCache();
    if (debug) bunshinApp.activateDebug();
    endPoint = pn.registerApplication (bunshinApp,id);
    bunshinApp.setRefreshTime(time_sec*1000);
    bunshinApp.setEndPoint (endPoint);


  }

  public void setInfoContext(String context, String path, String url, URL[] URLsList) {
    bunshinApp.setInfoContext(context,path,url,URLsList);
  }

  /**
   * Initializes the Bunshin layer.
   *
   * @param String path of the bunshin properties file
   */
  public void init(String path) throws Exception{

  	Properties prop = loadProp(path);

  	String id =(String)prop.get(Context.ID_APPLICATION);
  	StorageManager manager = (StorageManager)Class.forName((String)prop.get(Context.STORAGE_MANAGER)).newInstance();
  	manager.init(prop);
  	int replicaFactor = Integer.parseInt((String)prop.get(Context.REPLICA_FACTOR));
  	boolean cache = Context.TRUE.equals((String)prop.get(Context.CACHE));
  	boolean debug = Context.TRUE.equals((String)prop.get(Context.DEBUG));

    int time = Integer.parseInt((String)prop.get(Context.REFRESH_TIME));
  	init(id,manager,replicaFactor,time,cache,debug);
  	
  }


  /**
   * Asynchronous get method
   * @param String value
   * @param BunshinGetClient the callback client
   */
  public void retrieveObject(String context, Id key, BunshinGetClient client) throws IOException {

  	bunshinApp.get(context,key,"Object", client);
  }


  /**
   * Puts the pair (key,value)
   * @param Id of the key
   * @param Serializable value
   */
  public void storeObject(Id id, Serializable value) {
    bunshinApp.put(id,value,"Object");
  }

	/**
	 * Puts the pair (key,value)
	 * @param Context string
	 * @param Id of the key
	 * @param Serializable value
	 */
	public void storeObject(String context,Id id, Serializable value)
	{
		bunshinApp.put(context,id,value,"Object");
	}

	/**
	 * Puts the pair (key,url), when value = download(url);
	 * @param Id of the key
	 * @param URL url of the value
	 */
	public void insertURL(String context,Id id, URL url) {
	  bunshinApp.putURL(context,id,url,"URL");
	}

  /**
   * Puts the pair (key,value), when key = value
   * @param String of the key
   * @param Serializable value
   * @return Id of the key
   */
  public Id storeObject(String key, Serializable value) {
  	Id id = Utilities.generateHash(key);
    bunshinApp.put(id,value,"Object");
    return id;
  }

  /**
   * Synchronous get method
   * @param String of the key
   * @return Object value of this id key
   */
  public Object retrieveObject(String key) throws IOException {
  	Id id = Utilities.generateHash(key);
  	return retrieveObject(id);
  }

  /**
   * Synchronous get method
   * @param Id of the key
   * @return Object value of this id key
   */
  public Object retrieveObject(Id key) throws IOException {
    return retrieveObject(Context.DEFAULT_CONTEXT,key);
  }

	/**
	 * Synchronous get method
	 * @param Context String
	 * @param Id of the key
	 * @return Object value of this id key
	 */
	public Object retrieveObject(String context,Id key) throws IOException {

		int timeout = 0;
		lookupResultArrived = false;


		bunshinApp.get(context,key,"Object",new BunshinGetClient() {

			public void get (Object result) {

				synchronized (this) {



					if (result != null) {


						if (result instanceof bunshin.util.Values)
						{
							value =((bunshin.util.Values) result).get("Object");
						}
						else
						{
							value = result;
						}
					}
					else
					{
						value = null;
					}
					lookupResultArrived = true;
				}
			}
		}
			);

		synchronized (this)
		{
			while (!lookupResultArrived && timeout < 30)
			{
				try
				{
					Thread.sleep (100);
				}
				catch (InterruptedException ex)
				{
				}
				timeout++;
			}
		}

		return value;
	}

		/**
	 * Synchronous get method
	 * @param Context String
	 * @param Id of the key
	 * @return Object value of this id key
	 */
	public URL retrieveURL(String context,Id key) throws IOException {

		int timeout = 0;
		lookupResultArrived = false;


		bunshinApp.getURL(context,key,"URL",new BunshinURLClient() {

			public void get (URL result) {

				synchronized (this) {

					if (result != null) {

							urlValue = result;

					}
					else
					{
						urlValue = null;
					}
					lookupResultArrived = true;
				}
			}
		}
			);

		synchronized (this)
		{
			while (!lookupResultArrived && timeout < 30)
			{
				try
				{
					Thread.sleep (100);
				}
				catch (InterruptedException ex)
				{
				}
				timeout++;
			}
		}

		return urlValue;
	}


   	/**
	 * Synchronous get method
	 * @param Context String
	 * @param Id of the key
	 * @return Object value of this id key
	 */
	public Object retrieve(String context,Id key, final String field) throws IOException {

		int timeout = 0;
		lookupResultArrived = false;


		bunshinApp.get(context,key,field,new BunshinGetClient() {

			public void get (Object result) {

				System.out.println("get arrived : "+result);
				synchronized (this) {


					if (result != null) {


						if (result instanceof bunshin.util.Values)
						{
							value =((bunshin.util.Values) result).get(field);
						}
						else
						{
							value = result;
						}
					}
					else
					{
						value = null;
					}
					lookupResultArrived = true;
				}
			}
		}
			);

		synchronized (this)
		{
			while (!lookupResultArrived && timeout < 30)
			{
				try
				{
					Thread.sleep (100);
				}
				catch (InterruptedException ex)
				{
				}
				timeout++;
			}
		}

		return value;
	}




  /**
   * Remove method
   * @param String of the key
   */
  public void removeObject(String key) throws IOException
  {
  	Id id = Utilities.generateHash(key);
  	bunshinApp.remove(id,"Object");
  }

  /**
   * Remove method
   * @param Id of the key
   */
  public void removeObject(Id idValue) throws IOException {
  	bunshinApp.remove(idValue,"Object");
  }

  /**
   * Leaves the bunshin layer
   */
  public void leave() {
  	bunshinApp.leave();
  }


}

/*******************************************************************************
 * Bunshin : DHT Replication & Caching
 * Copyright (C) 2004-2005 Ruben Mondejar
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/

package bunshin.util;

import java.util.*;
import java.io.*;
 
/**
 *
 * Values of a given key in a bucket
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Values extends Hashtable {}
/*
  public class Values implements Cloneable,Serializable {
  	
  	  private Hashtable info;
  
  
  public Values() {
  	info = new Hashtable();
  }
  protected Values(Hashtable info) {
    this.info = info;  	
  }
  
  public void put (Object key, Object value) {
  	
  	//info.put(key,value);//WITHOUT SERIALIZE
  	
  	try {
  	
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    ObjectOutputStream os = new ObjectOutputStream(bos);
    os.writeObject(value);
	os.close();			
			
    byte[] bytes = bos.toByteArray();	
    
    info.put(key,bytes);
    
    } catch(Exception ex) {
      ex.printStackTrace();      
    }
    
  }
  
  public Object get(Object key) {
  	
  	Object value = null;
  	
  	
  	//value = info.get(key);//WITHOUT SERIALIZE
  	
  	byte[] wrapper = (byte[]) info.get(key);
 
    if (wrapper!=null) {
    
    try {
    	
      ByteArrayInputStream bis = new ByteArrayInputStream(wrapper);
      ObjectInputStream is = new ObjectInputStream(bis);
      value =  is.readObject();
      is.close();	  	
  	
  	  } catch(Exception ex) {
        ex.printStackTrace();      
      }
    } 
    
  	return value;
  	
  }
  
  public Object remove(Object key) {
  	
  	Object value = null;
  	
  	
  	byte[] wrapper = (byte[]) info.remove(key);
 
    if (wrapper!=null) {
    
    try {
    	
      ByteArrayInputStream bis = new ByteArrayInputStream(wrapper);
      ObjectInputStream is = new ObjectInputStream(bis);
      value =  is.readObject();
      is.close();	  	
  	
  	  } catch(Exception ex) {
        ex.printStackTrace();      
      }
    }  
  	return value;
  	
  }
  
  
  public boolean containsKey(Object key) {
  	return info.containsKey(key);
  }
  
  
  public long size() {
  	return info.size();
  }
  
  public Object clone() {
  	return new Values((Hashtable)info.clone());
  }
  
  public boolean isEmpty(){
  	return info.isEmpty();
  }
  
  public Collection keySet() {
  	return info.keySet();
  }
  
  

}*/
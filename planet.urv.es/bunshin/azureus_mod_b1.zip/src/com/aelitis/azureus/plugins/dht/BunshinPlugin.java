package com.aelitis.azureus.plugins.dht;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

import bunshin.*;
import bunshin.util.*;

import org.gudy.azureus2.core3.util.AESemaphore;
import org.gudy.azureus2.core3.util.AEThread;
import org.gudy.azureus2.core3.util.Constants;
import org.gudy.azureus2.core3.util.Debug;

import org.gudy.azureus2.plugins.Plugin;
import org.gudy.azureus2.plugins.PluginInterface;
import org.gudy.azureus2.plugins.PluginListener;
import org.gudy.azureus2.plugins.logging.LoggerChannel;
import org.gudy.azureus2.plugins.logging.LoggerChannelListener;
import org.gudy.azureus2.plugins.ui.UIManager;
import org.gudy.azureus2.plugins.ui.config.ActionParameter;
import org.gudy.azureus2.plugins.ui.config.BooleanParameter;
import org.gudy.azureus2.plugins.ui.config.IntParameter;
import org.gudy.azureus2.plugins.ui.config.LabelParameter;
import org.gudy.azureus2.plugins.ui.config.Parameter;
import org.gudy.azureus2.plugins.ui.config.ParameterListener;
import org.gudy.azureus2.plugins.ui.config.StringParameter;
import org.gudy.azureus2.plugins.ui.model.BasicPluginConfigModel;
import org.gudy.azureus2.plugins.ui.model.BasicPluginViewModel;

import com.aelitis.azureus.core.versioncheck.VersionCheckClient;

import com.aelitis.azureus.plugins.upnp.UPnPPlugin;

import rice.p2p.commonapi.Id;



/** Bunshin Plugin
 *
 * @author Ruben Mondejar
 */
public class BunshinPlugin implements Plugin {

	private static final String	PLUGIN_VERSION	= "1.0";
	private static final String	PLUGIN_NAME		= "Bunshin Plugin";
	
	public static final int			STATUS_DISABLED			= 1;
	public static final int			STATUS_INITALISING		= 2;
	public static final int			STATUS_RUNNING			= 3;
	public static final int			STATUS_FAILED			= 4;
	

	public static final byte		FLAG_SINGLE_VALUE	= 0x00;
	public static final byte		FLAG_DOWNLOADING	= 0x01;
	public static final byte		FLAG_SEEDING		= 0x02;
	public static final byte		FLAG_MULTI_VALUE	= 0x04;

	public static final int 	MAX_VALUE_SIZE		= 256;
	
		
	
	private PluginInterface		plugin_interface;	
	private Bunshin bunshin = null;
	private BunshinConnection conn = null;
	private String bunshinContext = "azureus_plugin";
	
	private boolean				enabled;
	private AESemaphore			init_sem = new AESemaphore("BunshinPlugin:init" );
	
	private LoggerChannel		log;
	
	private int					bunshin_port;
	private static String address;
	private int status = STATUS_DISABLED;
	

	/** This method is called when the plugin is loaded / initialized
   *
   * @param pluginInterface access to Azureus' plugin interface
   */
	public void initialize(PluginInterface pluginInterface) {
		
		status = STATUS_INITALISING;
		
		plugin_interface	= pluginInterface;
		
		plugin_interface.getPluginProperties().setProperty( "plugin.version", 	PLUGIN_VERSION );
		plugin_interface.getPluginProperties().setProperty( "plugin.name", 		PLUGIN_NAME );
		
		try {
			
			bunshin_port = 5009; //plugin_interface.getPluginconfig().getIntParameter( "TCP.Listen.Port" );

			log = plugin_interface.getLogger().getTimeStampedChannel(PLUGIN_NAME);

			UIManager	ui_manager = plugin_interface.getUIManager();

			final BasicPluginViewModel model = 
				ui_manager.createBasicPluginViewModel( PLUGIN_NAME);
			
			BasicPluginConfigModel	config = ui_manager.createBasicPluginConfigModel( "Plugins", "plugins.bunshin" );
				
			config.addLabelParameter2( "bunshin.info" );
			
			final BooleanParameter	enabled_param = config.addBooleanParameter2( "bunshin.enabled", "bunshin.enabled", true );

			final StringParameter	bunshin_bootstrap	= config.addStringParameter2( "bunshin.bootstrap.ip", "bunshin.bootstrap.ip", "auto" );
			
			final BooleanParameter	use_default_port = config.addBooleanParameter2( "bunshin.portdefault", "bunshin.portdefault", true );

			final IntParameter		bunshin_port_param	= config.addIntParameter2( "bunshin.port", "bunshin.port", bunshin_port );
					
			use_default_port.addDisabledOnSelection( bunshin_port_param );
			
			if ( !use_default_port.getValue()){
			
				bunshin_port	= bunshin_port_param.getValue();
			}			

					
			final BooleanParameter	advanced = config.addBooleanParameter2( "bunshin.advanced", "bunshin.advanced", false );

			LabelParameter	advanced_label = config.addLabelParameter2( "bunshin.advanced.label" );

			final StringParameter	override_ip	= config.addStringParameter2( "bunshin.override.ip", "bunshin.override.ip", "" );

			config.createGroup( "bunshin.advanced.group",
					new Parameter[]{ advanced_label, override_ip });

			advanced.addEnabledOnSelection( advanced_label );
			advanced.addEnabledOnSelection( override_ip );			
			
			final BooleanParameter	debug = config.addBooleanParameter2( "bunshin.debug", "bunshin.debug", false );

			config.createGroup( "bunshin.logging",
					new Parameter[]{ debug });

			debug.addListener(
				new ParameterListener()
				{
					public void
					parameterChanged(
						Parameter	param )
					{
						if ( bunshin != null ){
														
							if ( debug.getValue())  bunshin.activateDebug();
							
						}
					}
				});
				
							
			
			model.getActivity().setVisible( false );
			model.getProgress().setVisible( false );
			
			log.addListener(
					new LoggerChannelListener()
					{
						public void
						messageLogged(
							int		type,
							String	message )
						{
							model.getLogArea().appendText( message+"\n");
						}
						
						public void
						messageLogged(
							String		str,
							Throwable	error )
						{
							model.getLogArea().appendText( error.toString()+"\n");
						}
					});
		
			
			PluginInterface pi_upnp = plugin_interface.getPluginManager().getPluginInterfaceByClass( UPnPPlugin.class );
			
			if ( pi_upnp == null ){

				log.log( "UPnP plugin not found, can't map port" );
				
			}else{
				
				((UPnPPlugin)pi_upnp.getPlugin()).addMapping( 
								plugin_interface.getPluginName(), 
								false, 
								bunshin_port, 
								true );
			}

			
			Thread t = 
					new AEThread( "BunshinPlugin.init" )
					{
						public void
						runSupport()
						{
							try{							
									// we take the view that if the version check failed then we go ahead
									// and enable the DHT (i.e. we're being optimistic)
								
								enabled =
									(!VersionCheckClient.getSingleton().isVersionCheckDataValid()) ||
									VersionCheckClient.getSingleton().DHTEnableAllowed();
								
								if ( enabled ){
									
									model.getStatus().setText( "Initialising" );
									
									String	ip = null;
									
									if ( advanced.getValue()){
										
										ip = override_ip.getValue().trim();
										
										if ( ip.length() == 0 ){
											
											ip = null;
										}
									}
									
								
								}else{									

									model.getStatus().setText( "Disabled administratively due to network problems" );
								}
							}finally{
								
								init_sem.releaseForever();
							}
						}
					};
					
			t.setDaemon(true);
				
			t.start();
			
			plugin_interface.addListener(
				new PluginListener()
				{
					public void
					initializationComplete()
					{
					}
					
					public void
					closedownInitiated()
					{
						if ( conn != null ){							
							
							conn.leave();
							
						}
					}
					
					public void
					closedownComplete()
					{
					}
				});

			conn = new BunshinConnection(bunshin_bootstrap.getValue(),bunshin_port);
			conn.init("bunshin.properties");
			bunshin = conn.getBunshinApp();
			
			System.out.println("-----------------------------------------------------------------------");
			System.out.println("---000000----0-----0---0-----0----0000000---0----0---00000---0-----0---");
			System.out.println("---0-----0---0-----0---0-0---0---0----------0----0-----0-----0-0---0---");
			System.out.println("---000000----0-----0---0--0--0----000000----000000-----0-----0--0--0---");
			System.out.println("---0-----0---0-----0---0---0-0----------0---0----0-----0-----0---0-0---");
			System.out.println("---000000-----00000----0-----0---0000000----0----0---00000---0-----0---");
			System.out.println("-----------------------------------------------------------------------");
			System.out.println("-----000000-----0---------0-----0-----0000000----00000-----0-----0-----");
			System.out.println("-----0-----0----0---------0-----0----0-------------0-------0-0---0-----");
			System.out.println("-----000000-----0---------0-----0----0--0000-------0-------0--0--0-----");
			System.out.println("-----0----------0---------0-----0----0------0------0-------0---0-0-----");
			System.out.println("-----0----------000000-----00000------000000-----00000-----0-----0-----");
			
			enabled = true;
			init_sem.releaseForever();
			
			status = STATUS_RUNNING;
			
		} catch (Exception e) {			
			e.printStackTrace();
		}
		
	}    
	
	public boolean
	isEnabled()
	{
		init_sem.reserve();
		
		return( enabled );
	}
	
	public boolean
	peekEnabled()
	{
		if ( init_sem.isReleasedForever()){
			
			return( enabled );
		}
		
		return( true );	// don't know yet
	}
	
	
	public void
	put(
		final byte[]						key,
		final Object						value,
		final String 						field,
		final BunshinPluginPutClient			    listener)
	{
		if ( !isEnabled()){ 
			
			throw( new RuntimeException( "Bunshin isn't enabled" ));
		}
		
		//generate Id pastry
		Id id = Utilities.generateHash(key);
		
        //listener adapter
		bunshin.put( bunshinContext, id, value, field, listener);
		
	}
	
	public void
	get(
		final byte[]								key,	
		final String								field,
		final BunshinPluginGetClient			        listener )
	{
		if ( !isEnabled()){
			
			throw( new RuntimeException( "Bunshin isn't enabled" ));
		}	
				
		//generate Id pastry
		Id id = Utilities.generateHash(key);
		//listener adapter
		bunshin.get( bunshinContext, id, field, listener );		
	}
	
	public void
	remove(
		final byte[]						 key,
		final String						 field,
		final BunshinPluginRemoveClient	         listener )
	{
        if ( !isEnabled()){
			
			throw( new RuntimeException( "Bunshin isn't enabled" ));
		}	
		
//		generate Id pastry
		Id id = Utilities.generateHash(key);
		
		bunshin.remove( id, field, listener );
	
		
	}
	

		// direct read/write support
	/*
	public void
	registerHandler(
		byte[]							handler_key,
		final DHTPluginTransferHandler	handler )
	{
		if ( !isEnabled()){
			
			throw( new RuntimeException( "DHT isn't enabled" ));
		}
		
        //generate Id pastry
		Id id = Utilities.generateHash(handler_key);
		
		bunshin.registerHandler( id, handler );
		
	}
	
	
	public byte[]
	read(
		final DHTPluginProgressListener	listener,
		final DHTPluginContact			target,
		final byte[]					handler_key,
		final byte[]					key,
		final long						timeout )
	{
		if ( !isEnabled()){
			
			throw( new RuntimeException( "DHT isn't enabled" ));
		}
		
		for (int i=1;i<dhts.length;i++){

			final int f_i	= i;
			
			new AEThread( "mutli-dht: readXfer", true )
			{
				public void
				runSupport()
				{
					dhts[f_i].read( 
							new DHTPluginProgressListener()
							{
								public void
								reportSize(
									long	size )
								{
									if ( TRACE_NON_MAIN ){
										System.out.println( "DHT_" + f_i + ":readXfer: size = " + size );
									}
								}
								
								public void
								reportActivity(
									String	str )
								{
									if ( TRACE_NON_MAIN ){
										System.out.println( "DHT_" + f_i + ":readXfer: act = " + str );
									}
								}
								
								public void
								reportCompleteness(
									int		percent )
								{
									if ( TRACE_NON_MAIN ){
										System.out.println( "DHT_" + f_i + ":readXfer: % = " + percent );
									}
								}
							},
							target, handler_key, key, timeout );
				}
			}.start();
		}
		
		return( dhts[0].read( listener, target, handler_key, key, timeout ));
	}
    */
	
	public boolean
	isExtendedUseAllowed()
	{
		if ( !isEnabled()){
			
			return( false );
		}
		
		return( VersionCheckClient.getSingleton().DHTExtendedUseAllowed());
	}
	public void
	log(
		String	str )
	{
		log.log( str );
	}

	public int getPort() {
		return bunshin_port;
	}

	public int getStatus() {
		return status;
	}
}

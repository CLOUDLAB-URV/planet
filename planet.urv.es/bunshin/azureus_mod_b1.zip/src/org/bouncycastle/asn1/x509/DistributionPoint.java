package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

/**
 * The DistributionPoint object.
 * <pre>
 * DistributionPoint ::= SEQUENCE {
 *      distributionPoint [0] DistributionPointName OPTIONAL,
 *      reasons           [1] ReasonFlags OPTIONAL,
 *      cRLIssuer         [2] GeneralNames OPTIONAL
 * }
 * </pre>
 */
public class DistributionPoint
    extends ASN1Encodable
{
	DistributionPointName   	distributionPoint;
	ReasonFlags             		reasons;
	GeneralNames            	cRLIssuer;

    public static DistributionPoint getInstance(
        ASN1TaggedObject obj,
        boolean          explicit)
    {
        return getInstance(ASN1Sequence.getInstance(obj, explicit));
    }

    public static DistributionPoint getInstance(
        Object obj)
    {
        if(obj == null || obj instanceof DistributionPoint) 
        {
            return (DistributionPoint)obj;
        }
        
        if(obj instanceof ASN1Sequence) 
        {
            return new DistributionPoint((ASN1Sequence)obj);
        }
        
        throw new IllegalArgumentException("Invalid DistributionPoint: " + obj.getClass().getName());
    }

    public DistributionPoint(
        ASN1Sequence seq)
    {
        for (int i = 0; i != seq.size(); i++)
        {
        	ASN1TaggedObject	t = (ASN1TaggedObject)seq.getObjectAt(i);
        	switch (t.getTagNo())
        	{
        	case 0:
        		distributionPoint = DistributionPointName.getInstance(t, true);
        		break;
        	case 1:
        		reasons = new ReasonFlags(DERBitString.getInstance(t, true));
        		break;
        	case 2:
        		cRLIssuer = GeneralNames.getInstance(t, true);
        	}
        }
    }
    
    public DistributionPoint(
        DistributionPointName distributionPoint,
        ReasonFlags             	reasons,
        GeneralNames            cRLIssuer)
    {
		this.distributionPoint = distributionPoint;
		this.reasons = reasons;
		this.cRLIssuer = cRLIssuer;
    }
    
    public DistributionPointName getDistributionPoint()
    {
    	return distributionPoint;
    }

	public ReasonFlags getReasons()
	{
		return reasons;
	}
	
	public GeneralNames getCRLIssuer()
	{
		return cRLIssuer;
	}
	
    public DERObject toASN1Object()
    {
		ASN1EncodableVector  v = new ASN1EncodableVector();
		
		if (distributionPoint != null)
		{
			v.add(new DERTaggedObject(0, distributionPoint));
		}

		if (reasons != null)
		{
			v.add(new DERTaggedObject(1, reasons));
		}

		if (cRLIssuer != null)
		{
			v.add(new DERTaggedObject(2, cRLIssuer));
		}

		return new DERSequence(v);
    }
}

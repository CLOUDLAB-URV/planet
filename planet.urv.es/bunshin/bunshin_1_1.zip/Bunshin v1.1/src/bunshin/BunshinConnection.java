package bunshin;

import bunshin.*;
import bunshin.util.*;
import bunshin.storage.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.channels.*;

/**
 * @(#) BunshinConnection.java
 *
 * This class wraps a connection to Bunshin substrate and is used by the application as its main
 * DHT substrate.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class BunshinConnection {
	
   	
  // ----- VARIABLES -----

  // the collection of nodes which have been created
  protected rice.p2p.commonapi.Node[] nodes;

  // the number of nodes to create
  public static int NUM_NODES = 10;

  // ----- PASTRY SPECIFIC VARIABLES -----

  // the factory for creating pastry nodes
  protected PastryNodeFactory factory;

  // the simulator, in case of direct
  protected NetworkSimulator simulator;

  // ----- TESTING SPECIFIC FIELDS -----

  // the direct protocol
  public static final int PROTOCOL_DIRECT = -138;

  // the possible network simulation models
  public static final int SIMULATOR_SPHERE = -1;
  public static final int SIMULATOR_EUCLIDEAN = -2;

  // the factory which creates pastry ids
  public static IdFactory FACTORY = new PastryIdFactory();

  // ----- PASTRY SPECIFIC FIELDS -----

  // the port to begin creating nodes on
  public static int PORT = 5009;

  // the port on the bootstrap to contact
  public static int BOOTSTRAP_PORT = 5009;

  // the procotol to use when creating nodes
  public static int PROTOCOL = DistPastryNodeFactory.PROTOCOL_WIRE;

  // the simulator to use in the case of direct
  public static int SIMULATOR = SIMULATOR_SPHERE;

  // Reference to the Pastry node
  private PastryNode pn;
  
  // the host to boot the first node off of
  public static String BOOTSTRAP_HOST = "localhost";
  
  public BunshinImpl bunshinApp;
  
  public Endpoint endPoint;
  
  public Object value;
  boolean lookupResultArrived;

  // ----- ATTEMPT TO LOAD LOCAL HOSTNAME -----
  static {
    try {
      BOOTSTRAP_HOST = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {      
    }
  }
  
  public BunshinConnection(String path) throws Exception {   
    
    Properties prop = loadProp(path);
    
    String bootHost =(String)prop.get(Context.HOST);
    if (bootHost==null) bootHost = "auto";
    
    int bootPort = Integer.parseInt((String)prop.get(Context.PORT));
    
    PastryNodeFactory fac = null;
   try {   
     fac = (PastryNodeFactory)Class.forName((String)prop.get(Context.FACTORY)).newInstance();  	
   } catch (NullPointerException e) {}
    
    int protocol = Integer.parseInt((String)prop.get(Context.PROTOCOL)); 	

    createNode(bootHost,bootPort,fac,protocol);
  }
  
  public BunshinConnection(Properties prop) throws Exception { 
  
    String bootHost =(String)prop.get(Context.HOST);
    if (bootHost==null) bootHost = "auto";
    
    int bootPort = Integer.parseInt((String)prop.get(Context.PORT));
  
   PastryNodeFactory fac = null;
   try {   
     fac = (PastryNodeFactory)Class.forName((String)prop.get(Context.FACTORY)).newInstance();  	
   } catch (NullPointerException e) {}
    
    int protocol = Integer.parseInt((String)prop.get(Context.PROTOCOL)); 	

    createNode(bootHost,bootPort,fac,protocol);
  }
  
  public BunshinConnection(String bootHost, int bootPort, PastryNodeFactory fac, int protocol) { 
    createNode(bootHost,bootPort,fac,protocol);
  }
  
  private Properties loadProp(String path) throws Exception {
  	FileInputStream  fis = new FileInputStream(path);
	Properties prop = new Properties();
	prop.load(fis);
	fis.close();	  	
  	return prop;
  }

  /**
   * This method creates a new node which will serve as the underlying p2p layer
   *
   * @param args Constructor arguments: 0 - String bootstrap host; 1 - int bootstrap port; 2 - PastryNodeFactory factory; 3 - int protocol   
   */
  public void createNode (String bootHost, int bootPort, PastryNodeFactory fac, int protocol) { 

    if (!bootHost.equalsIgnoreCase ("auto")) {
      BOOTSTRAP_HOST = bootHost;
    }
    BOOTSTRAP_PORT = bootPort;
    PROTOCOL = protocol;

    if (SIMULATOR == SIMULATOR_SPHERE) {
      simulator = new SphereNetwork();
    } else {
      simulator = new EuclideanNetwork();
    }

    if (PROTOCOL == PROTOCOL_DIRECT) {
      factory = new DirectPastryNodeFactory (new RandomNodeIdFactory(), simulator);
      nodes = new Node[NUM_NODES];
    }

    // If Id factory is null, a new one is created
    if (fac == null) {
      int newPort = PORT;

      // If working in remote mode, check if port is already bound (this way
      // we allow several Dermis running on the same machine)
      if (PROTOCOL != PROTOCOL_DIRECT) {
        while (true) {
          DatagramChannel channel = null;
          try {
            channel = DatagramChannel.open();
            channel.configureBlocking (false);
            InetSocketAddress isa = new InetSocketAddress (newPort);
            channel.socket().bind (isa);
            channel.socket().close();
            channel.close();

            factory = DistPastryNodeFactory.getFactory (new RandomNodeIdFactory(), PROTOCOL, newPort);
            break;
          } catch (IOException e) {
            newPort += 100;
            System.out.println ("Port " + (newPort - 100) + " already bound. Trying " + newPort + "...");
          }
          finally {
            channel.socket().close();
            try {
              channel.close();
            }
            catch (IOException ex) {
             
            }
          }
        }
      }
    }
    else {
      factory = fac;
    }

    // Get bootstrap reference
    rice.pastry.NodeHandle bootstrap = getBootstrap();

    pn = factory.newNode (bootstrap);   // internally initiateJoins    
 
  }

  /**
   * Gets a handle to a bootstrap node.
   *
   * @return handle to bootstrap node, or null.
   */
  protected rice.pastry.NodeHandle getBootstrap() {
    if (PROTOCOL == PROTOCOL_DIRECT) {
      return ((DirectPastryNode) nodes[0]).getLocalHandle();
    } else {
      InetSocketAddress address = new InetSocketAddress (BOOTSTRAP_HOST, BOOTSTRAP_PORT);
      return ((DistPastryNodeFactory) factory).getNodeHandle (address);
    }
  }  

  public void init(String id, StorageManager manager, int replicaFactor) {
    bunshinApp = new BunshinImpl(id);    
    bunshinApp.setStorageManager(manager);
    bunshinApp.setReplicationFactor(replicaFactor);
    endPoint = pn.registerApplication (bunshinApp,id);
    bunshinApp.setEndPoint (endPoint);    
  }   
  
  public void init(String path) throws Exception{
  	
  	Properties prop = loadProp(path);
  	
  	String id =(String)prop.get(Context.ID_APPLICATION);
  	StorageManager manager = (StorageManager)Class.forName((String)prop.get(Context.STORAGE_MANAGER)).newInstance();  	
  	int replicaFactor = Integer.parseInt((String)prop.get(Context.REPLICA_FACTOR));
  	
  	init(id,manager,replicaFactor);  	
  }

  
  public Id storeObject(String id, Serializable value) {
  	return storeObject(id,value,true);
  }

  public void storeObject(Id id, Serializable value) {
    bunshinApp.put(id,value,true);  	
  }
  
  public Id storeObject(String id, Serializable value, boolean exclusive) {
  	Id key = Utilities.generateHash(id);	
    bunshinApp.put(key,value,exclusive);  	
    return key;
  }
  
  //synchron method!!
  public Object retrieveObject(String id) throws IOException {
  	Id key = Utilities.generateHash(id);	
  	return retrieveObject(key);
  }	
  
  //synchron method!!
  public Object retrieveObject(Id key) throws IOException {  	  	
  	
  	  int timeout = 0;
      lookupResultArrived = false;   
         

      bunshinApp.get(key,new BunshinClient() {
        public void get (Object result) {
          synchronized (this) {
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                // Get first value!!! (it should MERGE all values, and return them)
                value =((bunshin.util.Values) result).get(0);
              }
              else {
                value = result;
              }
            }
            else {
              value = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived && timeout < 30) {
          try {
            Thread.sleep (100);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
     
       return value;
    }
    
  
  //very simple methods

  public void storeString(String value) throws IOException {
  		
  	Id key = Utilities.generateHash(value);	
    bunshinApp.put(key,value,true);
  }

  //asynchron method!!
  public void retrieveString(String value, BunshinClient client) throws IOException {
  	Id key = Utilities.generateHash(value);
  	bunshinApp.get(key, client);
  }
  
  public void removeString(String value) throws IOException {
  	Id key = Utilities.generateHash(value);
  	bunshinApp.remove(key);
  }
  
  public void removeObject(Id idValue) throws IOException {
  	bunshinApp.remove(idValue);
  }
  
  public void leave() {
  	bunshinApp.leave();
  }

  
}

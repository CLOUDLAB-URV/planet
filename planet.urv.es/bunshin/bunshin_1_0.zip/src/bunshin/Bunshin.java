package bunshin;

import rice.p2p.commonapi.*;

/**
 * @(#) Bunshin.java
 *
 * This interface is exported by all instances of Bunshin DHT. 
 * 
 * @author Ruben Mondejar
 */
public interface Bunshin {

  /**
   * Stores the (key,value) pair in the Bunshin DHT
   *
   * @param key Id of the value
   * @param value Object to store
   * @param exclusive removes possible previous values (if any)
   */
  public void put(Id key, Object value, boolean exclusive);

  /**
   * Removes the values with a specific key
   *
   * @param key Id of the value   
   */
  public void remove(Id key);

  /**
   * Returns the values with a specific key and sets the Client application 
   *
   * @param key Id of the value 
   * @param client listener that implements BunshinClient 
   */
  public void get(Id key, BunshinClient client);
  
  /**
   * Removes the Client application for this Bunshin DHT 
   *
   * @param key of the value
   * @param client listener that implements BunshinClient 
   * @return true if the value has been remove
  */
  public boolean removeClient(Id key, BunshinClient client);
  
  /**
   * Before leaving the network, the application must call to this method
   * 
   */
  public void leave();
  
  
  /**
   * Sets the number of replicas  
   *
   * @param the number of replicas 
   */
  public void setReplicationFactor(int replicas);
  
  /**
   * Sets the storage manager
   *
   * @param storage manager
   */  
   public void setStorageManager(StorageManager storage);
 	
  /**
   * Returns the number of replicas used 
   *
   * @return the number of replicas 
   */
  public int getReplicationFactor();
  
  
  public void setEndPoint (Endpoint ep);

  }


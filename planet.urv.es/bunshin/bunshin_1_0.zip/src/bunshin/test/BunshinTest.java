package bunshin.test;

import bunshin.*;
import bunshin.util.*;

import rice.p2p.commonapi.*;

import rice.pastry.PastryNode;
import rice.pastry.PastryNodeFactory;
import rice.pastry.commonapi.*;
import rice.pastry.dist.*;
import rice.pastry.standard.*;
import rice.pastry.direct.*;

import java.io.*;
import java.net.*;
import java.nio.channels.*;

/**
 * @(#) BunshinTest.java
 *
 * This main class executes a test with a three diffreent rols. The first rol is a 
 * simple Pastry node and Bunshin application registered. In the second rol the application 
 * also stores a String in the DHT. The last rol restore the String with the given key.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class BunshinTest {
	
   	
  // ----- VARIABLES -----

  // the collection of nodes which have been created
  protected rice.p2p.commonapi.Node[] nodes;

  // the number of nodes to create
  public static int NUM_NODES = 10;

  // ----- PASTRY SPECIFIC VARIABLES -----

  // the factory for creating pastry nodes
  protected PastryNodeFactory factory;

  // the simulator, in case of direct
  protected NetworkSimulator simulator;

  // ----- TESTING SPECIFIC FIELDS -----

  // the direct protocol
  public static final int PROTOCOL_DIRECT = -138;

  // the possible network simulation models
  public static final int SIMULATOR_SPHERE = -1;
  public static final int SIMULATOR_EUCLIDEAN = -2;

  // the factory which creates pastry ids
  public static IdFactory FACTORY = new PastryIdFactory();

  // ----- PASTRY SPECIFIC FIELDS -----

  // the port to begin creating nodes on
  public static int PORT = 5009;

  // the port on the bootstrap to contact
  public static int BOOTSTRAP_PORT = 5009;

  // the procotol to use when creating nodes
  public static int PROTOCOL = DistPastryNodeFactory.PROTOCOL_WIRE;

  // the simulator to use in the case of direct
  public static int SIMULATOR = SIMULATOR_SPHERE;

  // Reference to the Pastry node
  private PastryNode pn;
  
  // the host to boot the first node off of
  public static String BOOTSTRAP_HOST = "localhost";
  
  public BunshinImpl bunshinApp;
  
  public Endpoint endPoint;
  
  public Object value;
  boolean lookupResultArrived;

  // ----- ATTEMPT TO LOAD LOCAL HOSTNAME -----
  static {
    try {
      BOOTSTRAP_HOST = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {      
    }
  }

  /**
   * This method creates a new node which will serve as the underlying p2p layer
   *
   * @param args Constructor arguments: 0 - String bootstrap host; 1 - int bootstrap port; 2 - PastryNodeFactory factory; 3 - int protocol
   * @throws ConnectionException If connection cannot be established against the bootstrap
   */
  public BunshinTest (String bootHost, int bootPort, PastryNodeFactory fac, int protocol) { 

    if (!bootHost.equalsIgnoreCase ("auto")) {
      BOOTSTRAP_HOST = bootHost;
    }
    BOOTSTRAP_PORT = bootPort;
    PROTOCOL = protocol;

    if (SIMULATOR == SIMULATOR_SPHERE) {
      simulator = new SphereNetwork();
    } else {
      simulator = new EuclideanNetwork();
    }

    if (PROTOCOL == PROTOCOL_DIRECT) {
      factory = new DirectPastryNodeFactory (new RandomNodeIdFactory(), simulator);
      nodes = new Node[NUM_NODES];
    }

    // If Id factory is null, a new one is created
    if (fac == null) {
      int newPort = PORT;

      // If working in remote mode, check if port is already bound (this way
      // we allow several Dermis running on the same machine)
      if (PROTOCOL != PROTOCOL_DIRECT) {
        while (true) {
          DatagramChannel channel = null;
          try {
            channel = DatagramChannel.open();
            channel.configureBlocking (false);
            InetSocketAddress isa = new InetSocketAddress (newPort);
            channel.socket().bind (isa);
            channel.socket().close();
            channel.close();

            factory = DistPastryNodeFactory.getFactory (new RandomNodeIdFactory(), PROTOCOL, newPort);
            break;
          } catch (IOException e) {
            newPort += 100;
            System.out.println ("Port " + (newPort - 100) + " already bound. Trying " + newPort + "...");
          }
          finally {
            channel.socket().close();
            try {
              channel.close();
            }
            catch (IOException ex) {
             
            }
          }
        }
      }
    }
    else {
      factory = fac;
    }

    // Get bootstrap reference
    rice.pastry.NodeHandle bootstrap = getBootstrap();

    pn = factory.newNode (bootstrap);   // internally initiateJoins
 
  }

  /**
   * Gets a handle to a bootstrap node.
   *
   * @return handle to bootstrap node, or null.
   */
  protected rice.pastry.NodeHandle getBootstrap() {
    if (PROTOCOL == PROTOCOL_DIRECT) {
      return ((DirectPastryNode) nodes[0]).getLocalHandle();
    } else {
      InetSocketAddress address = new InetSocketAddress (BOOTSTRAP_HOST, BOOTSTRAP_PORT);
      return ((DistPastryNodeFactory) factory).getNodeHandle (address);
    }
  }


  public void registerApplication() {
    bunshinApp = new BunshinImpl("Bunshin");    
    bunshinApp.setStorageManager(new MemStorage());
    bunshinApp.setReplicationFactor(3);
    endPoint = pn.registerApplication (bunshinApp, "Bunshin");
    bunshinApp.setEndPoint (endPoint);    
  }
  
  
  public Id storeObject(String id, Object value) {
  	return storeObject(id,value,true);
  }
  
  public Id storeObject(String id, Object value, boolean exclusive) {
  	Id key = Utilities.generateHash(id);	
    bunshinApp.put(key,value,exclusive);  	
    return key;
  }
  
  //synchron method!!
  public Object retrieveObject(String id) throws IOException {
  	Id key = Utilities.generateHash(id);	
  	return retrieveObject(key);
  }	
  
  //synchron method!!
  public Object retrieveObject(Id key) throws IOException {  	  	
  	
  	  int timeout = 0;
      lookupResultArrived = false;   
         

      bunshinApp.get(key,new BunshinClient() {
        public void get (Object result) {
          synchronized (this) {
            if (result != null) {
              if (result instanceof bunshin.util.Values) {
                // Get first value!!! (it should MERGE all values, and return them)
                value =((bunshin.util.Values) result).get(0);
              }
              else {
                value = result;
              }
            }
            else {
              value = null;
            }
            lookupResultArrived = true;
          }
        }
      }
      );

      synchronized (this) {
        while (!lookupResultArrived && timeout < 30) {
          try {
            Thread.sleep (100);
          }
          catch (InterruptedException ex) {
          }
          timeout++;
        }
      }
     
       return value;
    }
    
   
  
  
  
  //very simple methods

  public void storeString(String value) throws IOException {
  		
  	Id key = Utilities.generateHash(value);	
    bunshinApp.put(key,value,true);
  }

  public void retrieveString(String value) throws IOException {
  	Id key = Utilities.generateHash(value);
  	bunshinApp.get(key,new BunshinApplication(key));
  }
  
  public void removeString(String value) throws IOException {
  	Id key = Utilities.generateHash(value);
  	bunshinApp.remove(key);
  }
  
  public void leave() {
  	bunshinApp.leave();
  }

  public static void main(String args[]) {

  	BufferedReader dis = new BufferedReader(new InputStreamReader (System.in));
  	
    BunshinTest c = new BunshinTest("auto",5009,null,1);
    boolean end = false;
    int whatToDo = (Integer.valueOf(args[0])).intValue();
    System.out.println("whatToDo == "+whatToDo);
    if (whatToDo==0) {
      try {
       
        c.registerApplication();
        System.out.println("Prem <RETURN> per finalitzar...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      }
    }
    else if (whatToDo==1){
      try {
        
        c.registerApplication();

      	System.out.println ("Enter the String to store...");
    	String input = dis.readLine();    	
        c.storeString(input);
         
        System.out.println("Prem <RETURN> per finalitzar...");
        System.in.read();
        c.leave();
      }
      catch (IOException ex) {
      	ex.printStackTrace();
      }
    }
    else if (whatToDo==2){
        try {
        
          c.registerApplication();

      	  System.out.println ("Enter the String to retrieve" +
      	  		"...");
          String input = dis.readLine();
          c.retrieveString(input);
  
          System.out.println("Prem <RETURN> per finalitzar...");
          System.in.read();
          c.leave();
        }
        catch (IOException ex) {
        	ex.printStackTrace();
        }
      }
    else if (whatToDo==3){
        try {
        
          c.registerApplication();

      	  System.out.println ("Enter the String to remove" +
      	  		"...");
          String input = dis.readLine();
          c.removeString(input);
  
          System.out.println("Prem <RETURN> per finalitzar...");
          System.in.read();
          c.leave();
        }
        catch (IOException ex) {
        	ex.printStackTrace();
        }
      }
    System.exit(0);
  }
}

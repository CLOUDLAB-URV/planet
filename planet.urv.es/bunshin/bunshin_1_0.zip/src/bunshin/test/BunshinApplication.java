package bunshin.test;

import bunshin.*;
import rice.p2p.commonapi.*;

/**
 * @(#) BunshinApplication.java
 *
 * This class implements the interface BunshinClient, when the method
 * get is called, the result will be print on the standart out
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class BunshinApplication implements BunshinClient {     
    
	private Id id;
	
	public BunshinApplication(Id id) {
	  this.id = id;	
	}	
	
	public void get(Object value) {
      System.out.println("Get value returned! [ key : "+id+" value : "+value+"]");
    }

}
package bunshin.util;

import rice.p2p.commonapi.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @(#) Bucket.java
 *
 * The bucket, a chunk of hashtable, to belongs to specific key's rank
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Bucket implements java.io.Serializable {
	
	private Hashtable bucket;
	
	public Bucket() {
	  bucket = new Hashtable();
	} 
		
	public Map getMap() {
	  return bucket;
	}
	
	public int size() {
	  return bucket.size();	
	}
	
	public void add(Bucket newBucket) {
	  if (newBucket.size()>0) bucket.putAll(newBucket.getMap());	
	}
	
	public synchronized void insert(Id key, Object value) {
               
	  if (bucket.containsKey(key))  {
	  	
	    Values values = (Values) bucket.get(key);
	    if (!values.contains(value)) {
	      if (value instanceof Values) {
	      	 values.addAll((Collection)value);
	      }
	      else {
	        values.add(value);
	      }
	      bucket.put(key,values);
	    }	    
	  }		  
	  else {
	  	
	  	Values values;
	  	if (value instanceof Values) {
	      values = (Values) value;
	    }
	  	else {
	  	  values = new Values();
	  	  values.add(value);
	  	}  	
	    
	    bucket.put(key,values);		
	  }		
    }
	
	public synchronized void overwrite(Id key, Object value) {
        
    if (bucket.containsKey(key))
    	bucket.remove(key);
	
 	  Values values;
      if (value instanceof Values) {
       values = (Values) value;
      }
	  else { 
	  	values = new Values();
	  	values.add(value);
	  }	
      
      bucket.put(key,values);		
		
    }
	

          	
	public synchronized Object remove(Id key) {   
       return bucket.remove(key);                
       	    	  
    }
            
   	public synchronized Object load(Id key) {
 	
   		Object obj = bucket.get(key);
	    while (obj instanceof Values) obj = ((Values) obj).get(0);
	    
	    
		return obj;	  
    }   
   	
   	public synchronized Values extract(Id key) {   	 	
   		    return (Values) bucket.get(key);   		  
   	}   
   	   	
   	
   	
   	public synchronized Set valueSet() {
   	  HashSet set = new HashSet();
   	  Iterator it = bucket.values().iterator();   	  
   	  while(it.hasNext()) {
   	    Collection c = (Collection)it.next();
   	    set.addAll(c);	
   	  }   	  
   	  return set;   	  
   	}
   	
//   	public synchronized Iterator iterator() {
//   	  return bucket.keySet().clone().iterator();
//   	}
  
    public synchronized Set keySet() {
   	  return bucket.keySet();
   	}
  
   	
   	public String toString() {
   	  return "Bucket : "+bucket.toString();	
   	}
        
      
}
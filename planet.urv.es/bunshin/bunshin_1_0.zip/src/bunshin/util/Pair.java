package bunshin.util;

import java.util.*;
import java.io.*;
import rice.p2p.commonapi.*;

/**
 * @(#) Pair.java
 *
 * Pair Key/Values 
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Pair implements Serializable {
	
	private Id key;
	private Values values;
	
	public Pair(Id key, Values values) {
	  this.key=key;
	  this.values=values;
	}
	
	public Id getKey () {
		return key;
	}
	
	public Values getValues(){
		return values;
	}
}

package bunshin.util;

import java.util.*;
 
/**
 * @(#) Values.java
 *
 * Values of a given key in a bucket
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class Values extends Vector {}
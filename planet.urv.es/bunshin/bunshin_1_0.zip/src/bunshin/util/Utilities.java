package bunshin.util;

import rice.p2p.commonapi.*;
import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @(#) Utilities.java
 *
 * Util methods used in the bunshin classes
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */
 
public class Utilities {
	
	public static Collection convert(NodeHandleSet set) {
	   int size = set.size();	
	   Vector v = new Vector(size);	
	   
	   for (int i=0;i<size;i++) {
	   	  NodeHandle nh =  set.getHandle(i);
	   	  v.add(nh);	   	
	   }	   
	   return v;
	}	

    public static Id generateHash (String data) {
      MessageDigest md = null;

      try {
        md = MessageDigest.getInstance("SHA");
      }
      catch (NoSuchAlgorithmException e) {
        System.err.println("No SHA support!");
      }

      md.update(data.getBytes());
      byte[] digest = md.digest();

      Id newId = new rice.pastry.NodeId(digest);

      return newId;
    }
    
  
}	
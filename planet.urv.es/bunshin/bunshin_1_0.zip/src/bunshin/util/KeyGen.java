package bunshin.util;

/**
 * @author Ruben Mondejar
 *
 */

public class KeyGen implements java.io.Serializable {

  private static int cnt, ini, MAX;

  public KeyGen (int ini_value, int max) {
    cnt = ini = ini_value;
    MAX = max;
  }

  public static String generateKey() {
    cnt++;
    if (cnt>MAX) cnt = ini;

    return Integer.toString(cnt);
  }
}

package bunshin.messaging;

import bunshin.util.*;
import rice.p2p.commonapi.*;

/**
 * @(#) PutBucketMessage.java
 *
 * The put bucket message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PutBucketMessage implements Message {

  private String messageId;
  private Bucket bucket = null;
  private int phase;
  private NodeHandle nh = null;
	
  public PutBucketMessage(String messageId, NodeHandle nh, int phase) {  	
  	
  	this.phase = phase;
  	this.messageId = messageId;
  	
 
    this.nh = nh;  
  }  
  
  public PutBucketMessage(Bucket bucket) {  	
  	
  	this.phase = 3;  	
    this.bucket = bucket;
 
  }  
  
  public String getMessageId() {
  	return messageId;
  }
  
  public int getPhase() {
  	return phase;
  }
  
  public Bucket getBucket() {
  	return bucket;
  }
  
  public NodeHandle getNH() {
  	return nh;  	
  }
  
  public String toString() {
    return "PutBucketMessage "+bucket;
  }

}
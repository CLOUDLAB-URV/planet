package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) RemoveMessage.java
 *
 * The remove message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class RemoveMessage implements Message {

  private Id key;
	
  public RemoveMessage(Id key) {  	
  	this.key = key;     
  }  
  
  public Id getKey() {
  	return key;  	
  }

  
  public String toString() {
    return "RemoveMessage "+key;
  }

}
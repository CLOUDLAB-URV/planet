package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) ReplicaMessage.java
 *
 * The replica message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class ReplicaMessage implements Message {

  private Id key;
  private Object value;
  private NodeHandle source;
	
  public ReplicaMessage(Id key, Object value, NodeHandle source) {  	
  	this.key = key;  
  	this.value = value;
  	this.source = source;
  }  
  
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public NodeHandle getNH() {
  	return source;
  }
  
  public String toString() {
    return "ReplicaMessage from :"+source+" with key "+key+" value : "+value;
  }

}

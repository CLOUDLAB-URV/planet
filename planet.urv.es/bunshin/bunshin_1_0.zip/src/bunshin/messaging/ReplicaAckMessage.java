package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) ReplicaAckMessage.java
 *
 * The replica ack message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class ReplicaAckMessage implements Message {

  private Id key;
  private Object value;
  private NodeHandle source;
	
  public ReplicaAckMessage(Id key, NodeHandle source) {  	
  	this.key = key;  
  	this.source = source;
  }  
  
  public Id getKey() {
  	return key;  	
  }
  
 
  public NodeHandle getNH() {
  	return source;
  }
  
  public String toString() {
    return "ReplicaAckMessage from :"+source+" with key "+key;
  }

}
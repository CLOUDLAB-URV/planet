package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) ReplicaRemoveMessage.java
 *
 * The replica remove message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class RemoveReplicaMessage implements Message {

  private Id key;
  private Object value;
  private NodeHandle source;
	
  public RemoveReplicaMessage(NodeHandle nh, Id key) {  	
    this.source = nh;
  	this.key = key;    	
  }  
  
  public Id getKey() {
  	return key;  	
  }
  
  public NodeHandle getNH() {
  	return source;
  }
  
  public String toString() {
    return "ReplicaRemoveMessage key "+key;
  }

}

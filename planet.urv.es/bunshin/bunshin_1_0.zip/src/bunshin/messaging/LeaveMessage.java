package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) LeaveMessage.java
 *
 * The leave message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class LeaveMessage implements Message {

  private NodeHandle source = null;
  protected Object content = null;
	
  public LeaveMessage(NodeHandle source) {  	
  	this.source = source;  
  }
  
  public LeaveMessage(NodeHandle source, Object content) {  	
  	this.source = source;  
  	this.content=content;
  	
  }  
  
  public NodeHandle getNH() {
  	return source;
  }
      
  public boolean isContent(){
  	return content!=null;
  }
  
  public Object getContent() {
  	return content;
  }
  
  public String toString() {
    return "LeaveMessage from "+source+" content "+content;
  }

}
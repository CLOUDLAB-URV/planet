package bunshin.messaging;

/**
 * @(#) GetMessage.java
 *
 * The get message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

import rice.p2p.commonapi.*;

public class GetMessage implements Message {

  private String messageId;
  private Id key;
  private Object value = null;
  private int phase;
  private NodeHandle nh = null;
	
  public GetMessage(Id key, NodeHandle nh) {  	
  	
  	this.phase = 1;	
    this.key = key;
    this.nh = nh; 
    
  }  
  
  public GetMessage(Id key, Object value) {  	
  	
  	this.phase = 2;  	
    this.key = key;
    this.value = value; 
    
  }  
  
  public int getPhase() {
  	return phase;
  }
  
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public NodeHandle getNH() {
  	return nh;  	
  }
  
  public String toString() {
    return "GetMessage"+phase+" key : "+key+":"+value;
  }

}
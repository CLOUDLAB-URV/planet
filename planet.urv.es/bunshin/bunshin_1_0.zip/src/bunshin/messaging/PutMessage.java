package bunshin.messaging;

import rice.p2p.commonapi.*;

/**
 * @(#) PutMessage.java
 *
 * The put message.
 *
 * @author Ruben Mondejar  <Ruben.Mondejar@estudiants.urv.es>
 */

public class PutMessage implements Message {

  private Id key;
  private Object value = null;
  private boolean ex;
  
  public PutMessage(Id key, Object value, boolean ex) {  	
    this.key = key;
    this.value = value; 
    this.ex = ex;
  }  
 
  public Id getKey() {
  	return key;  	
  }
  
  public Object getValue() {
  	return value;
  }
  
  public boolean isExclusive() {
  	return ex;
  }
  
  public String toString() {
    return "PutMessage key "+key+" : "+value;
  }

}
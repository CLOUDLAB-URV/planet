package bunshin;

import bunshin.util.*;
import bunshin.messaging.*;
import java.util.*;

import rice.p2p.commonapi.*;


/**
 * @(#) BunshinImpl.java 
 *
 *  The provided implementation of Bunshin DHT.
 * 
 * @author <a href="mailto: ruben.mondejar@estudiants.urv.es">Ruben Mondejar </a>
 *	 
 */

public class BunshinImpl implements Bunshin, Application {
	
  // My data
  //private Bucket = new Bucket();
  private StorageManager storage;
  
  // Information about the nodes that replicate my data  
  private Bucket replicaNHs = new Bucket();
  
  // replicas from other nodes  
  private Hashtable replicaBuckets = new Hashtable(); //Node Id --> Bucket of pairs (key,value)
  private Hashtable replicaIdNH = new Hashtable();    //Node Id --> NodeHandle
  private Hashtable replicaKeyOwner = new Hashtable();  //Key --> Node Id
  
  private Endpoint endPoint = null;
  
  
  
  private PeriodicTask refreshTask = new PeriodicTask();

  private Timer timer = new Timer();
  
  private boolean first = true;
   
  private int time = 3000;
  
  private int replicationFactor = 1;
  
  
  // In the key's movement when a node send keys to another node this variable indicates if is a exclusive put
  
  private boolean EXCLUSIVE = true;
  
  /**
   * Identification of the application.
   */
  public static String applicationId= "DHT";
  /**
   * Identification of the application instance.
   */
  private String appId = applicationId;
  
  /**
   * Bunshin Clients
  */
  Hashtable clients = new Hashtable();
  
  
  
  /**
   * Constructor
   */
  public BunshinImpl() {  	
  }
  
  public BunshinImpl(String name) {
  	this.appId = name;
  }
  
  public void setId(String name) {
  	this.appId = name;
  }
  
   public boolean removeClient(Id key, BunshinClient client) {
    
    Vector id_clients;
  	
  	if (!clients.containsKey(key)) return false;
  	else id_clients =  id_clients = (Vector) clients.get(key);
  	
  	id_clients.remove(client);
  	clients.put(key,id_clients);
  	
  	return true;
  }
  
  /**
   * Gets the identification of the Application
   * @see planet.commonapi.Application#getId()
   */
  public String getId() {
   return appId; 
  }  
  
  public void setEndPoint (Endpoint ep) {
    endPoint = ep;	
    if (first) timer.schedule(refreshTask,0,time);
    else first=false;
    
    System.out.println("I'm node "+endPoint.getLocalNodeHandle().getId());
  }
  
  public void setStorageManager(StorageManager storage) {
  	this.storage = storage;
  }
  
  /**
   * Returns whether or not is the owner for the given key
   *
   * @param key The key in question
   * @return Whether or not we are currently the root
   */
   public boolean isOwner(Id key) {
    	NodeHandleSet set = endPoint.replicaSet(key, 1);

        if (set==null)
          return false;
        else {
          Id x = endPoint.getId();
         
          NodeHandle nh = set.getHandle(0);
          if (nh==null) {          	
          	return false;
          }	
          return nh.getId().equals(x);	
        }
          
    
  }
   
  /** 
   *  Sends to the first node of the replicaSet a special message to check if that have the replicated keys.
   * Remaining nodes are going to receive a normal message. 
   * 
   */
  public void leave () {
  	
  	timer.cancel(); 
  	
  	//missatge al meu succesor!!
  	NodeHandle myNH = endPoint.getLocalNodeHandle();  	
  	Collection c = Utilities.convert(endPoint.replicaSet(myNH.getId(),2));
  	Iterator it = c.iterator();
  	it.next();
  	NodeHandle nextRoot = null;
  	if (it.hasNext()) {
  	  nextRoot = (NodeHandle) it.next(); 	
  	  LeaveMessage message = new LeaveMessage(myNH,storage.getBucket());  	
  	  endPoint.route(null,message,nextRoot);  	  
  	  System.out.println("Leave message "+message+" to "+nextRoot);
  	   	
      message = new LeaveMessage(myNH);   	
      it = replicaNHs.valueSet().iterator();  

   	  while(it.hasNext()) { 	  	
   	    NodeHandle to = (NodeHandle) it.next(); 	    
   	    if (!to.getId().equals(nextRoot.getId())) {
   	    	endPoint.route(null,message,to); 	    	
   	    }
   	  }
   	 
  	}
 
  }
  
  /**
   * Sets the number of replicas  
   *
   * @param the number of replicas 
   */
  public void setReplicationFactor(int replicas) {
  	replicationFactor=replicas;
  }
  
  /**
   * Returns the number of replicas used 
   *
   * @return the number of replicas 
   */
  public int getReplicationFactor() {
  	return replicationFactor;
  }
  
  /**
   * Checks that is the owner all keys are already  
   */  
  private void checkMyKeys(){
  	Bucket store = storage.getBucket();
  	Vector v = new Vector(store.keySet());
  	for(int i=0; i<v.size();i++) {
  	  Id key = (Id) v.get(i);
  	  if (!isOwner(key)) {
  	  	try {  	  	
  	  	  undoReplica(key);
  	  	  Object obj = storage.remove(key);
  	  	  //put the all values 
  	  	  put(key,obj,EXCLUSIVE);
  	  	} catch(StorageException ex) {
  	  		//non-critical exception
  	  	}
  	  }
  	}    	
  }
  
  private Collection remFailNH(Collection c) {
  	Collection c2 = new Vector();
  	Iterator it2 = c.iterator();
	while (it2.hasNext()) {
	  NodeHandle nh = (NodeHandle) it2.next();
	  if (nh.isAlive()) {
	  	c2.add(nh);
	  }	
	}	
	return c2;
  }  
  
  private void addReplica(Id key, Collection c) {  	

    NodeHandle localNH = endPoint.getLocalNodeHandle();
    Object obj = storage.retreive(key);
  	Collection v = Utilities.convert(endPoint.replicaSet(key,replicationFactor+1));  
  	v.removeAll(c);
  	Iterator it = v.iterator();
  	if (it.hasNext()) {
  	   NodeHandle nh = (NodeHandle) it.next();
  	   if (nh!=null) {
  	   	 c.add(nh);  	   	 
  	   	 //new replica try sended
  	   	 endPoint.route(null,new ReplicaMessage(key,obj,localNH),nh);  	   	 
  	   }
    }
  }
  
  /**
   * Checks the replica nodes that stores my keys/values  
   */
  private void checkMyReplicas() {  	  	
  	Bucket store = storage.getBucket();
  	Vector v = new Vector(store.keySet());
  	for(int i=0; i<v.size();i++) {
  	  Id key = (Id) v.get(i);
  	  Collection nhs = (Collection) replicaNHs.extract(key);  		  		
  	  if (nhs!=null) {
      //Check to find some failed node
        Collection nhs2 = remFailNH(nhs);
      //Chech to find a not suficient number of copies of some key		  
        //System.out.println(nhs2.size()+" < "+replicationFactor+"?");
        int tries = replicationFactor - nhs2.size();
	  	for (int j=0;j<tries;j++) {
	      addReplica(key,nhs2);  		  
	  	}  	
  	  }
  	}
  }	
  
  private void checkReplicas() {
    Vector v = new Vector(replicaIdNH.values());
  	for(int i=0; i<v.size();i++) {
  	  NodeHandle nh = (NodeHandle) v.get(i);  	  
	  if (!nh.isAlive()) {
	  	//System.out.println("id "+endPoint.getId()+" checkReplica of "+nh+" is alive ?"+nh.isAlive());
	    replicaIdNH.remove(nh.getId());
	    
	    Bucket replicas = (Bucket) replicaBuckets.remove(nh.getId());
	    
	    Vector c = new Vector(replicas.keySet());
	  	while(!c.isEmpty()) {
	  	  Id key = (Id) c.firstElement();	  	  
	  	  Object obj = replicas.remove(key);	  	  
	  	  c.remove(key);
	  	  replicaKeyOwner.remove(key);
	  	  put(key,obj,EXCLUSIVE);	  	  
	  	} 
	  }
	}    	
  }
  
  /**
   * This method is invoked to inform the application that the given node has either joined or left
   * the neighbor set of the local node, as the set would be returned by the neighborSet call.
   *
   * @param handle The handle that has joined/left
   * @param joined Whether the node has joined or left
   */
  public void update(NodeHandle handle, boolean joined) {
  	   
  	  
      if (joined){      	
      	//only checkMyKeys();
      	refresh(1);
      	//System.out.println ("Update node ["+endPoint.getId()+"] : "+handle+" joined ");
      }
      else {
      	//call to  checkMyReplicas() &  	checkReplicas()
      	refresh(2);
      	//System.out.println ("Update node ["+endPoint.getId()+"] : "+handle+" left ");
      }   
      

  }
  
  /**
   * This method is invoked on applications when the underlying node
   * is about to forward the given message with the provided target to
   * the specified next hop.  Applications can change the contents of
   * the message, specify a different nextHop (through re-routing), or
   * completely terminate the message.
   *
   * @param message The message being sent, containing an internal message
   * along with a destination key and nodeHandle next hop.
   *
   * @return Whether or not to forward the message further
   */
  public boolean forward(Message message) {
    //System.out.println ("Forward app ["+appId+"] node ["+endPoint.getId()+"]");
    return true;
  }
  
  public boolean forward(RouteMessage message) {
    //System.out.println ("Forward app ["+appId+"] node ["+endPoint.getId()+"]");
    //System.out.println ("RouteMessage, prev : ["+message.getPrevNodeHandle()+"], next : ["+message.getNextHopHandle()+"]");
    return true;
  }

  /**
   * This method is called on the application at the destination node
   * for the given id.
   *
   * @param id The destination id of the message
   * @param message The message being sent
   */
  public void deliver (Id id, Message message) {
  	
  	Id key;
  	Object value;
  	
  	//System.out.println ("Deliver app ["+appId+"] node ["+endPoint.getId()+"] \nmessage : "+message);
  	  	
    if (message instanceof PutMessage) {
    	
      PutMessage mesg = (PutMessage) message; 
      try {
        if (!mesg.isExclusive()) storage.insert(mesg.getKey(),mesg.getValue());
   	    else storage.overwrite(mesg.getKey(),mesg.getValue());
        //send replicas      
        System.out.println("I'm the owner of the "+mesg.getValue());
        replicate(mesg.getKey(),mesg.getValue());              	
      }catch(StorageException ex) {
      	ex.printStackTrace();
      	//activate threshold?
      	//send reject ack ?
      }
    }              
    
    else if (message instanceof PutBucketMessage) {
      PutBucketMessage mesg = (PutBucketMessage) message;   
      int phase = mesg.getPhase();
      switch(phase) {
      	case 1 :
      	  //check if the insertion is possible!	
      	  if (!storage.isFull()) endPoint.route(null, new PutBucketMessage(mesg.getMessageId(),endPoint.getLocalNodeHandle(),2), mesg.getNH());	
      	  //else send reject ack
      	  
      	break;
      	case 2 :
      	  Bucket bucket = (Bucket) replicaBuckets.remove(mesg.getNH());
          if (bucket!=null) {
          	Iterator it = bucket.keySet().iterator();          
            while(it.hasNext()) {
      	      Id k = (Id) it.next();
      	      Id owner = (Id) replicaKeyOwner.get(k);
      	      if (owner.equals(mesg.getNH().getId())) replicaKeyOwner.remove(k);
            }      
          }
          
      	  endPoint.route(null, new PutBucketMessage(bucket),mesg.getNH());	
      	break;
      	case 3 : 
      	  bucket = mesg.getBucket();
      	  try {      	  
      	    storage.add(bucket);      	     	  
      	  }catch(StorageException ex) {
      	  	ex.printStackTrace();
      	    //activate threshold?
      	    //send reject ack ?
          }  
      	break;      	
      }              
    }
    
    else if (message instanceof RemoveMessage) {
      RemoveMessage mesg = (RemoveMessage) message; 
      try {          
      
        //remove replicas
        undoReplica(mesg.getKey());        
        //System.out.println("Removing "+mesg.getKey());
        storage.remove(mesg.getKey());    
        
        
      }catch(StorageException ex) {
      	ex.printStackTrace();
        //send reject ack ?
      }    	
    }
    else if (message instanceof RemoveReplicaMessage) {
      
      RemoveReplicaMessage mesg = (RemoveReplicaMessage) message; 
      
      Id owner = (Id) replicaKeyOwner.remove(mesg.getKey());
      
      Bucket replicas = (Bucket) replicaBuckets.get(owner);
      //System.out.println("Replicas "+replicas);
      if (replicas!=null) {
      	replicas.remove(mesg.getKey());      
        if (replicas.size()>0) replicaBuckets.put(mesg.getNH().getId(),replicas);
        else replicaBuckets.remove(mesg.getNH().getId());
        //System.out.println("Replicas Final "+replicaBuckets);
      }
    }
    
    
    else if (message instanceof GetMessage) {
      GetMessage mesg = (GetMessage) message;
      int phase = mesg.getPhase();      
      switch(phase) {
      	case 1 :
      	  key = mesg.getKey();
      	  value = storage.retreive(key);
      	  if (value==null) value = getReplicaValue(key);
          endPoint.route (null, new GetMessage(key,value), mesg.getNH());  	
      	break;
      	case 2 :
      	  key = mesg.getKey();
      	  value = mesg.getValue();
      	  
      	  if(value instanceof Values) {
      	  	Values v = (Values) value;
      	  	if (v.size()==1) value = v.firstElement(); 
      	  }
		  
      	  if (clients!=null) {
      	  	Vector id_clients = (Vector) clients.remove(key);
      	  	for(int i=0; i<id_clients.size(); i++) {
      	  	  BunshinClient client = (BunshinClient) id_clients.get(i);
      	  	  
      	  	  client.get(value);	
      	  	}  
      	  }
      	  
      	break;
      }
          
    }
    else if (message instanceof ReplicaMessage) {
      ReplicaMessage mesg = (ReplicaMessage) message;
      key = mesg.getKey();
      value = mesg.getValue();      
 
      putReplica(mesg.getNH(),key,value);  
      endPoint.route (null, new ReplicaAckMessage(key,endPoint.getLocalNodeHandle()), mesg.getNH());
      //System.out.println("Saving replica "+value+" of "+mesg.getNH().getId());
    }
    else if (message instanceof ReplicaAckMessage) {
      ReplicaAckMessage mesg = (ReplicaAckMessage) message;
      key = mesg.getKey();
      replicaNHs.insert(key,mesg.getNH());    
    }
    
    else if (message instanceof LeaveMessage) {      	
      LeaveMessage mesg = (LeaveMessage) message;
      NodeHandle source = mesg.getNH();
      
      if (mesg.isContent()) {      	        
      	Bucket newKeys = (Bucket) mesg.getContent();
      	try {      	
      	  storage.add(newKeys);    
      	}catch(StorageException ex) {
      		ex.printStackTrace();
      	    //activate threshold?
      	    //send reject ack ?
        }   
      }
      
      //System.out.println(replicaBuckets);
      //System.out.println("Deleting "+mesg.getNH().getId()+" entries");
      	
      //remove replicas of a given owner       	    	
      replicaIdNH.remove(mesg.getNH().getId());	      	
      Bucket bucket = (Bucket) replicaBuckets.remove(mesg.getNH().getId());
      if (bucket!=null) {      
        Iterator it = bucket.keySet().iterator();
        while(it.hasNext()) {
      	  Id k = (Id) it.next();
      	  Id owner = (Id) replicaKeyOwner.get(k);
      	  if (owner.equals(mesg.getNH().getId())) replicaKeyOwner.remove(k);
        }
      }	
      //System.out.println(replicaBuckets);      
      
    }
    else {
      System.out.println ("Deliver Error : Wrong message : "+message);	
    }
  }
  
  
  /**
   *  Sends a PutMessage to the root's key with a new value for the given key
   */
  public void put(Id key, Object value, boolean exclusive) {
  	
  	if (isOwner(key)) {
  	  try {  	  
  	    if (!exclusive) storage.insert(key,value);
  	    else storage.overwrite(key,value);
        //send replicas
  	    //System.out.println("I'm the owner of the "+value);
        replicate(key,value);     
      }catch(StorageException ex) {
      	ex.printStackTrace();
        //activate threshold?
      	//send local reject ack
      }  
  	}
  	else {
  	  endPoint.route(key, new PutMessage(key,value,exclusive), null);  	
  	}
  	 
  }
  
  
  /**
   *  Sends a RemoveMessage to the root's key to indicate the key that it must eliminate.  
   */
  public void remove(Id key) {
  	if (isOwner(key)) {
  	  try {  	  
  	    undoReplica(key);        
        //System.out.println("Removing "+key);
        storage.remove(key);   
      }catch(StorageException ex) {
      	ex.printStackTrace();
        //activate threshold?
      	//send local reject ack
      }  
  	}
  	endPoint.route(key, new RemoveMessage(key), null);
  }  
  /**
   *  Sends a GetMessage following a 2 phases protocol. When the request is resolved, the method
   * get(key) of the BunshinClient returns the result.
   */
  public void get(Id key, BunshinClient client) {
  	
    Vector id_clients;
  	
  	if (!clients.containsKey(key)) id_clients = new Vector();
  	else id_clients =  id_clients = (Vector) clients.get(key);
  	
  	id_clients.add(client);
  	clients.put(key,id_clients);
  	
  	endPoint.route(key, new GetMessage(key,endPoint.getLocalNodeHandle()), null); 	
  }
  
  
  /**
   * Inserts in the structure of replicas a new (key,value) from a specific node
   * 
   * @param own
   * @param key
   * @param value
   */
  private void putReplica(NodeHandle own, Id key, Object value) {
  	Bucket b;
  	if (replicaBuckets.containsKey(own.getId())) {
  	  b = (Bucket) replicaBuckets.get(own.getId());  	  
  	}
  	else {
  	  b = new Bucket();  	  
  	}
  	b.overwrite(key,value);
	replicaBuckets.put(own.getId(),b);
	replicaKeyOwner.put(key,own.getId());
	replicaIdNH.put(own.getId(),own); 	 	  	
  }
  
  /**
   * Sends a replica of the pair (key,value) to replicationFactor nodes from replicaSet
   *  
   * @param key
   * @param value
   */
  private void replicate(Id key, Object value) {
  	
  	//reset possible replicas
  	replicaNHs.remove(key);  
  	
  	NodeHandle nh = endPoint.getLocalNodeHandle();
  	Collection c = Utilities.convert(endPoint.replicaSet(key,replicationFactor+1));
  	if (c!=null) {
  	Iterator it = c.iterator();  	
  	while(it.hasNext()) {
  	  NodeHandle to = (NodeHandle) it.next();
	  if (!to.getId().equals(nh.getId())) {
	  	//System.out.println("Sending replica to "+to.getId());
  	    endPoint.route(null,new ReplicaMessage(key,value,nh),to);
	  }
  	}
  	}
  }  
  
  /**
   * Sends remove replica of the all keys to replica nodes
   *  
   * @param key   
   */
  private void undoReplica(Id key) {
  	 	
  	Collection c = (Collection)replicaNHs.remove(key);
  	if (c!=null) {
  	  	
  	  Iterator it = c.iterator();  	
  	  while(it.hasNext()) {
  	    NodeHandle nh = (NodeHandle) it.next();
	  	//System.out.println("Removing replica from "+nh.getId());
  	    endPoint.route(null,new RemoveReplicaMessage(nh,key),nh);

  	  }
  	}
  }  
  
  
  /**
   * Finds in the replicated buckets a specific value
   * 
   * @param key
   * @return Object value
   */
  private Object getReplicaValue(Id key) {
    Iterator it = replicaBuckets.values().iterator();
    boolean found = false;
    Object value = null;
    while(it.hasNext() && !found) {
      Bucket b = (Bucket) it.next();
      value = b.load(key);
      found = (value!=null);
    }
    return value;
  }

  private synchronized void refresh(int mode) {
    
  	if ( mode==0) {  
      checkMyKeys();
      checkMyReplicas();
      checkReplicas();
  	}  	
  	else if (mode==1) {  
  	  checkMyKeys();	
  	}
  	else {
  	  checkMyReplicas();
  	  checkReplicas();  		
  	}
  	
  }
  
  class PeriodicTask extends TimerTask {
			
		public void run() {
			refresh(0);
		}
  }	
  
	
}

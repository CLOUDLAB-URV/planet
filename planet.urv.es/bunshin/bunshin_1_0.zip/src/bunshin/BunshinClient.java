package bunshin;

/**
 * @(#) BunshinClient.java
 *
 * This interface represents a client using the Bunshin DHT system.
 * 
 * @author Ruben Mondejar
 */
public interface BunshinClient {

  /**
   * This method is invoked when a get request is delivered for a key this
   * client is interested in.
   *
   * @return value Object stored, may be Values if it have two values or more for the given key.   
   */
  public void get(Object value);  
}


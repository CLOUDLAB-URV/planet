/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm;

import dermi.*;
import dermi.annotation.*;

/**
 * This remote interface is implemented by any Dermi component.
 * All Dermi components exported interfaces must implement it.
 * It provides the activation and passivation callbacks as well as the
 * queryInterface method, � la COM's IUnknown
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public interface ComponentInterface extends ERemote {
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException;

  // These methods are not remote, hence the lack of annotations
  public void activate() throws ActivationException;
  public void passivate() throws PassivationException;
}

/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.simple;

import java.net.URL;
import dermi.dcm.*;

/**
 * Sample test which shows how to deploy a component in Dermi, and how to obtain
 * an instance, and call its methods.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class TestSimpleComponent {
  /**
   * Constructor: gets component instances and calls methods on them
   */
  public TestSimpleComponent() {
    // Slides component factory
    ComponentFactory fac = null;
    try {
        // Look up factory in Dermi's DOLR service
        fac = (SlidesFactory) ComponentUtil.getComponentFactory ("p2p://slides-simple.deim.etse.urv.es");
    } catch (ComponentNotRegisteredException e) {
      System.out.println ("Component not registered, unable to continue.");
      System.exit (-1);
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    try {
        // Here we create a component's instance. Since this component can implement multiple
        // interfaces, we MUST specify that we wish to obtain an instance of the specified interface

        // Component is instantiated, and an implementation of the parameter class is returned
        // Singleton: if an instance already exists, it gets a stub to the running instance
        //            else, a new instance is created locally, and its associated stub is returned.
        Controls slidesControls = (Controls) fac.createInstance ("dermi.dcm.samples.simple.Controls", "slides0001");

        // Now we can interact with the component calling any of the interface's methods
        slidesControls.loadImageSet ("slides.txt");
        slidesControls.first();

        // If a reference to another interface of the component is required, we can call the queryInterface()
        // method specifying the desired interface, as seen below:
        Screen slidesScreen = (Screen) slidesControls.queryInterface ("dermi.dcm.samples.simple.Screen");

        // Now we can call methods on the interface Screen
        System.out.println (slidesScreen.getImage());
        System.out.println ("---------------------------------------------");
    } catch (InterfaceNotFoundException e) {
      System.out.println ("Interface cannot be found, unable to continue.");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Main method: first called when executing this class
   * @param args String[] Input arguments
   * @throws Exception If something goes wrong ;-)
   */
  public static void main (String[] args) throws Exception {
    // This is how components are deployed: we must specify a JAR file which contains all component's classes
    ComponentUtil.deployComponent (new URL ("file:./class_store/components/slides-simple.jar"));

    // Test component
    TestSimpleComponent ex = new TestSimpleComponent();

    // If you wish to undeploy a component, you can proceed this way
    ComponentUtil.unDeployComponent ("p2p://slides-simple.deim.etse.urv.es");
  }
}

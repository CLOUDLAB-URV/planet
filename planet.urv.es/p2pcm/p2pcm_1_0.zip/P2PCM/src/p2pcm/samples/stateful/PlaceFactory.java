/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.stateful;

import dermi.*;
import dermi.dcm.*;
import dermi.util.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * Place component's factory class. Note that it must extend <b>ComponentFactory</b>
 * Moreover, it must provide a standard set of annotations which indicate the component's
 * metadata:
 *     - id         --  Component's unique ID
 *     - stateful   --  Whether it is stateful or stateless
 *     - persistent --  Which kind of persistence is applied: currently only PersistenceType.CONTAINER works
 *     - replicated --  Whether it is replicated or not (singleton)
 *     - url        --  URL where the component's metadata entry will be bound in the decentralized registry
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */

@DCMFactory (
    id = "819daf87-176f-49a1-a65d-d63e6dff7984",
    stateful = true,
    persistent = PersistenceType.CONTAINER,
    replicated = true,
    url = "p2p://place-stateful.deim.etse.urv.es"
    )
public class PlaceFactory extends ComponentFactory {
  public PlaceFactory() {
  }

  public PlaceFactory (String componentURL) throws RemoteException {
    super (componentURL);
  }

  public ComponentInterface createInstance (String interf, String instance) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[PlaceFactory] - Trying to create instance without arguments...");
    return super.createInstance (interf, instance);
  }

  public ComponentInterface createInstance (String interf, String instance, Object...args) throws InterfaceNotFoundException, RemoteException {
    System.out.println ("[PlaceFactory] - Trying to create instance with arguments...");
    return super.createInstance (interf, instance, args);
  }
}

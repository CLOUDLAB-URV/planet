/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.stateful;

import java.net.URL;
import dermi.dcm.*;

public class TestIdle {
    public TestIdle() {
        ComponentFactory pfac = null, sfac = null;
        try {
            // Busquem la factoria del component al DOLR de Dermi
            pfac = (PlaceFactory) ComponentUtil.getComponentFactory ("p2p://place-stateful.deim.etse.urv.es");
            sfac = (SlidesFactory) ComponentUtil.getComponentFactory ("p2p://slides-stateful.deim.etse.urv.es");
        } catch (ComponentNotRegisteredException e) {
            System.out.println ("Component not registered, unable to continue.");
            System.exit (-1);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        try {
            Place place = (Place) pfac.createInstance ("dermi.dcm.samples.stateful.Place", "place-gnatz");
//            Slides slides = (Slides) sfac.createInstance ("dermi.dcm.samples.stateful.Slides", "slides000002", "slide1");
//            Slides slides2 = (Slides) sfac.createInstance ("dermi.dcm.samples.stateful.Slides", "slides000003", "slide2");
//            Slides slides3 = (Slides) sfac.createInstance ("dermi.dcm.samples.stateful.Slides", "slides000004", "slide3");
//            Slides slides4 = (Slides) sfac.createInstance ("dermi.dcm.samples.stateful.Slides", "slides000005", "slide4");
//            Slides slides5 = (Slides) sfac.createInstance ("dermi.dcm.samples.stateful.Slides", "slides000006", "slide5");

            // Ara interactuem amb el component via una de les seves interficies (Controls)
//            slides.first();

//            place.addThing (new SlidesImpl());
//            place.addThing (slides2);
//            place.addThing (slides3);
//            place.addThing (slides4);
//            place.addThing (slides5);

/*            java.util.Iterator i = place.getThings().iterator();

            while (i.hasNext()) {
              Slides s = (Slides) i.next();
              System.out.println ("Iterating... " + s.getCurrentImageSet());
            }
*/
            System.out.println ("---------------------------------------------");
        } catch (InterfaceNotFoundException e) {
            System.out.println ("Interface cannot be found, unable to continue.");
        } catch (Exception ex) {
          ex.printStackTrace();
        }
    }

    public static void main (String[] args) throws Exception {
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/slides-stateful.jar"));
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/place-stateful.jar"));
      TestIdle ex = new TestIdle ();
    }
}

/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.comp;

import dermi.dcm.*;

import java.net.URL;
import java.util.Iterator;

/**
 * Sample test which shows how to deploy a component in Dermi, and how to obtain
 * an instance, and call its methods
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
public class TestMultipleComponents {
  /**
   * Constructor: gets component instances and calls methods on them
   */
  public TestMultipleComponents() {
    // Place and Slides component factories
    ComponentFactory pfac = null, sfac = null;
    try {
        // Look up factory in Dermi's DOLR service
        pfac = (PlaceFactory) ComponentUtil.getComponentFactory ("p2p://place-comp.deim.etse.urv.es");
        sfac = (SlidesFactory) ComponentUtil.getComponentFactory ("p2p://slides-comp.deim.etse.urv.es");
      } catch (ComponentNotRegisteredException e) {
        System.out.println ("Component not registered, unable to continue.");
        System.exit (-1);
      } catch (Exception ex) {
        ex.printStackTrace();
      }

    try {
        // Here we create a component's instance. Since this component can implement multiple
        // interfaces, we MUST specify that we wish to obtain an instance of the specified interface

        // Component is instantiated, and an implementation of the parameter class is returned
        // Singleton: if an instance already exists, it gets a stub to the running instance
        //            else, a new instance is created locally, and its associated stub is returned.
        Place place = (Place) pfac.createInstance ("dermi.dcm.samples.comp.Place", "place00000000");
        Slides slides = (Slides) sfac.createInstance ("dermi.dcm.samples.comp.Slides", "slides000002", "slide1");
        Slides slides2 = (Slides) sfac.createInstance ("dermi.dcm.samples.comp.Slides", "slides000003", "slide2");
        Slides slides3 = (Slides) sfac.createInstance ("dermi.dcm.samples.comp.Slides", "slides000004", "slide3");
        Slides slides4 = (Slides) sfac.createInstance ("dermi.dcm.samples.comp.Slides", "slides000005", "slide4");
        Slides slides5 = (Slides) sfac.createInstance ("dermi.dcm.samples.comp.Slides", "slides000006", "slide5");

        // Now we can interact with the component calling any of the interface's methods
        slides.first();

        place.addThing (slides);
        place.addThing (slides2);
        place.addThing (slides3);
        place.addThing (slides4);
        place.addThing (slides5);

        Iterator i = place.getThings().iterator();

        while (i.hasNext()) {
          Slides s = (Slides) i.next();
          System.out.println ("Iterating... " + s.getCurrentImageSet());
        }

        System.out.println ("---------------------------------------------");
      } catch (InterfaceNotFoundException e) {
        System.out.println ("Interface cannot be found, unable to continue.");
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    }

    /**
     * Main method: first called when executing this class
     * @param args String[] Input arguments
     * @throws Exception If something goes wrong ;-)
     */
    public static void main (String[] args) throws Exception {
      // This is how components are deployed: we must specify a JAR file which contains all component's classes
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/slides-comp.jar"));
      ComponentUtil.deployComponent (new URL ("file:./class_store/components/place-comp.jar"));

      // Test component
      TestMultipleComponents ex = new TestMultipleComponents();

      // If you wish to undeploy a component, you can proceed this way
      ComponentUtil.unDeployComponent ("p2p://place-comp.deim.etse.urv.es");
      ComponentUtil.unDeployComponent ("p2p://slides-comp.deim.etse.urv.es");
    }
}

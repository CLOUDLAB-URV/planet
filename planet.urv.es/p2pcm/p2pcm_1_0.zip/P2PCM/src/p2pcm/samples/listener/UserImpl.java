/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.listener;

import dermi.*;
import dermi.dcm.*;
import dermi.exception.*;
import dermi.annotation.*;

import java.util.*;

/**
 * This is the component's base class. In this case, it implements all the component's interfaces.
 * It is in fact a special Dermi Remote Object that must extend the Component class, and be
 * labelled with @DCMImplementation annotation tag.
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DCMImplementation
public class UserImpl extends Component implements User {
  private String userName = "";

  // Dermi stub constructor: REQUIRED
  public UserImpl() {
  }

  // Dermi skel constructor: REQUIRED
  public UserImpl (Properties env) throws RemoteException {
    super (env);
  }

  // Constructor with arguments
  public UserImpl (Properties env, String username) throws RemoteException {
    this (env);
    this.userName = username;
    System.out.println ("[User] - component created. Name: " + userName);
  }

  public String getName() throws RemoteException {
    return userName;
  }

  /**
   * The queryInterface method must return a suitable component implementation
   * for the specified interface
   * @param interf String The desired interface implementation
   * @return ComponentInterface The desired implementation instance
   * @throws InterfaceNotFoundException If the component does not provide an implementation for such specified interface
   */
  public ComponentInterface queryInterface (String interf) throws InterfaceNotFoundException {
    try {
      if (interf.equals ("dermi.dcm.ComponentInterface") || interf.equals ("dermi.dcm.samples.listener.User")) {
        // Stub will either be local or remote, depending on the case
        ERemote ab = this.copy();
        return (ComponentInterface) this.copy();
      }
    } catch (RemoteException re) {
      throw new InterfaceNotFoundException ("Unable to query for interface " + interf + ": " + re.getMessage());
    }
    throw new InterfaceNotFoundException ("Interface " + interf + " not implemented.");
  }
}

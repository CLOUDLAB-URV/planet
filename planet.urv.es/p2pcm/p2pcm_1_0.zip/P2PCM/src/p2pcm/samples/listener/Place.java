/*******************************************************************************
 * P2PCM: A DHT-based Peer-to-Peer Middleware for Distributed Components.
 * Copyright (C) 2003-2005 Carles Pairot
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ******************************************************************************/
package p2pcm.samples.listener;

import dermi.dcm.*;
import dermi.listener.*;
import dermi.exception.*;
import dermi.annotation.*;

/**
 * Place component's interface. Note that it must extend <b>ComponentInterface</b>
 * and be labelled as @DermiRemoteInterface
 *
 * @author Carles Pairot   <carles.pairot@urv.net>
 * @version 1.2
 */
@DermiRemoteInterface
public interface Place extends ComponentInterface {
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public void join (User u) throws RemoteException;
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public void leave (User u) throws RemoteException;
  @RemoteMethod (granularity = Granularity.MULTICALL, type = SynchronyType.SYNCHRONOUS)
  public java.util.Collection getUsers() throws RemoteException;
  @RemoteMethod (granularity = Granularity.LISTENER)
  public void addUserListener (Class eventClass, BasicListener sL) throws RemoteException;
  @RemoteMethod (granularity = Granularity.LISTENER)
  public void removeUserListener (Class eventClass, BasicListener sL) throws RemoteException;
}

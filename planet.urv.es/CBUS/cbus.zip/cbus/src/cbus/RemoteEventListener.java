package cbus;


import java.util.Hashtable;

/**
*		Interface for subscribing to remote events
*/
public interface RemoteEventListener {

/**
*		This method is the standard callback provided for remote events.
*		@param evt Remote event.
*/
  public void eventArrived(Hashtable evt);
		
}
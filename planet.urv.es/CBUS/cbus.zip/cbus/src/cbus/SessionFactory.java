package cbus;


import java.util.*;
import java.io.*;
import java.net.*;

/**
*		Facility class that connects to the Notification service using environment params and 
*   instantiates the apropriate class provider 
*/


public class SessionFactory {
	
	/**
	*	
	*	@param env Hashtable Environment connection properties
	* @see ants.comm.Context
	* @return ants.comm.Session return a Session of the type specified in Environment properties.
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/
	
	public static Session createSession(Hashtable env)
		throws SessionException
	{
		try
		{
			Session ses = (Session)Class.forName((String)env.get(Context.PROVIDER_CLASS)).newInstance();
			ses.open(env);
		
			return ses;
		}catch (ClassNotFoundException e1){
				throw new SessionException(e1);
		//		Debug.error (e1);
		}catch (InstantiationException e2){
  			throw new SessionException(e2);
		//	  Debug.error(e2);
		}catch (IllegalAccessException e3){
				 throw new SessionException(e3);
					 //			 Debug.error(e3);
		}
	}	
	
	
	
	/**
	*	
	*	@param envFile Name of the file containing environment connection properties.
	* @see ants.comm.Context
	* @return ants.comm.Session return a Session of the type specified in Environment properties.
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/

		public static Session createSession(String envFile)
		throws SessionException
		{
		try
		{
			FileInputStream  fis = new FileInputStream(envFile);
			Properties env = new Properties();
			env.load(fis);
						
			Session ses = (Session)Class.forName((String)env.get(Context.PROVIDER_CLASS)).newInstance();
			ses.open(env);
			return ses;
	
		}catch (ClassNotFoundException e1){
				 throw new SessionException(e1);
			}catch (InstantiationException e2){
				 throw new SessionException(e2);
		}catch (IllegalAccessException e3){
				 throw new SessionException(e3);
		} catch (java.io.FileNotFoundException e4)
		{
				 throw new SessionException(e4);
		}catch (java.io.IOException e5)
		{
				 throw new SessionException(e5);
		}

	}	

 
	/**
	*	
	*	@param fileUrl URL of the file containing environment connection properties.
	* @see ants.comm.Context
	* @return ants.comm.Session return a Session of the type specified in Environment properties.
	* @throws ants.comm.SessionException Error produced in the connection phase.
	*/

		public static Session createSession(URL fileUrl)
		throws SessionException
		{
 
	 	try
			{
				Properties env = new Properties();
				env.load(fileUrl.openStream());
										
				Session ses = (Session)Class.forName((String)env.get(Context.PROVIDER_CLASS)).newInstance();
				ses.open(env);
				return ses;

			
			}catch (ClassNotFoundException e1){
				 throw new SessionException(e1);
			}catch (InstantiationException e2){
				 throw new SessionException(e2);
			}catch (IllegalAccessException e3){
					 throw new SessionException(e3);
				}catch (java.io.IOException e5)
			{
				 throw new SessionException(e5);
			}


		}
 
	
}
package cbus.tests;

public class JavaObject implements java.io.Serializable
{
			private String name;
			

	public JavaObject(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
	
	
}
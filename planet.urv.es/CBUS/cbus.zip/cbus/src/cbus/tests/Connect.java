package cbus.tests;
	
import cbus.*;
import java.util.*;

	public class Connect implements ConnectionListener {
		
		private int status = 0;
		
        public void publisherUnsubscribed()	{	      
	      status = 1;
	    }
	    public void publisherClosed()	{
	      status = 2;
	    }
	    public void publisherCrashed()	{
	      status = 3;
	    }
	    public int getStatus() {
	      return status;
	    } 
	    
    }	
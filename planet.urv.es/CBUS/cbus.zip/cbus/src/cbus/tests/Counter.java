package cbus.tests;
	
import cbus.*;
import java.util.*;

	public class Counter implements RemoteEventListener
	{
		public int cnt =0;
		
		public void eventArrived(Hashtable evt)
		{
			cnt++;
		}
		
		public int getCnt()
		{
				return cnt;	
		}
	}
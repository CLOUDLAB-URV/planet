package cbus.tests;

import cbus.*;
import java.util.*;

public class ObjectReceiver implements RemoteEventListener	{

  private JavaObject obj;
		
  public void eventArrived(Hashtable evt) {
    JavaObject si = (JavaObject)evt.get("object");	
	this.obj = si;
  }
		
  public JavaObject getObj() {
	return obj;	
  }
		
}
package cbus.tests;
	
import cbus.*;
import java.util.*;

	public class Counter2 implements RemoteEventListener
	{
		public int cnt =0;
		
		public void eventArrived(Hashtable evt) {
			if (evt.containsKey("info"))  cnt++;
		}
		
		public int getCnt()	{
		  return cnt;	
		}
	}
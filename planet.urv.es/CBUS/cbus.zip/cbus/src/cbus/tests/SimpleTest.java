package cbus.tests;

import cbus.*;
import interceptor.*;
import java.util.*;
import java.io.*;
import junit.framework.*;

/**
 * Some simple tests.
 *
 */
public class SimpleTest extends TestCase {

  protected Session conn;

  public SimpleTest(String name) {
	super(name);
  }

  protected void setUp() {
		
    try {
  		
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
		
	  conn = SessionFactory.createSession(env); 
	  
	} catch (Exception e1) {
	  e1.printStackTrace();	
	}	
  }


  public static Test suite() {
    return new TestSuite(SimpleTest.class);
  }
	
  public void testEvents() throws Exception {
		    
	//Add Subscriptions
	Counter filip = new Counter();
	conn.subscribe(filip,"filip");		

	Counter terrance = new Counter();
	conn.subscribe(terrance,"terrance");

    //Send Notifications
	Hashtable filipevt = new Hashtable();
	filipevt.put("subject","filip");
	Hashtable terranceevt = new Hashtable();
	terranceevt.put("subject","terrance");

	for (int i=0;i<100;i++)
	  conn.publish(filipevt);
	for (int j=0;j<200;j++)
	  conn.publish(terranceevt);
	
	Thread.currentThread().sleep(4000);
		
	assertEquals(100,filip.getCnt());
	assertEquals(200,terrance.getCnt());
	
	//Remove Subscriptions		
	conn.unsubscribe(filip,"filip");		
	conn.unsubscribe(terrance,"terrance");
	
	conn.close();
	
  }
	
  public void testFilter() throws Exception {
		       
	//Add Subscriptions
	Counter2 lst = new Counter2();  	   	 
    conn.subscribe(lst,"join");
	
	//Add Filter
	InterceptorListener lst2 = new Listener2(); 
    conn.addInterceptor(lst2,"join");
	
    //Send Notifications
	Hashtable notif = new Hashtable();
	notif.put("subject","join");
	
	for (int i=0;i<20;i++)
	  conn.publish(notif);
	
	Thread.currentThread().sleep(4000);
		
	assertEquals(20,lst.getCnt());	
	
	conn.removeInterceptor(lst2,"join");
	conn.unsubscribe(lst,"join");	
	
	conn.close();	
  }
  
  public void testInfoPublisher() throws Exception {
	
	Hashtable info = new Hashtable();	 
	info.put("publisher","hello");
	
	conn.registerPublisher("hello",info);
    
    Hashtable info2 = conn.infoPublisher("hello"); 
    	
	assertEquals(info,info2);
	
	conn.unregisterPublisher("hello");	
	
	conn.close();
  }
    	
  public void testObjEvents() throws Exception {
			
    ObjectReceiver rv = new ObjectReceiver();
    
	conn.subscribe(rv,"value1");
		
	JavaObject theObj = new JavaObject("MSG");
	Hashtable evt = new Hashtable();
	evt.put("subject","value1");	
	conn.publish(evt,theObj);
		
	Thread.currentThread().sleep(4000);
	
	JavaObject receivedObj = rv.getObj();
	assertEquals("OBJECT ARRIVED OK",theObj.getName(),receivedObj.getName());		
	
	conn.unsubscribe(rv,"value1");	
	
	conn.close();	
  }	
  
  public void testConnectPublisher() throws Exception {
	
	
	Hashtable info = new Hashtable();	 
	info.put("publisher","hello");
	
	conn.registerPublisher("hello",info);
	
	Counter subs = new Counter();  	   	 
    conn.subscribe(subs,"hello");
	
	Connect lst = new Connect();
	conn.addConnectionListener(lst,"hello");
	
	Thread.currentThread().sleep(2000);
            
    conn.unregisterPublisher("hello");	
    
    Thread.currentThread().sleep(2000);
    
	assertEquals(lst.getStatus(),1);	
	
	conn.close();
  }
  
  //ConnectionListener without previous subscription
  public void testException1() throws Exception {
	
	try {		
		
	  Connect lst = new Connect();
	  conn.addConnectionListener(lst,"hello");
    }    
    catch (SessionException se) {         
	  assertEquals(1,1);	
    }
	
	conn.close();
  }
  
  //ConnectionListener without previous publisher register 
  public void testException2() throws Exception {
	
	try {
				
	  Counter subs = new Counter();  	   	 
      conn.subscribe(subs,"hello");
      
	  Connect lst = new Connect();
	  conn.addConnectionListener(lst,"hello");
    }
    catch (SessionException se) {   
	  assertEquals(1,1);	
    }
	
	conn.close();
  }
	
}
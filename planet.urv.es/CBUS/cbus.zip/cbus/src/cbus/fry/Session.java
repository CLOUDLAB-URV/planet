package cbus.fry;

import cbus.*;

import java.io.*;
import java.net.*;
import java.util.*;


/**
 *		The session class stablishes a simple contract to access publish/subscribe 
 *	middleware. It mimics the delegation event model to smooth the transition from 
 *  local to remote events for Java programmers
 *
 */
public class Session implements cbus.Session {
	
	private Communication comm;	
	private Dispatcher disp;
	
	private Hashtable subscriptions,connections;
	private Vector publications;
	private String filters;//Filter folder path
	private boolean[] ackArrived;

  public void open(Hashtable env) throws SessionException {
      
      String host = (String)env.get(Context.PROVIDER_HOST);
      String s= (String)env.get(Context.PROVIDER_PORT);
      filters = (String) env.get(Context.FILTERS_FOLDER);
      
      int port = Integer.parseInt(s);         
      
      try { 
        comm = new Communication(host,port);
	    
	    subscriptions = new Hashtable();
	    connections = new Hashtable();    
	    publications = new Vector();
	    ackArrived = new boolean[8];
	  
	    disp = new Dispatcher(comm,subscriptions,connections,ackArrived);      
        disp.start(); 
        
      }catch (java.io.IOException ex)	{
	    throw new SessionException(ex);
	  } 
  }

  public void close() throws SessionException {
  	try {    
  	  Hashtable event = new Hashtable();
  	  event.put(Protocol.ACTION,new Integer(Protocol.CLOSE));
  	  
  	  comm.send(event);         
   	}catch (Exception ex)	{
	  throw new SessionException(ex);
	}
  }


  public void publish(Hashtable event) throws SessionException { 
    if (!event.containsKey(Protocol.SUBJECT)) 
      throw new SessionException(new Exception("Publish error : can't publish a event without subject"));
    try {         
      comm.send(event);     
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}
  }
  
  public void publish(Hashtable event, Object obj) throws SessionException { 
    try { 
      Hashtable evt = (Hashtable) event.clone();

	  ByteArrayOutputStream bos = new ByteArrayOutputStream();
	  ObjectOutputStream os = new ObjectOutputStream(bos);
	  os.writeObject(obj);
	  os.close();			
			
	  byte[] bytes = bos.toByteArray();
	  evt.put("object",bytes);					
      
      publish(evt);
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}
  }
  
  public void registerPublisher (String subs, Hashtable evt) throws SessionException {     
    
    Hashtable event = (Hashtable) evt.clone();
    event.put(Protocol.ACTION,new Integer(Protocol.REGISTER_SUBS));
    event.put(Protocol.SUBJECT,subs);
    
    try {   
      comm.send(event);      
      publications.add(subs);
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}	
  }
  
  public void unregisterPublisher (String subs) throws SessionException {     
    if (publications.contains(subs)) {
      Hashtable event = new Hashtable();
      event.put(Protocol.ACTION,new Integer(Protocol.UNREGISTER_SUBS));
      event.put(Protocol.SUBJECT,subs);   
      try {   
        comm.send(event);     
        publications.remove(subs);      
      }catch (Exception ex)	{
	    throw new SessionException(ex);
	  }	
    }
    else
      throw new SessionException(new Exception("Unregister error : Don't exist this publication"));
  }
  
  
  public Hashtable infoPublisher(String subs) throws SessionException {
    
    Hashtable event = new Hashtable();
    event.put(Protocol.ACTION,new Integer(Protocol.INFO_SUBS));
    event.put(Protocol.SUBJECT,subs);    
    
    ackArrived[3] = ackArrived[0] = false;
    
    try {   
      comm.send(event);      
      
      int  timeout = 0;      
	  while ( !ackArrived[3] && timeout<10 ) {
	    try{
		  Thread.currentThread().sleep(300);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	  }
	    
	  if (ackArrived[0] || !ackArrived[3]) 
	    throw new SessionException(new Exception("Subscription info request refused by server"));
	  
	  return comm.getInfo();
      
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}	
  }
  
  public boolean existPublisher(String subs) throws SessionException {
    
    Hashtable event = new Hashtable();
    event.put(Protocol.ACTION,new Integer(Protocol.EXIST_SUBS));
    event.put(Protocol.SUBJECT,subs);    
    
    ackArrived[6] = ackArrived[0] = false;
    
    try {   
      comm.send(event);      
      
      int  timeout = 0;      
	  while ( !ackArrived[6] && !ackArrived[0] && timeout<10 ) {
	    try{
		  Thread.currentThread().sleep(300);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	  }
	    
	  if (timeout>=10) 
	    throw new SessionException(new Exception("Publisher exists request refused by server"));
	  
	  return ackArrived[6];
      
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}	
  }
  
   
  public void subscribe(RemoteEventListener listener, String subs)  throws SessionException {    
     
	if (subscriptions.containsKey(subs)) {
	  Vector listeners = (Vector) subscriptions.get(subs);
	  listeners.add(listener);
	  subscriptions.put(subs,listeners); 
    }
    
	else {
	
	  Vector listeners = new Vector();	  	
	  listeners.add(listener);
	  
      Hashtable event = new Hashtable();
      event.put(Protocol.ACTION,new Integer(Protocol.ADD_SUBS));
      event.put(Protocol.SUBJECT,subs);   
    
      ackArrived[0] = ackArrived[1] = false;
    
      try {   
        comm.send(event);      
      
        int  timeout = 0;      
	    while ( !ackArrived[1] && timeout<10 ) {
	      try{
		    Thread.currentThread().sleep(300);
		  }catch (InterruptedException ex){ex.printStackTrace();}
		  timeout++;
	    }
	    
	    if (ackArrived[0] || !ackArrived[1]) 
	      throw new SessionException(new Exception("Subscription request refused by server"));
	    
        else subscriptions.put(subs,listeners);     
      
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}
	}	
  }
  
  public Vector getSubscribers(String subs) throws SessionException {
    
    Hashtable event = new Hashtable();
    event.put(Protocol.ACTION,new Integer(Protocol.GET_SUBS));
    event.put(Protocol.SUBJECT,subs);    
    
    ackArrived[7] = ackArrived[0] = false;
    
    try {   
      comm.send(event);      
      
      int  timeout = 0;      
	  while ( !ackArrived[7] && timeout<10 ) {
	    try{
		  Thread.currentThread().sleep(300);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	  }
	    
	  if (ackArrived[0] || !ackArrived[7]) 
	    throw new SessionException(new Exception("Get subscriptor request refused by server"));
	  
	  return comm.getVector();
      
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}	
  }
	
  public void unsubscribe(RemoteEventListener listener, String subs) throws SessionException {
  	
  	Vector listeners = (Vector) subscriptions.get(subs);
	listeners.remove(listener);
	
	if (listeners.size()>0) subscriptions.put(subs,listeners);
	
	else {
	  	  
  	  Hashtable event = new Hashtable();
      event.put(Protocol.ACTION,new Integer(Protocol.REM_SUBS));
      event.put(Protocol.SUBJECT,subs);   
          
      ackArrived[0] = ackArrived[2] = false;
    
      try {   
        comm.send(event);      
      
        int  timeout = 0;      
	    while ( !ackArrived[2] && timeout<10 ) {
	      try{
		    Thread.currentThread().sleep(300);
		  }catch (InterruptedException ex){ex.printStackTrace();}
		  timeout++;
	    }
	    
	    if (ackArrived[0] || !ackArrived[2]) 
	      throw new SessionException(new Exception("subscription delete request refused by server"));
	    
	    else subscriptions.remove(subs);	  	
      
      }catch (Exception ex)	{
	    throw new SessionException(ex);
	  }
    }
  }

  public void addConnectionListener(ConnectionListener listener, String subs) throws SessionException {
    
    if (connections.containsKey(subs)) 
  	  throw new SessionException(new Exception("The connection to this subscription already exists"));
  	  
    else {
	  
	  if (!subscriptions.containsKey(subs)) {
	    throw new SessionException(new Exception("Don't exist any subscription for this connection"));
      }
    
  	  else {	        
	  
        Hashtable event = new Hashtable();
        event.put(Protocol.SUBJECT,subs);   
        event.put(Protocol.ACTION,new Integer(Protocol.ADD_CONN));
            
        ackArrived[4] = ackArrived[1] = false;
    
        try {   
          comm.send(event);      
      
          int  timeout = 0;      
	      while ( !ackArrived[4] && timeout<10 ) {
	        try{
		      Thread.currentThread().sleep(300);
		    }catch (InterruptedException ex){ex.printStackTrace();}
		    timeout++;
	      }
	    
	      if (ackArrived[0] || !ackArrived[4]) 
	        throw new SessionException(new Exception("Connection subscription request refused by server"));
	    
          else connections.put(subs,listener);   
      
        }catch (Exception ex)	{
	      throw new SessionException(ex);
	    }
	  }
	}	
    	
  }
  
  public void removeConnectionListener(String subs) throws SessionException {    
    if (connections.containsKey(subs)) {
  	   
  	  Hashtable event = new Hashtable();
      event.put(Protocol.SUBJECT,subs);   
      event.put(Protocol.ACTION,new Integer(Protocol.REM_CONN));
            
      ackArrived[5] = ackArrived[1] = false;
    
      try {   
        comm.send(event);      
      
        int  timeout = 0;      
	    while ( !ackArrived[5] && timeout<10 ) {
	      try{
		    Thread.currentThread().sleep(300);
		  }catch (InterruptedException ex){ex.printStackTrace();}
		  timeout++;
	    }
	    
	    if (ackArrived[0] || !ackArrived[5]) 
	      throw new SessionException(new Exception("Connection remove request refused by server"));
	    
          else connections.remove(subs);
      
        }catch (Exception ex)	{
	      throw new SessionException(ex);
	    }
  	   
     }  	
     else     
	  throw new SessionException(new Exception("Don't exist any connection for this subject"));
	
  }  
  
  
  public void addInterceptor(InterceptorListener listener, String subs) throws SessionException {    	
   
    Hashtable event = new Hashtable();
    event.put(Protocol.ACTION,new Integer(Protocol.ADD_FILTER));
    event.put(Protocol.SUBJECT,subs); 

    String name = listener.getClass().getName();    
    event.put("name",name);
    try {  
       
     String baseUrl = new String(filters);
     String filename = new String(name);
     String urlName = baseUrl + (baseUrl.endsWith("/") ? "":"/") + filename.replace('.','/') + ".class";     
     File inputFile = new File(urlName);          
	 FileInputStream fis = new FileInputStream(inputFile);
	 byte[] bytes = new byte[(int)inputFile.length()];	 
     fis.read(bytes);        
     fis.close();          
     event.put("class",bytes);        
   
     comm.send(event);               
     
    }catch (Exception ex)	{	
	  throw new SessionException(ex);
	}
  	
  }
  
  public void removeInterceptor(InterceptorListener listener,String subs) throws SessionException {      

    Hashtable event = new Hashtable();
    event.put(Protocol.ACTION,new Integer(Protocol.REM_FILTER));
    event.put(Protocol.SUBJECT,subs);     
    
    String name = listener.getClass().getName();    
    event.put("name",name);
  
    try {   
      comm.send(event);  
    }catch (Exception ex)	{
	  throw new SessionException(ex);
	}
  }

  
} 
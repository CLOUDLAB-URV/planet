package cbus.fry;

import cbus.*;

import java.io.*;
import java.net.*;
import java.util.*;


public class Dispatcher extends Thread {
     
    private Communication comm;
	private boolean[] ackArrived;
	
	private boolean close;
	private Hashtable subscriptions,connections;
	
	public Dispatcher(Communication comm, Hashtable subscriptions, 
	                  Hashtable connections, boolean[] ackArrived)	{
	  this.comm = comm;
	  	  	  
	  this.subscriptions=subscriptions;	
	  this.connections=connections;		  	  	 	  	
	  this.ackArrived=ackArrived;
	  this.close = false;
	}

  
	public void run() {	  
	    Hashtable event;	    
	    try {
		  while (!close) {
		  	try {
		  	  event=(Hashtable) comm.receive();	
		  	  //System.out.println(event);	  	              
		  			  	
		    if (event.containsKey("#ack")) {
		      Integer resp = (Integer) event.get("#ack");  
		      
		      //String subs = (String) event.get("subject");
	      	
		      int code = resp.intValue();
		      switch (code) {
		      	//Add Subscription
		      	case Protocol.ADD_SUBS : 
		      	  ackArrived[1] = true;
		      	break;
		      	//Remove Subscription
		      	case Protocol.REM_SUBS : 
		      	  ackArrived[2] = true;
		      	break;
			      	
		      	//Info Publisher
		      	case Protocol.INFO_SUBS : 
		      	         event.remove("#ack");
		      	         comm.setInfo(event);		      	         
		      	         ackArrived[3] = true;			      	        
		      	break;
		      	//Add Connection
		      	case Protocol.ADD_CONN : 
		      	  ackArrived[4] = true;
		      	break;
		      	//Remove Connection
		      	case Protocol.REM_CONN : 
		      	  ackArrived[5] = true;
		      	break;
		      	//Exist Publisher
		      	case Protocol.EXIST_SUBS : 		      	  
		      	  ackArrived[6] = true;			      	        
		      	break;
		      	//Get Subscriptions
		      	case Protocol.GET_SUBS : 
		      	  Vector v = (Vector) event.get("IPs");
		      	  comm.setVector(v);		      	         
		      	  ackArrived[7] = true;			      	        
		      	break;
		      	//Communication Close
		      	case Protocol.CLOSE : 
		      	  close = true;
		      	  comm.close();
		      	break;    	

		      	//ERROR
		      	case Protocol.ERROR : 
		      	  ackArrived[0] = true;
		      }		    	
		    }
		    //Publisher close the subscription
		    else if (event.containsKey("#unregister_subs")) {	       
		       
		       String subject = (String) event.get("#unregister_subs");	
		       
		       if (connections.containsKey(subject)) {
		       	 ConnectionListener conn = (ConnectionListener) connections.get(subject);
		         String reason = (String) event.get("reason");
		       
		         if (reason.equals("unsubscribed")) conn.publisherUnsubscribed();		         
		         else if (reason.equals("close")) 	conn.publisherClosed();	         
   		         else if (reason.equals("crash"))   conn.publisherCrashed();		         

		       }		       
		    }		    
		  
		    else {
		  					  		  	
		  	  String subject = (String) event.get("subject");			  	  	  
		  	
	   	  	  if (subscriptions.containsKey(subject)) {	
	   	  	  
	   	  	    if (event.containsKey("object")) {
	   	  	      byte[] bytes = (byte[]) event.get("object");
	   	  	      
	              ByteArrayInputStream bis = new ByteArrayInputStream(bytes);		
			      ObjectInputStream ois = new ObjectInputStream(bis);
			      Object obj = ois.readObject();
			      ois.close();
			      
			      event.put("object",obj);
	   	  	    	
	   	  	    }
	   	  	  
	   	  	    Vector v = (Vector) subscriptions.get(subject);		   
	   	  	    Iterator it = v.iterator();
	   	  	    while (it.hasNext()) {
		  	      RemoteEventListener lst = (RemoteEventListener) it.next();
		   	      lst.eventArrived(event);
		   	    }
		      } 
		    }
		    
		  	} catch (EOFException e) {	
		  	e.printStackTrace();
		  	} catch (IOException e) {	
		  	e.printStackTrace();
		  	} catch (ClassNotFoundException e) {		  	 
		  	e.printStackTrace();
		  	} catch (NullPointerException e) {
		  	e.printStackTrace();
		  	}
		  } 
		  
	   } catch (Exception ex) {
	     System.out.println("Fatal Error : Connetion Reset");
	   }
	}

}
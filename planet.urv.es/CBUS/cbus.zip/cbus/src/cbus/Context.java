package cbus;

/**
*		This interface represents a naming context, which consists of a set of name-to-object bindings
*   These constants will be used for connecting to different Notification services.
*/


public class Context
{
	
	/**
	*  Constant that holds the name of the environment property for specifying configuration information for the class factory  provider
  *  to use. 
	*/
	
	public static final String PROVIDER_CLASS = "cbus.class";
	
	/**
	*  Constant that holds the name of the environment property for specifying configuration information for the service provider
  *  to use.
	*/
	public static final String PROVIDER_HOST = "cbus.host";
	
/**
	*  Constant that holds the name of the environment property for specifying configuration information for the port numberof the  provider
  *  to use.
	*/

	public static final String PROVIDER_PORT = "cbus.port";

  /**
	*  Constant that holds the name of the environment property for specifying configuration information for the port numberof the  provider
  *  to use.
	*/

	public static final String FILTERS_FOLDER = "FILTERS_FOLDER";
	
	
	
}
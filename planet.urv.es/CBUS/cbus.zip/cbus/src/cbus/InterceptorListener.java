package cbus;

import java.util.Hashtable;

/**
*		Interface for subscribing to filter events
*       @author Ruben Mondejar
*/
public interface InterceptorListener {

/**
*		This method is the standard callback provided for filtered events.
*		@param evt Filter event.
*		@return the filtered event 
*/
  public Hashtable interceptorEventArrived (Hashtable evt);
		
}
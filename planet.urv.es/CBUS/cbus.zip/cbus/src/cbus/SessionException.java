package cbus;


/**
*		Wrapper Exception class to different Exceptions
*   It simply stores the incoming Exception and provides a method for obtaining the *real* exception.
*/

public class SessionException extends Exception {
	private Exception ex;
	
	
	public SessionException(Exception ex)
	{
		super(ex.getMessage());
		this.ex = ex;
	}

	/**
	*		Return the Exception produces in the notification service.
	* @return Exception the Exception occured in the underlying Notificacion Service.
	*/
	
	public Exception getException()
	{
		return ex;
	}

}
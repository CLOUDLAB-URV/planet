package cbus.examples;

import cbus.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * A simple consumer
 * @author Ruben Mondejar
 * 07/07/2003
 */ 
 
public class Client5 {
	
  public static class Listener implements RemoteEventListener {
    public void eventArrived(Hashtable evt)	{
	  System.out.println(evt.get("subject"));
	}
  }
  
  public static void main(String[] args) {
  	try{
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
		
	 cbus.Session chat = SessionFactory.createSession(env);	       
     
  	 Listener lst = new Listener();  	   	 
     chat.subscribe(lst,"hello");
     	 
     boolean exist = chat.existPublisher("hello");       	 

     if (exist) {     
          
       Hashtable info = chat.infoPublisher("hello");       	 
       System.out.println(info);     
       
     }
       	 
     Vector list = chat.getSubscribers("hello");  	 
     System.out.println(list);
     
     while (true) {
       Thread.sleep(5000);
       System.out.println("-----");
     }
     //chat.close(); 
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
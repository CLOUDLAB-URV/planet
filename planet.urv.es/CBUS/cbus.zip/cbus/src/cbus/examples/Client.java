package cbus.examples;

import cbus.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * A simple publisher
 * @author Ruben Mondejar
 * 07/07/2003
 */ 
 
public class Client {
  
  public static void main(String[] args) {
  	try{
  		
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
		
	 cbus.Session chat = SessionFactory.createSession(env); 

 	 for (int i=0; i<20; i++) {  	 
  	 
  	  Thread.sleep(1000);
  	  	
       Hashtable notif = new Hashtable();
       notif.put("subject","hello");
     
       chat.publish(notif);      

     }
     
     chat.close(); 
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
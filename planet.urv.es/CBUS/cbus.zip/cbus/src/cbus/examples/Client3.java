package cbus.examples;

import cbus.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * A simple publisher
 * @author Ruben Mondejar
 * 07/07/2003
 */ 
 
public class Client3 {
  
  public static void main(String[] args) {
  	try{
  		
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
		
	 cbus.Session chat = SessionFactory.createSession(env); 
	 
	 Hashtable info = new Hashtable();	 
	 info.put("publisher","hello");
	 chat.registerPublisher("hello",info);
   	   	 
 	 while(true) {
  	 
  	  Thread.sleep(1000);
  	  	
       Hashtable event2 = new Hashtable();
       event2.put("subject","hello");
     
       chat.publish(event2);      

     }
     //chat.unregisterPublisher("hello");
     //chat.close(); 
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
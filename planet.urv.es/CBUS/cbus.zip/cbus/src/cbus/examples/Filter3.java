package cbus.examples;

import cbus.*;
import interceptor.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * A simple filter
 * @author Ruben Mondejar
 * 13/07/2003
 */ 
 
public class Filter3 {
	 
  public static void main(String[] args) {
  	try{
  		
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
		
	  cbus.Session chat = SessionFactory.createSession(env);	  	 
    
     InterceptorListener lst3 = new Listener3(); 
     chat.addInterceptor(lst3,"join");
       	 
     while (true) {
       Thread.sleep(5000);
       System.out.println("-----");
     }
     
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
package cbus.examples;

import cbus.*;
import interceptor.*;
import java.io.*;
import java.net.*;
import java.util.*;


/**
 * A filter & consumer 
 * @author Ruben Mondejar
 * 10/07/2003
 */ 
 
public class Filter2 {
	
  public static class Listener implements RemoteEventListener {
    public void eventArrived(Hashtable evt)	{
	  System.out.println(evt.get("info"));
	}
  }  
  
  public static void main(String[] args) {
  	try{
  		
	 FileInputStream  fis = new FileInputStream("env.properties");
	 Properties env = new Properties();
	 env.load(fis);
				
	 cbus.Session chat = SessionFactory.createSession(env);	  
          
	   	   	 
  	 RemoteEventListener lst = new Listener();  	   	 
     chat.subscribe(lst,"join");
     
     InterceptorListener lst2 = new Listener2(); 
     chat.addInterceptor(lst2,"join");
     
     InterceptorListener lst3 = new Listener3(); 
     chat.addInterceptor(lst3,"join");
       	 
     while (true) {
       Thread.sleep(5000);
       System.out.println("-----");       
     }
     //chat.removeInterceptor(lst2,"join");
     
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
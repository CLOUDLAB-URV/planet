package cbus.examples;

import cbus.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class Tester implements RemoteEventListener
{
	public int n = 0;
	
	public void eventArrived(Hashtable evt)
	{
		n++;
	}
	
	public static void main(String args[])
	{
		try{
			
		Tester nu =new Tester();
		long conn1 = System.currentTimeMillis();
		  				
	    FileInputStream  fis = new FileInputStream("env.properties");
	    Properties env = new Properties();
	    env.load(fis);
		
	    cbus.Session conn = SessionFactory.createSession(env);    
		
		long conn2 = System.currentTimeMillis();
		System.out.println("CONN TIME = "+ (conn2-conn1));
		
		conn.subscribe(nu,"hello");	
		
		Hashtable evt= new Hashtable();
		evt.put("subject","hello");
		evt.put("msg","sdsds");
		long send1 = System.currentTimeMillis();
		for (int i= 0;i<10000;i++)
				conn.publish(evt);
		long send2 = System.currentTimeMillis();
		
		System.out.println("SEND TIME = "+ (send2-send1));

		Thread.sleep(5000);		
		System.out.println(nu.n);
		
		conn.close();		
		}catch (Exception e){
		   e.printStackTrace();	
		}
	
	}
	
}
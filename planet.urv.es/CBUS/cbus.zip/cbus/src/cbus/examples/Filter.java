package cbus.examples;

import cbus.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class Filter {
	

/**
 * A simple publisher
 * @author Ruben Mondejar
 * 10/07/2003
 */  
  
  public static void main(String[] args) {
  	try{
  		  		
  	 Hashtable env = new Hashtable();
     env.put(Context.PROVIDER_CLASS, "cbus.fry.Session");
	 env.put(Context.PROVIDER_HOST, "localhost");
	 env.put(Context.PROVIDER_PORT, "5555");
		
	 cbus.Session chat = SessionFactory.createSession(env);
	   	 
	 chat.registerPublisher("join", new Hashtable());  	   	 
 	 
  	 while(true) {
  	 
  	  Thread.sleep(2000);
  	  	
       Hashtable event2 = new Hashtable();
       event2.put("subject","join");
       event2.put("info","nothing");
     
       chat.publish(event2);      

     }
     //chat.close(); 
		
    }catch (Exception e) {
	  e.printStackTrace();	
	}
  }
}
package cbus;

import java.util.Vector;
import java.util.Hashtable;
import java.net.URL;
/**
 *		The session class stablishes a simple contract to access publish/subscribe 
 *	middleware. It mimics the delegation event model to smooth the transition from 
 *  local to remote events for Java programmers
 *
 */
public interface Session {
	
 /**
  *		The open method is mainly used by the facility class SessionFactory, so
  * normally should not be used by programmers.
  * @param env key/value pairs representing connection parameters
  * @see cbus.Context
  * @throws ants.comm.SessionException it throws the wrapper SessionException encapsulating
  *  all posible problems in the connection phase. 
  */	
	
  public void open(Hashtable evt) throws SessionException;
  
  /**
   * 	The close method safety frees resources and closes the connection.
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection. 
   */
    
  public void close() throws SessionException;
  
  /**
   * 	The publish method produces notifications in a simple and straightforward style.
   * @param event event uses the well-known java.util.Hashtable for creating key-value pairs notifications
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating	
   *  all posible problems with the connection and Notification. 
   */
   
  public void publish(Hashtable event) throws SessionException;
  
  	
  /**
   *	Publisher method that accepts a Serializable Java object as parameter. It will be received 
   * in the client with the key "object" in the Hashtable event parameter. 
   * @param event event uses the well-known java.util.Hashtable for creating key-value pairs notifications
   * @param obj Java serializable object
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and Notification. 
   */
  
  public void publish(Hashtable event, Object obj) throws SessionException;
  
  /**
   *	This method registers in the server the subscription before the publisher can send notifications for this subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @param info is a Hashtable with information of the publisher that will be stored in the server
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
       
  public void registerPublisher (String subs, Hashtable info) throws SessionException;
  
  /**
   *	This method returns true if the publisher of a specific subscription exists
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @return boolean is true if the publisher exists
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
   
  public boolean existPublisher(String subs) throws SessionException;
  /**
   *	This method returns information of the publisher of a specific subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @return Hashtable information stored in the server by the publisher
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
  
  public Hashtable infoPublisher(String subs) throws SessionException;
  
    /**
   *	This method removes the publisher subscription, since won't publish more notifications for this subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.   
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
      
  public void unregisterPublisher (String subs) throws SessionException; 
    
  /**
   *	This method creates a listener of remote events that matches the subscription specified in subscription param.
   * @param listener the Listener of remote events, it will handle incoming events matching the subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @see cbus.RemoteEventListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */

  public void subscribe(RemoteEventListener listener, String subs)  throws SessionException;
  
  /**
   *	This method returns a Vector that contain the InetAddress of each one the subscribers of a specific subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @return Vector of the InetAddress objects
   * @see java.net.InetAddress
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
  public Vector getSubscribers(String subs) throws SessionException;  
  
  /**
   *	This method removes the subscription specified in subscription param.
   * @param listener the ConnectionListener of remote connection events
   * @param subscription the subscription to be removed (using specific constraint filter language)
   * @see cbus.RemoteEventListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and removal of subscriptions. 
   */
   	  	
  public void unsubscribe(RemoteEventListener listener, String subs) throws SessionException;
  
  /**
   *	This method creates a listener of remote connection events that matches the subscription specified in subscription param.
   * @param listener the ConnectionListener of remote connection events, it will handle incoming events matching the connection
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @see cbus.ConnectionListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
   
  public void addConnectionListener(ConnectionListener listener, String subs) throws SessionException;
 
  /**
   *	This method removes the connection listener specified in subscription param.
   * @param subscription the connection listener to be removed 
   * @see cbus.ConnectionListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and removal of subscriptions. 
   */
     
  public void removeConnectionListener(String subs) throws SessionException;
  
  
  /**
   *	This method creates a interceptor to specified subscription.
   * @param listener the InterceptorListener of remote events, it will filter incoming events matching the subscription
   * @param subscription The subscription is represented using a String in the specific contrainst filter language of the used Notification service.
   * @see cbus.InterceptorListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and subscription. 
   */
  	
  public void addInterceptor(InterceptorListener listener, String subs) throws SessionException;
   
  /**
   *	This method removes the interceptor listener specified in subscription param.
   * @param subscription the interceptor listener to be removed 
   * @see cbus.InterceptorListener
   * @throws cbus.SessionException it throws the wrapper SessionException encapsulating
   *  all posible problems with the connection and removal of subscriptions. 
   */
      
  public void removeInterceptor(InterceptorListener listener, String subs) throws SessionException;    
        
} 
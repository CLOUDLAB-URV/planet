package cbus;

/**
*		Interface for subscribing to publisher remote events
*/

public interface ConnectionListener {

/**
*		  This method executes when the remote publisher unsubscribe 
*       a determinate subject.
*/
    public void publisherUnsubscribed();
    
/**
*		  This method executes when the remote publisher closes the connection
*       with the server
*/
    public void publisherClosed();
    
/**
*		  This method executes when the remote publisher loses the connection
*       with the server
*/
    public void publisherCrashed();

		
}
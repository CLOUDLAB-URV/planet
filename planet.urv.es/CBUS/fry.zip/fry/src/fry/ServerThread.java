package fry;

import cbus.*;
import fry.util.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * The Fry server thread connect the server resources with the client, 
 * take his subscriptions / notifications / filters  and moreover 
 * also deliver the notifications
 *
 * @author Ruben Mondejar
 * 05/07/2003
 */ 

public class ServerThread extends Thread{
	
	//Global tads
	private Communication comm;
    private Clients clients;
    private Connections connections;
	private Filters filters;
	private Hashtable publishers;
	private EventLog log;
	
	//Local tads
	private Vector mysubs,myconn,mynotif;
	private Hashtable myfilters;
	private boolean close;
	
	public ServerThread(Communication comm,Clients clients,Connections connections,
	                    Filters filters, Hashtable publishers, EventLog log) {
		
		try {
			this.comm = comm;
			this.log = log;
			this.clients = clients;
			this.connections = connections;
			this.filters = filters;
			this.publishers = publishers;
	        
	        mysubs = new Vector();
	        myfilters = new Hashtable();
	        myconn = new Vector();
	        mynotif = new Vector();	        
	        close = false;
	        	        			
		}catch (Exception e) {
			e.printStackTrace();	
		}
	
	}

	public void run() {	
  	  try {		
	    while(!close) {
	    	
		  Hashtable event = (Hashtable) comm.receive();	

		  if (event.containsKey(Protocol.ACTION)) {
		  	
		  	String subject = "";
		  	
		  	if (event.containsKey(Protocol.SUBJECT))		  	
		      subject = (String) event.get(Protocol.SUBJECT);
		  	
		  	Integer action = (Integer) event.get(Protocol.ACTION);		  	
		  
		    switch (action.intValue()) {
		    	
		      //Register Subscription
		      case Protocol.REGISTER_SUBS :
		    			    	
		        boolean exist = connections.regSubs(subject);
		    
  		        if (!exist) {
		          Hashtable info = (Hashtable) event.clone();
		          info.remove(Protocol.ACTION);
		          info.remove(Protocol.SUBJECT);
		          publishers.put(subject,info);
		          mynotif.add(subject);
		          log.put("Register subs "+subject+" from "+comm.getInetAddress());
		       
		        }
		    	   
		      break;
		      
		      //Exist Publisher
		      case Protocol.EXIST_SUBS :
		    		    	    	    	    
		        if (publishers.containsKey(subject)) {
		          Hashtable ack = new Hashtable();
		          ack.put("#ack",action);
		          comm.send(ack);		      		      
		        }		    	   
		        else {
			      Hashtable ack = new Hashtable();
                  ack.put("#ack",new Integer(Protocol.ERROR));
                  comm.send(ack);		      		      
		        }
		      break;
		  
		      //Info Publisher
		      case Protocol.INFO_SUBS :
		    		    	    	    	    
		        if (publishers.containsKey(subject)) {
		          Hashtable info = (Hashtable) publishers.get(subject);
		          info.put("#ack",action);
		          comm.send(info);		      		      
		        }		    	   
		        else {
			      Hashtable ack = new Hashtable();
		          //ack.put("subject",subject);
                  ack.put("#ack",new Integer(Protocol.ERROR));
                  comm.send(ack);		      		      
		        }
		      break;
		  		  
		      //Unregister Subscription
		      case Protocol.UNREGISTER_SUBS :		    
                
                if (mynotif.contains(subject)) {		    	    
		          Hashtable alert = new Hashtable();
		          alert.put("#unregister_subs",subject);
		          alert.put("reason","unsubscribed");
		    
		          if (connections.containsKey(subject)){
		            Collection c = connections.getConnections(subject);			        
                    Iterator it = c.iterator();		  	
	                while (it.hasNext()) {
	                  ObjectOutputStream out = (ObjectOutputStream) it.next(); 	
	                  try {
	                    out.writeObject(alert);		        
	                  }catch(IOException ex) {}	  
	                }
	          
	                boolean successful = connections.unregSubs(subject);
		    
		            if (successful) {
		              log.put("Unregister subs "+subject+" from "+comm.getInetAddress());
		              publishers.remove(subject);
		              mynotif.remove(subject);		      
		            }
	              }		    	   
	            }  
		       break;
		  
		      //Add Subscription
		      case Protocol.ADD_SUBS :
		    		    	    		    
		        boolean successful = clients.addSubs(subject,getName(),comm);
		  
		        Hashtable ack = new Hashtable();
		        //ack.put("subject",subject);

		        if (successful) {		        			          
		          log.put("Add subs "+subject+" from "+comm.getInetAddress());
		          mysubs.add(subject);
		          ack.put("#ack",action);
		          comm.send(ack);	
		        }
		        else {
		          log.put("Refused add subscription "+subject+" from "+comm.getInetAddress());
		          ack.put("#ack",new Integer(Protocol.ERROR));
		          comm.send(ack);	
		       }
		      break;	
		      
		      //Get Subscriptors
		      case Protocol.GET_SUBS :
		    		    	    	    	    
		        if (clients.containsKey(subject)) {
		          Vector IPs = new Vector();		          
		          
		          Collection c = clients.getClients(subject);			        
                  Iterator it = c.iterator();		  	
	              while (it.hasNext()) {	              
	                Communication comm = (Communication) it.next();  
	                InetAddress ip = comm.getInetAddress();	              
	                IPs.add(ip);	                
		          }
		          
		          ack = new Hashtable();		          
		          ack.put("#ack",action);
		          ack.put("IPs",IPs);
		          comm.send(ack);		      		      
		        }		    	   
		        else {
			      ack = new Hashtable();
		          //ack.put("subject",subject);
                  ack.put("#ack",new Integer(Protocol.ERROR));
                  comm.send(ack);		      		      
		        }
		      break;
		  	  
		      //Remove Subscription 
		      case Protocol.REM_SUBS :		      	        
		    		    	    		    
		        successful = clients.remSubs(subject,getName());
		    
		        ack = new Hashtable();
		        //ack.put("subject",subject);
		    
		        if (successful) {
		          log.put("Remove subscription "+subject+" from "+comm.getInetAddress());
		          mysubs.remove(subject);
		          ack.put("#ack",action);
		          comm.send(ack);			      			    		      
		        }
		        else {
		          log.put("Refused remove subs "+subject+" from "+comm.getInetAddress());
		          ack.put("#ack",new Integer(Protocol.REM_SUBS));
		          comm.send(ack);	
		        }	    	    	  	
		      break;
		      
		      //Add Connection
		      case Protocol.ADD_CONN :
		    		    	    		    
		        successful = connections.addConn(subject,getName(),comm.getOut());
		  
		        ack = new Hashtable();
		        //ack.put("subject",subject);
		    
		        if (successful) {		        			          
		          log.put("Add connection "+subject+" from "+comm.getInetAddress());
		          myconn.add(subject);
		          ack.put("#ack",action);
		          comm.send(ack);	
		        }
		        else {
		          log.put("Refused add connection "+subject+" from "+comm.getInetAddress());
		          ack.put("#ack",new Integer(Protocol.ERROR));
		          comm.send(ack);	
		       }
		      break;	
		  	  
		      //Remove Connection
		      case Protocol.REM_CONN :
		    		    	    		    
		        successful = connections.remConn(subject,getName());
		    
		        ack = new Hashtable();
		        //ack.put("subject",subject);
		    
		        if (successful) {
		          log.put("Remove connection "+subject+" from "+comm.getInetAddress());
		          myconn.remove(subject);
		          ack.put("#ack",action);
		          comm.send(ack);			      			    		      
		        }
		        else {
		          log.put("Refused remove connection "+subject+" from "+comm.getInetAddress());
		          ack.put("#ack",new Integer(Protocol.ERROR));
		          comm.send(ack);	
		        }	    	    	  	
		      break;      
		  
		      //Add Filter
		      case Protocol.ADD_FILTER :
	    	    
		        successful = false;
		    
		        if (clients.containsKey(subject)) {
		    	
	  	          String name = (String) event.get("name");					        
		          byte[] bytes = (byte[]) event.get("class");
		          
		          ClassLoader loader = new ByteClassLoader(bytes);		
		          Class theClass = loader.loadClass(name);		
	              Constructor theConstructor = theClass.getConstructor(null);			
 		          InterceptorListener filter = (InterceptorListener)theConstructor.newInstance(null);
 		          
		          successful = filters.addFilter(subject,getName(),filter);
		      		        	      
		          if (successful) {		          	
		            log.put("Add filter "+subject+" from "+comm.getInetAddress());
		            
		            Vector v;
		            if(myfilters.containsKey(subject)) 
		              v = (Vector) myfilters.get(subject);		              
		            
		            else v = new Vector();	              
		            
		            v.add(filter.getClass().getName());		
		            myfilters.put(subject,v);
		            
		          }
		          else 
		            log.put("Refused add filter "+subject+" from "+comm.getInetAddress());	      
		        }		    
		    
		      break;
		  				  
		      //Remove Filter
		      case Protocol.REM_FILTER :
                
                String name = (String) event.get("name");			
		        successful = filters.remFilter(subject,getName(),name);
		    
		        //ack = new Hashtable();
		        //ack.put("subject",subject);
		      
		        if (successful) {
		          log.put("Remove filter "+subject+" from "+comm.getInetAddress());
   		          
  		          Vector v;
		          if(myfilters.containsKey(subject)) {
		            v = (Vector) myfilters.get(subject);		            
		            v.remove(name);		
		            myfilters.put(subject,v);		 
		          }     			    		      	
		        }
		        else 
		         log.put("Refused remove filter "+subject+" from "+comm.getInetAddress());
	    	    	  	
		      break;
		  
		      //Close Communication
		      case Protocol.CLOSE :		    
		  	
		  	    filters.remFilters(myfilters,getName());		    		    
		   	    clients.remClients(mysubs,getName());	
		   	    connections.remConnections(myconn,getName());	    
		    		    
		        Iterator it = mynotif.iterator();
  		        while (it.hasNext()) {
		    	
		          subject = (String) it.next();		      
		          Hashtable alert = new Hashtable();
		          alert.put("#unregister_subs",subject);
		          alert.put("reason","close");
		      
		          if (connections.containsKey(subject)){
		            Collection c = connections.getConnections(subject);			        
                    Iterator it2 = c.iterator();		  	
	                while (it2.hasNext()) {
	                  ObjectOutputStream out = (ObjectOutputStream) it2.next();
	                  try {
	                    out.writeObject(alert);		        
	                  }catch(IOException ex) {}	            
		            }
		          }	
		        } 
		        ack = new Hashtable();
		        ack.put("#ack",action);
		        comm.send(ack);	
		    
		        try {
		          comm.close();			    	
                }catch(IOException ex) {}
                log.put("Connection close by "+comm.getInetAddress());                
		        close = true;
		         
              break;
            }
          }
		  //Notif		      
		  else  { 
		     if (event.containsKey(Protocol.SUBJECT)) {		  	
		      String subject = (String) event.get(Protocol.SUBJECT);		    
		      log.put("Notify "+event+" from "+comm.getInetAddress());
		    
		      if (filters.containsKey(subject)) {	
                Vector v = filters.getFilters(subject);	
	            Iterator it = v.iterator();		  	
	            while (it.hasNext()) {	          	
	              Object filter = it.next();
	              InterceptorListener listener = (InterceptorListener) filter;
	              event = listener.interceptorEventArrived(event);
                }
	  
      	        if (clients.containsKey(subject)) {		     
	              Collection c = clients.getClients(subject);			        
                  Iterator it2 = c.iterator();		  	
	              while (it2.hasNext()) {
	                Communication comm = (Communication) it2.next();  
	                ObjectOutputStream out = comm.getOut();
	                try {
	                  out.writeObject(event);		     	              	              	                   
	                }catch(IOException ex) {}	 	        
		          }
		        }
	          }
	      
		      else if (clients.containsKey(subject)) {		     
		        Collection c = clients.getClients(subject);			        
                Iterator it = c.iterator();		  	
	            while (it.hasNext()) {	              
	              Communication comm = (Communication) it.next();  
	              ObjectOutputStream out = comm.getOut();
	              try {
	                out.writeObject(event);		     	              	              	                   
	              }catch(IOException ex) {}	     
		        }
		      }		    
            }
          } 
        }//end while     
      
          } catch (Exception e) {		
            clients.remClients(mysubs,getName());		    
			filters.remFilters(myfilters,getName());
			connections.remConnections(myconn,getName());
		   		    		    
		    Iterator it = mynotif.iterator();
		    while (it.hasNext()) {
		    	
		      String subject = (String) it.next();		      
		      Hashtable alert = new Hashtable();
		      alert.put("#unregister_subs",subject);
		      alert.put("reason","crash");
		      
		      if (connections.containsKey(subject)){
		        Collection c = connections.getConnections(subject);			        
                Iterator it2 = c.iterator();		  	
	            while (it2.hasNext()) {
	              ObjectOutputStream out = (ObjectOutputStream) it2.next();
	              try {
	                out.writeObject(alert);		        
	              }catch(IOException ex) {}	            
		        }
		      }	
		    } 		    
		   e.printStackTrace();
         
          	log.put("Connection crashed by "+comm.getInetAddress()); 	
          	
	    } 
        
	}
	
}
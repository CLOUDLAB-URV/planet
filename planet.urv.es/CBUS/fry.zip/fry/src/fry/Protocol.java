package fry;

public class Protocol {
	
	public static final int REGISTER_SUBS = 1;
	
	public static final int EXIST_SUBS = 2;

	public static final int INFO_SUBS = 3;
	
	public static final int UNREGISTER_SUBS = 4;
	
	public static final int ADD_SUBS = 5;
	
	public static final int GET_SUBS = 6;
	
	public static final int REM_SUBS = 7;
	
	public static final int ADD_CONN = 8;
	
	public static final int REM_CONN = 9;
	
	public static final int ADD_FILTER = 10;
	
	public static final int REM_FILTER = 11;
	
	public static final int CLOSE = 12;
	
	public static final int ERROR = -1;
	
	public static final String ACTION = "action";
	
	public static final String SUBJECT = "subject";
}
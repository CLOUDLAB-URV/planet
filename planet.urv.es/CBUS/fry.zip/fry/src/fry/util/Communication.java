package fry.util;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Class communication it's a simple socket abstraction solution
 * @author Ruben Mondejar
 * 10/07/2003
 */ 
 
public class Communication {
	 
	private Socket socket;
	private ObjectOutputStream out;	
	private ObjectInputStream in;
	

	// Server mode
	public Communication(ServerSocket ss) throws UnknownHostException, IOException {
   	  
	  socket = ss.accept();    
	  OutputStream os = socket.getOutputStream();
	  out = new ObjectOutputStream(os);
	  
	  InputStream is = socket.getInputStream();	  
	  in = new ObjectInputStream(is);
	  
	  
    }
	
	//Client mode
    public Communication(String ip, int port) throws UnknownHostException, IOException {
    	      
	  socket = new Socket(ip,port);
	  OutputStream os = socket.getOutputStream();
	  this.out = new ObjectOutputStream(os);
	  
	  InputStream is = socket.getInputStream();	  
	  this.in = new ObjectInputStream(is);
	  
	  
    }
    
    public ObjectOutputStream getOut() {
      return out;
    }
    
    public void close() throws IOException {
      in.close();
      out.close();
      socket.close(); 
    }
    
    public void send(Object obj) throws IOException, InterruptedException {
    //  while (count <0) {
    //    wait();
    //  }
    //  count--;
      out.writeObject(obj);  
    //  count++;
    //  notify();
      
    }
    
    public synchronized Object receive() throws IOException, ClassNotFoundException, InterruptedException {
    //while (count2 <0) {
    //    wait();
    //  }
    //  count2--;	
      Object obj = in.readObject();
    //  count2++;  
    //  notify();
      return obj;
    }
    
    public InetAddress getInetAddress() {
      return socket.getInetAddress();
    }
    public String toString() {
      return socket.toString();
    }
}

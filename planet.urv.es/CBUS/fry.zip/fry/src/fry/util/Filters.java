package fry.util;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Server filters structure
 * @author Ruben Mondejar
 * 10/07/2003
 */ 


public class Filters extends Hashtable {
    
	//Return true if the add is successful
	
	public synchronized boolean addFilter(String subject, String id, Object filter) {
             
      boolean successful = false;     
	  
	  String name = filter.getClass().getName();	  
	  	  
	  if (containsKey(subject))  {
	  	//filters of subject
	    HashQueue queue = (HashQueue) get(subject);
	    
		if (!queue.containsKey(id+name)) {
		  queue.append(id+name,filter);					
		  put(subject,queue);	
		  successful=true;
	    }	    
	    
	  }
	  else {
	    HashQueue queue = new HashQueue();
	    queue.append(id+name,filter);
	    put(subject,queue);	
		successful=true;			
	  }		  
    
      return successful;
    }
    
    
    //Return true if the remove is successful
       	
	public synchronized boolean remFilter(String subject, String id, String filter) {	
             
      boolean successful = false;     
      
      if (containsKey(subject)) {		  	
       //filters of subject
	    HashQueue queue = (HashQueue) get(subject);
	    
		if (queue.containsKey(id+filter)) {
		   queue.delete(id+filter);
		   
		   if (queue.size()>0) put(subject,queue);			   
		   else remove(subject);
		   
		   successful = true;		
	    }
		
	  }
      return successful;
    }
    
        
    
    public synchronized void remFilters(Hashtable filters, String id) {
      Collection c = filters.keySet();
      Iterator it = c.iterator();	
      while (it.hasNext()) {
      	String subject = (String) it.next();      	
        Vector subjects = (Vector) filters.get(subject);
        Iterator it2 = subjects.iterator();		  	
	    while (it2.hasNext()) {
	      String name = (String) it2.next();
	      remFilter(subject,id,name);	          	
	    }     
      }
    }
       
    //Return a Vector of filters in a FIFO order
    
    public synchronized Vector getFilters(String subject) {	
      
      HashQueue queue = (HashQueue) get(subject);			        
      return queue.getQueue();             
    } 
      
}
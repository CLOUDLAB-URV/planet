package fry.util;

import java.util.*;
import java.io.*;

 public class EventLog {
   
   //level 0 --> nothing
   //level 1 --> all, except Notify
   //level 2 --> all
   //level 3 --> all to file
   //level 4 --> all to screen & to file
   
   private int level;
   PrintStream file;
   
   
   public EventLog(int level) {
   	 this.level = level; 
   	 try {
   	   if (level >= 3) this.file= new PrintStream(new FileOutputStream(new File("log.txt")));    	  	 
     }
     catch(Exception e) {}
   }

   public void put(String msg) {
   	 if (level  == 2 || ( !msg.startsWith("Notify") && level == 1) )	
   	   System.out.println(msg);  
   	 else if (level == 3 ) 
   	   file.println(msg); 
   	 else if (level == 4) {
   	   file.println(msg); 
   	   System.out.println(msg);     	   
   	 }	       
   	 
   } 
   
}

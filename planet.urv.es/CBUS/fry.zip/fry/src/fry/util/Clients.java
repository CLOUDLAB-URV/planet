package fry.util;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Server clients structure
 * @author Ruben Mondejar
 * 05/07/2003
 */ 

public class Clients extends Hashtable {
    
	//Return true if the add is successful
	
	public synchronized boolean addSubs(String subject, String id, Communication comm) {
             
      boolean successful = false;     
	  
	  if (containsKey(subject))  {
	  	//clients of subject
	    Hashtable cos = (Hashtable) get(subject);
	    
		if (!cos.containsKey(id)) {
		  cos.put(id,comm);					
		  put(subject,cos);	
		  successful=true;
	    }	    
	    
	  }		  
	  else {
	    Hashtable cos = new Hashtable();
	    cos.put(id,comm);					
        put(subject,cos);
        successful=true;			
	  }		  
    
    
      return successful;
    }
    
    //Return true if the remove is successful
       	
	public synchronized boolean remSubs(String subject, String id) {	
             
      boolean successful = false;     
      
      if (containsKey(subject)) {		  	
        //clients of subject
	    Hashtable cos = (Hashtable) get(subject);
	    
		if (cos.containsKey(id)) {
		   cos.remove(id);
		   put(subject,cos);			   
		   successful = true;		
	    }
		
	  }
      return successful;
    }
    
        
    //Return Communication Collection by the clients of a subject
    
    public synchronized Collection getClients(String subject) {	
      
      Hashtable cos = (Hashtable) get(subject);			        
      return cos.values();             
    }
	
    //Remove a client of a group of subjects
    public synchronized void remClients(Vector subjects, String id) {

      Iterator it = subjects.iterator();		  	
	  while (it.hasNext()) {
	    String subject = (String) it.next();
	    remSubs(subject,id);	          	
	  }     

    }
       
        
      
}
package fry.util;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Server connections structure
 * @author Ruben Mondejar
 * 22/07/2003
 */ 

public class Connections extends Hashtable {
    
	//Return true if the add is successful
	
	public synchronized boolean addConn(String subject, String id, ObjectOutputStream out) {
             
      boolean exists = false;     
	  
	  if (containsKey(subject))  {
	  	//connections of subject
	    Hashtable cos = (Hashtable) get(subject);
	    
		if (!cos.containsKey(id)) {
		  cos.put(id,out);					
		  put(subject,cos);	
		  exists=true;
	    }	    
	    
	  }		  
    
      return exists;
    }
    
    //Return true if the remove is successful
       	
	public synchronized boolean remConn(String subject, String id) {	
             
      boolean successful = false;     
      
      if (containsKey(subject)) {		  	
        //clients of subject
	    Hashtable cos = (Hashtable) get(subject);
	    
		if (cos.containsKey(id)) {
		   cos.remove(id);
		   put(subject,cos);			   
		   successful = true;		
	    }
		
	  }
      return successful;
    }
    
    public synchronized boolean regSubs(String subject) {
      
      boolean exists = true;
      
      if (!containsKey(subject)) {
        Hashtable cos = new Hashtable();
        put(subject,cos);
        exists = false;
      }
      
      return exists;
          
    }
    
    public synchronized boolean unregSubs(String subject) {
      
      boolean successful = false;
      
      if (containsKey(subject)) {
      	remove(subject);        
        successful = true;
      }
      
      return successful;
          
    }
        
    //Return ObjectOutputStream Collection by the clients of a subject
    
    public synchronized Collection getConnections(String subject) {	
      
      Hashtable cos = (Hashtable) get(subject);			        
      return cos.values();             
    }
	    
    //Remove a client of a group of subjects
    public synchronized void remConnections(Vector subjects, String id) {

      Iterator it = subjects.iterator();		  	
	  while (it.hasNext()) {
	    String subject = (String) it.next();
	    remConn(subject,id);	          	
	  }     

    }
       
        
      
}
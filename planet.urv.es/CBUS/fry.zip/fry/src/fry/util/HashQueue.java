package fry.util;

import java.util.*;

/**
 * Queue tad with hash methods 
 * @author Ruben Mondejar
 * 12/07/2003
 */ 


public class HashQueue extends Hashtable {
    
    private Vector queue;
    
    public HashQueue() {
      super();
      queue = new Vector();
    }
    
    public void append(Object key, Object elem) {
       queue.add(elem);
       put(key,elem);       
    }
    
    public void delete(Object key) {
       Object elem = get(key);
       queue.remove(elem);
       remove(key);    	
    }
    
    public Vector getQueue() {
      return (Vector) queue.clone();
    }
}
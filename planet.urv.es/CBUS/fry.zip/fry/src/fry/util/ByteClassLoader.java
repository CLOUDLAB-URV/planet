package fry.util;

import java.util.*;
import java.io.*;

 public class ByteClassLoader extends ClassLoader {
 
   byte[] source;
   
   public ByteClassLoader(byte[] bytes) {
   	 super();
   	 source = bytes;
   }

   public Class loadClass(String name, boolean resolve) throws ClassNotFoundException{
   	 return super.loadClass(name,resolve);
   }
    
   public Class findClass(String name) {         
     byte[] b = loadClassData(name);
     return defineClass(name, b, 0, b.length);
   }

   private byte[] loadClassData(String name) {
     return source;     
   }
   
   
}

package fry;

import fry.util.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 *   The Fry server receive the connection request and create
 * the threads to control this communication
 * 
 * @author Ruben Mondejar
 * 05/07/2003
 */ 
 
public class Server {
	
    private Clients clients;
    private Filters filters;
    private Connections connections;
    private Hashtable publishers;
    private EventLog log;
          
    public Server() {
      try {			
                  
	    FileInputStream  fis = new FileInputStream("env.properties");
		Properties env = new Properties();
		env.load(fis);
     
        int port = 5555;
        
        if (env.containsKey("port")) {
          String p= (String)env.get("port");       
          port = Integer.parseInt(p); 
        }
        
        int level = 2;
        
        if (env.containsKey("level")) {
          String l= (String)env.get("level");       
          level = Integer.parseInt(l); 
        }
	    	    
	    clients = new Clients();
	    connections = new Connections();
	    filters = new Filters();
	    publishers = new Hashtable();
	    log = new EventLog(level);	    
	    	    
	   	ServerSocket ss = new ServerSocket(port);	
		System.out.println("Fry server 0.4b initializing");		
		System.out.println("Accepting client connections on port "+port);
		System.out.println("Event log level "+level);
		while (true) {                		  
		  Communication comm = new Communication(ss); 	
		  System.out.println("New connection : "+comm);					
		  new ServerThread(comm,clients,connections,filters,publishers,log).start();			  
		}			
	  }catch (Exception e) {
		e.printStackTrace();
	  }	
    }
    
	public static void main(String[] args) {
	  Server bus = new Server();	 
    }
}

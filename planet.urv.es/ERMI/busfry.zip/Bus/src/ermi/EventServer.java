/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

import cbus.*;
import java.util.*;
import java.io.*;
import ermi.util.*;
/**
 *
 *  EventServer is an utility class for Skels and Stubs (both inherit from EventServer).
 *  This class handles event service connections, disconnections, event dispatching, exception wrapping 
 *  and stub class requests. It is internally used by ERMI so <b>it is not aimed for end users</b>.
 * 
 */
public class EventServer implements java.io.Serializable
{
	protected transient Session conn = null;
	protected String uid;
	protected String class_store="";
	protected String className;
	private String provider_url;
	private String provider_port;
	private String provider_class;
	protected Properties eref;
	
	
	
	
	
	
	public EventServer(Properties env) throws RemoteException
	{

		this.eref = env;
		String store = env.getProperty("CLASS_STORE");
		if (store!=null)
			this.class_store = store;
		
			
		conn = Bus.getBus(env);
	
	
	}

	/*
	public EventServer(String fileName)
	{
		
		try
		{ 		   	
			conn = SessionFactory.createSession(fileName);
			
	   }catch (SessionException e1)
		   {
			   e1.getException().printStackTrace();
	
	   }	
	}
	
	*/
	
	
	

	
	public void dispatchEvent(Hashtable evt,byte data[]) throws RemoteException
			{
				try
				{
					
					ByteWrapper bw = new ByteWrapper(data);
					conn.publish(evt,bw);
						
				}catch (SessionException e){throw new ConnectionException(e.getMessage());}	
		
			}
	
	
	public void dispatchEvent(Hashtable evt,java.io.Serializable params) throws RemoteException
			{
				try
				{
				
					conn.publish(evt,params);
						
				}catch (SessionException e){throw new ConnectionException(e.getMessage());}	
		
			}
	public void dispatchEvent(Hashtable evt) throws RemoteException
				{
					try
					{
						conn.publish(evt);		
					}catch (SessionException e){throw new ConnectionException(e.getMessage());}	
		
				}
	public String getUID()
	{
		return uid;
		
	}
	
	public void writeERef(String fileName)
	{
			try
			{
			
				
				eref.setProperty(Context.CLASS_ID,uid);
				eref.setProperty(Context.CLASS_NAME,className+"Stub");
				
				
				
				FileOutputStream fos = new FileOutputStream(fileName);
				
				
				eref.store(fos,"Object Reference");
				
				fos.close();
			
			
				}catch (java.io.IOException e)
			{
				e.printStackTrace();
			}	
		
	}
	
	public Properties getERef()
	{
			
			
				eref.setProperty(Context.CLASS_ID,uid);
				eref.setProperty(Context.CLASS_NAME,className+"Stub");
				
				
				return eref;
		
	}
	
	protected  byte[] getBytes( String filename ) throws IOException 
	{
		// Find out the length of the file
		File file = new File( filename );
		long len = file.length();
		// Create an array that's just the right size for the file's
		// contents
		byte raw[] = new byte[(int)len];
		// Open the file
		FileInputStream fin = new FileInputStream( file );
		// Read all of it into the array; if we don't get all,
		// then it's an error.
		int r = fin.read( raw );
		if (r != len)
			throw new IOException( "Can't read all, "+r+" != "+len );
		// Don't forget to close the file!
		fin.close();
		// And finally return the file contents as an array
		return raw;
	}	
	
	
}

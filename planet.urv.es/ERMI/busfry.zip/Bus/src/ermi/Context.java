/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */

package ermi;

/**
 *   Context contains ERMI middleware constants like connection timeouts, block delays 
 *   and String constants for the properties objects.
 * 
 */

public class Context 
{
	
	/**
	 * 
	 * Time out for the ERMI Middleware. It implies a TIMEOUT*DELAY milliseconds.
	 * 
	 */
	
	public static int TIMEOUT = 50;

	/**
	 * 
	 * Default delay for synchronous calls. 
	 * 
	 */
	
	public static int DELAY = 10;
	
	/**
	 * 
	 * CLASS_STORE is the constant that references to the directory contaning loadable remote stubs.
	 * 
	 */
	public static final String CLASS_STORE = "CLASS_STORE";
	
	/**
	 * 
	 * CLASS_NAME is the constant that references to the name of the Stub class for the properties reference.
	 * 
	 */
	
	public static final String CLASS_NAME = "CLASS_NAME";
	
	/**
	 * 
	 * CLASS_ID is the unique identifier assigned to an object server. It is used for all subscriptions
	 * related to this object.
	 * 
	 */
	public static final String CLASS_ID = "CLASS_ID";
}

/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

/**
 *
 * The EFilter interface serves to identify objects that can be intercepted by ermi distributed Filters.
 * <br>
 *  It is internally used by ERMI to create filter subscriptions so <b>it is not aimed for end users </b>.
 */
public interface EFilter extends ERemote {

/**
	 * It changes the subscription of the remote object in order to allow interception.
	 * See ERMI architecture for more information
	 * 
 	 * @throws ermi.RemoteException - if the connection with the event service fails. 
	 */

	public String addFilter(String uid)  throws RemoteException;
	
	/**
	 * It changes the subscription of the remote object in order to allow interception.
	 * See ERMI architecture for more information
	 * @throws ermi.RemoteException - if the connection with the event service fails.  
	 */
	public void removeFilter() throws RemoteException;
	/**
	 * It changes the subscription of the remote object in order to allow interception.
	 * See ERMI architecture for more information
	 * @throws ermi.RemoteException - if the connection with the event service fails.  
	 */
	
	public void removeFilter(String uid)  throws RemoteException;
}

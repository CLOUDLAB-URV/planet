/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;

/**
 *
 */
public class Rmic  {

	static Vector basicTypes = new Vector();
	static Vector wrappers = new Vector();
	
	public static void main(String[] args) throws Exception
	{
		
		String className = args[0];
		StringBuffer buf = new StringBuffer();
		
		basicTypes.add("int");
		basicTypes.add("char");
		basicTypes.add("double");
		basicTypes.add("float");	
		basicTypes.add("long");	
		basicTypes.add("boolean");	
		
		wrappers.add("Integer");
		wrappers.add("Character");
		wrappers.add("Double");
		wrappers.add("Float");	
		wrappers.add("Long");	
		wrappers.add("Boolean");	
		
	//	System.out.println(generateSkel(buf,className));
		String name = getClassName(className);
	
		
		FileOutputStream fos = new FileOutputStream(name+"Skel.java");
		PrintStream pos = new PrintStream(fos);
		pos.print(generateSkel(buf,className));
		pos.close();
					
		
		StringBuffer buf2 = new StringBuffer();
			
	//	System.out.println(generateStub(buf2,className));
		FileOutputStream fos2 = new FileOutputStream(name+"Stub.java");
		PrintStream pos2 = new PrintStream(fos2);
		pos2.print(generateStub(buf2,className));
		pos2.close();
			
	}
	
	public static String getClassName(String className)
	{
		try
		{
			Class theClass = Class.forName(className);
			Package pac = theClass.getPackage();
			
			if (pac !=null)
			{
					
				int length1 = pac.getName().length();
				String cls = className.substring(length1+1,className.length());
			
				return cls;
			}else 
			{
			
				return className;
			}
			
						
			
		}catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		return null;
	}
	
	public static String getPackageName(String className)
	{
		try
		{
			Class theClass = Class.forName(className);
			
			Package pac = theClass.getPackage();
			if (pac !=null)
				return pac.getName();
			else return "NOPACKAGE";
			
			
			
		}catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		return null;
	}
	
	public static String generateSkel(StringBuffer output, String className)
	{
		
		String cls,pName;
		try
		{
			Class theClass = Class.forName(className);
			Package pac = theClass.getPackage();
			
			if (pac !=null)
			{
				
				int length1 = pac.getName().length();
				cls = className.substring(length1+1,className.length());
				pName = pac.getName();
				
			}else 
			{
				cls = className;
				pName = "NOPACKAGE";
			}
		
		skelHeader(output,cls,pName);
		setSkelConstructor(output,cls,className);
		setSkelHandler(output,className);
		setSkelMethods(output,className);
		setCloseMethod(output,className);
		output.append("}\n");
		
		}catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		
		return output.toString();
		
		
	}
	
	public static void skelHeader(StringBuffer output,String className, String tpackage)
	{
		if (!tpackage.equals("NOPACKAGE"))
			output.append("package "+tpackage+";\n\n");
		
		
		output.append("import cbus.*;\n");
		output.append("import java.util.*;\n");
		output.append("import ermi.*;\n");
		output.append("import ermi.registry.FileRegistry;\n");
		
		output.append("\n\n\n");
		output.append("public abstract class "+className+"Skel extends EventServer implements RemoteEventListener,"+className+"\n");
		output.append("{\n");
		output.append("String method;\n");
		output.append("String stubId;\n");
		output.append("Hashtable msg = new Hashtable();\n");
		output.append("String  subs;\n");
		output.append("\n");
	}
	
	public static void setSkelConstructor(StringBuffer output,String className,String cls)
	{
		output.append("public "+className+"Skel(Properties env) throws ermi.RemoteException\n");
		output.append("{\n");
		output.append("\tsuper(env);\n");
	//	output.append("\tHashtable subs = new Hashtable();\n");
		output.append("\tuid = ermi.util.UID.getUID();\n");
		output.append("\tsubs =uid;\n");
	//	output.append("\tthis.uid=uid;\n");
		output.append("\tclassName = \""+cls+"\";\n");
		
		output.append("\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
		output.append("}\n");
			
	}
	public static void setSkelHandler(StringBuffer output,String className)
		{
			boolean in = true;
			boolean out = true;
			try
			{
			
				output.append("public void eventArrived(java.util.Hashtable evt)\n");
				output.append("{\n");
				output.append("\tmethod = (String)evt.get(\"METHOD\");\n");
				output.append("\tstubId = (String)evt.get(\"STUBID\");\n");
			
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				
				
				
				Class params[],result;
				boolean isListener;
				for (int a=0;a<methods.length;a++)
				{
					isListener = true;
					params =methods[a].getParameterTypes();
					in = true;
					out = true;
			
					String methodName = methods[a].getName();
					isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
					if (!isListener)
					{
					
						if (a==0) 
							output.append("\tif (method.equals(\""+methodName+"\"))\n");
						else 
							output.append("\telse if (method.equals(\""+methodName+"\"))\n");
						
						output.append("\t{\n");		
						result = methods[a].getReturnType();
						
						if (result.getName().equals("void"))
							out = false;
						
						if (params.length==0)
							in = false;
						
						if (in==false&&out==false)
						{	
							output.append("\t\ttry {\n");
							output.append("\t\t\t"+methods[a].getName()+"();");	
							
							setEvent1(output,methodName);
							output.append("\t\t}catch(RemoteException ex){\n");	
							setEvent11(output,methodName);
							output.append("\t\t}\n");
						}else if (in==false&&out==true)
						{
							
							output.append("\t\ttry {\n");
							
							String type = result.getName();
							int found = find(type);
							if (found>=0)
							{
								String wrap = (String)wrappers.elementAt(found);
								
								output.append("\t\t\t"+result.getName()+" res2 = "+methods[a].getName()+"();\n");
								output.append("\t\t\t"+wrap+" res = new "+wrap+"(res2);\n");
					
							}else 
							{
								output.append("\t\t\t"+result.getName()+" res = "+methods[a].getName()+"();\n");
							}
							
							
							// if result.type in basictypes:
							// output.append("\t\t"+result.getName()+" res2 = "+methods[a].getName()+"();\n");
							// output.append("\t\t"+wrap+" res = res2."+type+"Value();\n");
							
							setEvent2(output,methodName);
							output.append("\t\t}catch(RemoteException ex){\n");	
							setEvent11(output,methodName);
							output.append("\t\t}\n");
											
						}else if (in==true&&out==false)
						{
								
								output.append("\t\ttry {\n");
								
								output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");	
								output.append("\t\t\t"+methods[a].getName()+"(");
								int i;
								for (i=0;i<params.length-1;i++)
								{
									
									String type = params[i].getName();
									int found = find(type);
									if (found>=0)
									{
										String wrap = (String)wrappers.elementAt(found);
										output.append("(("+wrap+")args.elementAt("+i+"))."+type+"Value(),");
									}else 
									{
										output.append("("+params[i].getName()+")args.elementAt("+i+"),");
									}
									
									// if params[i].type in basictypes:
									// output.append("("+wrap+")args.elementAt("+i+")."+type+"Value(),");							
									
				
									
								}
								String type = params[i].getName();
								int found = find(type);
								if (found>=0)
								{
									String wrap = (String)wrappers.elementAt(found);
									output.append("(("+wrap+")args.elementAt("+i+"))."+type+"Value());");	
								}else 
								{
									output.append("("+params[i].getName()+")args.elementAt("+i+"));\n");
								}
								// if params[i].type in basictypes:
									// output.append("("+wrap+")args.elementAt("+i+")."+type+"Value());");		
								
								
								setEvent1(output,methodName);	
								output.append("\t\t}catch(RemoteException ex){\n");	
								setEvent11(output,methodName);
								output.append("\t\t}\n");
								
						}else if (in==true&&out==true)
						{
								
								output.append("\t\ttry {\n");
								
								output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");	
								
								// if result.type in basictypes:
								// output.append("\t\t"+result.type+" res2 = "+methods[a].getName()+"(");	
								String resulttype = result.getName();
								String wrap1="";
								int found1 = find(resulttype);
								if (found1>=0)
								{
									wrap1 = (String)wrappers.elementAt(found1);
									output.append("\t\t\t"+resulttype+" res2 = "+methods[a].getName()+"(");
								}else 
								{
									output.append("\t\t\t"+result.getName()+" res = "+methods[a].getName()+"(");
								}
								
									
							
								int i;
								for (i=0;i<params.length-1;i++)
								{
									String type = result.getName();
									int found = find(type);
									if (found>=0)
									{
										String wrap = (String)wrappers.elementAt(found);
										output.append("("+wrap+")args.elementAt("+i+")."+type+"Value(),");
									}else 
									{
										output.append("("+params[i].getName()+")args.elementAt("+i+"),");
									}
								}
								String type = result.getName();
								int found = find(type);
								if (found>=0)
								{
									String wrap = (String)wrappers.elementAt(found);
									output.append("("+wrap+")args.elementAt("+i+")."+type+"Value());");	
								}else 
								{
									output.append("("+params[i].getName()+")args.elementAt("+i+"));\n");
								}
								if (found1>=0)
									output.append("\t\t"+wrap1+" res = res2."+resulttype+"Value();\n");
								// if result.type in basictypes:
								// output.append("\t\t"+result.wrap+" res = res2."+res.type+"Value();\n");	
							
								setEvent2(output,methodName);
								output.append("\t\t}catch(RemoteException ex){\n");	
								setEvent11(output,methodName);
								output.append("\t\t}\n");
						}
						output.append("\t}\n");
					}
				}
				setByteHandler(output);
				setFilterHandler(output);
				output.append("}\n");
			}catch (ClassNotFoundException ex)	
			{
				ex.printStackTrace();
			}
			
		}
	
		public static void setFilterHandler(StringBuffer output)
		{
			//addFilter
			
			output.append("\telse if (method.equals(\"addFilter\"))\n");
			output.append("\t{\n");
			output.append("\t\tRemoteException ex=null; \n");
			output.append("\t\tVector args = (Vector)evt.get(\"object\");\n");
			output.append("\t\tString uidf = (String)args.elementAt(0);\n");
			output.append("\t\ttry{	conn.removeSubscription(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			output.append("\t\tString res = uid;\n");
			output.append("\t\tuid = uidf;\n");
			output.append("\t\tsubs = uid;\n");
			output.append("\t\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\tmsg.put(\"subject\",res+\":RESULT:\"+stubId);\n");
			output.append("\t\tmsg.put(\"METHOD\",\"addFilter\");\n");
			
			output.append("\t\tif (ex!=null){\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}else{\n");
			
			output.append("\t\t\tmsg.put(\"TYPE\",\"DYSPATCH\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,res);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}\n");		
			
			
			
			
			
			output.append("\t}\n");
			
//			removeFilter
			
			 output.append("\telse if (method.equals(\"removeFilter\"))\n");
			 output.append("\t{\n");
			
			 output.append("\t\tRemoteException ex=null; \n");
			 output.append("\t\tVector args = (Vector)evt.get(\"object\");\n");
			 output.append("\t\tString uidf = (String)args.elementAt(0);\n");
			 output.append("\t\ttry{	conn.removeSubscription(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			 output.append("\t\tString res = uid;\n");
			 output.append("\t\tuid = uidf;\n");
			 output.append("\t\tsubs = uid;\n");
			 output.append("\t\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			
			
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\tmsg.put(\"subject\",res+\":RESULT:\"+stubId);\n");
			output.append("\t\tmsg.put(\"METHOD\",\"removeFilter\");\n");
			
			output.append("\t\tif (ex!=null){\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}else{\n");
			
			output.append("\t\t\tmsg.put(\"TYPE\",\"DYSPATCH\");\n");
			output.append("\t\t\tmsg.put(\"RESULT\",\"VOID\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}\n");		
			output.append("\t}\n");	
			
			 
			 
	}	
	public static void setByteHandler(StringBuffer output)
		{
			
			output.append("\telse if (method.equals(\"getBytes\"))\n");
			output.append("\t{\n");
			
			output.append("\t\t try \n");
			output.append("\t\t{\n");
			
			output.append("\t\t\tString aClass = Rmic.getClassName(className);\n");
			output.append("\t\t\tString fileClass = class_store+aClass+\"Stub.class\";\n");
			output.append("\t\t\tbyte data[] = getBytes(fileClass);\n");
			
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULTDYNAMIC:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"DYSPATCH\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\"getBytes\");\n");
			
			output.append("\t\t\tdispatchEvent(msg,data);\n");	
			output.append("\t\t }catch (java.io.IOException ex1) { \n");
			
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULTDYNAMIC:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\"getBytes\");\n");
			
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex1);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");		
			
			output.append("\t\t } catch (RemoteException ex2) {ex2.printStackTrace();} \n");
			
			output.append("\t}\n");
			
			
		}	
		
		public static void setEvent1(StringBuffer output,String methodName)
		{
			output.append("\t\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULT:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
			output.append("\t\t\tmsg.put(\"RESULT\",\"VOID\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg);\n");	
			output.append("\t\t\t}catch(RemoteException e){e.printStackTrace();}\n");	
		}
		public static void setEvent11(StringBuffer output,String methodName)
		{
			output.append("\t\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULT:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
		//	output.append("\t\t\tmsg.put(\"RESULT\",ex);\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");	
		}
		
		public static void setEvent2(StringBuffer output, String methodName)
		{
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULT:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
			
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,res);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");	
		}
		public static void setTriggerEvent(StringBuffer output, String methodName)
		{
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"subject\",uid+\":RESULT:"+methodName+"\");\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
			
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,res);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");	
		}
		
	public static void setSkelMethods(StringBuffer output,String className)
		{
			String name;
			try
			{
			
							
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				Class params[],result;	
				boolean isListener = false;
				for (int i=0;i<methods.length;i++)
				{
					name = methods[i].getName();
					isListener = (name.startsWith("add")||name.startsWith("remove"))&&name.endsWith("Listener");
					if (isListener)
						setListenerMethods(output,methods[i]);
					
					if (name.startsWith("add")&&name.endsWith("Listener"))
					{
						Class arg[] =methods[i].getParameterTypes();
						Method mListeners[]  =arg[0].getMethods();
						Class paramsListener[] = mListeners[0].getParameterTypes();
						String event1 = 	paramsListener[0].getName();				
						String event;
						Package pac = theClass.getPackage();
						if (pac !=null)
						{
								 int ll = pac.getName().length();
						
							 event = event1.substring(ll+1);
						} 
						else 
						{
								event = event1;  
						}
						output.append("public void trigger"+event+"("+event+" res) throws ermi.RemoteException\n");
						output.append("{\n");
						setTriggerEvent(output,event);
						
						output.append("}\n");					
					
						
					}	
							
					
				}
				
				
				
			}catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		
	public static String generateStub(StringBuffer output, String className)
	{
		
		String cls,pName;
		try
		{
			Class theClass = Class.forName(className);
			Package pac = theClass.getPackage();
			
			if (pac !=null)
			{
				
				int length1 = pac.getName().length();
				cls = className.substring(length1+1,className.length());
				pName = pac.getName();
				
			}else 
			{
				cls = className;
				pName = "NOPACKAGE";
			}
		
		stubHeader(output,cls,pName);
		setStubConstructor(output,cls,className);
		setStubHandler(output,className);
		setStubMethods(output,className);
		setStubMethods(output,"ermi.IFilter");
		setStubFilterMethod(output,className);
		setStubUtilMethod(output,className);
		output.append("}\n");
		
		}catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		
		return output.toString();
		
		
	}
	
	public static void stubHeader(StringBuffer output,String className, String tpackage)
	{
		if (!tpackage.equals("NOPACKAGE"))
			output.append("package "+tpackage+";\n\n");
		
		output.append("import ermi.*;\n");
		output.append("import cbus.SessionException;\n");
		output.append("import cbus.Session;\n");
		output.append("import cbus.RemoteEventListener;\n");
		output.append("import java.util.*;\n");
		output.append("import ermi.registry.FileRegistry;\n");
		output.append("import java.io.*;\n");
		output.append("\n\n\n");
		output.append("public  class "+className+"Stub extends EventServer implements RemoteEventListener,"+className+",EFilter\n");
	//	output.append("public  class "+className+"Stub extends EventServer implements RemoteEventListener,"+className+"\n");

		output.append("{\n");
		output.append("private String  subs;\n");
		output.append("private Vector listeners = new Vector();\n");
		output.append("private boolean resultArrived = false;\n");
		output.append("private boolean exception = false;\n");
		output.append("private Object result;\n");
		output.append("private String method;\n");
		output.append("private String stubId;\n");
		output.append("private int timeout;\n");
		output.append("private int listener_cnt = 0;\n");
		output.append("\n");
	}
	
	public static void setStubConstructor(StringBuffer output,String className, String cls)
	{
		output.append("public "+className+"Stub(Properties env) throws ermi.RemoteException\n");
		output.append("{\n");		
		output.append("\tsuper(env);\n");
		output.append("\tString muid = env.getProperty(Context.CLASS_ID);\n");
		output.append("\tuid = muid;\n");
		output.append("\tclassName = \""+cls+"\";\n");
		
		output.append("\tstubId = ermi.util.UID.getUID();\n");
		output.append("\tsubs = uid+\":RESULT:\"+stubId;\n");
		output.append("\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
		
		output.append("}\n");
		
		output.append("public "+className+"Stub(Properties env,String stub) throws ermi.RemoteException\n");
		output.append("{\n");		
		output.append("\tsuper(env);\n");
		output.append("\tString muid = env.getProperty(Context.CLASS_ID);\n");
		output.append("\tuid = muid;\n");
		output.append("\tclassName = \""+cls+"\";\n");
		output.append("\tstubId = ermi.util.UID.getUID();\n");
		output.append("\tsubs = uid+\":RESULT:\"+stubId;\n");
		output.append("\tconn = null;\n");
		output.append("}\n");
			
	}
		
		
		
		
	public static void setStubHandler(StringBuffer output,String className)
		{
			boolean in = true;
			boolean out = true;
			try
			{
			
				output.append("public void eventArrived(java.util.Hashtable evt)\n");
				output.append("{\n");
				output.append("\tmethod = (String)evt.get(\"METHOD\");\n");
				output.append("\tString type;\n");
			
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				
				
				
				Class params[],result;
				boolean isListener;
				for (int a=0;a<methods.length;a++)
				{
					isListener = true;
					params =methods[a].getParameterTypes();
					in = true;
					out = true;
			
					String methodName = methods[a].getName();
					isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
					
					if (!isListener)
					{
			
			
						if (a==0) 
							output.append("\tif (method.equals(\""+methodName+"\"))\n");
						else 
							output.append("\telse if (method.equals(\""+methodName+"\"))\n");
						
						output.append("\t{\n");		
						result = methods[a].getReturnType();
						
						if (result.getName().equals("void"))
							out = false;
						
						
						
						if (out==false)
						{	
							output.append("\t\tresult = evt.get(\"object\");\n");
							output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
							output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
							output.append("\t\t\texception = true;\n");
							output.append("\t\tresultArrived = true;\n");	
							
							
							
						}else 
						{
							output.append("\t\tresult = evt.get(\"object\");\n");
							output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
							output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
							output.append("\t\t\texception = true;\n");
							output.append("\t\tresultArrived = true;\n");	
							
											
						}
						output.append("\t}\n");	
					}
					/*else
					{
						if (methodName.startsWith("add"))
							
							{
								parseOnEvent(output,methods[a],a);
								output.append("\t}\n");		
							}
					}*/
					
					
				}
			
				output.append("\telse if (method.equals(\"addFilter\"))\n");
				output.append("\t{\n");	
				output.append("\t\tresult = evt.get(\"object\");\n");
				output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
				output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
				output.append("\t\t\texception = true;\n");
				output.append("\t\tresultArrived = true;\n");	
				output.append("\t}\n");	
				
				output.append("\telse if (method.equals(\"removeFilter\"))\n");
				output.append("\t{\n");	
				output.append("\t\tresult = evt.get(\"object\");\n");
				output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
				output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
				output.append("\t\t\texception = true;\n");
				output.append("\t\tresultArrived = true;\n");	
				output.append("\t}\n");	
					
				
				output.append("}\n");
			}catch (ClassNotFoundException ex)	
			{
				ex.printStackTrace();
			}
			
		}	
		
		public static void parseOnEvent(StringBuffer output,Method aMethod, int numMethod)
		{
			Class arg[] =aMethod.getParameterTypes();
			Method mListeners[]  =arg[0].getMethods();
			Class paramsListener[] = mListeners[0].getParameterTypes();
				
			
			String event1 = 	paramsListener[0].getName();				
			String event;
			Package pac = paramsListener[0].getPackage();
			if (pac !=null)
			{
				int ll = pac.getName().length();
				event = event1.substring(ll+1);
			}
			else 
			{
				event = event1;  
			}
			
			
			
			
			
			
			
			
			String methodName = aMethod.getName();
			String listener = methodName.substring(3,methodName.length());
			
			if (numMethod==0) 
					output.append("\tif (method.equals(\""+event+"\"))\n");
			
			else 
				output.append("\telse if (method.equals(\""+event+"\"))\n");
			
			output.append("\t{\n");		
			
			output.append("\t\t"+event+" result = ("+event+")evt.get(\"object\");\n");
			output.append("\t\tVector clisteners = (Vector)listeners.clone();\n");
			output.append("\t\tIterator it = clisteners.iterator();\n");	
			output.append("\t\twhile (it.hasNext())\n");
			output.append("\t\t{\n");
			output.append("\t\t\t"+listener+" aListener = ("+listener+")it.next();\n");
			output.append("\t\t\taListener."+mListeners[0].getName()+"(result);\n");
			output.append("\t\t}\n");
			
		}
		
		
		public static void setStubMethods(StringBuffer output,String className)
		{
			boolean in = true;
			boolean out = true;
			try
			{
			
							
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				Class params[],result;
				
				
				for (int a=0;a<methods.length;a++)
				{
					params =methods[a].getParameterTypes();
					in = true;
					out = true;
			
					String methodName = methods[a].getName();
				//	boolean isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
		
			
						
					output.append("public "+methods[a].getReturnType().getName()+ " "+methodName+"(");
					int j = 0;
					if (params.length==0)
					{
						output.append(")\n");
					//	if (!isListener)
							output.append(" throws RemoteException\n");
						
						
					} else if (params.length==1)
					{
						output.append(params[0].getName()+" p0) \n");
					//	if (!isListener)
							output.append(" throws RemoteException\n");
					}else 
					{
						for (j=0;j<params.length-1;j++)
						{
							output.append(params[j].getName()+" p"+j+",");
						}
						output.append(params[j].getName()+" p"+j+") \n");
				//		if (!isListener)
							output.append(" throws RemoteException\n");
					}
					
					parseMethod(output,methods[a]);
				
				
						
				}
				
				
			
			
			
		
			}catch (ClassNotFoundException ex)	
			{
				ex.printStackTrace();
			}
			
		}
		
		
	public static void parseMethod(StringBuffer output,Method aMethod)
	{
		Class result = aMethod.getReturnType();
		Class params[] =aMethod.getParameterTypes();			
		boolean in = true;
		boolean out = true;
		
		String methodName = aMethod.getName();
		boolean isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
		
		if (!isListener)
		{
		
					
			if (result.getName().equals("void"))
				out = false;
			if (params.length==0)
				in = false;
						
			output.append("{\n");
			output.append("\tHashtable evt = new Hashtable();\n");
			output.append("\tevt.put(\"subject\",uid);\n");
			output.append("\tevt.put(\"TYPE\",\"DISPATCH\");\n");
			output.append("\tevt.put(\"STUBID\",stubId);\n");
			output.append("\tevt.put(\"METHOD\",\""+aMethod.getName()+"\");\n");
			output.append("\tresultArrived = false;\n");
			
			
			if (in ==false)
			{
				output.append("\tdispatchEvent(evt);\n");
			} else 
			{
				output.append("\tVector args = new Vector();\n");
				
				
				
				for (int y=0;y<params.length;y++)
				{
					String type = params[y].getName();
					int found = find(type);
					
					Class interfaces[] = params[y].getInterfaces();
					if (contains(interfaces,"ermi.ERemote"))
					{
							output.append("\targs.add(p"+y+".copy());\n");
						
					}else
					{
						if (found>=0)
						{
							String wrap = (String)wrappers.elementAt(found);
							output.append("\targs.add(new "+wrap+"(p"+y+"));\n");	
						
						}else 
						{
							output.append("\targs.add(p"+y+");\n");
						}
					
					}
					
		
				
				
				}
				output.append("\tdispatchEvent(evt,args);\n");
				
				
			}		
				
				output.append("\ttimeout=0;");
				output.append("\twhile (!resultArrived&&timeout<Context.TIMEOUT)\n");
				output.append("\t{\n");
				output.append("\t\ttry{\n");
				output.append("\t\t\tThread.currentThread().sleep(Context.DELAY);\n");
				output.append("\t\t}catch (InterruptedException ex){ex.printStackTrace();}\n");
				output.append("\t\ttimeout++;\n");
				output.append("\t}\n");
				
				output.append("\tif (exception){\n");
				output.append("\t\texception = false;\n");
				output.append("\t\tRemoteException ex = (RemoteException)result;\n");
				output.append("\t\tthrow ex;\n");
				output.append("\t} else if (timeout==Context.TIMEOUT){\n");
				output.append("\t\tthrow new TimeoutException(\"Server is not alive\");\n");
				output.append("\t} ");
				
			if (out == true) 	
			{
				output.append("\telse \n {");
				String type = result.getName();
				int found = find(type);
			
				if (found>=0)
				{
					String wrap = (String)wrappers.elementAt(found);
					output.append("\t\t"+wrap+" res = ("+wrap+")result;\n");	
					output.append("\t\treturn res."+type+"Value();\n");	
					
				}else 
				{
					output.append("\t\t"+result.getName()+" res = ("+result.getName()+")result;\n");	
					output.append("\t\treturn res;\n");
				}
					output.append("\t}\n");
			}	
				
					
				
		
		}else 
		{
			output.append("{\n");
			if (methodName.startsWith("add"))
			{
				output.append("\tif (listener_cnt==0){\n");
				output.append("\t\tString lsubs;\n");
				output.append("\t\tlsubs = uid+\":RESULT:SpriteEvent\";\n");
				output.append("\t\ttry{\n");
				
				output.append("\t\t\tconn.subscribe(new RemoteEventListener(){\n");
				output.append("\t\t\tpublic void eventArrived(java.util.Hashtable evt){\n");
			
				Class arg[] =aMethod.getParameterTypes();
				Method mListeners[]  =arg[0].getMethods();
				Class paramsListener[] = mListeners[0].getParameterTypes();
				String event1 = 	paramsListener[0].getName();				
				String event;
				Package pac = arg[0].getPackage();
				if (pac !=null)
				{
					 int ll = pac.getName().length();
					 event = event1.substring(ll+1);
				} 
				else 
				{
					event = event1;  
				}		
				output.append("\t\t\t"+event+" result = ("+event+")evt.get(\"object\");\n");
				output.append("\t\t\tVector clisteners = (Vector)listeners.clone();\n");
				output.append("\t\t\tIterator it = clisteners.iterator();\n");
				output.append("\t\t\twhile (it.hasNext()){\n");
				output.append("\t\t\t\t"+arg[0].getName()+ " aListener = ("+arg[0].getName()+")it.next();\n");
				output.append("\t\t\t\taListener.onEvent(result);\n");
			
				output.append("\t\t\t}\n");
				output.append("\t\t}},lsubs);	\n");
				output.append("\t}catch (SessionException ex){throw new ConnectionException(\"Problem subscribing Listener\");}\n");
				output.append("\t}\n");
				output.append("\tlisteners.add(p0);\n");
				output.append("\tlistener_cnt++;\n");
				
				
			}else
			{
				output.append("\tlisteners.remove(p0);\n");
				output.append("\tlistener_cnt--;\n");
				output.append("\tif (listener_cnt==0){\n");
				output.append("\t\tString  lsubs;\n");
				output.append("\t\tlsubs = uid+\":RESULT:SpriteEvent\";\n");
				output.append("\t\ttry{\n");
				
				output.append("\t\t\tconn.removeSubscription(this,lsubs);\n");
				output.append("\t\t}catch (SessionException ex){throw new ConnectionException(\"Problem subscribing Listener\");}\n");
				output.append("\t}\n");
			}
			
		}
		
		output.append("}\n");
		
	
		
	}

	public static boolean contains (Class list[],String aClass)
	{
		boolean found = false;
		int cnt =0;
		String name;
		
		while (!found&&cnt<list.length)
		{
			name = list[cnt].getName();
			found = name.equals(aClass);
			cnt++;
		}
		return found;
	}


	public static void setStubFilterMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void removeFilter() throws RemoteException\n");
				output.append("{\n");
				output.append("}\n");		
						
			}	
	public static void setStubUtilMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void close() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\tif (conn!=null){\n");
				output.append("\t\ttry{	conn.removeSubscription(this,subs);ermi.util.Bus.close();conn = null;	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("\t}\n");
				output.append("}\n");		
				
				output.append("public void init() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\tconn = ermi.util.Bus.getBus(eref);\n");
				output.append("\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				
				
				output.append("private void writeObject(java.io.ObjectOutputStream out) throws IOException\n");
				output.append("{\n");
				output.append("\ttry{\n");
				output.append("\t\tclose();\n");
				output.append("\t}catch (RemoteException e){throw new IOException(\"Problems with the Event Service\");}\n");
				output.append("\tout.defaultWriteObject();\n");
				output.append("}\n");		
				
				output.append("private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException\n");
				output.append("{\n");
				output.append("\ttry{\n");
				output.append("\t\tin.defaultReadObject ();\n");
				output.append("\t\tinit();\n");
				output.append("\t}catch (RemoteException e){e.printStackTrace();}\n");
				output.append("}\n");		
				
				output.append("public boolean equals(Object obj)\n");
				output.append("{\n");
				output.append("\tERemote ref = (ERemote)obj;\n");
				output.append("\treturn ref.getERef().equals(getERef());\n");
				output.append("}\n");	
				
				output.append("public ERemote copy() throws RemoteException\n");
				output.append("{\n");
				output.append("\tERemote ref = FileRegistry.loadStub(getERef());\n");
				output.append("\treturn (ERemote)ref;\n");
				output.append("}\n");	
				
						
			}	

	public static void setCloseMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void close() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\ttry{	conn.removeSubscription(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				output.append("public void init() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\tconn = ermi.util.Bus.getBus(eref);\n");
				output.append("\ttry{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				output.append("public ERemote copy() throws RemoteException\n");
				output.append("{\n");
				output.append("\tERemote ref = FileRegistry.loadStub(getERef());\n");
				output.append("\treturn (ERemote)ref;\n");
				output.append("}\n");	
				
						
			}	
public static void setListenerMethods(StringBuffer output,Method aMethod)
			{
				Class params [] = aMethod.getParameterTypes();
				
			
				output.append("public void "+aMethod.getName()+"("+params[0].getName()+ " l0) throws ermi.RemoteException {} \n");
				
				
						
			}

	public static int  find(String type)
	{
		int found = -1000;
		int i =0;
		int length = basicTypes.size();
	
		while (found<0&&i<length)
		{
			String elem = (String)basicTypes.elementAt(i);
			
			if (elem.equals(type))
				found = i;
			else 
				i++;
			
		}
		return found;
		
	}	
		
}

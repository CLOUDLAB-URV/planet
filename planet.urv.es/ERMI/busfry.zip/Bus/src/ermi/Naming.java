/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 * 
 */
package ermi;

import ermi.registry.*;
import ermi.registry.FileRegistry;
import java.util.*;

/**
 *
 *  The Naming class provides methods for storing and obtaining references to remote objects 
 *  in the remote object registry.<br><br>
 *  
 *  The ermi.Naming API (unlike java.RMI) does not use URLs, but Properties Object or files 
 *  containing connection parameters. It is then mandatory to call loadRegistry before using 
 * the functionality of the Registry..
 
 * 
 */
public class Naming 
{
	 private static ERegistry registry = null;
	
	/**
	 * It connects to the Registry using the information contained in the properties file ref).
	 * @param ref Name of properties file containing connection parameters.
 	 * @throws ermi.RemoteException - if the connection with the event service fails.  
	 */
	 
	 public static void  loadRegistry(String ref) throws RemoteException
	 {
	 	if (registry==null)
	 		registry = (ERegistry)FileRegistry.loadERef(ref);
		else 
			throw new RegistryNotLoadedException("Registry already loaded");
	 	 	
	 }
	 
	 /**
	 * Disconnects from to the Registry.
	 * @throws ermi.RemoteException - if the connection with the event service fails.  
	 */
	 
	  public static void  unloadRegistry() throws RemoteException
	 {
	 	if (registry!=null)
	 	{
	 		registry.close();
	 		registry = null;
	 	}else
	 	{ 
			throw new RegistryNotLoadedException("Registry not loaded");
	 	} 	
	 	
	 }
	 
	 /**
	 *  Returns a reference, a stub, for the remote object associated with the specified name.
	 * @param ref Id of the remote object in the Registry
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @throws ermi.NotBoundException - if the Registry does not contains this Id.
 	 * @return ermi.Eremote Reference to the remote object
	  */
	 public static ERemote lookup(String name) throws RemoteException
	 {
	 	if (registry==null)
	 		throw new RegistryNotLoadedException("Registry not loaded");
	 	Properties eref = registry.lookup(name);
	 	ERemote result = (ERemote)FileRegistry.loadERef(eref);
	 	
	 	return result;
	 }
	 
	 /**
	 *  Binds the specified name to a remote object.
	 * @param name Id of the remote object 
	 * @param ref remote object reference to bind
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 
	 public static void bind(String name, ERemote ref) throws RemoteException
	 {
	 	if (registry==null)
	 		throw new RegistryNotLoadedException("Registry not loaded");
		registry.bind(name,ref.getERef());

	 }
	 
	 /**
	 *  Unbinds the specified name from the registry.
	 * @param name Id of the remote object 
	 * @throws ermi.NotBoundException - if the Registry does not contains this Id.
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 public static void unbind(String name) throws RemoteException
	 {
	 	if (registry==null)
	 		throw new RegistryNotLoadedException("Registry not loaded");
		registry.unbind(name);
	 }
	 
	  /**
	 *  Rebinds the specified name in the registry.
	 * @param name Id of the remote object 
 	 * @param ref remote object reference to bind
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 public static void rebind(String name, ERemote ref) throws RemoteException
	 {
	 	if (registry==null)
	 		throw new RegistryNotLoadedException("Registry not loaded");
		registry.rebind(name,ref.getERef());
	 }
	 
	  /**
	 *  Returns a Vector of the names bound in the registry. 
	 * The Vector contains a snapshot of the names present in the registry at the time of the call.
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return java.util.Vector  A list of Ids from remote objects. 
 	 */
	 
	public static Vector list() throws RemoteException
	 {
	 	if (registry==null)
	 		throw new RegistryNotLoadedException("Registry not loaded");
		return registry.list();
	 }

}

/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;


/**
 *
 * A RemoteException is the common superclass for a number of communication-related 
 * exceptions that may occur during the execution of a remote method call. 
 * Each method of a remote interface, an interface that extends ermi.Remote,
 *  must list ERemoteException in its throws clause. 
 * 
 */
public class RemoteException extends Exception implements java.io.Serializable {

	public RemoteException(String msg)
		{
			super(msg);
		}
}

package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class NamingTest extends TestCase {

	SimpleImpl server,server2;
	ERegistryImpl registry;
	
	public NamingTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
				
			server = new SimpleImpl(env);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			server2 = new SimpleImpl(env);
			Naming.bind("/simple2",server);
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			server2.close();
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(SimpleTest.class);
	}
	
	
	public void testList() throws Exception
	{
	
		Vector list = Naming.list();
		int size = list.size();
		
		assertEquals(size,2);
		
		Naming.unbind("/simple2");
		
		Vector list2 = Naming.list();
		int size2 = list2.size();
		assertEquals(size2,1);
		
	
	}
	public void testNotBound() throws Exception
	{
		try
		{
			Simple client = (Simple)Naming.lookup("/no");
			assertEquals(1,0);
		}catch (NotBoundException ex)
		{
			assertEquals(1,1);
		}
		
		
	
	}
	
}
package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.samples.mobile.*;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class MobileTest extends TestCase {

	SimpleImpl server,server2;
	ERegistryImpl registry;
	TeleportImpl port;
	
	
	public MobileTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
				
			server = new SimpleImpl(env);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			
			
			port = new TeleportImpl(env);
			Naming.bind("/port",port);
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			port.close();
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(MobileTest.class);
	}
	
	
	public void testMobile() throws Exception
	{
		Simple client = (Simple)Naming.lookup("/simple");
		client.setEdad("30");
		String s = client.getEdad();
		assertEquals("30",s);
	
		Teleport airport = (Teleport)Naming.lookup("/port");
		server.close();
		airport.send(server);
		airport.close();
		
		client.setEdad("40");
		s = client.getEdad();
		assertEquals("40",s);
		
		client.close();
		
	
	}
	
	public void testClose() throws Exception
	{
		Simple client = (Simple)Naming.lookup("/simple");
		client.setEdad("30");
		String s = client.getEdad();
		assertEquals("30",s);
	
		Teleport airport = (Teleport)Naming.lookup("/port");
		server.close();
		
		try
		{
			client.setEdad("40");
			s = client.getEdad();
			assertEquals("40",s);
			assertEquals(1,0);
		} catch (RemoteException ex)
		{
			assertEquals(1,1);
		}
		
		airport.send(server);
		airport.close();
		
		client.setEdad("60");
		s = client.getEdad();
		assertEquals("60",s);
		
		client.close();
	
	}
	
}
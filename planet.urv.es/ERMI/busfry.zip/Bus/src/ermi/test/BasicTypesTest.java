package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.basictypes.*;
import ermi.registry.*;
import ermi.RemoteException;

/**
 * Some simple tests.
 *
 */
public class BasicTypesTest extends TestCase {

	SpriteImpl server;
	
	public BasicTypesTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			server = new SpriteImpl(5,env);
			server.writeERef("ior.properties");
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(ermi.test.BasicTypesTest.class);
	}
	
	
	public void testClient() throws Exception
	{
	
		Sprite client = (Sprite)FileRegistry.loadERef("ior.properties");
		client.setX(50);
		int s = client.getX();
		assertEquals(50,s);
		client.close();
		
	
	}
	
	
}
package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.samples.reference.*;

import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class ReferenceTest extends TestCase {

	PlaceImpl place;
	ERegistryImpl registry;
	UserImpl user1,user2;
	
	public ReferenceTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
		
			place = new PlaceImpl("chat",env);
			
			Naming.loadRegistry("registry.properties");
			Naming.bind("/place",place);
			
			user1 = new UserImpl("pedro",env);
			user2 = new UserImpl("mer",env);
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			place.close();
			user1.close();
			user2.close();
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(ReferenceTest.class);
	}
	
	
	public void testJoin() throws Exception
	{
		Place thePlace = (Place)Naming.lookup("/place");
		thePlace.join(user1);
		
		Vector list = thePlace.getUsers();
		int size = list.size();
		
		assertEquals(size,1);
		
		thePlace.leave(user1);
		
		Vector list2 = thePlace.getUsers();
		int size2 = list2.size();
		
		assertEquals(size2,0);
		thePlace.close();
		
	
	}
	
	public void testUsers() throws Exception
	{
		Place thePlace = (Place)Naming.lookup("/place");
		thePlace.join(user1);
		
		Vector list = thePlace.getUsers();
		int size = list.size();
		
		assertEquals(size,1);
		
		Place thePlace2 = (Place)Naming.lookup("/place");
		thePlace2.join(user2);
		
		
		Vector list2 = thePlace.getUsers();
		int size2 = list2.size();
		Vector list3 = thePlace2.getUsers();
		int size3 = list3.size();
		
		assertEquals(size2,2);
		assertEquals(size3,2);
		
		thePlace2.leave(user2);
		
		Vector list4 = thePlace.getUsers();
		int size4 = list4.size();
		assertEquals(size4,1);
		
		thePlace.close();
		thePlace2.close();
	
	}
	
	public void testUser() throws Exception
	{
		Place thePlace = (Place)Naming.lookup("/place");
		thePlace.join(user1);
		
		
		Place thePlace2 = (Place)Naming.lookup("/place");
		
		
		Vector list = thePlace2.getUsers();
		Iterator it = list.iterator();
		User user = (User)it.next();
		String name = user.getName();
		assertEquals("pedro",name);
		
		
		
		thePlace.close();
		thePlace2.close();
	
	}
	
	
}
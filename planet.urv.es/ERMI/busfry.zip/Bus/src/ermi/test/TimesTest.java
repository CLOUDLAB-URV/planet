package ermi.test;
import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.times.*;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class TimesTest extends TestCase {

	SimpleImpl server;
	ERegistryImpl registry;
	
	public TimesTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
				
			server = new SimpleImpl(env);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(TimesTest.class);
	}
	
	
	public void testList() throws Exception
	{
	
		try{
			long time1 = System.currentTimeMillis();
			
			Simple simple = (Simple)Naming.lookup("/simple");
			long time2= System.currentTimeMillis();
			System.out.println("TIME 1:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			simple.sayMsg("salu2");	
			time2= System.currentTimeMillis();
			System.out.println("TIME 2:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			System.out.println(simple.getMsg());	
			time2= System.currentTimeMillis();
			System.out.println("TIME 3:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			for (int i=0;i<100;i++)
				simple.sayMsg("salu2"+i);
			time2= System.currentTimeMillis();
			System.out.println("TIME 4:"+(time2-time1));	
			
			simple.close();
			
		}catch(NotBoundException e){
			e.printStackTrace();	
		}catch(RemoteException e4){
			System.out.println(e4.getMessage());
		 }
	}
		
	
	

		
	
	
}
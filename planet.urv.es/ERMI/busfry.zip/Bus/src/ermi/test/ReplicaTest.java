package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.samples.replica.*;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class ReplicaTest extends TestCase {

	SpriteImpl server;
	ERegistryImpl registry;
	
	public ReplicaTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
				
			server = new SpriteImpl(env,3);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/replica",server);
		
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(ReplicaTest.class);
	}
	
	
	public void testReplicaGet() throws Exception
	{
	
		SpriteImpl client = (SpriteImpl)Naming.lookup("/replica");
		int value = client.getX();
		assertEquals(value,3);
		client.setX(20);
		value = client.getX();
		assertEquals(value,20);
		value = server.getX();
		assertEquals(value,20);
	
		client.close();
	}
	
	
}
package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.samples.ignorefilter.*;
import ermi.registry.*;
import ermi.RemoteException;
import ermi.*;


public class RemoveFilterTest extends TestCase {

	SimpleImpl server;
	IgnoreSkel filter;
	ERegistryImpl registry;
	
	public RemoveFilterTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		

		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
			
				
			server = new SimpleImpl(env);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
		
			filter =(IgnoreSkel)FileRegistry.loadFilter("/simple","ermi.samples.ignorefilter.Ignore");
			filter.removeFilter();

				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			Naming.unloadRegistry();
			registry.close();
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(RemoveFilterTest.class);
	}
	
	/*
	public void testClient() throws Exception
	{
	
		Simple client = (Simple)Naming.lookup("/simple");
		client.setEdad("30");
		String s = client.getEdad();
		assertEquals("NO",s);
		client.close();
	
	}
	*/
	public void testClient() 
	{
		try
		{
			
		
		
		Simple client = (Simple)Naming.lookup("/simple");
	
	
			client.setEdad("30");
			String s = client.getEdad();
			assertEquals("30",s);
			client.close();
			
		}catch(RemoteException ex)
		{
			ex.printStackTrace();
			assertEquals("30","20");
			/*try
			{
				server.init();
			}catch(RemoteException e)
			{
				e.printStackTrace();
			}*/
		}
	
	}
}

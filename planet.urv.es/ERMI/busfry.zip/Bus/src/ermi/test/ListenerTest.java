package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;

import ermi.samples.listener.*;
import ermi.samples.listener.TestListener;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class ListenerTest extends TestCase {

	SpriteImpl server;
	ERegistryImpl registry;
	
	public ListenerTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
			
			server = new SpriteImpl("hola",env);	
			
			Naming.loadRegistry("registry.properties");
			Naming.bind("/listener",server);
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
		
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(ListenerTest.class);
	}
	
	
	public void testListener() throws Exception
	{
	
		Sprite client= (Sprite)Naming.lookup("/listener");
		TestListener l1 = new TestListener();
		TestListener l2 = new TestListener();
		TestListener l3 = new TestListener();
		
		client.addSpriteListener(l1);
		client.addSpriteListener(l2);
		client.addSpriteListener(l3);
		
		Sprite client2= (Sprite)Naming.lookup("/listener");
		client2.setX("SI");
		
		assertEquals(l1.getValue(),"SI");
		assertEquals(l2.getValue(),"SI");
		assertEquals(l3.getValue(),"SI");
		
		
		client.close();
		client2.close();
	
	}
	
	public void testRemoteListener() throws Exception
	{
	
		Sprite client= (Sprite)Naming.lookup("/listener");
		TestListener l1 = new TestListener();
		TestListener l2 = new TestListener();
		
		
		client.addSpriteListener(l1);
		
		Sprite client2= (Sprite)Naming.lookup("/listener");
		
		client2.addSpriteListener(l2);
		
		Sprite client3= (Sprite)Naming.lookup("/listener");
		client3.setX("SI");
		
		
		
		
		
		assertEquals(l1.getValue(),"SI");
		assertEquals(l2.getValue(),"SI");
	
		
		
		client.close();
		client2.close();
		client3.close();
	
	}
	
	public void testCountListener() throws Exception
	{
	
		Sprite client= (Sprite)Naming.lookup("/listener");
		TestListener l1 = new TestListener();
		TestListener l2 = new TestListener();
		
		
		client.addSpriteListener(l1);
		
		Sprite client2= (Sprite)Naming.lookup("/listener");
		
		client2.addSpriteListener(l2);
		
		Sprite client3= (Sprite)Naming.lookup("/listener");
		
		for (int i=0;i<100;i++)
			client3.setX(i+"");
		
				
		assertEquals(l1.getValue(),"99");
		assertEquals(l2.getValue(),"99");
	
		assertEquals(l1.getCnt(),100);
		assertEquals(l2.getCnt(),100);
		
		client.close();
		client2.close();
		client3.close();
	
	}
	
	
	/*
	public void testNotBound() throws Exception
	{
		try
		{
			Simple client = (Simple)Naming.lookup("/no");
			assertEquals(1,0);
		}catch (NotBoundException ex)
		{
			assertEquals(1,1);
		}
		
		
	
	}*/
	
}
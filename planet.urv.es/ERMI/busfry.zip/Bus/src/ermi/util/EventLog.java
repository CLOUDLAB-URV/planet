package ermi.util;



import ants.comm.*;
import java.util.*;
import java.io.*;

public class EventLog implements RemoteEventListener{
	Vector events = new Vector();
	
	public void eventArrived(Hashtable evt)
	{
	
		System.out.println(evt);
		System.out.println("------------------------------------");
		events.add(evt);
	}



	public static void main(String[] args) throws Exception{
		
		Hashtable subs = new Hashtable();
		subs.put("TYPE","DISPATCH");
		EventLog log = new EventLog();
		
	   	Hashtable env = new Hashtable();
		env.put(Context.PROVIDER_URL,"127.0.0.1");
		env.put(Context.PROVIDER_PORT,"2917");
		env.put(Context.PROVIDER_CLASS,"ants.comm.elvin.Session");
		  	
		Session conn = SessionFactory.createSession(env);
		conn.addRemoteEventListener(log,subs);
		
		DataInputStream dis = new DataInputStream(System.in);
		String cmd="";
		while ((cmd = dis.readLine())!="quit")
		{
			if (cmd.equals("flush"))
			{
				FileOutputStream logFile = new FileOutputStream("log.events");
				PrintStream pos = new PrintStream (logFile);
				Iterator it = log.events.iterator();
				while (it.hasNext())
				{
					Hashtable evt = (Hashtable)it.next();
					pos.println(evt);
					pos.println("-----------------------------");
					
				}
				pos.close();
				
				
				
			}
				
			
		}
		
			
			
	   
	}
}

package ermi.util;


import cbus.*;
import java.util.Properties;
import ermi.*;


public class Bus 
{
	
	public static Session bus = null;
	public static int count =0;
	
	public static Session getBus(Properties env) throws RemoteException 
	{
	
		if (bus==null)
		{
			count++;
			try
			{ 
				
				bus = SessionFactory.createSession(env);
					
		   }catch (SessionException e1)
			   {
				 //  e1.getException().printStackTrace();
				throw new ConnectionException(e1.getMessage());
		   }	
			
		}else
		{
			count++;
		}
		
		return bus;
		
		
	}
	
	public static void close()
	{
		count--;
		if (count<=0)
		{
			try
			{ 
				
				bus.close();
				bus = null;
				count =0;	
		   }catch (SessionException e1)
			   {
				   e1.getException().printStackTrace();
		
		   }	
		}
	}
	
}

/*
 * Created on 20-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.util;

import java.io.*;
import org.doomdark.uuid.*;

public class UID {

	public static String getUID()
	{
		UUIDGenerator gen = UUIDGenerator.getInstance();
		UUID id = gen.generateRandomBasedUUID();
		return id.toString();
		
	//	long uid = System.currentTimeMillis();
	//	return String.valueOf(uid);
	}
	public static void writeUID(String fileName,String uid)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream(fileName);
			PrintStream pos = new PrintStream(fos);
			pos.println(uid);
			pos.close();
			
			
		}catch (IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static String readUID(String fileName)
	{
		try
		{
			FileInputStream fos = new FileInputStream(fileName);
			DataInputStream pos = new DataInputStream(fos);
			String res =  pos.readLine();
			pos.close();
			return res;
			
			
		}catch (IOException ex)
		{
			ex.printStackTrace();
		}
		return "";
	}
	
}

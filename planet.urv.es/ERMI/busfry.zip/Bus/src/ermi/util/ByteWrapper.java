
package ermi.util;


public class ByteWrapper implements java.io.Serializable 
{
	private byte data[];
	public ByteWrapper(byte data[])
	{
		this.data = data;
	}
	
	public byte[] getBytes()
	{
		return data;
	}

}

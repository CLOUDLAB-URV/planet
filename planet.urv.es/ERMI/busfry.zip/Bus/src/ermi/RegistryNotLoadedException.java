package ermi;


public class RegistryNotLoadedException extends RemoteException {

	
	public RegistryNotLoadedException(String msg) {
		super(msg);
	}

}

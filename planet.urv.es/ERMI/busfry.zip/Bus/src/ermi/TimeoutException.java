/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

/**
 *
 * A TimeoutException is thrown if the timeout expires in a remote call. 
 * 
 * 
 */

public class TimeoutException extends RemoteException {

	public TimeoutException(String msg)
		{
			super(msg);
		}
}
/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

import java.util.Properties;
/**
 * 
 *
 * The Remote interface serves to identify interfaces whose methods may be invoked 
 * from a non-local virtual machine. Any object that is a remote object must directly
 *  or indirectly implement this interface. Only those methods specified in a "remote 
 * interface", an interface that extends ermi.Remote are available remotely.
 * <br>
 *  The current implementation of ermi does not support inheritance from other remote Interfaces.
 *
 */
public interface ERemote {
	
	/**
	 * Returns a Property object containing the required information to connect to this remote object.
	 * The information contained in this file includes the event service location, event service factory class, and 
	 * Object unique id for remote subscriptions.
	 * @return Reference Information for a remote object (connection and subscription information).
	 * 
	 */
	
	public Properties getERef();
	
	/**
	 * Removes all subscriptions for this object and releases event service connection.<br>
	 * It is highly recommended 
	 * to call this method on object references that will no longer be used.
	 *
	 * @throws ermi.RemoteException - if the connection with the event service fails. 
	 */
	public void close() throws RemoteException;
	
	/**
	 * Connects to the event service and creates all subscriptions for this object.
	 *
	 * @throws ermi.RemoteException - if the connection with the event service fails. 
	 */
	public void init() throws RemoteException;
	
	/**
	 * Returns a reference to a new stub instance of this remote object. This is mainly used
	 * in the pass by reference calls to remote objects. This stub is later initialized (init) when 
	 * is deserialized in the demanding endpoint.<br><br>. <b> For internal use </b>
	 * See the ERMI documentation for more information about this.
	 * 
	 *
	 * @throws ermi.RemoteException - if the stub cannot be instantiated for any reason (explained in the RemoteException message). 
	 */
	
	public ERemote copy() throws RemoteException;
}

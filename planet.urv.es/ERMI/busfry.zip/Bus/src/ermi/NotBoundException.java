/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */

package ermi;

/**
 *
 * A NotBoundException is thrown if an attempt is made to lookup in the registry 
 * a name that has no associated binding.
 * 
 */


public class NotBoundException extends RemoteException {

	public NotBoundException(String msg)
		{
			super(msg);
		}
}
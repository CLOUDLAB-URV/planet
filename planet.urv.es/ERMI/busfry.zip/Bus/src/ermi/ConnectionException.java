/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

/**

 *
 * A ConnectionException is thrown if an Exception occurs in the Event middleware. 
 * 
 * 
 */
public class ConnectionException extends RemoteException {

	public ConnectionException(String msg)
	{
		super(msg);
	}

}

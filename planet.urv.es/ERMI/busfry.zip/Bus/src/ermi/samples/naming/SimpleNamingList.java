package ermi.samples.naming;


import ermi.*;
import ermi.samples.simple.*;
import java.util.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleNamingList {

	public static void main(String[] args) throws Exception
	{
		Naming.loadRegistry("registry.properties");
		Vector list = Naming.list();
		Iterator it = list.iterator();
		while (it.hasNext())
		{
			String s = (String) it.next();
			System.out.println(s);
			
		}
		Naming.unloadRegistry();
	}
}

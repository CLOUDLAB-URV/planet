/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.naming;

import ermi.*;
import ermi.samples.simple.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

public class SimpleNamingClient {

	public static void main(String[] args) throws Exception
	{
		Naming.loadRegistry("registry.properties");
		Simple client = (Simple)Naming.lookup("/simple");
		
		client.setEdad("30");
		String s = client.getEdad();
		System.out.println(s);
		client.setEdad("99");
		String res = client.concat(new Integer(3),"544",new Integer(33));
		System.out.println(res);
		client.close();
		Naming.unloadRegistry();
	}
}

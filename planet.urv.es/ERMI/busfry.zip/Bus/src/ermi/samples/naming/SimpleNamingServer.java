/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.naming;

import ermi.samples.simple.*;
import java.util.*;
import java.io.*;
import ermi.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleNamingServer {

	public static void main(String[] args) 
	{

		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SimpleImpl server = new SimpleImpl(env);
			
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			
			System.in.read();
						
		}catch (Exception e)
		{
			 e.printStackTrace();
		}	
		
		
	}
}

package ermi.samples.basictypes;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
import java.util.Properties;
/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteImpl extends SpriteSkel
{
	

	private int x;

	public SpriteImpl(int x, Properties env) throws ermi.RemoteException
	{
		super(env);
		this.x = x;
		
	}

	/* (non-Javadoc)
	 * @see Sprite#getX()
	 */
	public int getX() {
		
		return x;
	}

	/* (non-Javadoc)
	 * @see Sprite#setX(int)
	 */
	public void setX(int x) {
		this.x = x;

	}

}

package ermi.samples.basictypes;

import ermi.registry.*;
/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteClient {

	public static void main(String[] args) throws ermi.RemoteException
	{
		Sprite client = (Sprite)FileRegistry.loadERef("ior.properties");
		client.setX(50);
		int s = client.getX();
		System.out.println(s);
		client.close();
		
	}
}

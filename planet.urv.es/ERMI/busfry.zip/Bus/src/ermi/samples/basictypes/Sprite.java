package ermi.samples.basictypes;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Sprite extends ermi.ERemote 
{
		public int getX() throws ermi.RemoteException;	
	
		public void setX(int x) throws ermi.RemoteException;

}

package ermi.samples.basictypes;

import cbus.*;
import java.util.*;
import ermi.*;
import ermi.registry.FileRegistry;



public abstract class SpriteSkel extends EventServer implements RemoteEventListener,Sprite
{
String method;
String stubId;
Hashtable msg = new Hashtable();
String  subs;

public SpriteSkel(Properties env) throws ermi.RemoteException
{
	super(env);
	uid = ermi.util.UID.getUID();
	subs =uid;
	className = "ermi.samples.basictypes.Sprite";
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	stubId = (String)evt.get("STUBID");
	if (method.equals("getX"))
	{
		try {
			int res2 = getX();
			Integer res = new Integer(res2);
		Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","getX");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e2){e2.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","getX");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("setX"))
	{
		try {
			Vector args = (Vector)evt.get("object");
			setX(((Integer)args.elementAt(0)).intValue());			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","setX");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e){e.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","setX");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("getBytes"))
	{
		 try 
		{
			String aClass = Rmic.getClassName(className);
			String fileClass = class_store+aClass+"Stub.class";
			byte data[] = getBytes(fileClass);
		Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULTDYNAMIC:"+stubId);
			msg.put("TYPE","DYSPATCH");
			msg.put("METHOD","getBytes");
			dispatchEvent(msg,data);
		 }catch (java.io.IOException ex1) { 
		Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULTDYNAMIC:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","getBytes");
			try{
				dispatchEvent(msg,ex1);
			}catch(RemoteException e2){e2.printStackTrace();}
		 } catch (RemoteException ex2) {ex2.printStackTrace();} 
	}
	else if (method.equals("addFilter"))
	{
		RemoteException ex=null; 
		Vector args = (Vector)evt.get("object");
		String uidf = (String)args.elementAt(0);
		try{	conn.removeSubscription(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		String res = uid;
		uid = uidf;
		subs = uid;
		try{	conn.subscribe(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		Hashtable msg = new Hashtable();
		msg.put("subject",res+":RESULT:"+stubId);
		msg.put("METHOD","addFilter");
		if (ex!=null){
			msg.put("TYPE","EXCEPTION");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}else{
			msg.put("TYPE","DYSPATCH");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("removeFilter"))
	{
		RemoteException ex=null; 
		Vector args = (Vector)evt.get("object");
		String uidf = (String)args.elementAt(0);
		try{	conn.removeSubscription(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		String res = uid;
		uid = uidf;
		subs = uid;
		try{	conn.subscribe(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		Hashtable msg = new Hashtable();
		msg.put("subject",res+":RESULT:"+stubId);
		msg.put("METHOD","removeFilter");
		if (ex!=null){
			msg.put("TYPE","EXCEPTION");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}else{
			msg.put("TYPE","DYSPATCH");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
}
public void close() throws ermi.RemoteException
{
	try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

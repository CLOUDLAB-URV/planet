package ermi.samples.times;

public interface Simple extends ermi.ERemote
{
  

	public void sayMsg(String msg) throws ermi.RemoteException;

  	public String getMsg() throws ermi.RemoteException;
  
  
   
}
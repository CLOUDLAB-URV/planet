package ermi.samples.times;

import ermi.*;
import ermi.samples.simple.*;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleClient {

	public static void main(String[] args) {
		
		
		try{
			long time1 = System.currentTimeMillis();
			Naming.loadRegistry("registry.properties");
			Simple simple = (Simple)Naming.lookup("/simple");
			long time2= System.currentTimeMillis();
			System.out.println("TIME 1:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			simple.sayMsg("salu2");	
			time2= System.currentTimeMillis();
			System.out.println("TIME 2:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			System.out.println(simple.getMsg());	
			time2= System.currentTimeMillis();
			System.out.println("TIME 3:"+(time2-time1));
			
			time1 = System.currentTimeMillis();
			for (int i=0;i<100;i++)
				simple.sayMsg("salu2"+i);
			time2= System.currentTimeMillis();
			System.out.println("TIME 4:"+(time2-time1));	
			
		}catch(NotBoundException e){
			e.printStackTrace();	
		}catch(RemoteException e4){
			System.out.println(e4.getMessage());
		 }
	}
}

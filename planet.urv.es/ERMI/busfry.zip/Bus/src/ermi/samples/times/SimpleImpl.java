package ermi.samples.times;

import java.util.*;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleImpl extends SimpleSkel{
	
	public SimpleImpl(Properties env) throws ermi.RemoteException
	{
		super(env);
	}
	
	public void sayMsg(String msg) 
 	{
				System.out.println(msg);
	}

  	public String getMsg () 
	{
		
		return "HOLA";	
	}

}

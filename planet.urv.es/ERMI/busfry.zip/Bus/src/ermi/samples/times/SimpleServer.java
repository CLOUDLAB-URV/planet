package ermi.samples.times;

import java.io.*;
import java.util.*;
import ermi.registry.*;
import ermi.*;
/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SimpleServer {

	public static void main(String[] args) {
		
		try{
		
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SimpleImpl server = new SimpleImpl(env);
			
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			
			
	
			System.in.read();
	
		}	catch(ermi.RemoteException e2){e2.printStackTrace();
		}	catch(java.io.IOException e1){e1.printStackTrace();}
		
	}
}

/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.simple;

import ermi.*;
/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface Simple extends ERemote
{

	public void setEdad(String edad) throws RemoteException;
	

	public String getEdad() throws RemoteException;
	
	
	public String concat(Integer x, String y, Integer z) throws RemoteException;
	



}

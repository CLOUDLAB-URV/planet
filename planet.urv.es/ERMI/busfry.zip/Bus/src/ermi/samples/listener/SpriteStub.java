package ermi.samples.listener;

import ermi.*;
import cbus.SessionException;
import cbus.Session;
import cbus.RemoteEventListener;
import java.util.*;
import ermi.registry.FileRegistry;
import java.io.*;



public  class SpriteStub extends EventServer implements RemoteEventListener,Sprite,EFilter
{
private String  subs;
private Vector listeners = new Vector();
private boolean resultArrived = false;
private boolean exception = false;
private Object result;
private String method;
private String stubId;
private int timeout;
private int listener_cnt = 0;

public SpriteStub(Properties env) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.samples.listener.Sprite";
	stubId = ermi.util.UID.getUID();
	subs = uid+":RESULT:"+stubId;
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public SpriteStub(Properties env,String stub) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.samples.listener.Sprite";
	stubId = ermi.util.UID.getUID();
	subs = uid+":RESULT:"+stubId;
	conn = null;
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	String type;
	if (method.equals("getX"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("setX"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("addFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("removeFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
}
public java.lang.String getX()
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","getX");
	resultArrived = false;
	dispatchEvent(evt);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public void setX(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","setX");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void addSpriteListener(ermi.samples.listener.SpriteListener p0) 
 throws RemoteException
{
	if (listener_cnt==0){
		String lsubs;
		lsubs = uid+":RESULT:SpriteEvent";
		try{
			conn.subscribe(new RemoteEventListener(){
			public void eventArrived(java.util.Hashtable evt){
			SpriteEvent result = (SpriteEvent)evt.get("object");
			Vector clisteners = (Vector)listeners.clone();
			Iterator it = clisteners.iterator();
			while (it.hasNext()){
				ermi.samples.listener.SpriteListener aListener = (ermi.samples.listener.SpriteListener)it.next();
				aListener.onEvent(result);
			}
		}},lsubs);	
	}catch (SessionException ex){throw new ConnectionException("Problem subscribing Listener");}
	}
	listeners.add(p0);
	listener_cnt++;
}
public void removeSpriteListener(ermi.samples.listener.SpriteListener p0) 
 throws RemoteException
{
	listeners.remove(p0);
	listener_cnt--;
	if (listener_cnt==0){
		String  lsubs;
		lsubs = uid+":RESULT:SpriteEvent";
		try{
			conn.removeSubscription(this,lsubs);
		}catch (SessionException ex){throw new ConnectionException("Problem subscribing Listener");}
	}
}
public java.lang.String addFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","addFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public void removeFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","removeFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void removeFilter() throws RemoteException
{
}
public void close() throws ermi.RemoteException
{
	if (conn!=null){
		try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();conn = null;	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
private void writeObject(java.io.ObjectOutputStream out) throws IOException
{
	try{
		close();
	}catch (RemoteException e){throw new IOException("Problems with the Event Service");}
	out.defaultWriteObject();
}
private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException
{
	try{
		in.defaultReadObject ();
		init();
	}catch (RemoteException e){e.printStackTrace();}
}
public boolean equals(Object obj)
{
	ERemote ref = (ERemote)obj;
	return ref.getERef().equals(getERef());
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

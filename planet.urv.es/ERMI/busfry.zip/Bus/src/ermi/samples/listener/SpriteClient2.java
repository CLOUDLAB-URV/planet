/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;

import ermi.registry.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteClient2 {

	


	public static void main(String[] args) throws Exception
	{
		Sprite client = (Sprite)FileRegistry.loadERef("ior.properties");
		client.addSpriteListener(new MiListener());
	}
}

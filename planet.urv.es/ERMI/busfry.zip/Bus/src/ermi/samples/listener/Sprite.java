/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

public interface Sprite extends ermi.ERemote 
{
	public String getX() throws ermi.RemoteException;	
	public void setX(String x) throws ermi.RemoteException;
	public void addSpriteListener(SpriteListener sL) throws ermi.RemoteException; 
	public void removeSpriteListener(SpriteListener sL) throws ermi.RemoteException;
}




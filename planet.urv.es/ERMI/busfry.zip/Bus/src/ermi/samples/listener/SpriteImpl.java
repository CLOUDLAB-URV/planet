/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;


import java.util.Properties;
/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteImpl extends SpriteSkel
{
	private SpriteEvent sEvent = new SpriteEvent("2");

	private String x;

	public SpriteImpl(String x, Properties env) throws ermi.RemoteException
	{
		super(env);
		this.x = x;
		
	}

	/* (non-Javadoc)
	 * @see Sprite#getX()
	 */
	public String getX() {
		
		return x;
	}

	/* (non-Javadoc)
	 * @see Sprite#setX(int)
	 */
	public void setX(String x) throws ermi.RemoteException{
		this.x = x;
		sEvent.setX(x);
		triggerSpriteEvent(sEvent);

	}
	
	
}

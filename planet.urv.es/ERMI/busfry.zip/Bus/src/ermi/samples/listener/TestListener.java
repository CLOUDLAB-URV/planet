package ermi.samples.listener;


public class TestListener implements SpriteListener
	{
		
		String value="NO";
		int cnt = 0;
		
		public void onEvent(SpriteEvent eL)
		{
			value = eL.getX();
			cnt++;
		}
		public int getCnt()
		{
			return cnt;
		}
		public String getValue()
		{
			return value;
		}
		
	}
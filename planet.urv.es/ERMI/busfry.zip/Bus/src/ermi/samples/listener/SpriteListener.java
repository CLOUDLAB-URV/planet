package ermi.samples.listener;
/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface SpriteListener 
{
	public void onEvent(SpriteEvent eL);
}

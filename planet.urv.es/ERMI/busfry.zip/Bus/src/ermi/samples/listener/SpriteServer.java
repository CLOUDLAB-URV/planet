/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;

import java.io.*;
import java.util.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteServer {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SpriteImpl server = new SpriteImpl("hola",env);
			server.writeERef("ior.properties");
			System.in.read();
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
}
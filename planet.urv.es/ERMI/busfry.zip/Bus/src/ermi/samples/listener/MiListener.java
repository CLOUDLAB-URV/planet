/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;

class MiListener implements SpriteListener
	{
		public void onEvent(SpriteEvent eL)
		{
			System.out.println(eL.getX());
		}
		
	}
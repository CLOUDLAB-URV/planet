/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.listener;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SpriteEvent implements java.io.Serializable
{
		String x;
	
		public SpriteEvent(String x)
		{
			this.x = x;
		
		}
	
		public String getX()
		{
			return x;	
		}
	
		public void setX(String x)
		{
			this.x = x;	
		}
}

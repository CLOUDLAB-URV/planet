package ermi.samples.mobile;

import java.util.Properties;
import ermi.samples.simple.*;
import ermi.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class TeleportImpl extends TeleportSkel
{
	public TeleportImpl(Properties env) throws RemoteException{
		super(env);
	}
	
	public void send(Object ref) throws RemoteException
	{
		ERemote server = (ERemote)ref;
		server.init();
		
	}
	

}

package ermi.samples.mobile;

import ermi.*;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Teleport extends ERemote {
	public void send(Object ref) throws RemoteException;
	

}

package ermi.samples.mobile;

import java.io.*;
import java.util.Properties;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class TeleportServer {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			TeleportImpl server = new TeleportImpl(env);
			server.writeERef("port.properties");
			System.in.read();
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
}

package ermi.samples.mobile;

import ermi.samples.simple.*;
import java.io.*;
import java.util.*;
import ermi.registry.*;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class TeleportClient {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SimpleImpl server = new SimpleImpl(env);
			server.writeERef("ior.properties");
			
			DataInputStream dis = new DataInputStream(System.in);
			System.out.println("ready...");
			String input = dis.readLine();
			
			Teleport airport = (Teleport)FileRegistry.loadERef("port.properties");
			server.close();
			
			airport.send(server);
			airport.close();
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
		
	}
}

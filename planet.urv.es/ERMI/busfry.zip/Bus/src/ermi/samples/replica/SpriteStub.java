package ermi.samples.replica;

import ermi.*;
import cbus.SessionException;
import cbus.Session;
import cbus.RemoteEventListener;
import java.util.*;
import ermi.registry.FileRegistry;
import java.io.*;



public  abstract class SpriteStub extends EventServer implements RemoteEventListener,Sprite
{
private String subs;
private boolean replicaLoaded = false;
private boolean resultArrived = false;
private boolean exception = false;
private Object result;
private String method;
private SpriteSkel replica;
private int timeout;
private int listener_cnt = 0;

public SpriteStub(Properties env) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	if (muid ==null){
		uid = ermi.util.UID.getUID();
		env.setProperty(Context.CLASS_ID,uid);
	}
	else { uid = muid; }
	className = "ermi.samples.replica.Sprite";
	subs = uid+":RESULT";
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	replica = new SpriteSkel(env,this);
	initData();
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	if (method.equals("getData")&&!replicaLoaded)
	{
		ermi.samples.replica.SpriteData data = (ermi.samples.replica.SpriteData)evt.get("object");
		loadData(data);
		replicaLoaded = true;
	}
}
public void setX(int p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("METHOD","setX");
	resultArrived = false;
	Vector args = new Vector();
	args.add(new Integer(p0));
	dispatchEvent(evt,args);
	timeout=0;	while (timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
}
public abstract void  update_setX(int p0); 
public void close() throws ermi.RemoteException
{
	if (conn!=null){
		try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();conn = null;	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
private void writeObject(java.io.ObjectOutputStream out) throws IOException
{
	try{
		close();
	}catch (RemoteException e){throw new IOException("Problems with the Event Service");}
	out.defaultWriteObject();
}
private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException
{
	try{
		in.defaultReadObject ();
		init();
	}catch (RemoteException e){e.printStackTrace();}
}
public boolean equals(Object obj)
{
	ERemote ref = (ERemote)obj;
	return ref.getERef().equals(getERef());
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
public Properties getERef()
{
	eref.setProperty(Context.CLASS_ID,uid);
	eref.setProperty(Context.CLASS_NAME,className+"Impl");
	return eref;
}
public abstract void loadData(ermi.samples.replica.SpriteData data);
public abstract ermi.samples.replica.SpriteData getData();
public void initData() throws RemoteException
{
	Hashtable msg = new Hashtable();
	msg.put("subject",uid);
	msg.put("TYPE","DISPATCH");
	msg.put("METHOD","getData");
	dispatchEvent(msg);
	int timeout=0;	
	while (!replicaLoaded&&timeout<Context.TIMEOUT){
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	replicaLoaded = true;
}
}

package ermi.samples.replica;

import ermi.*;
import java.io.*;
import java.util.*;

public class SpriteClient2 {

	public static void main(String[] args) throws Exception
	{
			
			Naming.loadRegistry("registry.properties");
			SpriteImpl client = (SpriteImpl)Naming.lookup("/replica");
			int value = client.getX();
			System.out.println("VALUE:"+value);
			client.setX(20);
			 value = client.getX();
			System.out.println("VALUE:"+value);
			
	}
}

package ermi.samples.replica;

import cbus.SessionException;
import cbus.RemoteEventListener;
import java.util.*;
import ermi.*;
import ermi.registry.FileRegistry;



public  class SpriteSkel extends EventServer implements RemoteEventListener
{
String method;
SpriteStub stub;
Hashtable msg = new Hashtable();
String subs;

public SpriteSkel(Properties env,SpriteStub stub) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	if (muid ==null){
		uid = ermi.util.UID.getUID();
		env.setProperty(Context.CLASS_ID,uid);
	}
	else { uid = muid; }
	subs = uid;
	this.stub=stub;
	className = "ermi.samples.replica.Sprite";
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	if (method.equals("setX"))
	{
			Vector args = (Vector)evt.get("object");
			stub.update_setX(((Integer)args.elementAt(0)).intValue());	}
	else if (method.equals("getData"))
	{
		SpriteData data = stub.getData(); 
		Hashtable msg = new Hashtable();
		msg.put("subject",uid+":RESULT");
		msg.put("METHOD","getData");
			try{
				dispatchEvent(msg,data);
			}catch(RemoteException e2){e2.printStackTrace();}
	}
}
public void close() throws ermi.RemoteException
{
	try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

package ermi.samples.replica;

import java.util.Properties;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SpriteImpl extends  SpriteStub
{
	private int x;
	
	public SpriteImpl(Properties env,int x) throws ermi.RemoteException
	{
		super(env);
		this.x = x;
	}
	public SpriteImpl(Properties env) throws ermi.RemoteException
	{
		super(env);
	}
	
	public void setX(int x) throws ermi.RemoteException
	{
		super.setX(x);
	}
	
	public int getX()
	{
		return x;
	}
	
	public void update_setX(int x)
	{
		this.x = x;		
	}
	
	public void loadData(SpriteData data)
	{
		this.x = data.getX();	
	}
	
	public SpriteData getData()
	{
		return new SpriteValues(x);
	}
	
}

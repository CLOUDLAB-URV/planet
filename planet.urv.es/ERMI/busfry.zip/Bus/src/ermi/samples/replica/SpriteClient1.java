package ermi.samples.replica;

import ermi.*;
import java.io.*;
import java.util.*;

public class SpriteClient1 {

	public static void main(String[] args) throws Exception
	{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SpriteImpl server = new SpriteImpl(env,3);
			
			Naming.loadRegistry("registry.properties");
			Naming.bind("/replica",server);
			System.in.read();
			
	}
}

/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.exception;

import java.util.*;
import ermi.RemoteException;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleImpl  extends SimpleSkel
{

	String edad="12";

	/**
	 * Constructor for BubaImpl.
	 */
	public SimpleImpl(Properties env) throws RemoteException
	{
		super(env);
	}

	public void setEdad(String edad) throws RemoteException
	{
		this.edad = edad;
	}
	

	public String getEdad() throws RemoteException
	{
		return edad;
	}
	
	
	
	public String concat(Integer x, String y, Integer z) throws RemoteException,ConcatException
	{
		
		throw new ConcatException("FAIL");
		//	return edad+y+x+z;
	}
}

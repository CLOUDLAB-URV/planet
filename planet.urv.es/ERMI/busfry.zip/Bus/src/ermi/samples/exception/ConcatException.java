package ermi.samples.exception;

import ermi.RemoteException;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class ConcatException extends RemoteException {

	/**
	 * Constructor for ConcatException.
	 * @param msg
	 */
	public ConcatException(String msg) {
		super(msg);
	}

}

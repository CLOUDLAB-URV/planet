/*
 * Created on 25-jun-2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package ermi.samples.exception;

import java.io.*;
import java.util.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleServer {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			SimpleImpl server = new SimpleImpl(env);
			server.writeERef("ior.properties");
			System.in.read();
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
}

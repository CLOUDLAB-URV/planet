package ermi.samples.dynamic;

import ermi.registry.*;
/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleClient {

	public static void main(String[] args) throws Exception
	{
		Simple client = (Simple)FileRegistry.loadERef("ior.properties");
		client.setEdad("30");
		String s = client.getEdad();
		System.out.println(s);
		client.setEdad("99");
		String res = client.concat(new Integer(3),"543",new Integer(33));
		System.out.println(res);
		client.close();
	}
}

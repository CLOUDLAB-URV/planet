package ermi.samples.dynamic;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Simple extends ermi.ERemote
{

	public void setEdad(String edad) throws ermi.RemoteException;
	

	public String getEdad() throws ermi.RemoteException;
	
	
	public String concat(Integer x, String y, Integer z) throws ermi.RemoteException;
	



}


package ermi.samples.dynamic;

import java.util.*;

/**
 * @author Pedro Garc�a 
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SimpleImpl  extends SimpleSkel
{

	String edad="12";

	/**
	 * Constructor for BubaImpl.
	 */
	public SimpleImpl(Properties env) throws ermi.RemoteException{
		super(env);
	}

	public void setEdad(String edad) throws ermi.RemoteException
	{
		this.edad = edad;
	}
	

	public String getEdad() throws ermi.RemoteException
	{
		return edad;
	}
	
	
	
	public String concat(Integer x, String y, Integer z) throws ermi.RemoteException
	{
		return edad+y+x+z;
	}
}
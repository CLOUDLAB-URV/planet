package ermi.samples.filter;

import java.util.*;
import ermi.RemoteException;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class LogFilterImpl extends LogFilterStub 
{

	public LogFilterImpl(Properties env) throws RemoteException
	{
		super(env);
	}
	
	public void setEdad(java.lang.String p0) throws RemoteException
	{
		System.out.println("SETEDAD "+p0);
		super.setEdad(p0);
	}
	
	public java.lang.String getEdad() throws RemoteException
	{
		System.out.println("GETEDAD ");
		return super.getEdad();
	}
	
	public java.lang.String concat(java.lang.Integer p0,java.lang.String p1,java.lang.Integer p2) throws RemoteException
	{
		System.out.println("CONCAT "+p0+" "+p1+" "+p2);
		return super.concat(p0,p1,p2);
		
	}	
}

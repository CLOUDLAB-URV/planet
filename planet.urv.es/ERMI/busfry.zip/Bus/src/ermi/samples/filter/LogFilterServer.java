package ermi.samples.filter;

import ermi.registry.*;
import java.io.*;
import ermi.*;
/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class LogFilterServer {

	public static void main(String[] args) 
	{
		
		try
		{
			Naming.loadRegistry("registry.properties");
			LogFilterSkel server =(LogFilterSkel)FileRegistry.loadFilter("/simple","ermi.samples.filter.LogFilter");
			DataInputStream dis = new DataInputStream(System.in);
			
			String input = "";
			while (!(input = dis.readLine()).equals("quit"))
			{
				System.out.println(input+" entrada");
				if (input.equals("exit"))
				{
					System.out.println(" OUT!!!");
					server.removeFilter();
			
				}
			}
			Naming.unloadRegistry();
						
		}catch (Exception e)
		{
			 e.printStackTrace();
		}	
		
	}
}

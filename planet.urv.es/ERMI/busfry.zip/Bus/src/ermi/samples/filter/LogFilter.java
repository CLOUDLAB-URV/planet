package ermi.samples.filter;

import ermi.samples.simple.*;
import ermi.EFilter;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface LogFilter extends Simple,EFilter{

}

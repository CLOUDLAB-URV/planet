package ermi.samples.filter;

import ermi.*;
import ermi.registry.*;
import cbus.*;
import java.util.*;



public  class LogFilterSkel extends EventServer implements RemoteEventListener,ermi.EFilter
{
String method;
String stubId;
LogFilter intercept;
Hashtable msg = new Hashtable();
String subs;

public LogFilterSkel(Properties env) throws ermi.RemoteException
{
	super(env);
	uid = env.getProperty(ermi.Context.CLASS_ID);
	subs = uid;
	System.out.println("READY!");
	className = "ermi.samples.filter.LogFilter";
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	intercept = new LogFilterImpl(env);
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	stubId = (String)evt.get("STUBID");
	if (method.equals("concat"))
	{
		try {
			Vector args = (Vector)evt.get("object");
				java.lang.String res = intercept.concat((java.lang.Integer)args.elementAt(0),(java.lang.String)args.elementAt(1),(java.lang.Integer)args.elementAt(2));
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","concat");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e2){e2.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","concat");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("setEdad"))
	{
		try {
			Vector args = (Vector)evt.get("object");
			intercept.setEdad((java.lang.String)args.elementAt(0));
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","setEdad");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e){e.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","setEdad");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("getEdad"))
	{
		try {
			java.lang.String res = intercept.getEdad();
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","getEdad");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e2){e2.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","getEdad");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("addFilter"))
	{
		try {
			Vector args = (Vector)evt.get("object");
			String res = intercept.addFilter((String)args.elementAt(0));
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","addFilter");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e){e.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("subject",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","addFilter");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("removeFilter"))
	{
		RemoteException ex=null; 
		Vector args = (Vector)evt.get("object");
		String uidf = (String)args.elementAt(0);
		try{	conn.removeSubscription(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		String res = uid;
		uid = uidf;
		subs = uid;
		try{	conn.subscribe(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		Hashtable msg = new Hashtable();
		msg.put("subject",res+":RESULT:"+stubId);
		msg.put("METHOD","removeFilter");
		if (ex!=null){
			msg.put("TYPE","EXCEPTION");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}else{
			msg.put("TYPE","DYSPATCH");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
}
public String addFilter(String uid) throws RemoteException
{
	return intercept.addFilter(uid);
}
public void removeFilter(String uidf) throws RemoteException
{
	intercept.removeFilter(uidf);
}
public void removeFilter() throws RemoteException
{
	intercept.removeFilter(uid);
	close();
}
public void close() throws ermi.RemoteException
{
	try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	intercept.close();
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

package ermi.samples.reference;

import ermi.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface User extends ERemote
{
	public String getName() throws RemoteException;
	

	public void setName(String name) throws RemoteException;
	
	
	

}

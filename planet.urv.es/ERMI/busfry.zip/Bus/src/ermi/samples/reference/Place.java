package ermi.samples.reference;

import ermi.*;
import java.util.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Place extends ERemote
{
	public void join(User aUser) throws RemoteException;
	

	public void leave(User aUser) throws RemoteException;
	
	
	public Vector getUsers() throws RemoteException;
}

package ermi.samples.reference;


import ermi.RemoteException;
import java.util.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PlaceImpl extends PlaceSkel
{
	String name;
	Vector users = new Vector();
	/**
	 * Constructor for BubaImpl.
	 */
	public PlaceImpl(String name,Properties env) throws RemoteException
	{
		super(env);
		this.name = name;
		
	}

	public void join(User aUser) throws RemoteException
	{
		users.add(aUser);
		
	}
	

	public void leave(User aUser) throws RemoteException
	{
		if (users.contains(aUser))
			users.remove(aUser);
		else throw new RemoteException("Not Found");
	}
	
	
	public Vector getUsers() throws RemoteException
	{
		
		return (Vector)users.clone();
	}

}

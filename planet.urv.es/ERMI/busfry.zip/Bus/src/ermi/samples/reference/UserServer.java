package ermi.samples.reference;



import java.io.*;
import java.util.*;
import ermi.registry.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class UserServer {

	public static void main(String[] args) 
	{
		try
		{
			Place thePlace = (Place)FileRegistry.loadERef("ior.properties");
			
			
					
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			UserImpl server = new UserImpl("pedro",env);
			
			thePlace.join(server);
			String input = "";
			System.out.println("READY!");
			DataInputStream dis = new DataInputStream(System.in);
			while ((input = dis.readLine())!="quit")
			{
				if (input.equals("quit"))
				{
					System.out.println(" OUT!!!");
					thePlace.leave(server);
					//System.exit(0);
				}
			}
			
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
}

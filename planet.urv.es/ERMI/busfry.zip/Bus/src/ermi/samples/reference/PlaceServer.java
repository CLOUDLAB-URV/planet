package ermi.samples.reference;


import java.io.*;
import java.util.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PlaceServer {

	public static void main(String[] args)
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			PlaceImpl server = new PlaceImpl("chat",env);
			server.writeERef("ior.properties");
			System.out.println("READY!");
			System.in.read();
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
}

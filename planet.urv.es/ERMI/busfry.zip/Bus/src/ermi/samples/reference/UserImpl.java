package ermi.samples.reference;

import ermi.RemoteException;
import java.util.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class UserImpl extends UserSkel{

		String name;

	/**
	 * Constructor for BubaImpl.
	 */
	public UserImpl(String name,Properties env) throws RemoteException
	{
		super(env);
		this.name = name;
		
	}

	public void setName(String name)
	{
		this.name = name;
	}
	

	public String getName()
	{
		return name;
	}
}

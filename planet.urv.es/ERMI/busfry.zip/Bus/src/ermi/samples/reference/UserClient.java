package ermi.samples.reference;


import java.io.*;
import java.util.*;
import ermi.registry.*;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class UserClient {

	public static void main(String[] args) throws Exception
	{
		Place thePlace = (Place)FileRegistry.loadERef("ior.properties");
		Vector users = thePlace.getUsers();
		Iterator it = users.iterator();
		while (it.hasNext())
		{
			User a = (User)it.next();
			System.out.println(a.getName());
			a.close();	
		}
		thePlace.close();
		
		
	}
}

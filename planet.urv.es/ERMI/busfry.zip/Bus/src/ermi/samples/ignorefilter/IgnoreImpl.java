package ermi.samples.ignorefilter;


import java.util.Properties;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class IgnoreImpl extends IgnoreStub 
{

	public IgnoreImpl(Properties env) throws ermi.RemoteException
	{
		super(env);
	}
	
	public void setEdad(java.lang.String p0)
	{
		// System.out.println("Ignoring setEdad");
		//super.setEdad(p0);
	}
	
	public java.lang.String getEdad()
	{
		// System.out.println("Ignoring GETEDAD ");
		return "NO";
	}
	
	public java.lang.String concat(java.lang.Integer p0,java.lang.String p1,java.lang.Integer p2)
	{
		// System.out.println("Ignoring CONCAT");
		return "NO!!!";
		
//		return super.concat(p0,p1,p2);
		
	}	
}

package ermi.samples.ignorefilter;

import ermi.registry.*;
import java.io.*;
import ermi.*;

/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class IgnoreServer {

	public static void main(String[] args) 
	{
		try
		{
			Naming.loadRegistry("registry.properties");
			IgnoreSkel server =(IgnoreSkel)FileRegistry.loadFilter("/simple","ermi.samples.ignorefilter.Ignore");
			DataInputStream dis = new DataInputStream(System.in);
			
			String input = "";
			while (!(input = dis.readLine()).equals("quit"))
			{
				System.out.println(input+" entrada");
				if (input.equals("exit"))
				{
					System.out.println(" OUT!!!");
					server.removeFilter();
					
				}
			}
			Naming.unloadRegistry();
		
		
		}catch (Exception e)
		{
			 e.printStackTrace();
		}	
	}
}

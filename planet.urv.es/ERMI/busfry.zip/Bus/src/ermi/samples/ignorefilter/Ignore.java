package ermi.samples.ignorefilter;

import ermi.samples.simple.Simple;
import ermi.EFilter;
/**
 * @author Administrador
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface Ignore extends Simple,EFilter
{

}

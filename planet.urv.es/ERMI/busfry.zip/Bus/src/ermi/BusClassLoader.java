/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */

package ermi;


import java.net.*;
import java.util.*;
import java.io.*;
import cbus.*;
import ermi.util.*;


/**
 * 
 *
 * The BusClassLoader is a custom class loader that makes a request to the remote object for the stub class
 * when this is not found in the local machine. The remote object then sends the stub class using the event service
 * and the bussclassloader loads it in the custom virtual machine enabling highly dynamic remote applications.<br>
 * The difference with java.RMI is that each object is then responsible for returning the stub class for remote clients.
 * See ERMI documentation for more information.
 * 
 * 
 */

public class BusClassLoader extends ClassLoader implements RemoteEventListener{

  String baseUrl;

  Hashtable cache = new Hashtable();
  Hashtable evt = new Hashtable();
  String subs;
  Session conn = null;
  byte data[];
  boolean resultArrived = false;
  boolean exception = false;
  Properties env;
	

  public BusClassLoader(Properties env) {

    super();
    
		this.env = env;   
		
		String uid = env.getProperty(Context.CLASS_ID);	
		
		String stubId = ermi.util.UID.getUID();
		subs = uid+":RESULTDYNAMIC:"+stubId;
    	evt.put("OBJECT",uid);
		evt.put("TYPE","DISPATCH");
		evt.put("METHOD","getBytes"); 
		evt.put("STUBID",stubId);
   

  }

	public void eventArrived(Hashtable evt)
		{
			//System.out.println("Byte event !!!");
			String type = (String)evt.get("TYPE");
			if (type.equals("EXCEPTION"))
			{
				exception = true;
			}else 
			{
				
				ByteWrapper bw = (ByteWrapper)evt.get("object");
				data = bw.getBytes();
				
			}
			resultArrived = true;
		}

	public void close()
	{
	/*	try
		{*/
			
			if (conn!=null)
			{
					Bus.close();
					conn = null;
			}
		/*}catch (SessionException ex)
   		 {
   			 	ex.printStackTrace();	
    	}*/
	}

  private byte [] loadClassData(String name) throws ClassNotFoundException {

    String urlName = baseUrl + (baseUrl.endsWith("/") ? "":"/") + name.replace('.','/') + ".class";


    try {

      URL url = new URL(urlName);

      URLConnection connexion = url.openConnection();

      

      connexion.connect();

      int len = connexion.getContentLength();

      if(len == -1)

	throw new ClassNotFoundException();

      byte[] result = new byte[len];

      InputStream input = connexion.getInputStream();

      

      int offset = 0;

      int nb;

      while((nb = input.read(result,offset,len)) != -1){

	offset+=nb;

	len-=nb;

      }

      input.close();

      return result;

    }

    catch(Exception e){

      throw new ClassNotFoundException();

    }

  }

	/**
	*	 Method that remote class load the specifed class
	* @param name Complete Class name
	* @param resolve Boolean Look up remotely.
	* @throws ClassNotFoundException Problem with the loaded Class. Nof found.
	*/

  public synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException {

    try{

      return findSystemClass(name);

    }

    catch(Exception e) {

	 
	 
	  
      Class c = (Class)cache.get(name);

      if (c == null) {
		System.out.println("REMOTE");
		try
    	{
    	 	conn= Bus.getBus(env);
    		conn.subscribe(this,subs);	
    		evt.put("subject",subs);	
    		conn.publish(evt);
    	}catch (SessionException ex)
   		 {
   			 	throw new ClassNotFoundException("Problems with the Event service ");	
    	}
    	catch (RemoteException ex2)
   		 {
   			 	throw new ClassNotFoundException("Problems with the Event service ");	
    	}
		//byte data[] = loadClassData(name);
		int  timeout = 0;
		while (!resultArrived&&timeout<10)
		{
			try{
				Thread.currentThread().sleep(50);
			}catch (InterruptedException ex){ex.printStackTrace();}
			timeout++;
		}
		if (exception)
		{
			exception = false;
			throw new ClassNotFoundException("Remote class is not available");
			
		}else if (timeout==10)
		{
			throw new ClassNotFoundException("Remote class is not available");
		}
		c = defineClass(data, 0, data.length);
	
		cache.put(name, c);

      }

      if (resolve)
		resolveClass(c);
	
      return c;

    }

  }

}

package ermi;


public interface IFilter 
{
	public String addFilter(String uid);
	public void removeFilter(String uid);
}

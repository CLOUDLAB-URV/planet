package ermi.registry;

import java.io.*;
import java.util.*;

public class RegistryServer {

	public static void main(String[] args) 
	{
		
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			ERegistryImpl server = new ERegistryImpl(env);
			server.writeERef("registry.properties");
			System.in.read();
						
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
		
		
	}
}

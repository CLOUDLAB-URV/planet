/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 *
 */

package ermi.registry;

import java.util.*;
import ermi.*;
/**
 *
 * For obtaining references to remote objects, ERMI provides a simple remote object
 *  registry interface, implemented by ERMI's rmiregistry, that provides methods 
 * for storing and retrieving remote object references. 
 * The ermi.Naming class provides methods to access a remote object registry. 
 */
public interface ERegistry extends ERemote
{
	 /**
	 *  Returns a reference, a stub, for the remote object associated with the specified name.
	 * @param ref Id of the remote object in the Registry
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @throws ermi.NotBoundException - if the Registry does not contains this Id.
 	 * @return ermi.Eremote Reference to the remote object
	  */
	
	 public Properties lookup(String name) throws RemoteException;
	
	 /**
	 *  Binds the specified name to a remote object.
	 * @param name Id of the remote object 
	 * @param ref remote object reference to bind
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 public void bind(String name, Properties ref) throws RemoteException;
	
	 /**
	 *  Unbinds the specified name from the registry.
	 * @param name Id of the remote object 
	 * @throws ermi.NotBoundException - if the Registry does not contains this Id.
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 public void unbind(String name) throws RemoteException;
	 
	   /**
	 *  Rebinds the specified name in the registry.
	 * @param name Id of the remote object 
 	 * @param ref remote object reference to bind
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
	  */
	 public void rebind(String name, Properties ref) throws RemoteException;
	 
	 
	 /**
	 *  Returns a Vector of the names bound in the registry. 
	 * The Vector contains a snapshot of the names present in the registry at the time of the call.
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return java.util.Vector  A list of Ids from remote objects. 
 	 */
	 
	 public Vector list() throws RemoteException;
}

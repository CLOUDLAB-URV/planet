package ermi.registry;

import java.util.*;
import ermi.*;




public class ERegistryImpl extends ERegistrySkel 
{
	
	private Hashtable directory = new Hashtable();

	
	public ERegistryImpl(Properties env) throws RemoteException{
		super(env);
	}

	 public Properties lookup(String name) throws RemoteException
	 {
	 	if (!directory.containsKey(name))
	 		throw new NotBoundException("Object Not Bound");
	 	return (Properties)directory.get(name);
	 }
	 
	 public void bind(String name, Properties ref)
	{
	
		directory.put(name,ref);
	}
	 public void unbind(String name) throws RemoteException
	 {
	 	if (!directory.containsKey(name))
	 		throw new NotBoundException("Object Not Bound");
	 	directory.remove(name);
	 }
	 
	 public void rebind(String name, Properties ref)
	 {
	 	directory.put(name,ref);
	 }
	 public Vector list()
	 {
	 	return  new Vector(directory.keySet());
	 	
	 	
	 }



}

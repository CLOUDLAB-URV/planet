/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */

package ermi.registry;


import java.io.*;
import java.util.*;
import ermi.*;
import ermi.util.*;
import java.lang.reflect.*;
/**
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class FileRegistry {

 	/**
	 *  Returns a reference, a stub, for the remote object associated with the specified file location.
	 * @param fileName Name of properties file containing object location
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return ermi.Eremote Reference to the remote object
	  */


	public static ERemote loadERef(String fileName) throws RemoteException
	{
		try
		{
			FileInputStream  fis = new FileInputStream(fileName);
			Properties env = new Properties();
			env.load(fis);
			String className = env.getProperty(Context.CLASS_NAME);
			
			BusClassLoader loader = new BusClassLoader(env);
			Class theClass = loader.loadClass(className);	
			loader.close();		
			
	//		Class theClass = Class.forName(className);
			Class params[] = new Class[1];
			params[0]= env.getClass();
 			Constructor theConstructor = theClass.getConstructor(params);
 			Object args[] = new Object[1];
 			args[0] = env;
 			ERemote ref = (ERemote)theConstructor.newInstance(args);
 			return ref;
						
		}catch (FileNotFoundException e)
		{
				 throw new RemoteException(e.getMessage());
		}catch (IOException e2)
		{
				 throw new RemoteException(e2.getMessage());
		}catch (ClassNotFoundException e3)
		{
				 throw new RemoteException(e3.getMessage());
		}catch (NoSuchMethodException e4)
		{
				 throw new RemoteException(e4.getMessage());
		}catch (InstantiationException e5)
		{
				 throw new RemoteException(e5.getMessage());
		}catch (IllegalAccessException e6)
		{
				 throw new RemoteException(e6.getMessage());
		}catch (InvocationTargetException e7)
		{
				 throw new RemoteException(e7.getMessage());
		}
		
	
	}
	
	/**
	 *  Returns a reference, a stub, for the remote object associated with the specified information in the properties Object.
	 * @param env Object properties containing object location
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return ermi.Eremote Reference to the remote object
	  */
	
	public static ERemote loadERef(Properties env) throws RemoteException
	{
		try
				{
				
					String className = env.getProperty(Context.CLASS_NAME);
					
					BusClassLoader loader = new BusClassLoader(env);
					Class theClass = loader.loadClass(className);			
					loader.close();
			//		Class theClass = Class.forName(className);
					
					Class params[] = new Class[1];
					params[0]= env.getClass();
					Constructor theConstructor = theClass.getConstructor(params);
					Object args[] = new Object[1];
					args[0] = env;
					ERemote ref = (ERemote)theConstructor.newInstance(args);
					return ref;
						
			}catch (ClassNotFoundException e3)
			{
					 throw new RemoteException(e3.getMessage());
			}catch (NoSuchMethodException e4)
			{
					 throw new RemoteException(e4.getMessage());
			}catch (InstantiationException e5)
			{
					 throw new RemoteException(e5.getMessage());
			}catch (IllegalAccessException e6)
			{
					 throw new RemoteException(e6.getMessage());
			}catch (InvocationTargetException e7)
			{
					 throw new RemoteException(e7.getMessage());
			}
		
		
	}
	
	/**
	 *  Returns a reference, a stub, for the remote object associated with the specified information in the properties Object. The stub is not initialized and this is not connected to the event bus. This method is internally used to pass remote
	 * objects by reference. 
	 * @param env Object properties containing object location
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return ermi.Eremote Reference to the remote object (stub not initialized)
	  */
	
	public static ERemote loadStub(Properties env) throws RemoteException
	{
		try
				{
				
					String className = env.getProperty(Context.CLASS_NAME);
					
					BusClassLoader loader = new BusClassLoader(env);
					Class theClass = loader.loadClass(className);	
					loader.close();		

			//		Class theClass = Class.forName(className);
					
					Class params[] = new Class[2];
					String b = "P";
					params[0]= env.getClass();
					params[1]= b.getClass();
					Constructor theConstructor = theClass.getConstructor(params);
					Object args[] = new Object[2];
					args[0] = env;				
					args[1] = b;
					ERemote ref = (ERemote)theConstructor.newInstance(args);
					return ref;
						
			}catch (ClassNotFoundException e3)
			{
					 throw new RemoteException(e3.getMessage());
			}catch (NoSuchMethodException e4)
			{
					 throw new RemoteException(e4.getMessage());
			}catch (InstantiationException e5)
			{
					 throw new RemoteException(e5.getMessage());
			}catch (IllegalAccessException e6)
			{
					 throw new RemoteException(e6.getMessage());
			}catch (InvocationTargetException e7)
			{
					 throw new RemoteException(e7.getMessage());
			}
		
		
	}
	
	
	/**
	 *  Returns a reference to a Filter that intercepts object calls to remote object called objId in the registry.
	 * @param env Object properties containing object location
	 * @param filterClass Name of the filter class
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return ermi.Eremote Reference to the remote object
	  */
	
	public static EFilter loadFilter(String objId,String filterClass) throws RemoteException
	{
		try
		{
		
			EFilter cl = (EFilter)Naming.lookup(objId);
			String uidf = UID.getUID();
		
			String uid =  cl.addFilter(uidf);
			cl.close();
			Properties env = cl.getERef();
			env.setProperty(Context.CLASS_ID,uid);		
			env.setProperty("UIDF",uidf);	
		
			BusClassLoader loader = new BusClassLoader(env);
			Class theClass = loader.loadClass(filterClass+"Skel");		
			loader.close();
			
				
			Class params[] = new Class[1];
			params[0]= env.getClass();
	 		Constructor theConstructor = theClass.getConstructor(params);
	 		Object args[] = new Object[1];
	 		args[0] = env;
	 		EFilter ref = (EFilter)theConstructor.newInstance(args);

	
	 		return ref;
		}catch (ClassNotFoundException ex1)
		 {
		 	 throw new RemoteException(ex1.getMessage());
		 }catch (NoSuchMethodException ex2)
		 {
		 	 throw new RemoteException(ex2.getMessage());
		 }catch (IllegalAccessException ex3)
		 {
		 	 throw new RemoteException(ex3.getMessage());
		 }catch (InstantiationException ex4)
		 {
		 	 throw new RemoteException(ex4.getMessage());
		 }catch (InvocationTargetException ex5)
		 {
		 	 throw new RemoteException(ex5.getMessage());
		 }	  
		
		
			
	}
	/**
	 *  Returns a reference to a Filter that intercepts object calls to remote object called objId in the registry.
	 * @param ref Object properties containing object location
	 * @param filterClass Name of the filter class
 	 * @throws ermi.RemoteException - if the connection with the event service fails.
 	 * @return ermi.Eremote Reference to the remote object
	  */
	
	public static EFilter loadFilter(Properties refp,String filterClass) throws RemoteException
	{
		try
		{
		
			EFilter cl = (EFilter)FileRegistry.loadERef(refp);
			String uidf = UID.getUID();
		
			String uid =  cl.addFilter(uidf);
			cl.close();
		
			Properties env = cl.getERef();
			env.setProperty(Context.CLASS_ID,uid);		
			env.setProperty("UIDF",uidf);	
		
			BusClassLoader loader = new BusClassLoader(env);
			Class theClass = loader.loadClass(filterClass+"Skel");	
			loader.close();		
			Class params[] = new Class[1];
			params[0]= env.getClass();
	 		Constructor theConstructor = theClass.getConstructor(params);
	 		Object args[] = new Object[1];
	 		args[0] = env;
	 		EFilter ref = (EFilter)theConstructor.newInstance(args);

	
	 		return ref;
		}catch (ClassNotFoundException ex1)
		 {
		 	 throw new RemoteException(ex1.getMessage());
		 }catch (NoSuchMethodException ex2)
		 {
		 	 throw new RemoteException(ex2.getMessage());
		 }catch (IllegalAccessException ex3)
		 {
		 	 throw new RemoteException(ex3.getMessage());
		 }catch (InstantiationException ex4)
		 {
		 	 throw new RemoteException(ex4.getMessage());
		 }catch (InvocationTargetException ex5)
		 {
		 	 throw new RemoteException(ex5.getMessage());
		 }	  
		
		
			
	}
}

package ermi.registry;

import ermi.*;
import cbus.SessionException;
import cbus.Session;
import cbus.RemoteEventListener;
import java.util.*;
import ermi.registry.FileRegistry;
import java.io.*;



public  class ERegistryStub extends EventServer implements RemoteEventListener,ERegistry,EFilter
{
private String  subs;
private Vector listeners = new Vector();
private boolean resultArrived = false;
private boolean exception = false;
private Object result;
private String method;
private String stubId;
private int timeout;
private int listener_cnt = 0;

public ERegistryStub(Properties env) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.registry.ERegistry";
	stubId = ermi.util.UID.getUID();
	subs = uid+":RESULT:"+stubId;
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public ERegistryStub(Properties env,String stub) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.registry.ERegistry";
	stubId = ermi.util.UID.getUID();
	subs = uid+":RESULT:"+stubId;
	conn = null;
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	String type;
	if (method.equals("list"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("lookup"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("bind"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("unbind"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("rebind"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("addFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("removeFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
}
public java.util.Vector list()
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","list");
	resultArrived = false;
	dispatchEvent(evt);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.util.Vector res = (java.util.Vector)result;
		return res;
	}
}
public java.util.Properties lookup(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","lookup");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.util.Properties res = (java.util.Properties)result;
		return res;
	}
}
public void bind(java.lang.String p0,java.util.Properties p1) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","bind");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	args.add(p1);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void unbind(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","unbind");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void rebind(java.lang.String p0,java.util.Properties p1) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","rebind");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	args.add(p1);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public java.lang.String addFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","addFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public void removeFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("subject",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","removeFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void removeFilter() throws RemoteException
{
}
public void close() throws ermi.RemoteException
{
	if (conn!=null){
		try{	conn.removeSubscription(this,subs);ermi.util.Bus.close();conn = null;	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.subscribe(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
private void writeObject(java.io.ObjectOutputStream out) throws IOException
{
	try{
		close();
	}catch (RemoteException e){throw new IOException("Problems with the Event Service");}
	out.defaultWriteObject();
}
private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException
{
	try{
		in.defaultReadObject ();
		init();
	}catch (RemoteException e){e.printStackTrace();}
}
public boolean equals(Object obj)
{
	ERemote ref = (ERemote)obj;
	return ref.getERef().equals(getERef());
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

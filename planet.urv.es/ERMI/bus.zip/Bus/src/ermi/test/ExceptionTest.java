package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.exception.*;
import ermi.registry.*;
import ermi.*;

/**
 * Some simple tests.
 *
 */
public class ExceptionTest extends TestCase {

	SimpleImpl server;
	ERegistryImpl registry;
	
	public ExceptionTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			registry = new ERegistryImpl(env);
			
		
			
				
			server = new SimpleImpl(env);
			Naming.loadRegistry("registry.properties");
			Naming.bind("/simple",server);
			
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
			Naming.unloadRegistry();
			registry.close();
			
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return new TestSuite(ExceptionTest.class);
	}
	
	
	public void testList() throws Exception
	{
	
		Simple simple = (Simple)Naming.lookup("/simple");
		
		try
		{
			String s = simple.concat(new Integer(1),"WW",new Integer(2));
			assertEquals(1,0);
		}catch (ConcatException ex)
		{
			assertEquals(1,1);
		}
		
		simple.close();
		
	
	}
	public void testNotBound() throws Exception
	{
		try
		{
			Simple client = (Simple)Naming.lookup("/no");
			assertEquals(1,0);
		}catch (NotBoundException ex)
		{
			assertEquals(1,1);
		}
		
		
	
	}
	
}
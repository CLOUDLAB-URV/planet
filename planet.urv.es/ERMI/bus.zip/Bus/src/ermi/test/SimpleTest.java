package ermi.test;


import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.simple.*;
import ermi.registry.*;
import ermi.RemoteException;

/**
 * Some simple tests.
 *
 */
public class SimpleTest extends TestCase {

	SimpleImpl server;
	
	public SimpleTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			server = new SimpleImpl(env);
			server.writeERef("ior.properties");
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		TestSuite t = new TestSuite(SimpleTest.class);
		t.addTestSuite(NamingTest.class);
		t.addTestSuite(BasicTypesTest.class);
		t.addTestSuite(FilterTest.class);
		t.addTestSuite(MobileTest.class);
		t.addTestSuite(ReferenceTest.class);
		t.addTestSuite(ExceptionTest.class);
		t.addTestSuite(ListenerTest.class);
		t.addTestSuite(DynamicTest.class);
		t.addTestSuite(RemoveFilterTest.class);
		t.addTestSuite(ReplicaTest.class);
		return t;
	}
	
	
	public void testClient() throws Exception
	{
	
		
		Simple client = (Simple)FileRegistry.loadERef("ior.properties");
		client.setEdad("30");
		String s = client.getEdad();
		assertEquals("30",s);
		client.close();
	
	}
	
	public void testTimeOut() 
	{
		try
		{
			server.close();
			Simple client = (Simple)FileRegistry.loadERef("ior.properties");
			client.setEdad("30");
			String s = client.getEdad();
			assertEquals("30","20");
			client.close();
			
		}catch(RemoteException ex)
		{
			assertEquals("30","30");
			try
			{
				server.init();
			}catch(RemoteException e)
			{
				e.printStackTrace();
			}
		}
	
	}
}
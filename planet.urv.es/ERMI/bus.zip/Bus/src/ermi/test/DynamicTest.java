package ermi.test;

import junit.framework.*;

import java.io.*;
import java.util.*;
import ermi.samples.dynamic.*;
import ermi.registry.*;
import ermi.RemoteException;

/**
 * Some simple tests.
 *
 */
public class DynamicTest extends TestCase {

	SimpleImpl server;
	
	public DynamicTest(String name) {
		super(name);
	}
	protected void setUp() 
	{
		try
		{
			FileInputStream  fis = new FileInputStream("env.properties");
			Properties env = new Properties();
			env.load(fis);
			server = new SimpleImpl(env);
			server.writeERef("ior.properties");
				
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	

	}

	protected void tearDown()
	{
		try
		{
			server.close();
		}catch (Exception e)
		{
			 e.printStackTrace();
		}
	}
	
	
	public static Test suite() 
	{

		
		return  new TestSuite(DynamicTest.class);
	}
	
	
	public void testClient() throws Exception
	{
	
		
		Simple client = (Simple)FileRegistry.loadERef("ior.properties");
		client.setEdad("30");
		String s = client.getEdad();
		assertEquals("30",s);
		client.close();
	
	}
	
	public void testTimeOut() 
	{
		try
		{
			server.close();
			Simple client = (Simple)FileRegistry.loadERef("ior.properties");
			client.setEdad("30");
			String s = client.getEdad();
			assertEquals("30","20");
			client.close();
			
		}catch(RemoteException ex)
		{
			assertEquals("30","30");
			try
			{
				server.init();
			}catch(RemoteException e)
			{
				e.printStackTrace();
			}
		}
	
	}
}

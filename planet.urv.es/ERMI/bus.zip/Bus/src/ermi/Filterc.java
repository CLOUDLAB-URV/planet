/**
 * Created on 07-jul-2003
 * @author Pedro Garc�a 
 */
package ermi;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;

/**
*
 */
public class Filterc 
{
	static Vector basicTypes = new Vector();
	static Vector wrappers = new Vector();
	
		public static void main(String[] args) throws Exception
		{
			String className = args[0];
			StringBuffer buf = new StringBuffer();
		
			basicTypes.add("int");
			basicTypes.add("char");
			basicTypes.add("double");
			basicTypes.add("float");	
			basicTypes.add("long");	
			basicTypes.add("boolean");	
		
			wrappers.add("Integer");
			wrappers.add("Character");
			wrappers.add("Double");
			wrappers.add("Float");	
			wrappers.add("Long");	
			wrappers.add("Boolean");	
		
			
		
		//	System.out.println(generateSkel(buf,className));
			String interfaceName = className;
			className = getInterface(className);	
			String cname = getClassName(className);
			String iname = getClassName(interfaceName);
			
			
			FileOutputStream fos = new FileOutputStream(iname+"Skel.java");
			PrintStream pos = new PrintStream(fos);
			pos.print(generateSkel(buf,interfaceName,className));
			pos.close();
					
		
			StringBuffer buf2 = new StringBuffer();
			
		//	System.out.println(generateStub(buf2,className));
			FileOutputStream fos2 = new FileOutputStream(iname+"Stub.java");
			PrintStream pos2 = new PrintStream(fos2);
			pos2.print(generateStub(buf2,interfaceName,className));
			pos2.close();
			
		}
	
		public static String getInterface(String className)
		{
			try
			{
				int found = -1;
				Class theClass = Class.forName(className);
				Class interfaces[] = theClass.getInterfaces();
				for (int i=0;i<interfaces.length;i++)
				{
					if (interfaces[i].getName().equals("ermi.EFilter")) 
						found =i;	
				}
				switch (found)
				{
					case -1:System.out.println("ERROR");System.exit(0); break;
					case 0: return interfaces[1].getName();
					case 1: return interfaces[0].getName();
				}
				
				
			}catch (ClassNotFoundException ex)
			{
				ex.printStackTrace();
			}	
			return "";
				
		}
	
		public static String getClassName(String className)
		{
			try
			{
				Class theClass = Class.forName(className);
				Package pac = theClass.getPackage();
			
				if (pac !=null)
				{
				
					int length1 = pac.getName().length();
					String cls = className.substring(length1+1,className.length());
					return cls;
				}else 
				{
					return className;
				}
			
						
			
			}catch (ClassNotFoundException ex)
			{
				ex.printStackTrace();
			}
			return null;
		}
	
		public static String getPackageName(String className)
		{
			try
			{
				Class theClass = Class.forName(className);
			
				Package pac = theClass.getPackage();
				if (pac !=null)
					return pac.getName();
				else return "NOPACKAGE";
			
			
			
			}catch (ClassNotFoundException ex)
			{
				ex.printStackTrace();
			}
			return null;
		}
	
		public static String generateSkel(StringBuffer output, String iname,String className)
		{
		
			String cls,pName;
			try
			{
				Class theClass = Class.forName(iname);
				Package pac = theClass.getPackage();
			
				if (pac !=null)
				{
				
					int length1 = pac.getName().length();
					cls = iname.substring(length1+1,iname.length());
					pName = pac.getName();
				
				}else 
				{
					cls = iname;
					pName = "NOPACKAGE";
				}
		
			skelHeader(output,cls,pName);
			setSkelConstructor(output,cls,iname);
			setSkelHandler(output,className);
			setSkelMethods(output,className);
			setSkelFilterMethods(output,className);
			setCloseMethod(output,className);
			output.append("}\n");
		
			}catch (ClassNotFoundException ex)
			{
				ex.printStackTrace();
			}
		
			return output.toString();
		
		
		}
	
		public static void skelHeader(StringBuffer output,String className, String tpackage)
		{
			if (!tpackage.equals("NOPACKAGE"))
				output.append("package "+tpackage+";\n\n");
		
			output.append("import ermi.*;\n");
			output.append("import ermi.registry.*;\n");
			output.append("import ants.comm.*;\n");
			output.append("import java.util.*;\n");
			
		
			output.append("\n\n\n");
			output.append("public  class "+className+"Skel extends EventServer implements RemoteEventListener,ermi.EFilter\n");
			output.append("{\n");
			output.append("String method;\n");
			output.append("String stubId;\n");
			output.append(className+" intercept;\n");
			output.append("Hashtable msg = new Hashtable();\n");
			output.append("Hashtable subs = new Hashtable();\n");
			output.append("\n");
		}
	
		public static void setSkelConstructor(StringBuffer output,String className,String cls)
		{
			output.append("public "+className+"Skel(Properties env) throws ermi.RemoteException\n");
			output.append("{\n");
			output.append("\tsuper(env);\n");
			output.append("\tuid = env.getProperty(ermi.Context.CLASS_ID);\n");
			output.append("\tsubs.put(\"OBJECT\",uid);\n");
			output.append("\tSystem.out.println(\"READY!\");\n");
			output.append("\tclassName = \""+cls+"\";\n");
			output.append("\ttry{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
			output.append("\tintercept = new "+className+"Impl(env);\n");
		
			output.append("}\n");
			
		}
		public static void setSkelHandler(StringBuffer output,String className)
			{
				boolean in = true;
				boolean out = true;
				try
				{
			
					output.append("public void eventArrived(java.util.Hashtable evt)\n");
					output.append("{\n");
					output.append("\tmethod = (String)evt.get(\"METHOD\");\n");
					output.append("\tstubId = (String)evt.get(\"STUBID\");\n");
			
					Class theClass = Class.forName(className);
					Method methods[] = theClass.getDeclaredMethods();
				
				
				
					Class params[],result;
					boolean isListener;
					for (int a=0;a<methods.length;a++)
					{
						isListener = true;
						params =methods[a].getParameterTypes();
						in = true;
						out = true;
			
						String methodName = methods[a].getName();
						isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
						if (!isListener)
						{
					
							if (a==0) 
								output.append("\tif (method.equals(\""+methodName+"\"))\n");
							else 
								output.append("\telse if (method.equals(\""+methodName+"\"))\n");
						
							output.append("\t{\n");		
							result = methods[a].getReturnType();
						
							if (result.getName().equals("void"))
								out = false;
						
							if (params.length==0)
								in = false;
						
							if (in==false&&out==false)
							{	
								output.append("\t\ttry {\n");
								output.append("\t\t\tintercept."+methods[a].getName()+"();");	
							
								setEvent1(output,methodName);
								output.append("\t\t}catch(RemoteException ex){\n");	
								setEvent11(output,methodName);
								output.append("\t\t}\n");
							
							}else if (in==false&&out==true)
							{
							
							    output.append("\t\ttry {\n");
								String type = result.getName();
								int found = find(type);
								if (found>=0)
								{
									String wrap = (String)wrappers.elementAt(found);
									output.append("\t\t\t"+result.getName()+" res2 = intercept."+methods[a].getName()+"();\n");
									output.append("\t\t\t"+wrap+" res = new "+wrap+"(res2);\n");
					
								}else 
								{
									output.append("\t\t\t"+result.getName()+" res = intercept."+methods[a].getName()+"();\n");
								}
							
							
							
								setEvent2(output,methodName);
								output.append("\t\t}catch(RemoteException ex){\n");	
								setEvent11(output,methodName);
								output.append("\t\t}\n");
											
							}else if (in==true&&out==false)
							{
									output.append("\t\ttry {\n");
									output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");	
									output.append("\t\t\tintercept."+methods[a].getName()+"(");
									int i;
									for (i=0;i<params.length-1;i++)
									{
									
										String type = params[i].getName();
										int found = find(type);
										if (found>=0)
										{
											String wrap = (String)wrappers.elementAt(found);
											output.append("(("+wrap+")args.elementAt("+i+"))."+type+"Value(),");
										}else 
										{
											output.append("("+params[i].getName()+")args.elementAt("+i+"),");
										}
									
										// if params[i].type in basictypes:
										// output.append("("+wrap+")args.elementAt("+i+")."+type+"Value(),");							
									
				
									
									}
									String type = params[i].getName();
									int found = find(type);
									if (found>=0)
									{
										String wrap = (String)wrappers.elementAt(found);
										output.append("(("+wrap+")args.elementAt("+i+"))."+type+"Value());");	
									}else 
									{
										output.append("("+params[i].getName()+")args.elementAt("+i+"));\n");
									}
									// if params[i].type in basictypes:
										// output.append("("+wrap+")args.elementAt("+i+")."+type+"Value());");		
								
								
									setEvent1(output,methodName);	
									output.append("\t\t}catch(RemoteException ex){\n");	
									setEvent11(output,methodName);
									output.append("\t\t}\n");
								
							}else if (in==true&&out==true)
							{
								
									output.append("\t\ttry {\n");
									output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");	
								
									// if result.type in basictypes:
									// output.append("\t\t"+result.type+" res2 = "+methods[a].getName()+"(");	
									String resulttype = result.getName();
									String wrap1="";
									int found1 = find(resulttype);
									if (found1>=0)
									{
										wrap1 = (String)wrappers.elementAt(found1);
										output.append("\t\t\t"+resulttype+" res2 = intercept."+methods[a].getName()+"(");
									}else 
									{
										output.append("	\t\t\t"+result.getName()+" res = intercept."+methods[a].getName()+"(");
									}
								
									
							
									int i;
									for (i=0;i<params.length-1;i++)
									{
										String type = result.getName();
										int found = find(type);
										if (found>=0)
										{
											String wrap = (String)wrappers.elementAt(found);
											output.append("("+wrap+")args.elementAt("+i+")."+type+"Value(),");
										}else 
										{
											output.append("("+params[i].getName()+")args.elementAt("+i+"),");
										}
									}
									String type = result.getName();
									int found = find(type);
									if (found>=0)
									{
										String wrap = (String)wrappers.elementAt(found);
										output.append("("+wrap+")args.elementAt("+i+")."+type+"Value());");	
									}else 
									{
										output.append("("+params[i].getName()+")args.elementAt("+i+"));\n");
									}
									if (found1>=0)
										output.append("\t\t\t"+wrap1+" res = res2."+resulttype+"Value();\n");
									
									setEvent2(output,methodName);
									output.append("\t\t}catch(RemoteException ex){\n");	
									setEvent11(output,methodName);
									output.append("\t\t}\n");
							}
							output.append("\t}\n");
						}
					}
				//	setByteHandler(output);
					setFilterHandler(output);
					output.append("}\n");
				}catch (ClassNotFoundException ex)	
				{
					ex.printStackTrace();
				}
			
			}
	
			public static void setFilterHandler(StringBuffer output)
			{
				//addFilter
			
				output.append("\telse if (method.equals(\"addFilter\"))\n");
				output.append("\t{\n");
				output.append("\t\ttry {\n");
				
				output.append("\t\t\tVector args = (Vector)evt.get(\"object\");\n");
				output.append("\t\t\tString res = intercept.addFilter((String)args.elementAt(0));\n");
			
				output.append("\t\t\tHashtable msg = new Hashtable();\n");
				output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT:\"+stubId);\n");
				output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
				output.append("\t\t\tmsg.put(\"METHOD\",\"addFilter\");\n");
				output.append("\t\t\ttry{\n");	
				output.append("\t\t\t\tdispatchEvent(msg,res);\n");	
				output.append("\t\t\t}catch(RemoteException e){e.printStackTrace();}\n");
				output.append("\t\t}catch(RemoteException ex){\n");	
				setEvent11(output,"addFilter");
				output.append("\t\t}\n");
						
			
			
			
				output.append("\t}\n");
			
//				removeFilter
			
			 output.append("\telse if (method.equals(\"removeFilter\"))\n");
			 output.append("\t{\n");
			
			 output.append("\t\tRemoteException ex=null; \n");
			 output.append("\t\tVector args = (Vector)evt.get(\"object\");\n");
			 output.append("\t\tString uidf = (String)args.elementAt(0);\n");
			 output.append("\t\ttry{	conn.removeRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			 output.append("\t\tString res = uid;\n");
			 output.append("\t\tuid = uidf;\n");
			 output.append("\t\tsubs.put(\"OBJECT\",uid);\n");
			 output.append("\t\ttry{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}\n");
			
			
			output.append("\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\tmsg.put(\"OBJ\",res+\":RESULT:\"+stubId);\n");
			output.append("\t\tmsg.put(\"METHOD\",\"removeFilter\");\n");
			
			output.append("\t\tif (ex!=null){\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}else{\n");
			
			output.append("\t\t\tmsg.put(\"TYPE\",\"DYSPATCH\");\n");
			output.append("\t\t\tmsg.put(\"RESULT\",\"VOID\");\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");
			output.append("\t\t}\n");		
			output.append("\t}\n");	
			 
			 
		}	
		public static void setByteHandler(StringBuffer output)
			{
			
				output.append("\telse if (method.equals(\"getBytes\"))\n");
				output.append("\t{\n");
			
				output.append("\t\t try \n");
				output.append("\t\t{\n");
			
				output.append("\t\t\tString aClass = Rmic.getClassName(className);\n");
				output.append("\t\t\tString fileClass = class_store+aClass+\"Stub.class\";\n");
				output.append("\t\t\tbyte data[] = getBytes(fileClass);\n");
			
				output.append("\t\t\tmsg.clear();\n");
				output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT\");\n");
				output.append("\t\t\tmsg.put(\"TYPE\",\"DYNAMIC\");\n");
				output.append("\t\t\tmsg.put(\"METHOD\",\"getBytes\");\n");
			
				output.append("\t\t\tdispatchEvent(msg,data);\n");	
				output.append("\t\t }catch (java.io.IOException ex1) {ex1.printStackTrace();} \n");
			
				output.append("\t}\n");
			
			
			}	
		
			public static void setEvent1(StringBuffer output,String methodName)
			{
				output.append("\t\t\tHashtable msg = new Hashtable();\n");
				output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT:\"+stubId);\n");
				output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
				output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
				output.append("\t\t\tmsg.put(\"RESULT\",\"VOID\");\n");
				output.append("\t\t\ttry{\n");	
				output.append("\t\t\t\tdispatchEvent(msg);\n");	
				output.append("\t\t\t}catch(RemoteException e){e.printStackTrace();}\n");
			}
		
			public static void setEvent2(StringBuffer output, String methodName)
			{
					output.append("\t\t\tHashtable msg = new Hashtable();\n");
					output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT:\"+stubId);\n");
					output.append("\t\t\tmsg.put(\"TYPE\",\"DISPATCH\");\n");
					output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
					
					output.append("\t\t\ttry{\n");	
					output.append("\t\t\t\tdispatchEvent(msg,res);\n");	
					output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");	
			}
		
		public static void setEvent11(StringBuffer output,String methodName)
		{
			output.append("\t\t\tHashtable msg = new Hashtable();\n");
			output.append("\t\t\tmsg.put(\"OBJ\",uid+\":RESULT:\"+stubId);\n");
			output.append("\t\t\tmsg.put(\"TYPE\",\"EXCEPTION\");\n");
			output.append("\t\t\tmsg.put(\"METHOD\",\""+methodName+"\");\n");
		//	output.append("\t\t\tmsg.put(\"RESULT\",ex);\n");
			output.append("\t\t\ttry{\n");	
			output.append("\t\t\t\tdispatchEvent(msg,ex);\n");	
			output.append("\t\t\t}catch(RemoteException e2){e2.printStackTrace();}\n");	
		}
		public static void setSkelMethods(StringBuffer output,String className)
			{
				String name;
				try
				{
			
							
					Class theClass = Class.forName(className);
					Method methods[] = theClass.getDeclaredMethods();
					Class params[],result;	
				
					for (int i=0;i<methods.length;i++)
					{
						name = methods[i].getName();
						if (name.startsWith("add")&&name.endsWith("Listener"))
						{
							Class arg[] =methods[i].getParameterTypes();
							Method mListeners[]  =arg[0].getMethods();
							Class paramsListener[] = mListeners[0].getParameterTypes();
							String event1 = 	paramsListener[0].getName();				
							String event;
							Package pac = theClass.getPackage();
							if (pac !=null)
							{
									 int ll = pac.getName().length();
						
								 event = event1.substring(ll+1);
							} 
							else 
							{
									event = event1;  
							}
							output.append("public void trigger"+event+"("+event+" res)\n");
							output.append("{\n");
							setEvent2(output,event);
						
							output.append("}\n");					
						
						
						}	
							
					
					}
				
				
				
				}catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		
	public static void setSkelFilterMethods(StringBuffer output,String className)
		{
		
			output.append("public String addFilter(String uid) throws RemoteException\n");
			output.append("{\n");
			output.append("\treturn intercept.addFilter(uid);\n");
			output.append("}\n");					
						
			output.append("public void removeFilter(String uidf) throws RemoteException\n");
			output.append("{\n");
			output.append("\tintercept.removeFilter(uidf);\n");
			output.append("}\n");					
			
			output.append("public void removeFilter() throws RemoteException\n");
			output.append("{\n");
			output.append("\tintercept.removeFilter(uid);\n");
			output.append("\tclose();\n");
			output.append("}\n");		
						
		}	
							
					
					
		
		public static String generateStub(StringBuffer output, String iname,String className)
		{
		
			String cls,pName;
			try
			{
				Class theClass = Class.forName(iname);
				Package pac = theClass.getPackage();
			
				if (pac !=null)
				{
				
					int length1 = pac.getName().length();
					cls = iname.substring(length1+1,iname.length());
					pName = pac.getName();
				
				}else 
				{
					cls = iname;
					pName = "NOPACKAGE";
				}
		
			stubHeader(output,cls,pName);
			setStubConstructor(output,cls,iname);
			setStubHandler(output,className);
			setStubMethods(output,className);
			setStubMethods(output,"ermi.IFilter");
			setStubFilterMethod(output,className);
			setStubCloseMethod(output,className);
			output.append("}\n");
		
			}catch (ClassNotFoundException ex)
			{
				ex.printStackTrace();
			}
		
			return output.toString();
		
		
		}
	
		public static void stubHeader(StringBuffer output,String className, String tpackage)
		{
			if (!tpackage.equals("NOPACKAGE"))
				output.append("package "+tpackage+";\n\n");
		
			output.append("import ermi.*;\n");
			output.append("import ermi.registry.*;\n");
			output.append("import ants.comm.SessionException;\n");
			output.append("import ants.comm.Session;\n");
			output.append("import ants.comm.RemoteEventListener;\n");
			output.append("import java.util.*;\n");
			output.append("\n\n\n");
			output.append("public  class "+className+"Stub extends EventServer implements RemoteEventListener,"+className+"\n");
			output.append("{\n");
			output.append("private Hashtable evt = new Hashtable();\n");
			output.append("private Hashtable subs = new Hashtable();\n");
			output.append("private Vector args = new Vector();\n");
			output.append("private Vector listeners = new Vector();\n");
			output.append("private boolean resultArrived = false;\n");
			output.append("private boolean exception = false;\n");
			output.append("private Object result;\n");
			output.append("private String method;\n");
			output.append("private String stubId;\n");
			output.append("private int timeout;\n");
			output.append("\n");
		}
	
		public static void setStubConstructor(StringBuffer output,String className, String cls)
		{
			output.append("public "+className+"Stub(Properties env) throws ermi.RemoteException\n");
			output.append("{\n");		
			output.append("\tsuper(env);\n");
			output.append("\tString muid = env.getProperty(\"UIDF\");\n");
			output.append("\tuid = muid;\n");
			output.append("\tclassName = \""+cls+"\";\n");
			output.append("\tstubId = ermi.util.UID.getUID();\n");
			output.append("\tsubs.put(\"OBJ\",uid+\":RESULT:\"+stubId);\n");
			output.append("\ttry{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
		
			output.append("}\n");
			
		}
		
		
		
		
	public static void setStubHandler(StringBuffer output,String className)
		{
			boolean in = true;
			boolean out = true;
			try
			{
			
				output.append("public void eventArrived(java.util.Hashtable evt)\n");
				output.append("{\n");
				output.append("\tmethod = (String)evt.get(\"METHOD\");\n");
				output.append("\tString type;\n");
			
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				
				
				
				Class params[],result;
				boolean isListener;
				for (int a=0;a<methods.length;a++)
				{
					isListener = true;
					params =methods[a].getParameterTypes();
					in = true;
					out = true;
			
					String methodName = methods[a].getName();
					isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
					
					if (!isListener)
					{
			
			
						if (a==0) 
							output.append("\tif (method.equals(\""+methodName+"\"))\n");
						else 
							output.append("\telse if (method.equals(\""+methodName+"\"))\n");
						
						output.append("\t{\n");		
						result = methods[a].getReturnType();
						
						if (result.getName().equals("void"))
							out = false;
						
						
						
						if (out==false)
						{	
							output.append("\t\tresult = evt.get(\"object\");\n");
							output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
							output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
							output.append("\t\t\texception = true;\n");
							output.append("\t\tresultArrived = true;\n");	
							
							
							
						}else 
						{
							output.append("\t\tresult = evt.get(\"object\");\n");
							output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
							output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
							output.append("\t\t\texception = true;\n");
							output.append("\t\tresultArrived = true;\n");	
							
											
						}
						output.append("\t}\n");	
					}else
					{
						if (methodName.startsWith("add"))
							
							{
								parseOnEvent(output,methods[a],a);
								output.append("\t}\n");		
							}
					}
					
					
				}
			
				output.append("\telse if (method.equals(\"addFilter\"))\n");
				output.append("\t{\n");	
				output.append("\t\tresult = evt.get(\"object\");\n");
				output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
				output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
				output.append("\t\t\texception = true;\n");
				output.append("\t\tresultArrived = true;\n");	
				output.append("\t}\n");	
				
				output.append("\telse if (method.equals(\"removeFilter\"))\n");
				output.append("\t{\n");	
				output.append("\t\tresult = evt.get(\"object\");\n");
				output.append("\t\ttype = (String)evt.get(\"TYPE\");\n");
				output.append("\t\tif (type.equals(\"EXCEPTION\"))\n");
				output.append("\t\t\texception = true;\n");
				output.append("\t\tresultArrived = true;\n");	
				output.append("\t}\n");	
				
					
				
				output.append("}\n");
			}catch (ClassNotFoundException ex)	
			{
				ex.printStackTrace();
			}
			
		}	
		
			public static void parseOnEvent(StringBuffer output,Method aMethod, int numMethod)
			{
				Class arg[] =aMethod.getParameterTypes();
				Method mListeners[]  =arg[0].getMethods();
				Class paramsListener[] = mListeners[0].getParameterTypes();
				
			
				String event1 = 	paramsListener[0].getName();				
				String event;
				Package pac = paramsListener[0].getPackage();
				if (pac !=null)
				{
					int ll = pac.getName().length();
					event = event1.substring(ll+1);
				}
				else 
				{
					event = event1;  
				}
			
			
			
			
			
			
			
			
				String methodName = aMethod.getName();
				String listener = methodName.substring(3,methodName.length());
			
				if (numMethod==0) 
						output.append("\tif (method.equals(\""+event+"\"))\n");
			
				else 
					output.append("\telse if (method.equals(\""+event+"\"))\n");
			
				output.append("\t{\n");		
			
				output.append("\t\t"+event+" result = ("+event+")evt.get(\"object\");\n");
				output.append("\t\tVector clisteners = (Vector)listeners.clone();\n");
				output.append("\t\tIterator it = clisteners.iterator();\n");	
				output.append("\t\twhile (it.hasNext())\n");
				output.append("\t\t{\n");
				output.append("\t\t\t"+listener+" aListener = ("+listener+")it.next();\n");
				output.append("\t\t\taListener."+mListeners[0].getName()+"(result);\n");
				output.append("\t\t}\n");
			
			}
		
		
			public static void setStubMethods(StringBuffer output,String className)
		{
			boolean in = true;
			boolean out = true;
			try
			{
			
							
				Class theClass = Class.forName(className);
				Method methods[] = theClass.getDeclaredMethods();
				Class params[],result;
				
				
				for (int a=0;a<methods.length;a++)
				{
					params =methods[a].getParameterTypes();
					in = true;
					out = true;
			
					String methodName = methods[a].getName();
					boolean isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
		
			
						
					output.append("public "+methods[a].getReturnType().getName()+ " "+methodName+"(");
					int j = 0;
					if (params.length==0)
					{
						output.append(")\n");
						if (!isListener)
							output.append(" throws RemoteException\n");
						
						
					} else if (params.length==1)
					{
						output.append(params[0].getName()+" p0) \n");
						if (!isListener)
							output.append(" throws RemoteException\n");
					}else 
					{
						for (j=0;j<params.length-1;j++)
						{
							output.append(params[j].getName()+" p"+j+",");
						}
						output.append(params[j].getName()+" p"+j+") \n");
						if (!isListener)
							output.append(" throws RemoteException\n");
					}
					
					parseMethod(output,methods[a]);
				
				
						
				}
				
				
			
			
			
		
			}catch (ClassNotFoundException ex)	
			{
				ex.printStackTrace();
			}
			
		}
		
		
	public static void parseMethod(StringBuffer output,Method aMethod)
	{
		Class result = aMethod.getReturnType();
		Class params[] =aMethod.getParameterTypes();			
		boolean in = true;
		boolean out = true;
		
		String methodName = aMethod.getName();
		boolean isListener = (methodName.startsWith("add")||methodName.startsWith("remove"))&&methodName.endsWith("Listener");
		
		if (!isListener)
		{
		
					
			if (result.getName().equals("void"))
				out = false;
			if (params.length==0)
				in = false;
						
			output.append("{\n");
			output.append("\tHashtable evt = new Hashtable();\n");
			output.append("\tevt.put(\"OBJECT\",uid);\n");
			output.append("\tevt.put(\"STUBID\",stubId);\n");
			output.append("\tevt.put(\"TYPE\",\"DISPATCH\");\n");
			output.append("\tevt.put(\"METHOD\",\""+aMethod.getName()+"\");\n");
			output.append("\tresultArrived = false;\n");
			
			
			if (in ==false)
			{
				output.append("\tdispatchEvent(evt);\n");
			} else 
			{
				output.append("\targs.clear();\n");
				
				
				
				for (int y=0;y<params.length;y++)
				{
					
					String type = params[y].getName();
					int found = find(type);
					if (found>=0)
					{
						String wrap = (String)wrappers.elementAt(found);
						output.append("\targs.add(new "+wrap+"(p"+y+"));\n");	
						
					}else 
					{
						output.append("\targs.add(p"+y+");\n");
					}
					
						
					
					// if type = params[y].getClass().getName() is in (int,char,boolean,double,float,long)
					// wrap = type.toUpper(char0);
			     	// output.append("\targs.add(new "+wrap+"(p"+y+"));\n");
				
				}
				output.append("\tdispatchEvent(evt,args);\n");
				
				
			}		
				
				output.append("\ttimeout=0;");
				output.append("\twhile (!resultArrived&&timeout<Context.TIMEOUT)\n");
				output.append("\t{\n");
				output.append("\t\ttry{\n");
				output.append("\t\t\tThread.currentThread().sleep(Context.DELAY);\n");
				output.append("\t\t}catch (InterruptedException ex){ex.printStackTrace();}\n");
				output.append("\t\ttimeout++;\n");
				output.append("\t}\n");
				
				output.append("\tif (exception){\n");
				output.append("\t\texception = false;\n");
				output.append("\t\tRemoteException ex = (RemoteException)result;\n");
				output.append("\t\tthrow ex;\n");
				output.append("\t} else if (timeout==Context.TIMEOUT){\n");
				output.append("\t\tthrow new TimeoutException(\"Server is not alive\");\n");
				output.append("\t} ");
				
			if (out == true) 	
			{
				output.append("\telse \n {");
				String type = result.getName();
				int found = find(type);
			
				if (found>=0)
				{
					String wrap = (String)wrappers.elementAt(found);
					output.append("\t\t"+wrap+" res = ("+wrap+")result;\n");	
					output.append("\t\treturn res."+type+"Value();\n");	
					
				}else 
				{
					output.append("\t\t"+result.getName()+" res = ("+result.getName()+")result;\n");	
					output.append("\t\treturn res;\n");
				}
					output.append("\t}\n");
			}	
				// if result.type in (basictypes):
				// wrap = ...
				//	output.append("\t"+wrap+" res = ("+wrap+")result;\n");	
			//	output.append("\treturn res+"."+type+"Value();\n");
					
				
		
		}else 
		{
			output.append("{\n");
			if (methodName.startsWith("add"))
			{
				output.append("\tlisteners.add(p0);\n");
			}else
			{
				output.append("\tlisteners.remove(p0);\n");
			}
			
		}
		
		output.append("}\n");
		
	
		
	}

	public static void setStubFilterMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void removeFilter()\n");
				output.append("{\n");
				output.append("}\n");		
						
			}	

		public static int  find(String type)
		{
			int found = -1000;
			int i =0;
			int length = basicTypes.size();
	
			while (found<0&&i<length)
			{
				String elem = (String)basicTypes.elementAt(i);
			
				if (elem.equals(type))
					found = i;
				else 
					i++;
			
			}
			return found;
		
		}	
	public static void setCloseMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void close() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\ttry{	conn.removeRemoteEventListener(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("\tintercept.close();\n");
				output.append("}\n");		
				
				
				output.append("public void init() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\tconn = ermi.util.Bus.getBus(eref);\n");
				output.append("\ttry{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				
				output.append("public ERemote copy() throws RemoteException\n");
				output.append("{\n");
				output.append("\tERemote ref = FileRegistry.loadStub(getERef());\n");
				output.append("\treturn (ERemote)ref;\n");
				output.append("}\n");	
				
						
			}		
			
	public static void setStubCloseMethod(StringBuffer output,String className)
			{
				
			
				output.append("public void close() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\ttry{	conn.removeRemoteEventListener(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				
				output.append("public void init() throws ermi.RemoteException\n");
				output.append("{\n");
				output.append("\tconn = ermi.util.Bus.getBus(eref);\n");
				output.append("\ttry{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}\n");
				output.append("}\n");		
				
				
				output.append("public ERemote copy() throws RemoteException\n");
				output.append("{\n");
				output.append("\tERemote ref = FileRegistry.loadStub(getERef());\n");
				output.append("\treturn (ERemote)ref;\n");
				output.append("}\n");	
				
						
			}				
			

}

package ermi.samples.exception;

import ermi.*;
import ants.comm.SessionException;
import ants.comm.Session;
import ants.comm.RemoteEventListener;
import java.util.*;
import ermi.registry.FileRegistry;
import java.io.*;



public  class SimpleStub extends EventServer implements RemoteEventListener,Simple,EFilter
{
private Hashtable subs = new Hashtable();
private Vector listeners = new Vector();
private boolean resultArrived = false;
private boolean exception = false;
private Object result;
private String method;
private String stubId;
private int timeout;
private int listener_cnt = 0;

public SimpleStub(Properties env) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.samples.exception.Simple";
	stubId = ermi.util.UID.getUID();
	subs.put("OBJ",uid+":RESULT:"+stubId);
	try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public SimpleStub(Properties env,String stub) throws ermi.RemoteException
{
	super(env);
	String muid = env.getProperty(Context.CLASS_ID);
	uid = muid;
	className = "ermi.samples.exception.Simple";
	stubId = ermi.util.UID.getUID();
	subs.put("OBJ",uid+":RESULT:"+stubId);
	conn = null;
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	String type;
	if (method.equals("concat"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("setEdad"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("getEdad"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("addFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
	else if (method.equals("removeFilter"))
	{
		result = evt.get("object");
		type = (String)evt.get("TYPE");
		if (type.equals("EXCEPTION"))
			exception = true;
		resultArrived = true;
	}
}
public java.lang.String concat(java.lang.Integer p0,java.lang.String p1,java.lang.Integer p2) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("OBJECT",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","concat");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	args.add(p1);
	args.add(p2);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public void setEdad(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("OBJECT",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","setEdad");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public java.lang.String getEdad()
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("OBJECT",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","getEdad");
	resultArrived = false;
	dispatchEvent(evt);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public java.lang.String addFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("OBJECT",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","addFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} 	else 
 {		java.lang.String res = (java.lang.String)result;
		return res;
	}
}
public void removeFilter(java.lang.String p0) 
 throws RemoteException
{
	Hashtable evt = new Hashtable();
	evt.put("OBJECT",uid);
	evt.put("TYPE","DISPATCH");
	evt.put("STUBID",stubId);
	evt.put("METHOD","removeFilter");
	resultArrived = false;
	Vector args = new Vector();
	args.add(p0);
	dispatchEvent(evt,args);
	timeout=0;	while (!resultArrived&&timeout<Context.TIMEOUT)
	{
		try{
			Thread.currentThread().sleep(Context.DELAY);
		}catch (InterruptedException ex){ex.printStackTrace();}
		timeout++;
	}
	if (exception){
		exception = false;
		RemoteException ex = (RemoteException)result;
		throw ex;
	} else if (timeout==Context.TIMEOUT){
		throw new TimeoutException("Server is not alive");
	} }
public void removeFilter() throws RemoteException
{
}
public void close() throws ermi.RemoteException
{
	if (conn!=null){
		try{	conn.removeRemoteEventListener(this,subs);ermi.util.Bus.close();conn = null;	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
	}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
private void writeObject(java.io.ObjectOutputStream out) throws IOException
{
	try{
		close();
	}catch (RemoteException e){throw new IOException("Problems with the Event Service");}
	out.defaultWriteObject();
}
private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException
{
	try{
		in.defaultReadObject ();
		init();
	}catch (RemoteException e){e.printStackTrace();}
}
public boolean equals(Object obj)
{
	ERemote ref = (ERemote)obj;
	return ref.getERef().equals(getERef());
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}

package ermi.samples.mobile;

import ants.comm.*;
import java.util.*;
import ermi.*;
import ermi.registry.FileRegistry;



public abstract class TeleportSkel extends EventServer implements RemoteEventListener,Teleport
{
String method;
String stubId;
Hashtable msg = new Hashtable();
Hashtable subs = new Hashtable();

public TeleportSkel(Properties env) throws ermi.RemoteException
{
	super(env);
	uid = ermi.util.UID.getUID();
	subs.put("OBJECT",uid);
	className = "ermi.samples.mobile.Teleport";
	try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void eventArrived(java.util.Hashtable evt)
{
	method = (String)evt.get("METHOD");
	stubId = (String)evt.get("STUBID");
	if (method.equals("send"))
	{
		try {
			Vector args = (Vector)evt.get("object");
			send((java.lang.Object)args.elementAt(0));
			Hashtable msg = new Hashtable();
			msg.put("OBJ",uid+":RESULT:"+stubId);
			msg.put("TYPE","DISPATCH");
			msg.put("METHOD","send");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e){e.printStackTrace();}
		}catch(RemoteException ex){
			Hashtable msg = new Hashtable();
			msg.put("OBJ",uid+":RESULT:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","send");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("getBytes"))
	{
		 try 
		{
			String aClass = Rmic.getClassName(className);
			String fileClass = class_store+aClass+"Stub.class";
			byte data[] = getBytes(fileClass);
		Hashtable msg = new Hashtable();
			msg.put("OBJ",uid+":RESULTDYNAMIC:"+stubId);
			msg.put("TYPE","DYSPATCH");
			msg.put("METHOD","getBytes");
			dispatchEvent(msg,data);
		 }catch (java.io.IOException ex1) { 
		Hashtable msg = new Hashtable();
			msg.put("OBJ",uid+":RESULTDYNAMIC:"+stubId);
			msg.put("TYPE","EXCEPTION");
			msg.put("METHOD","getBytes");
			try{
				dispatchEvent(msg,ex1);
			}catch(RemoteException e2){e2.printStackTrace();}
		 } catch (RemoteException ex2) {ex2.printStackTrace();} 
	}
	else if (method.equals("addFilter"))
	{
		RemoteException ex=null; 
		Vector args = (Vector)evt.get("object");
		String uidf = (String)args.elementAt(0);
		try{	conn.removeRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		String res = uid;
		uid = uidf;
		subs.put("OBJECT",uid);
		try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		Hashtable msg = new Hashtable();
		msg.put("OBJ",res+":RESULT:"+stubId);
		msg.put("METHOD","addFilter");
		if (ex!=null){
			msg.put("TYPE","EXCEPTION");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}else{
			msg.put("TYPE","DYSPATCH");
			try{
				dispatchEvent(msg,res);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
	else if (method.equals("removeFilter"))
	{
		RemoteException ex=null; 
		Vector args = (Vector)evt.get("object");
		String uidf = (String)args.elementAt(0);
		try{	conn.removeRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		String res = uid;
		uid = uidf;
		subs.put("OBJECT",uid);
		try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){ex = new ConnectionException(e.getMessage());}
		Hashtable msg = new Hashtable();
		msg.put("OBJ",res+":RESULT:"+stubId);
		msg.put("METHOD","removeFilter");
		if (ex!=null){
			msg.put("TYPE","EXCEPTION");
			try{
				dispatchEvent(msg,ex);
			}catch(RemoteException e2){e2.printStackTrace();}
		}else{
			msg.put("TYPE","DYSPATCH");
			msg.put("RESULT","VOID");
			try{
				dispatchEvent(msg);
			}catch(RemoteException e2){e2.printStackTrace();}
		}
	}
}
public void close() throws ermi.RemoteException
{
	try{	conn.removeRemoteEventListener(this,subs);ermi.util.Bus.close();	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public void init() throws ermi.RemoteException
{
	conn = ermi.util.Bus.getBus(eref);
	try{	conn.addRemoteEventListener(this,subs);	}catch (SessionException e){throw new ConnectionException(e.getMessage());}
}
public ERemote copy() throws RemoteException
{
	ERemote ref = FileRegistry.loadStub(getERef());
	return (ERemote)ref;
}
}
